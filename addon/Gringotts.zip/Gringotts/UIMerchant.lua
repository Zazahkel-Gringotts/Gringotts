-- Gringotts : fenêtre marchand. Remplace celle de Blizzard : à gauche tes sacs (vendre d'un clic), à droite les articles du marchand (acheter).
local ADDON, ns = ...
local W = ns.W
local C = W.C
local Pl = ns.plus
local M = {}
ns.merchantUI = M

local function coins(c) return c and ns.api.coins(c) or W.col(C.grey, "—") end
local function db() return ns.api and ns.api.db and ns.api.db() or nil end
local function say(m) print("|cffe4b84eGringotts|r " .. m) end

local frame, P
local blizzHidden = false
local closing = false
local KIND = { junk = { "gris", "grey" }, pnj = { "marchand", "orange" }, hv = { "à l'HV", "green" }, keep = { "garder", "grey" } }

local function replaceOn() local d = db(); return not (d and d.set and d.set.merchantReplace == false) end

local function applyBlizzard()
  if not MerchantFrame then return end
  if blizzHidden then
    MerchantFrame:SetAlpha(0); MerchantFrame:EnableMouse(false)
    if MerchantFrame.SetFrameStrata then MerchantFrame.gringStrata = MerchantFrame.gringStrata or MerchantFrame:GetFrameStrata(); MerchantFrame:SetFrameStrata("BACKGROUND") end
  else
    MerchantFrame:SetAlpha(1); MerchantFrame:EnableMouse(true)
    if MerchantFrame.gringStrata then MerchantFrame:SetFrameStrata(MerchantFrame.gringStrata) end
  end
end

------------------------------------------------------------------------
-- Articles du marchand
------------------------------------------------------------------------
local function merchantItems()
  local out = {}
  local n = GetMerchantNumItems and GetMerchantNumItems() or 0
  for i = 1, n do
    local name, tex, price, qty, avail, usable, ext = GetMerchantItemInfo(i)
    if name then
      local link = GetMerchantItemLink and GetMerchantItemLink(i)
      local id = link and tonumber(link:match("item:(%d+)"))
      local stack = (GetMerchantItemMaxStack and GetMerchantItemMaxStack(i)) or 1
      out[#out + 1] = { idx = i, name = name, id = id, price = price or 0, qty = qty or 1, avail = avail or -1, usable = usable, ext = ext and true or false, stack = stack, link = link }
    end
  end
  return out
end

local function repairInfo()
  if not (CanMerchantRepair and CanMerchantRepair()) then return nil end
  local cost, can = GetRepairAllCost()
  return cost or 0, can
end

local function selected() return P.items and P.sel and P.items[P.sel] end

local function buyQty()
  return math.max(1, math.floor(tonumber(P.qty:GetText()) or 1))
end

local function refreshBuyBar()
  local e = selected()
  if not e then P.sBar:SetText(W.col(C.grey, "Clique un article pour l'acheter.")); P.buy:Disable(); return end
  local q = buyQty()
  local units = e.qty > 0 and e.qty or 1
  local total = e.price * math.ceil(q / units)
  P.sBar:SetText(("%s  ·  %s"):format(e.name, e.ext and W.col(C.orange, "coût spécial (jetons, honneur…)") or ("total " .. coins(total))))
  if e.ext or not Pl.merchant then P.buy:Disable() elseif GetMoney and GetMoney() < total then P.buy:Disable() else P.buy:Enable() end
end

local function doBuy()
  local e = selected(); if not e or e.ext then return end
  local q = buyQty()
  local left = q
  local per = math.max(1, e.stack or 1)
  while left > 0 do
    local n = math.min(left, per)
    BuyMerchantItem(e.idx, n)
    left = left - n
  end
  say(("Acheté : %d × %s."):format(q, e.name))
end

------------------------------------------------------------------------
-- Sacs
------------------------------------------------------------------------
local function refreshBags()
  if not P.rows then P.rows = Pl.bagRows() end
  local free, total = Pl.freeSlots()
  local gain, n = 0, 0
  local data = {}
  for _, r in ipairs(P.rows) do
    local vendable = (r.kind == "junk" or r.kind == "pnj")
    if r.checked and vendable then gain = gain + r.vendorTotal; n = n + 1 end
    local k = KIND[r.kind]
    data[#data + 1] = { id = r.id, chk = r.checked and vendable, toggle = function()
        if vendable then r.checked = not r.checked; M.refresh() end
      end,
      cells = { r.name, tostring(r.count), coins(r.perSlot), W.col(C[k[2]], k[1]) } }
  end
  P.tiles[1]:Set("Emplacements libres", ("%d / %d"):format(free, total), "", { tone = free <= 4 and "bad" or (free <= 10 and "warn" or "ok") })
  P.tiles[2]:Set("Cochés", tostring(n), "gris et marchand", {})
  P.tiles[3]:Set("Récupérable", coins(gain), "", { tone = "gold" })
  if Pl.merchant and n > 0 then P.sell:Enable() else P.sell:Disable() end
  P.bagList:SetData(data, true)
end

------------------------------------------------------------------------
-- Construction
------------------------------------------------------------------------
local function build()
  frame = ns.theme.window("GringottsMerchant", UIParent, 1200, 680, "Marchand", "vendre et acheter")
  frame:SetPoint("CENTER", UIParent, "CENTER", -80, 20)
  frame:SetFrameStrata("HIGH")
  frame:SetMovable(true); frame:EnableMouse(true); frame:RegisterForDrag("LeftButton")
  frame:SetScript("OnDragStart", frame.StartMoving)
  frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
  frame:SetClampedToScreen(true)
  if UISpecialFrames then tinsert(UISpecialFrames, "GringottsMerchant") end
  frame:SetScript("OnHide", function()
    blizzHidden = false; applyBlizzard()
    if Pl.merchant and not closing and CloseMerchant then closing = true; CloseMerchant(); closing = false end
  end)
  P = { rows = nil }
  local body = CreateFrame("Frame", nil, frame)
  body:SetPoint("TOPLEFT", frame, "TOPLEFT", 12, -40); body:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -12, 12)

  -- gauche : sacs
  local left = CreateFrame("Frame", nil, body)
  left:SetPoint("TOPLEFT", body, "TOPLEFT", 0, 0); left:SetPoint("BOTTOMLEFT", body, "BOTTOMLEFT", 0, 0); left:SetWidth(600)
  W.text(left, "GringottsH2", "Mes sacs", 0, 0, 300)
  P.tiles = {}
  for i = 1, 3 do local t = W.tile(left, 190, 64); t.frame:SetPoint("TOPLEFT", left, "TOPLEFT", (i - 1) * 198, -30); P.tiles[i] = t end
  P.b1 = W.button(left, "Cocher gris + marchand", 190, 26, function()
    for _, r in ipairs(P.rows or {}) do r.checked = (r.kind == "junk" or r.kind == "pnj") end; M.refresh() end); P.b1:SetPoint("TOPLEFT", left, "TOPLEFT", 0, -102)
  P.b2 = W.button(left, "Tout décocher", 130, 26, function() for _, r in ipairs(P.rows or {}) do r.checked = false end; M.refresh() end); P.b2:SetPoint("TOPLEFT", left, "TOPLEFT", 198, -102)
  P.sell = W.button(left, "Vendre les cochés", 180, 26, function()
    local n, g = Pl.sellChecked(P.rows or {})
    P.msg:SetText(W.col(C.green, ("%d emplacement(s) vendu(s) · %s"):format(n, ns.api.coins(g))))
    P.rows = nil
    if C_Timer then C_Timer.After(0.5, function() M.refresh() end) end
  end, "primary"); P.sell:SetPoint("TOPLEFT", left, "TOPLEFT", 336, -102)
  local T = ns.plusUI.mkTable(left, -136, { { "Objet", 0, 220 }, { "Qté", 230, 40, "RIGHT" }, { "Valeur / empl.", 280, 130, "RIGHT" }, { "Type", 430, 90 } }, 470,
    { icon = true, check = true, w = 590 })
  P.bagList = T.list
  P.msg = W.text(left, "GringottsTextSmall", "", 0, 0, 590, "LEFT", "BOTTOMLEFT")

  -- droite : marchand
  local right = CreateFrame("Frame", nil, body)
  right:SetPoint("TOPRIGHT", body, "TOPRIGHT", 0, 0); right:SetPoint("BOTTOMRIGHT", body, "BOTTOMRIGHT", 0, 0); right:SetWidth(560)
  ns.theme.panel(right, "panel", "line")
  P.mTitle = W.text(right, "GringottsH2", "Articles du marchand", 12, -8, 400)
  P.repair = W.button(right, "Réparer", 120, 24, function() if RepairAllItems then RepairAllItems(); C_Timer.After(0.4, M.refresh) end end)
  P.repair:SetPoint("TOPRIGHT", right, "TOPRIGHT", -12, -8)
  P.repInfo = W.text(right, "GringottsTextSmall", "", 0, -36, 536, "RIGHT"); P.repInfo:ClearAllPoints(); P.repInfo:SetPoint("TOPRIGHT", right, "TOPRIGHT", -12, -38)
  W.text(right, "GringottsLabelSmall", "Article", 40, -62, 250)
  W.text(right, "GringottsLabelSmall", "Prix", 300, -62, 110, "RIGHT")
  W.text(right, "GringottsLabelSmall", "Dispo", 420, -62, 60, "RIGHT")
  P.mList = W.list(right, 548, 380, 22, function(b)
    W.rowIcon(b, 6)
    b.n = W.text(b, "GringottsTextSmall", "", 34, -5, 256)
    b.p = W.text(b, "GringottsTextSmall", "", 300, -5, 110, "RIGHT")
    b.a = W.text(b, "GringottsTextSmall", "", 420, -5, 60, "RIGHT")
    b:SetScript("OnClick", function(self) if self.entry then P.sel = self.entry.idx2; P.qty:SetText("1"); M.refresh() end end)
    b:SetScript("OnEnter", function(self)
      if self.entry and self.entry.link and GameTooltip then GameTooltip:SetOwner(self, "ANCHOR_RIGHT"); GameTooltip:SetHyperlink(self.entry.link); GameTooltip:Show() end
    end)
    b:SetScript("OnLeave", function() if GameTooltip then GameTooltip:Hide() end end)
  end, function(b, e)
    b.entry = e
    W.setRowIcon(b, e.id)
    b.n:SetText(e.name .. (e.stackTxt or ""))
    b.p:SetText(e.ext and W.col(C.orange, "spécial") or coins(e.price))
    b.a:SetText(e.avail >= 0 and tostring(e.avail) or "∞")
    if P.sel == e.idx2 then b.sel:Show() else b.sel:Hide() end
  end)
  P.mList.frame:SetPoint("TOPLEFT", right, "TOPLEFT", 6, -82)
  P.sBar = W.text(right, "GringottsText", "", 12, 0, 530, "LEFT", "BOTTOMLEFT"); P.sBar:ClearAllPoints(); P.sBar:SetPoint("BOTTOMLEFT", right, "BOTTOMLEFT", 12, 44)
  P.qty = W.edit(right, 60, true); P.qty:SetPoint("BOTTOMLEFT", right, "BOTTOMLEFT", 12, 10); P.qty:SetText("1")
  P.qty:SetScript("OnTextChanged", function() if P.ready then refreshBuyBar() end end)
  P.buy = W.button(right, "Acheter", 170, 26, doBuy, "primary"); P.buy:SetPoint("BOTTOMLEFT", right, "BOTTOMLEFT", 82, 8)
  P.opt = W.button(right, "", 280, 24, function()
    local d = db(); if not d then return end
    d.set = d.set or {}; d.set.merchantReplace = not replaceOn() and true or false
    M.refresh()
  end); P.opt:SetPoint("BOTTOMRIGHT", right, "BOTTOMRIGHT", -8, 8)
  P.ready = true
  frame:Hide()
end

function M.refresh()
  if not frame or not frame:IsShown() then return end
  refreshBags()
  P.items = merchantItems()
  local data = {}
  for i, e in ipairs(P.items) do e.idx2 = i; if e.stack and e.stack > 1 and e.qty > 1 then e.stackTxt = " x" .. e.qty end; data[#data + 1] = e end
  P.mList:SetData(data, true)
  P.mTitle:SetText((UnitName and UnitName("npc")) or "Articles du marchand")
  local rc, can = repairInfo()
  if rc then
    P.repair:Show(); P.repInfo:Show()
    P.repInfo:SetText(rc > 0 and ("Réparation : " .. coins(rc)) or W.col(C.grey, "Équipement en bon état"))
    if can and rc > 0 and GetMoney() >= rc then P.repair:Enable() else P.repair:Disable() end
  else P.repair:Hide(); P.repInfo:Hide() end
  P.opt:SetText("Remplacer la fenêtre Blizzard : " .. (replaceOn() and "oui" or "non"))
  refreshBuyBar()
end

function M.show()
  if not (ns.api and db()) then return end
  if not frame then build() end
  P.rows = nil; P.sel = nil
  frame:Show()
  blizzHidden = true; applyBlizzard()
  M.refresh()
end

function M.onEvent(e)
  if not frame then return end
  if e == "MERCHANT_CLOSED" then
    closing = true; frame:Hide(); closing = false
  end
end

local ev = CreateFrame("Frame")
for _, e in ipairs({ "MERCHANT_SHOW", "MERCHANT_UPDATE", "MERCHANT_FILTER_ITEM_UPDATE", "BAG_UPDATE_DELAYED", "UPDATE_INVENTORY_DURABILITY" }) do pcall(ev.RegisterEvent, ev, e) end
ev:SetScript("OnEvent", function(_, e)
  if e == "MERCHANT_SHOW" then
    if replaceOn() then C_Timer.After(0.1, function() if Pl.merchant or (MerchantFrame and MerchantFrame:IsShown()) then M.show() end end) end
  elseif frame and frame:IsShown() then
    if e == "BAG_UPDATE_DELAYED" then P.rows = nil end
    M.refresh()
  end
end)
