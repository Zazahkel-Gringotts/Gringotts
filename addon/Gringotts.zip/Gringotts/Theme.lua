-- Gringotts : thème de l'interface en jeu, identique à celui du dashboard (mode sombre).
-- Couleurs : --bg #0f1319, --panel #161c25, --panel2 #1d2531, --line #2b3544, --ink #e7e3d8, --muted #a0a9b8, --gold #e4b84e, ok/info/warn/bad.
-- Polices : Barlow Semi Condensed (texte) et Spectral (titres), fournies dans Fonts/ (licence OFL).
local ADDON, ns = ...
local T = {}
ns.theme = T

local function hex(h) return { tonumber(h:sub(2, 3), 16) / 255, tonumber(h:sub(4, 5), 16) / 255, tonumber(h:sub(6, 7), 16) / 255 } end
T.hex = {
  bg = "#0f1319", panel = "#161c25", panel2 = "#1d2531", line = "#2b3544", ink = "#e7e3d8", muted = "#a0a9b8",
  gold = "#e4b84e", silver = "#c3cbd5", copper = "#d18a55",
  ok = "#4fc68d", okbg = "#15301f", info = "#79aef2", infobg = "#172840", warn = "#eba845", warnbg = "#33260f", bad = "#ee6a57", badbg = "#3a1815",
}
T.c = {}
for k, v in pairs(T.hex) do T.c[k] = hex(v) end
function T.code(name, s) local h = T.hex[name] or "#ffffff"; return "|cff" .. h:sub(2) .. tostring(s) .. "|r" end

-- Polices
local DIR = "Interface\\AddOns\\" .. (ADDON or "Gringotts") .. "\\Fonts\\"
local FILES = { sans = "BarlowSemiCondensed-Regular.ttf", semi = "BarlowSemiCondensed-SemiBold.ttf", bold = "BarlowSemiCondensed-Bold.ttf", serif = "BarlowSemiCondensed-Bold.ttf" }
T.fonts = FILES
function T.fontPath(kind) return DIR .. (FILES[kind] or FILES.sans) end

T.fontObjs = {}
local function mk(name, kind, size, col, flags)
  if not CreateFont then return end
  local f = CreateFont(name)
  T.fontObjs[name] = { f = f, kind = kind, size = size, col = col, flags = flags or "" }
  local ok, res = pcall(f.SetFont, f, T.fontPath(kind), size, flags or "")
  if not ok or res == false then pcall(f.SetFont, f, STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF", size, flags or "") end
  local c = T.c[col] or T.c.ink
  f:SetTextColor(c[1], c[2], c[3], 1)
  return f
end
-- Remplaçants des polices Blizzard : GameFontHighlight -> GringottsText, etc.
mk("GringottsText", "sans", 13, "ink")
mk("GringottsTextSmall", "sans", 12, "ink")
mk("GringottsLabel", "semi", 13, "ink")
mk("GringottsLabelSmall", "semi", 12, "muted")
mk("GringottsMuted", "sans", 12, "muted")
mk("GringottsH2", "serif", 17, "ink")
mk("GringottsH1", "serif", 24, "ink")
mk("GringottsValue", "serif", 18, "ink")
mk("GringottsKpi", "serif", 24, "ink")
mk("GringottsBrand", "serif", 18, "gold")
mk("GringottsBold", "bold", 13, "ink")
mk("GringottsOutline", "bold", 12, "ink", "OUTLINE")
mk("GringottsOutlineSmall", "semi", 10, "ink", "OUTLINE")

-- Taille et contraste du texte (Options › Général) : relit GringottsDB.ui.fontScale (%) et .contrast, applique sur les polices Gringotts
function T.applyLook()
  local u = GringottsDB and GringottsDB.ui or {}
  local sc = math.max(.8, math.min(1.4, (u.fontScale or 100) / 100))
  for _, o in pairs(T.fontObjs) do
    local ok, res = pcall(o.f.SetFont, o.f, T.fontPath(o.kind), math.floor(o.size * sc + .5), o.flags)
    if not ok or res == false then pcall(o.f.SetFont, o.f, STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF", math.floor(o.size * sc + .5), o.flags) end
    local c = T.c[o.col] or T.c.ink
    if u.contrast then
      if o.col == "muted" then c = { .80, .84, .91 } elseif o.col == "ink" then c = { .99, .97, .92 } end
    end
    o.f:SetTextColor(c[1], c[2], c[3], 1)
  end
end

------------------------------------------------------------------------
-- Éléments de base : fond + bordure 1 px faits de textures (aucun gabarit Blizzard)
------------------------------------------------------------------------
local function col(f, name, a) local c = T.c[name]; return c[1], c[2], c[3], a or 1 end

function T.edges(f, name, layer)
  local e = rawget(f, "_edges")
  if not e then
    e = {}
    for _, k in ipairs({ "t", "b", "l", "r" }) do e[k] = f:CreateTexture(nil, layer or "BORDER") end
    e.t:SetPoint("TOPLEFT", f, "TOPLEFT", 0, 0); e.t:SetPoint("TOPRIGHT", f, "TOPRIGHT", 0, 0); e.t:SetHeight(1)
    e.b:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 0, 0); e.b:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", 0, 0); e.b:SetHeight(1)
    e.l:SetPoint("TOPLEFT", f, "TOPLEFT", 0, 0); e.l:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 0, 0); e.l:SetWidth(1)
    e.r:SetPoint("TOPRIGHT", f, "TOPRIGHT", 0, 0); e.r:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", 0, 0); e.r:SetWidth(1)
    f._edges = e
  end
  for _, t in pairs(e) do t:SetColorTexture(col(f, name or "line")) end
  return e
end

-- Coins arrondis : textures Media/corner_fill et corner_ring (quart de disque), assemblées en « 9 tranches ».
-- Option Gringotts : GringottsDB.ui.square = true repasse tout en angles droits.
local MEDIA = "Interface\\AddOns\\" .. (ADDON or "Gringotts") .. "\\Media\\"
T.radius = { panel = 6, button = 5, edit = 4, window = 8 }
local function squareMode() return GringottsDB and GringottsDB.ui and GringottsDB.ui.square end
-- rayon effectif : 0 si le cadre est trop petit pour être arrondi proprement
function T.rad(f, kind, r)
  if squareMode() then return 0 end
  r = r or T.radius[kind] or 0
  local w, h = f:GetWidth(), f:GetHeight()
  if type(w) ~= "number" or type(h) ~= "number" or w < 4 * r or h < 3 * r then return 0 end
  return r
end

local CORNERS = {
  { "TOPLEFT", 0, 1, 0, 1 }, { "TOPRIGHT", 1, 0, 0, 1 }, { "BOTTOMLEFT", 0, 1, 1, 0 }, { "BOTTOMRIGHT", 1, 0, 1, 0 },
}
-- Fond + bordure à coins arrondis. f._bg et f._edges gardent l'API de T.panel/T.edges (SetColorTexture).
-- opts.topOnly : seuls les coins du haut sont arrondis (barre de titre) ; opts.noBorder : pas de bordure.
function T.round(f, r, bgName, borderName, opts)
  opts = opts or {}
  local fill, ring = {}, {}
  local function rect(tbl, layer)
    local t = f:CreateTexture(nil, layer); tbl[#tbl + 1] = t; t._rect = true; return t
  end
  local function corner(tbl, layer, tex, c)
    local t = f:CreateTexture(nil, layer); tbl[#tbl + 1] = t
    t:SetTexture(tex); t:SetSize(r, r); t:SetPoint(c[1], f, c[1], 0, 0); t:SetTexCoord(c[2], c[3], c[4], c[5])
    t.SetColorTexture = function(self, ...) self:SetVertexColor(...) end
    return t
  end
  local mid = rect(fill, "BACKGROUND"); mid:SetPoint("TOPLEFT", f, "TOPLEFT", r, 0); mid:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -r, 0)
  local lf = rect(fill, "BACKGROUND"); lf:SetPoint("TOPLEFT", f, "TOPLEFT", 0, -r); lf:SetPoint("BOTTOMRIGHT", f, "BOTTOMLEFT", r, opts.topOnly and 0 or r)
  local rt = rect(fill, "BACKGROUND"); rt:SetPoint("TOPRIGHT", f, "TOPRIGHT", 0, -r); rt:SetPoint("BOTTOMLEFT", f, "BOTTOMRIGHT", -r, opts.topOnly and 0 or r)
  for i, c in ipairs(CORNERS) do
    if opts.topOnly and i > 2 then break end
    corner(fill, "BACKGROUND", MEDIA .. "corner_fill", c)
  end
  local bg = { parts = fill }
  function bg:SetColorTexture(...) for _, t in ipairs(self.parts) do t:SetColorTexture(...) end end
  function bg:SetShown(v) for _, t in ipairs(self.parts) do t:SetShown(v) end end
  f._bg = bg
  if not opts.noBorder then
    local e = {}
    local t_ = f:CreateTexture(nil, "BORDER"); t_:SetPoint("TOPLEFT", f, "TOPLEFT", r, 0); t_:SetPoint("TOPRIGHT", f, "TOPRIGHT", -r, 0); t_:SetHeight(1)
    local b_ = f:CreateTexture(nil, "BORDER"); b_:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", r, 0); b_:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -r, 0); b_:SetHeight(1)
    local l_ = f:CreateTexture(nil, "BORDER"); l_:SetPoint("TOPLEFT", f, "TOPLEFT", 0, -r); l_:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 0, r); l_:SetWidth(1)
    local r_ = f:CreateTexture(nil, "BORDER"); r_:SetPoint("TOPRIGHT", f, "TOPRIGHT", 0, -r); r_:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", 0, r); r_:SetWidth(1)
    e.t, e.b, e.l, e.r = t_, b_, l_, r_
    for i, c in ipairs(CORNERS) do e["c" .. i] = corner(ring, "BORDER", MEDIA .. "corner_ring", c) end
    f._edges = e
    for _, t in pairs(e) do t:SetColorTexture(col(f, borderName or "line")) end
  end
  f._round = r
  bg:SetColorTexture(col(f, bgName or "panel"))
  return f
end

-- Panneau : fond + bordure (arrondis si le cadre est assez grand ; r = 0 force des angles droits)
function T.panel(f, bgName, borderName, r)
  local rad = r or T.rad(f, "panel")
  if rad and rad > 0 and not rawget(f, "_bg") then return T.round(f, rad, bgName, borderName) end
  if not rawget(f, "_bg") then f._bg = f:CreateTexture(nil, "BACKGROUND"); f._bg:SetAllPoints() end
  f._bg:SetColorTexture(col(f, bgName or "panel"))
  T.edges(f, borderName or "line")
  return f
end

-- Fenêtre : fond --bg, bordure --line, barre de titre avec marque (pièce + « Gringotts » en Spectral doré) et bouton de fermeture
function T.window(name, parent, w, h, title, sub)
  local f = CreateFrame("Frame", name, parent or UIParent)
  f:SetSize(w, h)
  T.panel(f, "bg", "line", T.rad(f, "window"))
  local bar = CreateFrame("Frame", nil, f)
  bar:SetPoint("TOPLEFT", f, "TOPLEFT", 1, -1); bar:SetPoint("TOPRIGHT", f, "TOPRIGHT", -1, -1); bar:SetHeight(28)
  local wr = T.rad(f, "window")
  if wr > 0 then T.round(bar, wr - 1, "panel", nil, { topOnly = true, noBorder = true })
  else bar._bg = bar:CreateTexture(nil, "BACKGROUND"); bar._bg:SetAllPoints(); bar._bg:SetColorTexture(col(bar, "panel")) end
  local ln = bar:CreateTexture(nil, "BORDER"); ln:SetPoint("BOTTOMLEFT"); ln:SetPoint("BOTTOMRIGHT"); ln:SetHeight(1); ln:SetColorTexture(col(bar, "line"))
  local ico = bar:CreateTexture(nil, "ARTWORK"); ico:SetSize(18, 18); ico:SetPoint("LEFT", bar, "LEFT", 8, 0)
  ico:SetTexture("Interface\\AddOns\\Gringotts\\Media\\seal")
  local t = bar:CreateFontString(nil, "OVERLAY", "GringottsBrand"); t:SetPoint("LEFT", ico, "RIGHT", 8, 0); t:SetText(title or "Gringotts")
  f.TitleText = t
  if sub then local s = bar:CreateFontString(nil, "OVERLAY", "GringottsMuted"); s:SetPoint("LEFT", t, "RIGHT", 10, -1); s:SetText(sub); f.SubText = s end
  f.titleBar = bar
  local x = T.button(bar, "x", 24, 20, function() f:Hide() end)
  x:SetPoint("RIGHT", bar, "RIGHT", -5, 0)
  f.close = x
  return f
end

-- Bouton : fond --panel2, bordure --line, bordure dorée au survol ; « primary » : fond doré
function T.button(parent, label, w, h, onclick, style, name)
  local b = CreateFrame("Button", name, parent)
  b:SetSize(w or 100, h or 22)
  local br = T.rad(b, "button")
  if br > 0 then T.round(b, br, "panel2", "line")
  else b._bg = b:CreateTexture(nil, "BACKGROUND"); b._bg:SetAllPoints(); T.edges(b, "line") end
  local fs = b:CreateFontString(nil, "OVERLAY", style == "primary" and "GringottsBold" or "GringottsLabel")
  fs:SetPoint("CENTER", b, "CENTER", 0, 0)
  b:SetFontString(fs)
  b._fs = fs
  b._style = style
  function b:_paint()
    local hot = self._hot and self:IsEnabled()
    if self._style == "primary" then
      self._bg:SetColorTexture(col(self, "gold")); local d = T.c.bg; self._fs:SetTextColor(d[1], d[2], d[3], 1)
    else
      self._bg:SetColorTexture(col(self, hot and "panel" or "panel2"))
      local c = self:IsEnabled() and T.c.ink or T.c.muted; self._fs:SetTextColor(c[1], c[2], c[3], 1)
    end
    for _, t in pairs(self._edges) do t:SetColorTexture(col(self, hot and "gold" or "line")) end
    self:SetAlpha(self:IsEnabled() and 1 or .55)
  end
  b:SetScript("OnEnter", function(self) self._hot = true; self:_paint() end)
  b:SetScript("OnLeave", function(self) self._hot = false; self:_paint() end)
  local en, dis = b.Enable, b.Disable
  function b:Enable() en(self); self:_paint() end
  function b:Disable() dis(self); self:_paint() end
  if label then b:SetText(label) end
  if onclick then b:SetScript("OnClick", onclick) end
  b:_paint()
  return b
end

-- Onglet / entrée de menu : texte discret, survol --panel2, état actif (Disable) : fond --panel2 et barre dorée
function T.tab(parent, label, w, h, onclick, side)
  local b = CreateFrame("Button", nil, parent)
  b:SetSize(w or 100, h or 24)
  b._bg = b:CreateTexture(nil, "BACKGROUND"); b._bg:SetAllPoints()
  b._bar = b:CreateTexture(nil, "ARTWORK"); b._bar:SetColorTexture(col(b, "gold"))
  if side then b._bar:SetPoint("TOPLEFT"); b._bar:SetPoint("BOTTOMLEFT"); b._bar:SetWidth(3)
  else b._bar:SetPoint("BOTTOMLEFT"); b._bar:SetPoint("BOTTOMRIGHT"); b._bar:SetHeight(2) end
  local fs = b:CreateFontString(nil, "OVERLAY", "GringottsLabel")
  if side then fs:SetPoint("LEFT", b, "LEFT", 12, 0); fs:SetJustifyH("LEFT") else fs:SetPoint("CENTER") end
  b:SetFontString(fs); b._fs = fs
  function b:_paint()
    local active = not self:IsEnabled()
    self._bar:SetShown(active)
    self._bg:SetColorTexture(col(self, "panel2", (active or self._hot) and 1 or 0))
    local c = (active or self._hot) and T.c.ink or T.c.muted; self._fs:SetTextColor(c[1], c[2], c[3], 1)
  end
  b:SetScript("OnEnter", function(self) self._hot = true; self:_paint() end)
  b:SetScript("OnLeave", function(self) self._hot = false; self:_paint() end)
  local en, dis = b.Enable, b.Disable
  function b:Enable() en(self); self:_paint() end
  function b:Disable() dis(self); self:_paint() end
  if label then b:SetText(label) end
  if onclick then b:SetScript("OnClick", onclick) end
  b:_paint()
  return b
end

-- Case à cocher : carré --bg à bordure --line, coche dorée ; b.text = libellé (même API que UICheckButtonTemplate)
function T.check(parent, label)
  local cb = CreateFrame("CheckButton", nil, parent)
  cb:SetSize(18, 18)
  cb._bg = cb:CreateTexture(nil, "BACKGROUND"); cb._bg:SetAllPoints(); cb._bg:SetColorTexture(col(cb, "bg"))
  T.edges(cb, "line")
  cb:SetCheckedTexture("Interface\\Buttons\\UI-CheckBox-Check")
  local ck = cb:GetCheckedTexture()
  if ck then ck:ClearAllPoints(); ck:SetPoint("CENTER", cb, "CENTER", 0, 0); ck:SetSize(26, 26); ck:SetVertexColor(T.c.gold[1], T.c.gold[2], T.c.gold[3]) end
  cb.text = cb:CreateFontString(nil, "OVERLAY", "GringottsLabel")
  cb.text:SetPoint("LEFT", cb, "RIGHT", 8, 0)
  if label then cb.text:SetText(label) end
  cb:SetScript("OnEnter", function(self) for _, t in pairs(self._edges) do t:SetColorTexture(col(self, "gold")) end end)
  cb:SetScript("OnLeave", function(self) for _, t in pairs(self._edges) do t:SetColorTexture(col(self, "line")) end end)
  return cb
end

-- Champ de saisie : fond --bg, bordure --line (dorée à la saisie)
function T.edit(parent, w, numeric, onenter)
  local e = CreateFrame("EditBox", nil, parent)
  e:SetSize(w or 60, 22); e:SetAutoFocus(false); e:SetFontObject("GringottsText")
  e:SetTextInsets(6, 6, 0, 0)
  local er = T.rad(e, "edit")
  if er > 0 then T.round(e, er, "bg", "line")
  else e._bg = e:CreateTexture(nil, "BACKGROUND"); e._bg:SetAllPoints(); e._bg:SetColorTexture(col(e, "bg")); T.edges(e, "line") end
  if numeric then
    if e.SetNumeric then e:SetNumeric(true) end
    if e.SetJustifyH then e:SetJustifyH("RIGHT") end
  end
  e:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
  e:SetScript("OnEnterPressed", function(self) self:ClearFocus(); if onenter then onenter(self) end end)
  -- bordure dorée pendant la saisie ; les scripts posés ensuite par SetScript restent appelés
  local user = {}
  local rawSet = e.SetScript
  local function style(self, name) for _, t in pairs(self._edges) do t:SetColorTexture(col(self, name)) end end
  rawSet(e, "OnEditFocusGained", function(self, ...) style(self, "gold"); if user.OnEditFocusGained then user.OnEditFocusGained(self, ...) end end)
  rawSet(e, "OnEditFocusLost", function(self, ...) style(self, "line"); if user.OnEditFocusLost then user.OnEditFocusLost(self, ...) end end)
  e.SetScript = function(self, name, fn)
    if name == "OnEditFocusGained" or name == "OnEditFocusLost" then user[name] = fn else rawSet(self, name, fn) end
  end
  return e
end

-- applique la taille / le contraste du texte réglés dans Options dès que la base est chargée
local lf = CreateFrame("Frame")
lf:RegisterEvent("PLAYER_LOGIN")
lf:SetScript("OnEvent", function() if T.applyLook then pcall(T.applyLook) end end)
