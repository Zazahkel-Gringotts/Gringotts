-- Gringotts : alertes de prix. Quand le prix connu d'un objet passe sous (bas) ou au-dessus (haut) d'un seuil, un message
-- s'affiche dans le chat avec un son, au plus une fois toutes les 30 minutes par alerte.
-- /gt alerte bas|haut <prix en or> <lien de l'objet> · /gt alerte · /gt alerte retirer <n> · /gt alerte vider
local ADDON, ns = ...
local Al = {}
ns.alerts = Al

local COOLDOWN = 1800
local function say(m) print("|cffe4b84eGringotts|r " .. m) end
local function list()
  local d = ns.api and ns.api.db and ns.api.db()
  if not d then return nil end
  d.alerts = d.alerts or {}
  return d.alerts
end
local function coins(c) return ns.api and ns.api.coins and ns.api.coins(c) or tostring(c) end

function Al.add(id, mode, copper)
  local L = list(); if not L then return false end
  local name = (C_Item and C_Item.GetItemNameByID and C_Item.GetItemNameByID(id)) or (GetItemInfo and (GetItemInfo(id))) or ("objet " .. id)
  for _, a in ipairs(L) do if a.id == id and a.mode == mode then a.copper = copper; a.name = name; a.last = nil; return true, name end end
  L[#L + 1] = { id = id, name = name, mode = mode, copper = copper }
  return true, name
end

function Al.check()
  local L = list(); local E = ns.engine
  if not (L and E and #L > 0) then return end
  local now = time and time() or 0
  for _, a in ipairs(L) do
    if not a.last or now - a.last >= COOLDOWN then
      local k = ns.norm and ns.norm(a.name) or a.name
      local ok, it = pcall(E.evaluate, k, a.name, a.id, 0)
      local p = ok and it and it.price
      if type(p) == "number" and ((a.mode == "bas" and p <= a.copper) or (a.mode == "haut" and p >= a.copper)) then
        a.last = now
        say(("ALERTE %s : %s est à %s (seuil %s %s)"):format(a.mode == "bas" and "prix bas" or "prix haut", a.name, coins(p), a.mode == "bas" and "≤" or "≥", coins(a.copper)) .. ((ns.gains and ns.gains.isSlow(k)) and " |cffaaaaaa[objet lent à la revente]|r" or ""))
        if PlaySound and SOUNDKIT and SOUNDKIT.AUCTION_WINDOW_OPEN then pcall(PlaySound, SOUNDKIT.AUCTION_WINDOW_OPEN) end
      end
    end
  end
end

function ns.alertCmd(arg)
  arg = (arg or ""):gsub("^%s+", "")
  local L = list(); if not L then say("Base non prête."); return end
  local mode, price = arg:match("^(%a+)%s+([%d%.,]+)")
  if arg == "" or arg == "liste" then
    if #L == 0 then say("Aucune alerte. Exemple : /gt alerte bas 2.5 [lien de l'objet] (prix en or).") return end
    for i, a in ipairs(L) do say(("%d. %s : %s %s"):format(i, a.name, a.mode == "bas" and "≤" or "≥", coins(a.copper)) .. ((ns.gains and ns.gains.isSlow(ns.norm(a.name))) and " |cffaaaaaa[objet lent à la revente]|r" or "")) end
  elseif arg:match("^vider") then
    for i = #L, 1, -1 do L[i] = nil end; say("Alertes effacées.")
  elseif arg:match("^retirer") then
    local n = tonumber(arg:match("^%a+%s+(%d+)"))
    if n and L[n] then say("Alerte retirée : " .. L[n].name); table.remove(L, n) else say("Numéro d'alerte inconnu (/gt alerte pour la liste).") end
  elseif (mode == "bas" or mode == "haut") and price then
    local id = tonumber(arg:match("item:(%d+)"))
    local gold = tonumber((price:gsub(",", ".")))
    if not (id and gold and gold > 0) then say("Il manque le lien de l'objet (maj + clic) ou le prix en or.") return end
    local ok, name = Al.add(id, mode, math.floor(gold * 10000 + .5))
    say(("Alerte %s : %s à %s."):format(mode, name or id, coins(math.floor(gold * 10000 + .5))))
    Al.check()
  else
    say("Usage : /gt alerte bas|haut <prix en or> <lien> · /gt alerte · /gt alerte retirer <n> · /gt alerte vider")
  end
end

local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN"); f:RegisterEvent("AUCTION_HOUSE_CLOSED")
f:SetScript("OnEvent", function(_, e)
  if e == "PLAYER_LOGIN" then
    if C_Timer then
      C_Timer.After(10, function() Al.check() end)
      if C_Timer.NewTicker then C_Timer.NewTicker(120, function() Al.check() end) end
    end
  else Al.check() end
end)
if ns.safe then f:SetScript("OnEvent", ns.safe(f:GetScript("OnEvent"), "alertes")) end
