-- Gringotts : swing timer du Tir automatique (chasseur uniquement).
-- La barre se remplit sur la vitesse de l'arme à distance. Dans les dernières 0,5 s (la visée) elle change de couleur :
-- il ne faut plus bouger, sinon le tir est annulé. Si tu bouges pendant la visée : flash rouge, la barre revient au début de la visée.
-- /gt tir : on | off | taille L H | opacite N | visee MS | texte on|off | munitions on|off | reset
-- Sous la barre, à gauche : icône des munitions équipées et quantité présente dans les sacs (orange sous 100, rouge à 0).
local ADDON, ns = ...
local Sh = {}
ns.shot = Sh

local AUTO_SHOT = 75
local DEF = { on = true, w = 260, h = 22, alpha = 1, text = true, aim = 0.5, ammo = true }
local AMMO_SLOT = 0               -- emplacement de munitions de l'équipement
local COL_FILL = { .30, .62, 1 }      -- avant la visée
local COL_AIM = { 1, .55, .10 }       -- visée : ne plus bouger
local COL_BAD = { 1, .15, .15 }       -- tir annulé / tu bouges pendant la visée

local function say(m) print("|cffe4b84eGringotts|r " .. m) end
local function isHunter() if not UnitClass then return false end; local _, c = UnitClass("player"); return c == "HUNTER" end
function Sh.cfg()
  GringottsDB = GringottsDB or {}
  local c = GringottsDB.shot
  if not c then c = {}; GringottsDB.shot = c end
  for k, v in pairs(DEF) do if c[k] == nil then c[k] = v end end
  return c
end

-- État du cycle
local S = { start = 0, speed = 3, active = false, flash = 0 }
Sh.S = S

local function rangedSpeed()
  local s = UnitRangedDamage and UnitRangedDamage("player")
  if type(s) == "number" and s > 0 then return s end
  return S.speed > 0 and S.speed or 3
end

-- Progression 0-1 du cycle et début de la visée (fraction). Pure : testable.
function Sh.progress(now, start, speed, aim)
  speed = (speed and speed > 0) and speed or 3
  local p = (now - start) / speed
  if p < 0 then p = 0 elseif p > 1 then p = 1 end
  local zf = 1 - (aim or .5) / speed
  if zf < 0 then zf = 0 end
  return p, zf, p >= zf
end

------------------------------------------------------------------------
-- Barre
------------------------------------------------------------------------
local f = CreateFrame("Frame", "GringottsShotBar", UIParent)
f:SetFrameStrata("MEDIUM"); f:SetClampedToScreen(true)
f:SetMovable(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton")
f:SetPoint("CENTER", UIParent, "CENTER", 0, -160)
f:Hide()
-- Habillage : bordure sombre + liseré clair, fond, remplissage avec reflet, zone de visée teintée, étincelle
local edge = f:CreateTexture(nil, "BACKGROUND", nil, -8); edge:SetAllPoints(); edge:SetColorTexture(0, 0, 0, 1)
local rim = f:CreateTexture(nil, "BACKGROUND", nil, -7); rim:SetPoint("TOPLEFT", -1, 1); rim:SetPoint("BOTTOMRIGHT", 1, -1); rim:SetColorTexture(1, 1, 1, .12)
local bg = f:CreateTexture(nil, "BACKGROUND", nil, -5); bg:SetPoint("TOPLEFT", 1, -1); bg:SetPoint("BOTTOMRIGHT", -1, 1); bg:SetColorTexture(.03, .04, .07, .92)
local zone = f:CreateTexture(nil, "BACKGROUND", nil, -4); zone:SetColorTexture(1, .55, .10, .22)
local fill = f:CreateTexture(nil, "ARTWORK"); fill:SetPoint("TOPLEFT", f, "TOPLEFT", 1, -1); fill:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 1, 1)
local gloss = f:CreateTexture(nil, "ARTWORK", nil, 2); gloss:SetPoint("TOPLEFT", fill, "TOPLEFT", 0, 0); gloss:SetPoint("TOPRIGHT", fill, "TOPRIGHT", 0, 0); gloss:SetColorTexture(1, 1, 1, .26)
local shade = f:CreateTexture(nil, "ARTWORK", nil, 2); shade:SetPoint("BOTTOMLEFT", fill, "BOTTOMLEFT", 0, 0); shade:SetPoint("BOTTOMRIGHT", fill, "BOTTOMRIGHT", 0, 0); shade:SetColorTexture(0, 0, 0, .18)
local mark = f:CreateTexture(nil, "OVERLAY"); mark:SetWidth(1); mark:SetColorTexture(1, .80, .45, .9)
local spark = f:CreateTexture(nil, "OVERLAY", nil, 3); spark:SetTexture("Interface\\CastingBar\\UI-CastingBar-Spark"); spark:SetBlendMode("ADD")
local function outlined(fs, size)
  local font = GameFontHighlight and GameFontHighlight.GetFont and GameFontHighlight:GetFont()
  if font then fs:SetFont(font, size, "OUTLINE") end
end
local txtL = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); txtL:SetPoint("LEFT", f, "LEFT", 6, 0); outlined(txtL, 12)
local txtR = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); txtR:SetPoint("RIGHT", f, "RIGHT", -6, 0); outlined(txtR, 10)
-- Munitions : tuile bordée (icône + quantité incrustée en bas à droite), sous la barre à gauche
local aBd = f:CreateTexture(nil, "ARTWORK", nil, 0); aBd:SetColorTexture(.55, .55, .6, .55)
local aBg = f:CreateTexture(nil, "ARTWORK", nil, 1); aBg:SetColorTexture(.05, .06, .09, 1)
local aIco = f:CreateTexture(nil, "ARTWORK", nil, 2); aIco:SetPoint("TOPLEFT", f, "BOTTOMLEFT", 1, -6)
if aIco.SetTexCoord then aIco:SetTexCoord(.07, .93, .07, .93) end
aBd:SetPoint("TOPLEFT", aIco, "TOPLEFT", -2, 2); aBd:SetPoint("BOTTOMRIGHT", aIco, "BOTTOMRIGHT", 2, -2)
aBg:SetPoint("TOPLEFT", aIco, "TOPLEFT", -1, 1); aBg:SetPoint("BOTTOMRIGHT", aIco, "BOTTOMRIGHT", 1, -1)
local aTxt = f:CreateFontString(nil, "OVERLAY", "GameFontNormal"); aTxt:SetPoint("BOTTOMRIGHT", aIco, "BOTTOMRIGHT", 0, 1); outlined(aTxt, 12)
f:SetScript("OnDragStart", function(self) if IsShiftKeyDown() then self:StartMoving() end end)
f:SetScript("OnDragStop", function(self)
  self:StopMovingOrSizing()
  local p, _, rp, x, y = self:GetPoint()
  Sh.cfg().pos = { p, rp, x, y }
end)

local function applyLook()
  local c = Sh.cfg()
  f:SetSize(c.w, c.h); f:SetAlpha(c.alpha)
  mark:SetHeight(c.h - 2); zone:SetHeight(c.h - 2); gloss:SetHeight(math.max(1, (c.h - 2) * .45)); shade:SetHeight(math.max(1, (c.h - 2) * .25))
  spark:SetSize(16, c.h * 2.2)
  local sz = math.max(28, math.min(44, c.h + 12)); aIco:SetSize(sz, sz)
  if c.pos then f:ClearAllPoints(); f:SetPoint(c.pos[1], UIParent, c.pos[2], c.pos[3], c.pos[4]) end
end
Sh.applyLook = applyLook

local function setColor(c) fill:SetColorTexture(c[1], c[2], c[3], 1) end
local function fmt(x) return (("%.1f"):format(x):gsub("%.", ",")) end

-- Munitions équipées (emplacement 0) et quantité présente dans les sacs. Renvoie id, icône, nombre.
function Sh.ammoInfo()
  local id = GetInventoryItemID and GetInventoryItemID("player", AMMO_SLOT)
  if not id then return nil, nil, 0 end
  local icon = (GetItemIcon and GetItemIcon(id)) or (GetInventoryItemTexture and GetInventoryItemTexture("player", AMMO_SLOT))
  local n = (GetItemCount and GetItemCount(id)) or 0
  return id, icon, n
end
function Sh.ammoRefresh()
  local c = Sh.cfg()
  if not c.ammo then aIco:Hide(); aBd:Hide(); aBg:Hide(); aTxt:SetText(""); return end
  local id, icon, n = Sh.ammoInfo()
  aIco:Show(); aBd:Show(); aBg:Show()
  aIco:SetTexture(icon or "Interface\\Icons\\INV_Ammo_Arrow_02")
  if aIco.SetDesaturated then aIco:SetDesaturated(id == nil) end
  if id == nil then aTxt:SetText("|cffff4d4d0|r")
  elseif n <= 0 then aTxt:SetText("|cffff4d4d0|r")
  elseif n < 100 then aTxt:SetText("|cffffa64d" .. n .. "|r")
  else aTxt:SetText(tostring(n)) end
  Sh.ammoShown = { id = id, n = n }
end

-- Démonstration (onglet Options) : cycle simulé en boucle, une fois sur deux « tu bouges » pendant la visée
function Sh.setDemo(on)
  Sh.demo = on and true or false
  S.demoT0 = GetTime(); S.demoN = 0
  f:SetFrameStrata(Sh.demo and "FULLSCREEN_DIALOG" or "MEDIUM")
  if Sh.refreshShow then Sh.refreshShow() end
  if Sh.ammoRefresh then Sh.ammoRefresh() end
end
function Sh.recenter()
  local c = Sh.cfg(); c.pos = nil
  f:ClearAllPoints(); f:SetPoint("CENTER", UIParent, "CENTER", 0, -160)
end
local function demoState(now, speed)
  local per = speed + 1.2
  local n = math.floor((now - S.demoT0) / per)
  local t = (now - S.demoT0) - n * per
  S.demoN = n
  return now - math.min(t, speed), n % 2 == 1 and t >= speed - .5 and t < speed + .6
end

local function update(now)
  local c = Sh.cfg()
  local speed = rangedSpeed(); S.speed = speed
  local demoMove
  if Sh.demo and not S.active then S.start, demoMove = demoState(now, speed); S.flash = demoMove and now + .05 or S.flash end
  local p, zf, inAim = Sh.progress(now, S.start, speed, c.aim)
  local W = (c.w or 260) - 2
  fill:SetWidth(math.max(.01, W * p))
  mark:ClearAllPoints(); mark:SetPoint("LEFT", f, "LEFT", 1 + W * zf, 0)
  zone:ClearAllPoints(); zone:SetPoint("TOPLEFT", f, "TOPLEFT", 1 + W * zf, -1); zone:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -1, 1)
  spark:ClearAllPoints(); spark:SetPoint("CENTER", fill, "RIGHT", 0, 0); spark:SetShown(p > 0 and p < 1)
  local moving = inAim and ((demoMove) or (not (Sh.demo and not S.active) and GetUnitSpeed and (GetUnitSpeed("player") or 0) > 0))
  if S.flash > now then setColor(COL_BAD)
  elseif moving then setColor(COL_BAD)
  elseif inAim then setColor(COL_AIM)
  else setColor(COL_FILL) end
  S.inAim, S.moving = inAim, moving and true or false
  if c.text then
    txtL:SetText(p >= 1 and "prêt" or (fmt(math.max(0, speed - (now - S.start))) .. " s"))
    txtR:SetText(inAim and "" or ("vit. " .. fmt(speed) .. " s"))
  else txtL:SetText(""); txtR:SetText("") end
end
Sh.update = update

f:SetScript("OnUpdate", function() update(GetTime()) end)

local function refreshShow()
  local c = Sh.cfg()
  f:SetShown(isHunter() and c.on and (S.active or Sh.demo))
  if S.active then Sh.ammoRefresh() end
end
Sh.refreshShow = refreshShow

------------------------------------------------------------------------
-- Événements
------------------------------------------------------------------------
local function isAuto(...)
  -- UNIT_SPELLCAST_* : unit, castGUID, spellID (Classic) ; sinon on compare le nom
  local a, b, c = ...
  if type(c) == "number" then return c == AUTO_SHOT end
  if type(b) == "number" then return b == AUTO_SHOT end
  local name = GetSpellInfo and GetSpellInfo(AUTO_SHOT)
  return name ~= nil and (b == name or c == name)
end

function Sh.onShot(now)           -- tir parti : nouveau cycle
  S.start = now; S.speed = rangedSpeed()
end
function Sh.onStart(now)          -- Tir automatique activé
  S.active = true; S.speed = rangedSpeed()
  local c = Sh.cfg()
  if now - S.start >= S.speed then S.start = now - math.max(0, S.speed - c.aim) end   -- arme prête : seule la visée reste
  refreshShow()
end
function Sh.onStop() S.active = false; refreshShow() end
function Sh.onCancel(now)         -- tir annulé : seulement si on était dans la visée
  local c = Sh.cfg()
  local _, _, inAim = Sh.progress(now, S.start, S.speed, c.aim)
  if not inAim then return false end
  S.flash = now + .4
  S.start = now - math.max(0, S.speed - c.aim)   -- la visée repart du début
  return true
end

local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
ev:SetScript("OnEvent", function(self, e, ...)
  if e == "PLAYER_LOGIN" then
    if not isHunter() then return end
    applyLook()
    Sh.ammoRefresh()
    for _, n in ipairs({ "START_AUTOREPEAT_SPELL", "STOP_AUTOREPEAT_SPELL", "UNIT_SPELLCAST_SUCCEEDED", "UNIT_SPELLCAST_INTERRUPTED", "UNIT_SPELLCAST_FAILED",
                         "BAG_UPDATE_DELAYED", "PLAYER_EQUIPMENT_CHANGED", "UNIT_INVENTORY_CHANGED" }) do self:RegisterEvent(n) end
    return
  end
  if not isHunter() then return end
  local now = GetTime()
  if e == "BAG_UPDATE_DELAYED" or e == "PLAYER_EQUIPMENT_CHANGED" or (e == "UNIT_INVENTORY_CHANGED" and ... == "player") then Sh.ammoRefresh(); return end
  if e == "START_AUTOREPEAT_SPELL" then Sh.onStart(now)
  elseif e == "STOP_AUTOREPEAT_SPELL" then Sh.onStop()
  else
    local unit = ...
    if unit ~= "player" or not isAuto(...) then return end
    if e == "UNIT_SPELLCAST_SUCCEEDED" then Sh.onShot(now)
    else Sh.onCancel(now) end
  end
end)

------------------------------------------------------------------------
-- Réglages et commande
------------------------------------------------------------------------
function Sh.set(k, v)
  local c = Sh.cfg()
  if k == "on" then c.on = v and true or false
  elseif k == "text" then c.text = v and true or false
  elseif k == "ammo" then c.ammo = v and true or false
  elseif k == "alpha" then v = tonumber(v); if not (v and v >= 10 and v <= 100) then return false end; c.alpha = v / 100
  elseif k == "aim" then v = tonumber(v); if not (v and v >= 100 and v <= 1500) then return false end; c.aim = v / 1000
  elseif k == "size" then local w, h = v[1], v[2]; if not (w and h and w >= 80 and w <= 800 and h >= 8 and h <= 80) then return false end; c.w, c.h = w, h
  else return false end
  applyLook(); refreshShow(); return true
end

ns.shotCmd = function(arg)
  arg = (arg or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
  local cmd, rest = arg:match("^(%S+)%s*(.*)$")
  if not isHunter() then say("Le swing timer du tir automatique est réservé aux chasseurs."); return end
  local c = Sh.cfg()
  if cmd == "taille" or cmd == "size" then
    local w, h = rest:match("^(%d+)%s+(%d+)$")
    say(Sh.set("size", { tonumber(w), tonumber(h) }) and ("Taille : " .. w .. " × " .. h) or "Taille : largeur 80-800 et hauteur 8-80 (ex. /gt tir taille 260 22).")
  elseif cmd == "opacite" or cmd == "opacity" then say(Sh.set("alpha", rest) and ("Opacité : " .. rest .. " %") or "Opacité : un nombre entre 10 et 100.")
  elseif cmd == "visee" or cmd == "aim" then say(Sh.set("aim", rest) and ("Zone de visée : " .. rest .. " ms") or "Visée : une durée en ms entre 100 et 1500 (0,5 s = 500).")
  elseif cmd == "texte" or cmd == "text" then Sh.set("text", rest ~= "off"); say("Texte de la barre : " .. (c.text and "affiché" or "masqué") .. ".")
  elseif cmd == "munitions" or cmd == "ammo" then Sh.set("ammo", rest ~= "off"); say("Icône de munitions : " .. (c.ammo and "affichée" or "masquée") .. ".")
  elseif cmd == "reset" then
    Sh.recenter(); say("Barre recentrée (Maj + glisser pour la déplacer).")
  else
    local on
    if cmd == "on" then on = true elseif cmd == "off" then on = false else on = not c.on end
    Sh.set("on", on); say("Barre du tir automatique : " .. (c.on and "activée (Maj + glisser pour la déplacer)." or "désactivée."))
  end
end
