-- Gringotts : onglet Métiers (liste | détail | plan de craft)
local ADDON, ns = ...
local W = ns.W
local C = W.C
local U = {}
ns.craftsUI = U
local K = ns.crafts

local LEFT_W, RIGHT_W = 440, 400
local ST = { go = { "Crafter", C.green }, buy = { "Acheter compo", C.orange }, no = { "Éviter", C.red }, noprice = { "Sans prix", C.grey }, learn = { "À apprendre", C.gold } }
local DOT = { [0] = { 1, .5, 0 }, [1] = { 1, .82, 0 }, [2] = { .3, .73, .09 }, [3] = { .54, .54, .54 } }
local S = { prof = nil, mode = "profit", chip = "all", sel = nil }
local GSRC = { t = "Entraîneur", v = "Patron chez un vendeur", f = "Recette à trouver (butin, quête, HV)", k = "Connue d'office" }
local function A() return ns.api end

-- Où acheter une recette non apprise : base intégrée (Alliance / Horde) + marchands vus en jeu
local VCOL = { A = "6db3ff", H = "ff7b6b", N = "d9c98a", R = "c79bff", S = "7fe0a0" }
local function vendorText(e)
  if e.learned or not ns.rv then return "" end
  local ls = ns.rv.lines(e.name, 3, VCOL, function(c) return A().coins(c) end)
  if #ls == 0 then return W.col(C.grey, "Vendeurs inconnus : visite un marchand de recettes, Gringotts le note.") end
  return W.col(C.gold, "Où l'obtenir") .. "\n" .. table.concat(ls, "\n")
end
local function coins(c) return c and A().coins(c) or W.col(C.grey, "—") end
local function pct(g) if not g then return "—" end return ("%+d %%"):format(math.floor(g * 100 + (g < 0 and -.5 or .5))) end

-- Guide 1-300 : lignes de la liste (étapes terminées repliées en une ligne), selon le filtre
local function isPkg() return S.mode == "guide" and K.guide(S.prof) and K.skillOf(S.prof) >= 300 end
local function pkgList()
  local pk = K.package(S.prof); if not pk then return {}, nil end
  local o = {}
  for _, a in ipairs(pk.items) do
    local keep = true
    if S.chip == "can" then keep = (a.price == nil) elseif S.chip == "good" then keep = a.miss > 0 end
    if keep then o[#o + 1] = a end
  end
  return o, pk
end
local function guideList()
  local steps = K.guideSteps(S.prof)
  if not steps then return {} end
  local o, ndone, upto = {}, 0, 0
  for _, x in ipairs(steps) do
    if x.done then ndone = ndone + 1; if x.s.b > upto then upto = x.s.b end end
    local keep = true
    if S.chip == "can" then keep = not x.done
    elseif S.chip == "good" then keep = (x.unpriced == 0) end
    if keep and not (x.done and S.chip == "all") then o[#o + 1] = x end
  end
  if ndone > 0 and S.chip == "all" then table.insert(o, 1, { step = true, collapsed = true, key = "gdone", ndone = ndone, upto = upto }) end
  return o
end

local function guideVendorText(x)
  local s = x.s
  if s.src == "f" then return W.col(C.orange, "Recette à trouver : butin, quête ou HV (aucun vendeur connu).") end
  if s.src ~= "v" then return "" end
  local ls = ns.rv and ns.rv.lines(s.n, 3, VCOL, function(c) return A().coins(c) end) or {}
  if #ls == 0 then return W.col(C.grey, "Vendeur : " .. (s.note or "inconnu")) end
  return W.col(C.gold, "Où l'obtenir") .. "\n" .. table.concat(ls, "\n")
end

local function shown()
  local list = (S.mode == "level") and K.levelList(S.prof) or K.profitList(S.prof)
  local o = {}
  if S.mode == "level" then
    if S.chip == "can" then for _, e in ipairs(list) do if e.learned then o[#o + 1] = e end end; list = o
    elseif S.chip == "good" then for _, e in ipairs(list) do if not e.learned then o[#o + 1] = e end end; list = o end
  else
    if S.chip == "can" then for _, e in ipairs(list) do if e.craftable > 0 then o[#o + 1] = e end end; list = o
    elseif S.chip == "good" then for _, e in ipairs(list) do if e.status == "go" or e.status == "buy" then o[#o + 1] = e end end; list = o end
  end
  return list
end

function U.build(pane)
  local P = {}
  U.p = P
  P.profBtns = {}
  for i = 1, 8 do
    local b = W.button(pane, "", 120, 24, function() S.prof = P.profBtns[i].prof; S.sel = nil; U.refresh() end)
    b:SetPoint("TOPLEFT", pane, "TOPLEFT", (i - 1) * 124, 0); b:Hide(); P.profBtns[i] = b
  end
  P.modeA = W.button(pane, "Crafts", 110, 24, function() S.mode = "profit"; S.sel = nil; S.chip = "all"; U.refresh() end)
  P.modeA:SetPoint("TOPRIGHT", pane, "TOPRIGHT", -238, 0)
  P.modeB = W.button(pane, "Montée", 110, 24, function() S.mode = "level"; S.sel = nil; S.chip = "all"; U.refresh() end)
  P.modeB:SetPoint("TOPRIGHT", pane, "TOPRIGHT", -124, 0)
  P.modeG = W.button(pane, "Guide 1-300", 120, 24, function() S.mode = "guide"; S.sel = nil; S.chip = "all"; U.qtyKey = nil; U.refresh() end)
  P.modeG:SetPoint("TOPRIGHT", pane, "TOPRIGHT", 0, 0)
  local body = CreateFrame("Frame", nil, pane); body:SetPoint("TOPLEFT", pane, "TOPLEFT", 0, -34); body:SetPoint("BOTTOMRIGHT", pane, "BOTTOMRIGHT", 0, 0)
  P.empty = W.text(pane, "GringottsText", "", 0, -50, 800)
  P.body = body
  -- gauche
  local left = CreateFrame("Frame", nil, body); left:SetPoint("TOPLEFT", body, "TOPLEFT", 0, 0); left:SetPoint("BOTTOMLEFT", body, "BOTTOMLEFT", 0, 0); left:SetWidth(LEFT_W)
  P.head = W.text(left, "GringottsH2", "", 0, 0, 300)
  P.skill = W.text(left, "GringottsTextSmall", "", 220, -4, LEFT_W - 230, "RIGHT")
  P.chips = {}
  local x = 0
  for _, c in ipairs({ { "all", "Toutes" }, { "can", "Faisables" }, { "good", "Rentables" } }) do
    local b = W.button(left, c[2], 100, 22, function() S.chip = c[1]; U.refresh() end); b:SetPoint("TOPLEFT", left, "TOPLEFT", x, -28); P.chips[c[1]] = b; x = x + 104
  end
  P.h1 = W.text(left, "GringottsLabelSmall", "Recette", 24, -58, 200)
  P.h2 = W.text(left, "GringottsLabelSmall", "Statut", 230, -58, 110, "RIGHT")
  P.h3 = W.text(left, "GringottsLabelSmall", "Faisables", 345, -58, 85, "RIGHT")
  P.list = W.list(left, LEFT_W, 640, 22, function(b)
    b.dot = W.fill(b, 1, 1, 1, 1); b.dot:SetSize(9, 9); b.dot:SetPoint("LEFT", b, "LEFT", 6, 0)
    b.name = W.text(b, "GringottsText", "", 24, -3, 205)
    b.st = W.text(b, "GringottsTextSmall", "", 230, -5, 110, "RIGHT")
    b.n = W.text(b, "GringottsTextSmall", "", 345, -5, 85, "RIGHT")
    if b.name.SetWordWrap then b.name:SetWordWrap(false) end
    b:SetScript("OnClick", function(self) if self.entry and not self.entry.collapsed then S.sel = self.entry.key; U.refresh() end end)
  end, function(b, e)
    b.entry = e
    if e.pkg then
      b.dot:SetColorTexture(.9, .72, .2, 1)
      b.name:SetText(e.name)
      b.st:SetText(e.total and coins(math.floor(e.total)) or W.col(C.red, "pas de prix"))
      b.n:SetText(tostring(e.qty))
      if S.sel == e.key then b.sel:Show() else b.sel:Hide() end
      return
    end
    if e.step then
      if e.collapsed then
        b.dot:SetColorTexture(.3, .73, .09, 1)
        b.name:SetText(W.col(C.grey, ("1 › %d · %d étape(s) terminée(s)"):format(e.upto, e.ndone)))
        b.st:SetText(""); b.n:SetText(""); b.sel:Hide()
        return
      end
      local dc = e.done and DOT[2] or (e.cur and DOT[0] or DOT[3])
      b.dot:SetColorTexture(dc[1], dc[2], dc[3], 1)
      b.name:SetText((e.done and W.col(C.grey, e.s.n)) or (e.cur and W.col(C.gold, e.s.n)) or e.s.n)
      b.st:SetText(e.unpriced > 0 and W.col(C.grey, "sans prix") or coins(math.floor(e.perPoint)))
      b.n:SetText(("%d›%d"):format(e.s.a, e.s.b))
      if S.sel == e.key then b.sel:Show() else b.sel:Hide() end
      return
    end
    local d = DOT[e.d or 3]; b.dot:SetColorTexture(d[1], d[2], d[3], 1)
    b.name:SetText(e.name)
    local st = ST[e.status]
    if S.mode == "level" then
      b.st:SetText((e.learned and "" or W.col(C.gold, "à apprendre  ")) .. (e.unpriced and W.col(C.grey, "sans prix") or coins(math.floor(K.perPoint(e)))))
    else b.st:SetText(W.col(st[2], st[1])) end
    b.n:SetText(e.craftable > 0 and tostring(e.craftable) or W.col(C.grey, "0"))
    if S.sel == e.key then b.sel:Show() else b.sel:Hide() end
  end)
  P.list.frame:SetPoint("TOPLEFT", left, "TOPLEFT", 0, -76)
  -- centre
  local f = CreateFrame("Frame", nil, body); f:SetPoint("TOPLEFT", body, "TOPLEFT", LEFT_W + 20, 0); f:SetPoint("BOTTOMRIGHT", body, "BOTTOMRIGHT", -RIGHT_W - 12, 0)
  local w = 600
  P.title = W.text(f, "GringottsH2", "", 0, 0, w)
  P.sub = W.text(f, "GringottsTextSmall", "", 0, -26, w)
  local tw = math.floor((w - 24) / 4)
  P.tiles = {}
  for i = 1, 4 do local t = W.tile(f, tw, 64); t.frame:SetPoint("TOPLEFT", f, "TOPLEFT", (i - 1) * (tw + 8), -50); P.tiles[i] = t end
  W.text(f, "GringottsLabel", "Composants", 0, -126, w)
  W.text(f, "GringottsLabelSmall", "Composant", 0, -148, 200)
  W.text(f, "GringottsLabelSmall", "Besoin", 210, -148, 60, "RIGHT")
  W.text(f, "GringottsLabelSmall", "En stock", 280, -148, 70, "RIGHT")
  W.text(f, "GringottsLabelSmall", "Manque", 360, -148, 70, "RIGHT")
  W.text(f, "GringottsLabelSmall", "Prix unitaire", 440, -148, 160, "RIGHT")
  P.rows = {}
  for i = 1, 8 do
    local y = -168 - (i - 1) * 20
    local bb = W.button(f, "Acheter", 56, 18, function() local l = P.rows[i].line; if l then local ok, why = K.buyLine(l, tonumber(P.qty:GetText()) or 1); if ok == false and why then K.msg, K.ok = why, false end; U.refresh() end end)
    bb:SetPoint("TOPLEFT", f, "TOPLEFT", 0, y + 1)
    P.rows[i] = { buy = bb, n = W.text(f, "GringottsText", "", 62, y, 143), a = W.text(f, "GringottsTextSmall", "", 210, y - 2, 60, "RIGHT"),
                  b = W.text(f, "GringottsTextSmall", "", 280, y - 2, 70, "RIGHT"), m = W.text(f, "GringottsTextSmall", "", 360, y - 2, 70, "RIGHT"),
                  p = W.text(f, "GringottsTextSmall", "", 440, y - 2, 160, "RIGHT") }
  end
  P.act = CreateFrame("Frame", nil, f); P.act:SetPoint("TOPLEFT", f, "TOPLEFT", 0, -350); P.act:SetSize(w, 270)
  ns.theme.panel(P.act, "okbg", "line")
  P.reco = W.text(P.act, "GringottsText", "", 10, -8, w - 20)
  W.text(P.act, "GringottsTextSmall", "Quantité", 10, -40, 70)
  P.qty = W.edit(P.act, 60, true); P.qty:SetPoint("TOPLEFT", P.act, "TOPLEFT", 82, -36); P.qty:SetText("1")
  P.minus = W.button(P.act, "-", 24, 22, function() P.qty:SetText(tostring(math.max(1, (tonumber(P.qty:GetText()) or 1) - 1))) end); P.minus:SetPoint("TOPLEFT", P.act, "TOPLEFT", 150, -35)
  P.plus = W.button(P.act, "+", 24, 22, function() P.qty:SetText(tostring((tonumber(P.qty:GetText()) or 0) + 1)) end); P.plus:SetPoint("TOPLEFT", P.act, "TOPLEFT", 178, -35)
  P.max = W.button(P.act, "Max", 50, 22, function() local e = U.cur; if e then P.qty:SetText(tostring(math.max(1, e.craftable))) end end); P.max:SetPoint("TOPLEFT", P.act, "TOPLEFT", 208, -35)
  P.craft = W.button(P.act, "Crafter", 190, 26, function()
    local e = U.cur; if e then K.craft(e, tonumber(P.qty:GetText()) or 0); U.refresh() end
  end); P.craft:SetPoint("TOPLEFT", P.act, "TOPLEFT", 10, -70)
  P.plan = W.button(P.act, "Ajouter au plan", 190, 26, function()
    local e = U.cur; if e then K.setPlan(e.key, (K.plan()[e.key] or 0) + (tonumber(P.qty:GetText()) or 0)); ns.gring.reload(); U.refresh() end
  end); P.plan:SetPoint("TOPLEFT", P.act, "TOPLEFT", 210, -70)
  P.shop = W.button(P.act, "Composants manquants › liste d'achats", 390, 24, function()
    local n = tonumber(P.qty:GetText()) or 1
    local src = {}
    if isPkg() then
      local _, pk = pkgList()
      for _, a in ipairs(pk and pk.items or {}) do if a.miss > 0 then ns.engine.addShop(A().norm(a.name), a.miss) end end
      ns.gring.refresh(); return
    end
    if S.mode == "guide" then for _, r in ipairs(P.rows) do if r.line then src[#src + 1] = r.line end end
    elseif U.cur then src = U.cur.lines end
    for _, l in ipairs(src) do
      local miss = math.max(0, l.need * n - l.have)
      if miss > 0 then ns.engine.addShop(A().norm(l.name), miss) end
    end
    ns.gring.refresh()
  end); P.shop:SetPoint("TOPLEFT", P.act, "TOPLEFT", 10, -104)
  P.info = W.text(P.act, "GringottsTextSmall", "", 10, -138, w - 20)
  P.msg = W.text(P.act, "GringottsTextSmall", "", 10, -166, w - 20)
  P.vend = W.text(P.act, "GringottsTextSmall", "", 10, -190, w - 20)
  -- droite : plan et file
  local right = CreateFrame("Frame", nil, body); right:SetPoint("TOPRIGHT", body, "TOPRIGHT", 0, 0); right:SetPoint("BOTTOMRIGHT", body, "BOTTOMRIGHT", 0, 0); right:SetWidth(RIGHT_W)
  ns.theme.panel(right, "panel", "line")
  W.text(right, "GringottsH2", "Plan de craft", 12, -8, RIGHT_W - 24)
  P.planRows = {}
  for i = 1, 12 do
    local y = -40 - (i - 1) * 22
    local r = {}
    r.n = W.text(right, "GringottsText", "", 12, y, 230); r.q = W.text(right, "GringottsTextSmall", "", 246, y - 2, 60, "RIGHT"); r.s = W.text(right, "GringottsTextSmall", "", 308, y - 2, 40, "LEFT")
    r.del = W.button(right, "x", 20, 18, function() if r.key then K.setPlan(r.key, 0); ns.gring.reload(); U.refresh() end end); r.del:SetPoint("TOPLEFT", right, "TOPLEFT", RIGHT_W - 32, y + 2)
    P.planRows[i] = r
  end
  P.planNote = W.text(right, "GringottsTextSmall", "", 12, -312, RIGHT_W - 24)
  P.qBtn = ns.theme.button(right, nil, 370, 34, nil, "primary", "GringottsCraftBtn"); P.qBtn:SetPoint("TOPLEFT", right, "TOPLEFT", 12, -350)
  P.qBtn:SetScript("OnClick", function() if not K.q then K.qStart() end; K.qStep(); U.refresh() end)
  P.qStop = W.button(right, "Arrêter la file", 160, 24, function() K.qStop(); U.refresh() end); P.qStop:SetPoint("TOPLEFT", right, "TOPLEFT", 12, -392)
  W.text(right, "GringottsTextSmall", W.col(C.grey, "Les composants du plan deviennent des besoins dans Stock & achats. Un clic ou Espace = un lot de craft (règle de Blizzard)."), 12, -432, RIGHT_W - 24)
  P.qMsg = W.text(right, "GringottsTextSmall", "", 12, -480, RIGHT_W - 24)
  P.lvlBox = CreateFrame("Frame", nil, right); P.lvlBox:SetPoint("TOPLEFT", right, "TOPLEFT", 0, -520); P.lvlBox:SetSize(RIGHT_W, 240)
  P.lvlTitle = W.text(P.lvlBox, "GringottsLabel", "Étape de montée", 12, 0, RIGHT_W - 24)
  P.ptsLbl = W.text(P.lvlBox, "GringottsTextSmall", "Points à gagner", 12, -28, 120)
  P.pts = W.edit(P.lvlBox, 60, true); P.pts:SetPoint("TOPLEFT", P.lvlBox, "TOPLEFT", 140, -24); P.pts:SetText("10")
  P.step = W.button(P.lvlBox, "Générer l'étape dans le plan", 250, 24, function()
    if S.mode == "guide" then K.guideGen(S.prof); ns.gring.reload() else K.levelStep(S.prof, tonumber(P.pts:GetText()) or 10) end
    U.refresh()
  end); P.step:SetPoint("TOPLEFT", P.lvlBox, "TOPLEFT", 12, -52)
  P.stepInfo = W.text(P.lvlBox, "GringottsTextSmall", "", 12, -86, RIGHT_W - 24)
  P.lvlBox:Hide()
  P.right = right
  P.ready = true
end

-- Barre de craft visible dans tous les onglets : lance la file sans ouvrir Métiers
function U.buildBar(frame)
  local b = ns.theme.button(frame, nil, 420, 26, nil, "primary", "GringottsCraftBar")
  b:SetPoint("BOTTOM", frame, "BOTTOM", 0, 8)
  b:SetScript("OnClick", function() if not K.q then K.qStart() end; K.qStep(); U.refresh() end)
  b:SetScript("OnHide", function() if ClearOverrideBindings then pcall(ClearOverrideBindings, b) end end)
  U.bar = b; U.updateBar()
end
function U.updateBar()
  local b = U.bar; if not b then return end
  local n = 0; for _ in pairs(K.plan()) do n = n + 1 end
  if n == 0 and not K.q then b:Hide(); return end
  b:Show()
  local pend = K.q and K.qPending() or n
  b:SetText(("Crafts du plan : %d restant(s) · clic ou Espace"):format(pend))
  if pend == 0 or K.busy then b:Disable() else b:Enable() end
  local hvBusy = ns.buy and ns.buy.qPending and ns.buy.qPending() > 0
  if K.q and not hvBusy and SetOverrideBindingClick then pcall(SetOverrideBindingClick, b, true, "SPACE", "GringottsCraftBar")
  elseif ClearOverrideBindings then pcall(ClearOverrideBindings, b) end
end

-- Détail d'une étape du guide : composants au prix HV, état de la recette, où l'obtenir
function U.pkgDetail(P, x, pk)
  for k = 1, 4 do P.tiles[k]:Set("", "", "") end
  for k = 1, 8 do local r = P.rows[k]; r.line = nil; r.buy:Hide(); r.n:SetText(""); r.a:SetText(""); r.b:SetText(""); r.m:SetText(""); r.p:SetText("") end
  P.craft:Disable(); P.plan:Disable(); P.shop:Enable(); P.vend:SetText("")
  P.title:SetText("Package " .. S.prof .. " 1 › 300")
  P.sub:SetText("Tout ce qu'il faut acheter pour monter de 1 à 300 (étapes parallèles exclues), aux prix HV du moment")
  if not pk then return end
  P.tiles[1]:Set("Coût total", pk.unpriced > 0 and (coins(math.floor(pk.total)) .. " +?") or coins(math.floor(pk.total)), "matériaux au prix HV")
  P.tiles[2]:Set("Matériaux", tostring(#pk.items), "lignes distinctes")
  P.tiles[3]:Set("Sans prix", tostring(pk.unpriced), pk.unpriced > 0 and "non comptés dans le total" or "tout est chiffré")
  P.tiles[4]:Set("Recettes", tostring(pk.nrec), "à acheter / trouver, hors total")
  if x then
    P.reco:SetText(W.col(C.gold, x.name) .. ("  ·  %d à acheter au total  ·  en stock %d  ·  manque %d"):format(x.qty, x.have, x.miss))
    for k, u in ipairs(x.uses) do
      local r = P.rows[k]; if not r then break end
      r.n:SetText(("%s (%d›%d)"):format(u.n, u.a, u.b)); r.a:SetText(tostring(u.q))
      r.p:SetText(x.price and coins(math.floor(x.price * u.q)) or W.col(C.red, "pas de prix"))
    end
  else P.reco:SetText("") end
  local rl = {}
  for _, s in ipairs(pk.recipes) do rl[#rl + 1] = ("%s (%d›%d) : %s"):format(s.n, s.a, s.b, (s.note or ""):gsub("%s*|.*$", "")) end
  P.info:SetText(#rl > 0 and W.col(C.grey, "Recettes (non comptées) :\n" .. table.concat(rl, "\n")) or "")
end

function U.guideDetail(P, x)
  local function clear()
    for k = 1, 4 do P.tiles[k]:Set("", "", "") end
    for k = 1, 8 do P.rows[k].line = nil; P.rows[k].buy:Hide(); P.rows[k].n:SetText(""); P.rows[k].a:SetText(""); P.rows[k].b:SetText(""); P.rows[k].m:SetText(""); P.rows[k].p:SetText("") end
    P.reco:SetText(""); P.info:SetText(""); P.vend:SetText("")
    P.craft:Disable(); P.plan:Disable(); P.shop:Disable()
  end
  if not x or x.collapsed then
    clear()
    P.title:SetText(W.col(C.grey, K.guide(S.prof) and "Aucune étape" or "Pas de guide pour ce métier")); P.sub:SetText("")
    return
  end
  local s, e = x.s, x.recipe
  local lvl = K.skillOf(S.prof)
  if U.qtyKey ~= x.key then U.qtyKey = x.key; P.qty:SetText(tostring(math.max(1, x.left > 0 and x.left or s.c))) end
  P.title:SetText(s.n)
  P.sub:SetText(("Étape %d › %d  ·  %d crafts  ·  environ %s point par craft"):format(s.a, s.b, s.c, (("%.1f"):format((s.b - s.a) / math.max(s.c, 1))):gsub("%.", ",")))
  P.tiles[1]:Set("Coût à l'HV", x.unpriced > 0 and (coins(math.floor(x.cost)) .. " +?") or coins(math.floor(x.cost)), x.unpriced > 0 and (x.unpriced .. " composant(s) sans prix") or ("pour " .. x.left .. " craft(s) restants"))
  P.tiles[2]:Set("Coût par point", x.unpriced > 0 and W.col(C.grey, "sans prix") or coins(math.floor(x.perPoint)), "prix HV du moment")
  P.tiles[3]:Set("Gain visé", "+" .. (s.b - s.a), ("%d › %d"):format(s.a, s.b))
  P.tiles[4]:Set("Reste à gagner", tostring(math.max(0, 300 - lvl)), "pour atteindre 300")
  local stock = ns.engine.stockMap()
  local nq = math.max(1, s.c)
  for k = 1, 8 do
    local m = s.m[k]; local r = P.rows[k]
    if m then
      local name, tot = m[1], m[2]
      local id = (A().db().ids or {})[A().norm(name)]
      local p = ns.prices.price(name, id)
      local have = stock[A().norm(name)] or 0
      local miss = math.max(0, tot - have)
      r.line = { name = name, id = id, need = math.ceil(tot / nq), have = have, miss = miss, price = p }
      if miss > 0 and K.canBuyLine(r.line) and not ns.buy.state then r.buy:Show(); r.buy:Enable() else r.buy:Show(); r.buy:Disable() end
      r.n:SetText(name); r.a:SetText(tostring(tot)); r.b:SetText(tostring(have)); r.m:SetText(miss > 0 and W.col(C.orange, tostring(miss)) or W.col(C.grey, "0"))
      r.p:SetText(p and coins(p) or W.col(C.red, "pas de prix"))
    else r.line = nil; r.buy:Hide(); r.n:SetText(""); r.a:SetText(""); r.b:SetText(""); r.m:SetText(""); r.p:SetText("") end
  end
  local state
  if x.done then state = W.col(C.green, "Étape terminée")
  elseif e and e.learned then state = W.col(C.green, "Prête à crafter") .. "  ·  recette apprise"
  elseif s.src == "k" then state = W.col(C.green, "Recette connue d'office")
  elseif s.src == "t" then state = W.col(C.gold, "Chez l'entraîneur")
  elseif s.src == "f" then state = W.col(C.orange, "Recette à trouver")
  else state = W.col(C.gold, "Recette à apprendre") end
  P.reco:SetText(state .. (s.note and s.note ~= "" and ("  ·  " .. (s.note:gsub("%s*|.*$", ""))) or "") .. (x.cur and W.col(C.gold, "  ·  étape en cours") or ""))
  if e then local ok, why = K.canCraft(e); P.info:SetText(ok and "" or W.col(C.grey, why or "")) else P.info:SetText(W.col(C.grey, "Recette non vue en jeu : ouvre la fenêtre du métier pour que Gringotts la lise.")) end
  P.vend:SetText((e and e.learned) and "" or guideVendorText(x))
  if e and e.learned and e.craftable > 0 and not K.busy then P.craft:Enable() else P.craft:Disable() end
  if e and e.learned then P.plan:Enable() else P.plan:Disable() end
  P.shop:Enable()
  P.craft:SetText(K.busy and "Craft en cours..." or "Crafter")
end

function U.refresh()
  local P = U.p; if not (P and P.ready) then return end
  K.refresh()
  local profs = K.professions()
  if #profs == 0 then
    P.body:Hide(); for _, b in ipairs(P.profBtns) do b:Hide() end; P.modeA:Hide(); P.modeB:Hide(); P.modeG:Hide()
    P.empty:SetText(W.col(C.grey, "Aucune recette connue : ouvre la fenêtre de chaque métier (une fois) sur chaque personnage pour que Gringotts lise tes recettes."))
    return
  end
  P.empty:SetText(""); P.body:Show(); P.modeA:Show(); P.modeB:Show(); P.modeG:Show()
  if S.mode == "profit" then P.modeA:Disable() else P.modeA:Enable() end
  if S.mode == "level" then P.modeB:Disable() else P.modeB:Enable() end
  P.modeG:SetText(K.guide(S.prof) and K.skillOf(S.prof) >= 300 and "Package 1-300" or "Guide 1-300")
  if S.mode == "guide" then P.modeG:Disable() else P.modeG:Enable() end
  local okp = false; for _, p in ipairs(profs) do if p == S.prof then okp = true end end
  if not okp then S.prof = profs[1] end
  for i, b in ipairs(P.profBtns) do
    local p = profs[i]
    if p then b.prof = p; b:SetText(p); b:Show(); if p == S.prof then b:Disable() else b:Enable() end else b:Hide() end
  end
  P.head:SetText(S.prof)
  local mx; for _, c in pairs(A().db().chars or {}) do local k = (c.skills or {})[S.prof]; if k and (not mx or k.l > mx.l) then mx = k end end
  P.skill:SetText(mx and ("niveau %d / %d"):format(mx.l, mx.m) or "")
  local pkg = isPkg()
  local lab = pkg and { all = "Toutes", can = "Sans prix", good = "Manquants" } or S.mode == "guide" and { all = "Toutes", can = "Restantes", good = "Avec prix" }
    or S.mode == "level" and { all = "Toutes", can = "Connues", good = "À apprendre" } or { all = "Toutes", can = "Faisables", good = "Rentables" }
  for k, b in pairs(P.chips) do b:SetText(lab[k]); if k == S.chip then b:Disable() else b:Enable() end end
  local guide = S.mode == "guide"
  local list, pk
  if pkg then list, pk = pkgList() else list = guide and guideList() or shown() end
  P.list:SetData(list, true)
  local sel; for _, e in ipairs(list) do if e.key == S.sel then sel = e end end
  if not sel then
    if pkg then sel = list[1]
    elseif guide then for _, e in ipairs(list) do if e.cur then sel = e end end; if not sel then for _, e in ipairs(list) do if not e.collapsed then sel = e; break end end end
    else sel = list[1] end
    S.sel = sel and sel.key or nil
  end
  if pkg then U.cur = nil elseif guide then U.cur = sel and sel.recipe or nil else U.cur = sel end
  P.h1:SetText(pkg and "Matériau" or guide and "Étape" or "Recette")
  P.h2:SetText(pkg and "Coût total" or (guide or S.mode == "level") and "Coût par point" or "Statut")
  P.h3:SetText(pkg and "Quantité" or guide and "Niveaux" or "Faisables")
  P.shop:SetText(pkg and "Tout le package › liste d'achats (manquants)" or "Composants manquants › liste d'achats")
  if pkg then P.lvlBox:Hide()
  elseif S.mode == "level" or guide then
    P.lvlBox:Show()
    P.lvlTitle:SetText(guide and "Guide 1-300" or "Étape de montée")
    if guide then P.ptsLbl:Hide(); P.pts:Hide(); P.step:SetText("Générer le plan du guide") else P.ptsLbl:Show(); P.pts:Show(); P.step:SetText("Générer l'étape dans le plan") end
  else P.lvlBox:Hide() end
  -- plan
  local n, i = 0, 1
  local keys = {}; for key in pairs(K.plan()) do keys[#keys + 1] = key end; table.sort(keys)
  for _, r in ipairs(P.planRows) do r.key = nil; r.n:SetText(""); r.q:SetText(""); r.s:SetText(""); r.del:Hide() end
  for _, key in ipairs(keys) do
    local r = P.planRows[i]; if not r then break end
    r.key = key; r.n:SetText(key:match(":(.*)$") or key); r.q:SetText("x " .. K.plan()[key]); r.del:Show()
    if K.q then for _, it in ipairs(K.q.items) do if it.e.key == key then r.s:SetText(W.col(it.state == "done" and C.green or (it.state == "skip" and C.orange or C.white), it.state == "done" and "OK" or (it.state == "skip" and "!" or ""))) end end end
    i = i + 1
  end
  P.planNote:SetText(#keys == 0 and W.col(C.grey, "Plan vide : « Ajouter au plan » sur une recette.") or "")
  local pend = K.q and K.qPending() or #keys
  P.qBtn:SetText(#keys == 0 and "Rien à crafter" or ("Lancer le suivant (Espace) · " .. pend .. " restant(s)"))
  if #keys == 0 or not K.available() then P.qBtn:Disable() else P.qBtn:Enable() end
  local si = K.lastStep
  if guide then
    local gi = K.lastGuide
    if not K.guide(S.prof) then P.stepInfo:SetText(W.col(C.grey, "Pas de guide 1-300 pour ce métier."))
    elseif gi then
      local t = ("%d étape(s) ajoutée(s) au plan (%d crafts)\nCoût des composants restants : %s"):format(gi.planned, gi.crafts, A().coins(math.floor(gi.cost)))
      if gi.unpriced > 0 then t = t .. W.col(C.grey, ("\n%d composant(s) sans prix : non comptés"):format(gi.unpriced)) end
      if #gi.learn > 0 then t = t .. "\n" .. W.col(C.gold, ("%d recette(s) à apprendre"):format(#gi.learn)) end
      if #gi.find > 0 then t = t .. "\n" .. W.col(C.orange, ("%d recette(s) à trouver"):format(#gi.find)) end
      P.stepInfo:SetText(t)
    else P.stepInfo:SetText(W.col(C.grey, "Ajoute au plan les crafts restants dont tu connais la recette. Régénère après avoir monté.")) end
  elseif si and si.recipe then
    local t = ("Étape : %d × %s\ncoût estimé %s"):format(si.n, si.recipe.name, A().coins(math.floor(si.cost)))
    if si.learn then t = t .. ("\nÀ apprendre : %s (%s par point au lieu de %s)"):format(si.learn.name, A().coins(math.floor(K.perPoint(si.learn))), A().coins(math.floor(K.perPoint(si.recipe))))
      local vl = ns.rv and ns.rv.lines(si.learn.name, 1, VCOL, function(c) return A().coins(c) end) or {}
      for _, l in ipairs(vl) do t = t .. "\n" .. l end
    end
    P.stepInfo:SetText(t)
  elseif si then P.stepInfo:SetText(W.col(C.orange, "Aucune recette connue et chiffrée pour monter.")) else P.stepInfo:SetText(W.col(C.grey, "Les points sont estimés : orange = 1 point par craft, jaune = 1 point pour 2 crafts. Régénère l'étape après avoir monté (les couleurs changent).")) end
  U.updateBar()
  P.qMsg:SetText(K.msg and W.col(K.ok and C.green or C.orange, K.msg) or "")
  -- détail
  if pkg then return U.pkgDetail(P, sel, pk) end
  if guide then return U.guideDetail(P, sel) end
  if not sel then
    P.title:SetText(W.col(C.grey, "Aucune recette")); P.sub:SetText(""); for k = 1, 4 do P.tiles[k]:Set("", "", "") end
    for k = 1, 8 do P.rows[k].buy:Hide(); P.rows[k].n:SetText(""); P.rows[k].a:SetText(""); P.rows[k].b:SetText(""); P.rows[k].m:SetText(""); P.rows[k].p:SetText("") end
    P.reco:SetText(""); P.info:SetText(""); return
  end
  local e = sel
  P.title:SetText(e.name)
  local who = {}; for nme in pairs(e.who) do who[#who + 1] = nme end; table.sort(who)
  P.sub:SetText(e.learned and ("%s · sait la faire : %s"):format(e.d and ("difficulté " .. K.DIFF[e.d]) or "", table.concat(who, ", "))
    or W.col(C.gold, "Recette à apprendre") .. (e.d and ("  ·  difficulté " .. K.DIFF[e.d]) or "") .. "  ·  " .. (e.src or "source inconnue : ouvre la fenêtre du métier"))
  P.tiles[1]:Set("Coût des composants", coins(e.cost), "prix HV du moment")
  P.tiles[2]:Set("Vente nette (×" .. e.q .. ")", coins(e.net), e.outPrice and ("prix HV " .. A().coins(e.outPrice)) or "")
  P.tiles[3]:Set("Profit / craft", e.profit and (e.profit >= 0 and coins(e.profit) or W.col(C.red, "-") .. coins(-e.profit)) or "—", e.margin and (pct(e.margin) .. " de marge") or "")
  P.tiles[4]:Set("Faisables", tostring(e.craftable), "avec le stock de tous tes persos")
  for k = 1, 8 do
    local l = e.lines[k]; local r = P.rows[k]
    r.line = l
    if l then
      local nq = tonumber(P.qty:GetText()) or 1
      if (l.need * nq - l.have) > 0 and K.canBuyLine(l) and not ns.buy.state then r.buy:Show(); r.buy:Enable() else r.buy:Show(); r.buy:Disable() end
      r.n:SetText(l.name); r.a:SetText(tostring(l.need)); r.b:SetText(tostring(l.have)); r.m:SetText(l.miss > 0 and W.col(C.orange, tostring(l.miss)) or W.col(C.grey, "0")); r.p:SetText(l.price and coins(l.price) or W.col(C.red, "pas de prix"))
    else r.buy:Hide(); r.n:SetText(""); r.a:SetText(""); r.b:SetText(""); r.m:SetText(""); r.p:SetText("") end
  end
  local st = ST[e.status]
  if S.mode == "level" then
    P.reco:SetText(W.col(st[2], st[1]) .. ("  ·  %s par point de compétence attendu (%d %% de chance)"):format(A().coins(math.floor(K.perPoint(e))), math.floor((K.CHANCE[e.d or 1] or .5) * 100)))
  else
  P.reco:SetText(W.col(st[2], st[1]) .. (e.status == "go" and ("  ·  %d faisables, profit %s par craft"):format(e.craftable, A().coins(e.profit)) or ""))
  end
  local ok, why = K.canCraft(e)
  P.info:SetText(ok and "" or W.col(C.grey, why or ""))
  P.vend:SetText(vendorText(e))
  if ok and e.craftable > 0 and not K.busy then P.craft:Enable() else P.craft:Disable() end
  if e.learned then P.plan:Enable() else P.plan:Disable() end
  P.craft:SetText(K.busy and "Craft en cours..." or "Crafter")
end
