-- Gringotts : journal d'erreurs et gardes. Les erreurs Lua venant de Gringotts sont comptées (fichier, ligne, nombre, trace) dans
-- GringottsDB.errors ; /gt erreurs les affiche, /gt erreurs copier ouvre une fenêtre à copier-coller, /gt erreurs vider les efface.
-- ns.safe(fn, nom) renvoie une fonction qui attrape les erreurs (journalisées) au lieu de déclencher le popup de Blizzard.
local ADDON, ns = ...

local function store()
  GringottsDB = GringottsDB or {}
  GringottsDB.errors = GringottsDB.errors or {}
  return GringottsDB.errors
end

local function sig(msg)
  msg = tostring(msg or "?")
  return (msg:gsub("%d+:%d+:%d+", ""):gsub("0x%x+", ""):sub(1, 240))
end

function ns.logError(msg, stack, label)
  local e = store()
  local k = sig(msg)
  local r = e[k]
  if not r then
    -- 40 erreurs distinctes au maximum : on retire la plus ancienne
    local n, oldest, ot = 0, nil, math.huge
    for key, v in pairs(e) do n = n + 1; if (v.last or 0) < ot then oldest, ot = key, v.last or 0 end end
    if n >= 40 and oldest then e[oldest] = nil end
    r = { msg = tostring(msg), count = 0, first = time and time() or 0 }
    e[k] = r
  end
  r.count = (r.count or 0) + 1
  r.last = time and time() or 0
  r.label = label or r.label
  if not r.stack and stack then r.stack = tostring(stack):sub(1, 1500) end
end

-- Hook sur le gestionnaire d'erreurs : on journalise ce qui vient de Gringotts, puis on laisse Blizzard faire comme avant.
local hooked
local function install()
  if hooked or not (geterrorhandler and seterrorhandler) then return end
  local prev = geterrorhandler()
  if type(prev) ~= "function" then return end
  seterrorhandler(function(msg, ...)
    local m = tostring(msg or "")
    if m:find("Gringotts", 1, true) then
      local ok, st = pcall(debugstack, 2, 8, 0)
      pcall(ns.logError, m, ok and st or nil)
    end
    return prev(msg, ...)
  end)
  hooked = true
end
install()
local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", function() hooked = false; install() end)

function ns.safe(fn, label)
  return function(...)
    local ok, err = xpcall(fn, function(m)
      local good, st = pcall(debugstack, 2, 8, 0)
      pcall(ns.logError, m, good and st or nil, label)
      return m
    end, ...)
    if ok then return err end   -- xpcall renvoie true, résultat : on ne propage que le résultat utile
  end
end

-- Appel protégé qui renvoie les résultats de fn (pour les lectures d'API susceptibles de renvoyer des valeurs masquées)
function ns.try(fn, ...)
  local r = { pcall(fn, ...) }
  if not r[1] then return nil end
  if issecretvalue then
    for i = 2, #r do if issecretvalue(r[i]) then r[i] = nil end end
  end
  return unpack(r, 2)
end

local function fmt(r)
  local ago = (time and r.last) and (time() - r.last) or 0
  local when = ago < 120 and "à l'instant" or (ago < 7200 and (math.floor(ago / 60) .. " min") or (math.floor(ago / 3600) .. " h"))
  return ("x%d · %s · %s"):format(r.count or 1, when, (tostring(r.msg):gsub("|", "||")))
end

local function sorted()
  local out = {}
  for _, r in pairs(store()) do out[#out + 1] = r end
  table.sort(out, function(a, b) return (a.last or 0) > (b.last or 0) end)
  return out
end

local function report(full)
  local lines = { "Gringotts : journal d'erreurs" }
  local list = sorted()
  if #list == 0 then lines[#lines + 1] = "Aucune erreur enregistrée." end
  for i, r in ipairs(list) do
    lines[#lines + 1] = ("%d. %s"):format(i, fmt(r))
    if full and r.stack then lines[#lines + 1] = r.stack end
  end
  return lines
end

local box
local function showBox(text)
  if not box then
    box = CreateFrame("Frame", "GringottsErrBox", UIParent, "BackdropTemplate")
    box:SetSize(640, 360); box:SetPoint("CENTER"); box:SetFrameStrata("DIALOG")
    if box.SetBackdrop then box:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 }); box:SetBackdropColor(.05, .06, .09, .96); box:SetBackdropBorderColor(.3, .35, .45, 1) end
    box:EnableMouse(true); box:SetMovable(true); box:RegisterForDrag("LeftButton")
    box:SetScript("OnDragStart", box.StartMoving); box:SetScript("OnDragStop", box.StopMovingOrSizing)
    local sf = CreateFrame("ScrollFrame", "GringottsErrBoxScroll", box, "UIPanelScrollFrameTemplate")
    sf:SetPoint("TOPLEFT", 12, -12); sf:SetPoint("BOTTOMRIGHT", -32, 40)
    local eb = CreateFrame("EditBox", nil, sf)
    eb:SetMultiLine(true); eb:SetFontObject(ChatFontNormal); eb:SetWidth(590); eb:SetAutoFocus(false)
    eb:SetScript("OnEscapePressed", function() box:Hide() end)
    sf:SetScrollChild(eb); box.eb = eb
    local close = CreateFrame("Button", nil, box, "UIPanelButtonTemplate")
    close:SetSize(100, 22); close:SetPoint("BOTTOMRIGHT", -12, 10); close:SetText("Fermer"); close:SetScript("OnClick", function() box:Hide() end)
    local hint = box:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); hint:SetPoint("BOTTOMLEFT", 14, 16); hint:SetText("Ctrl+A puis Ctrl+C pour copier")
    if UISpecialFrames then tinsert(UISpecialFrames, "GringottsErrBox") end
  end
  box.eb:SetText(text); box.eb:HighlightText(); box:Show(); box.eb:SetFocus()
end

function ns.errorsCmd(arg)
  arg = (arg or ""):lower()
  if arg == "vider" or arg == "clear" then
    if GringottsDB then GringottsDB.errors = {} end
    print("|cffe4b84eGringotts|r journal d'erreurs vidé.")
  elseif arg == "copier" or arg == "copy" then
    showBox(table.concat(report(true), "\n"))
  else
    for _, l in ipairs(report(false)) do print("|cffe4b84eGringotts|r " .. l) end
    print("|cffe4b84eGringotts|r /gt erreurs copier : fenêtre à copier · /gt erreurs vider : effacer")
  end
end
