-- Gringotts : vues reprises du dashboard : Enchantements (service en /w), Désenchantement, journal des ventes et achats.
-- Les deux premières sont des sous-onglets de Business (UIGring) ; le journal s'ajoute à Finances.
local ADDON, ns = ...
local W = ns.W
local C = W.C
local G = ns.gring
local X = {}
ns.extra = X

local function A() return ns.api end
local function E() return ns.engine end
local function norm(s) return ns.api.norm(s) end
local function coins(c) return c and A().coins(c) or W.col(C.grey, "—") end
local function sameRealm(c) return c.realm == A().realm() and c.faction == A().faction() end

-- prix court (colonnes étroites) : 12,3 po / 45 pa
local function short(c)
  if not c then return "—" end
  if c >= 10000 then return (("%.1f po"):format(c / 10000):gsub("%.0 po", " po")) end
  if c >= 100 then return ("%d pa"):format(math.floor(c / 100 + .5)) end
  return ("%d pc"):format(math.floor(c))
end

------------------------------------------------------------------------
-- Enchantements : coût des composants au prix HV, prix de vente du service, annonce prête à copier
------------------------------------------------------------------------
local EN = { sel = nil, chip = "all", rows = {} }

local function isEnchProf(p) return norm(p or "") == "enchantement" end

local function enchRows()
  local s = E().cfg()
  local out = {}
  for _, e in ipairs(ns.crafts.cache or {}) do
    if isEnchProf(e.prof) then
      local cost = e.cost or 0
      local price = (not e.unpriced) and cost > 0 and math.ceil(cost * (1 + s.enchMarkup) / 10000 - 1e-9) * 10000 or nil
      local net = price and (price - cost) or nil
      local roi = (net and cost > 0) and net / cost or nil
      local st = (not net) and "noprice" or (net < 0 and "bad") or ((roi or 0) < s.roiOk and "warn") or "ok"
      out[#out + 1] = { e = e, name = e.name, cost = cost, price = price, net = net, roi = roi, st = st, possible = e.craftable or 0, learned = e.learned }
    end
  end
  table.sort(out, function(a, b)
    if (a.net ~= nil) ~= (b.net ~= nil) then return a.net ~= nil end
    if a.net ~= b.net then return (a.net or 0) > (b.net or 0) end
    return a.name < b.name
  end)
  return out
end

local function announce(rows)
  local pick = {}
  for _, r in ipairs(rows) do
    if r.learned and r.possible >= 1 and r.net and r.net > 0 then pick[#pick + 1] = r end
  end
  table.sort(pick, function(a, b) return a.net > b.net end)
  local parts = {}
  for i = 1, math.min(5, #pick) do parts[#parts + 1] = ("%s %dg"):format(pick[i].name, math.floor(pick[i].price / 10000 + .5)) end
  if #parts == 0 then return "", 0 end
  return "Enchantement disponible (go /w pour d'autres besoins) : " .. table.concat(parts, ", ") .. ". Bon jeu!", #parts
end

local STC = { ok = { "Rentable", C.green }, warn = { "Marge faible", C.orange }, bad = { "En perte", C.red }, noprice = { "Prix manquant", C.grey } }

function G.buildEnchant(pane)
  local P = {}
  local LW = 620
  W.text(pane, "GringottsH2", "Enchantements", 0, 0, 300)
  P.sub = W.text(pane, "GringottsTextSmall", "", 0, -26, 900)
  P.annT = W.text(pane, "GringottsLabel", "Annonce prête à copier", 0, -52, 300)
  P.ann = W.edit(pane, 900, false)
  P.ann:SetPoint("TOPLEFT", pane, "TOPLEFT", 0, -72); P.ann:SetAutoFocus(false)
  P.annB = W.button(pane, "Sélectionner", 110, 24, function() P.ann:SetFocus(); P.ann:HighlightText() end)
  P.annB:SetPoint("TOPLEFT", pane, "TOPLEFT", 910, -70)
  P.annNote = W.text(pane, "GringottsTextSmall", W.col(C.grey, "Ctrl+C pour copier, puis colle dans le chat. Recalculée avec tes prix et ton stock."), 0, -100, 900)
  P.chips = {}
  local x = 0
  for _, c in ipairs({ { "all", "Toutes" }, { "ok", "Rentables" }, { "can", "Faisables" } }) do
    local b = W.button(pane, c[2], 100, 22, function() EN.chip = c[1]; P.Refresh(P) end); b:SetPoint("TOPLEFT", pane, "TOPLEFT", x, -124); P.chips[c[1]] = b; x = x + 104
  end
  W.text(pane, "GringottsLabelSmall", "Enchantement", 24, -154, 300)
  W.text(pane, "GringottsLabelSmall", "Coût compos", 300, -154, 90, "RIGHT")
  W.text(pane, "GringottsLabelSmall", "Prix service", 392, -154, 90, "RIGHT")
  W.text(pane, "GringottsLabelSmall", "Bénéfice", 484, -154, 80, "RIGHT")
  W.text(pane, "GringottsLabelSmall", "Faisables", 566, -154, 50, "RIGHT")
  P.list = W.list(pane, LW, 560, 22, function(b)
    b.dot = W.fill(b, 1, 1, 1, 1); b.dot:SetSize(9, 9); b.dot:SetPoint("LEFT", b, "LEFT", 6, 0)
    b.name = W.text(b, "GringottsText", "", 24, -3, 270)
    b.cost = W.text(b, "GringottsTextSmall", "", 300, -5, 90, "RIGHT")
    b.price = W.text(b, "GringottsTextSmall", "", 392, -5, 90, "RIGHT")
    b.net = W.text(b, "GringottsTextSmall", "", 484, -5, 80, "RIGHT")
    b.n = W.text(b, "GringottsTextSmall", "", 566, -5, 44, "RIGHT")
    if b.name.SetWordWrap then b.name:SetWordWrap(false) end
    b:SetScript("OnClick", function(self) EN.sel = self.entry.name; P.Refresh(P) end)
  end, function(b, r)
    b.entry = r
    local st = STC[r.st]
    b.dot:SetColorTexture(st[2][1], st[2][2], st[2][3], 1)
    b.name:SetText((r.learned and "" or W.col(C.grey, "(non apprise) ")) .. r.name)
    b.cost:SetText(short(r.cost)); b.price:SetText(short(r.price))
    b.net:SetText(r.net and ((r.net >= 0 and W.col(C.green, "+") or W.col(C.red, "-")) .. short(math.abs(r.net))) or "—")
    b.n:SetText(tostring(r.possible))
    if EN.sel == r.name then b.sel:Show() else b.sel:Hide() end
  end)
  P.list.frame:SetPoint("TOPLEFT", pane, "TOPLEFT", 0, -174)
  local right = CreateFrame("Frame", nil, pane); right:SetPoint("TOPRIGHT", pane, "TOPRIGHT", 0, -150); right:SetPoint("BOTTOMRIGHT", pane, "BOTTOMRIGHT", 0, 0); right:SetWidth(400)
  ns.theme.panel(right, "panel", "line")
  P.dTitle = W.text(right, "GringottsH2", "", 12, -10, 376)
  P.dSub = W.text(right, "GringottsTextSmall", "", 12, -36, 376)
  P.dLines = {}
  for i = 1, 8 do
    P.dLines[i] = { n = W.text(right, "GringottsText", "", 12, -64 - (i - 1) * 22, 190), q = W.text(right, "GringottsTextSmall", "", 204, -66 - (i - 1) * 22, 70, "RIGHT"),
      p = W.text(right, "GringottsTextSmall", "", 276, -66 - (i - 1) * 22, 110, "RIGHT") }
  end
  P.dTot = W.text(right, "GringottsText", "", 12, -250, 376)
  P.empty = W.text(pane, "GringottsText", "", 0, -190, 700)
  function P:Refresh()
    ns.crafts.refresh()
    local rows = enchRows()
    EN.rows = rows
    local s = E().cfg()
    local shown = {}
    for _, r in ipairs(rows) do
      if EN.chip == "all" or (EN.chip == "ok" and r.st == "ok") or (EN.chip == "can" and r.possible >= 1) then shown[#shown + 1] = r end
    end
    for k, b in pairs(self.chips) do if k == EN.chip then b:Disable() else b:Enable() end end
    self.list:SetData(shown, true)
    self.sub:SetText(W.col(C.grey, ("Prix du service = coût des composants au prix HV + %d %%, arrondi à la pièce d'or. %d enchantements relevés."):format(math.floor(s.enchMarkup * 100 + .5), #rows)))
    local txt, n = announce(rows)
    self.ann:SetText(txt)
    if #rows == 0 then self.empty:SetText(W.col(C.orange, "Aucun enchantement relevé : ouvre la fenêtre d'Enchantement en jeu avec un enchanteur, les recettes sont alors lues automatiquement."))
    elseif n == 0 then self.empty:SetText(W.col(C.grey, "Aucune annonce : aucun enchantement appris, rentable et faisable avec ton stock.")) else self.empty:SetText("") end
    local cur
    for _, r in ipairs(rows) do if r.name == EN.sel then cur = r end end
    for _, l in ipairs(self.dLines) do l.n:SetText(""); l.q:SetText(""); l.p:SetText("") end
    if not cur then self.dTitle:SetText("Détail"); self.dSub:SetText(W.col(C.grey, "Choisis un enchantement dans la liste.")); self.dTot:SetText(""); return end
    self.dTitle:SetText(cur.name)
    local st = STC[cur.st]
    self.dSub:SetText(W.col(st[2], st[1]) .. (cur.roi and ("  ·  ROI %d %%"):format(math.floor(cur.roi * 100 + .5)) or ""))
    for i, ln in ipairs(cur.e.lines or {}) do
      local l = self.dLines[i]; if not l then break end
      l.n:SetText(ln.name)
      l.q:SetText(("%d / %d"):format(ln.have, ln.need))
      l.p:SetText(ln.price and short(ln.price * ln.need) or W.col(C.red, "prix manquant"))
    end
    self.dTot:SetText(("Coût %s  ·  Service %s  ·  Bénéfice %s"):format(short(cur.cost), short(cur.price), cur.net and short(cur.net) or "—"))
  end
  return P
end

------------------------------------------------------------------------
-- Désenchantement : objets en stock (sacs et banques de tous les persos) et prix d'achat maximal par tranche d'ilvl
------------------------------------------------------------------------
local DE = { rows = {} }
local QN = { [2] = "Vert", [3] = "Bleu", [4] = "Épique" }
local BR = { { 5, 10 }, { 11, 15 }, { 16, 20 }, { 21, 25 }, { 26, 30 }, { 31, 35 }, { 36, 40 }, { 41, 45 }, { 46, 50 }, { 51, 55 }, { 56, 999 } }

local function deRows()
  local out = {}
  local cut = E().cfg().fee
  local me = UnitName and UnitName("player")
  for _, c in pairs(A().db().chars or {}) do
    if sameRealm(c) then
      for _, lst in ipairs({ c.equipBags or {}, c.equipBank or {} }) do
        for _, e in ipairs(lst) do
          local de = ns.deValue and ns.deValue(e.l or 0, e.q or 2, e.c or 4) or nil
          local ah = (c.name == me and e.link and ns.ahPriceOfLink) and ns.ahPriceOfLink(e.link) or nil
          local ahNet = ah and math.floor(ah * (1 - cut)) or nil
          local opts = {}
          if (e.s or 0) > 0 then opts[#opts + 1] = { "Marchand", e.s } end
          if de and de > 0 then opts[#opts + 1] = { "Désenchanter", de } end
          if ahNet and ahNet > 0 then opts[#opts + 1] = { "HV", ahNet } end
          table.sort(opts, function(a, b) return a[2] > b[2] end)
          out[#out + 1] = { name = e.n, char = c.name, l = e.l or 0, q = e.q or 2, cl = e.c or 4, de = de, sell = e.s or 0, ah = ahNet,
            best = opts[1] and opts[1][1] or "—", gain = opts[1] and opts[1][2] or 0 }
        end
      end
    end
  end
  table.sort(out, function(a, b) if a.gain ~= b.gain then return a.gain > b.gain end return a.name < b.name end)
  return out
end

local BESTC = { ["Désenchanter"] = C.blue, HV = C.green, Marchand = C.grey }

function G.buildDE(pane)
  local P = {}
  local LW = 860
  W.text(pane, "GringottsH2", "Désenchantement", 0, 0, 300)
  P.sub = W.text(pane, "GringottsTextSmall", "", 0, -26, 1000)
  W.text(pane, "GringottsLabelSmall", "Objet", 6, -56, 280)
  W.text(pane, "GringottsLabelSmall", "Perso", 290, -56, 110)
  W.text(pane, "GringottsLabelSmall", "ilvl", 400, -56, 36, "RIGHT")
  W.text(pane, "GringottsLabelSmall", "Qualité", 446, -56, 80)
  W.text(pane, "GringottsLabelSmall", "Désench.", 520, -56, 80, "RIGHT")
  W.text(pane, "GringottsLabelSmall", "Marchand", 604, -56, 70, "RIGHT")
  W.text(pane, "GringottsLabelSmall", "HV (net)", 678, -56, 70, "RIGHT")
  W.text(pane, "GringottsLabelSmall", "Meilleur choix", 756, -56, 100)
  P.list = W.list(pane, LW, 600, 22, function(b)
    b.name = W.text(b, "GringottsText", "", 6, -3, 280)
    b.char = W.text(b, "GringottsTextSmall", "", 290, -5, 110)
    b.l = W.text(b, "GringottsTextSmall", "", 400, -5, 36, "RIGHT")
    b.q = W.text(b, "GringottsTextSmall", "", 446, -5, 80)
    b.de = W.text(b, "GringottsTextSmall", "", 520, -5, 80, "RIGHT")
    b.s = W.text(b, "GringottsTextSmall", "", 604, -5, 70, "RIGHT")
    b.ah = W.text(b, "GringottsTextSmall", "", 678, -5, 70, "RIGHT")
    b.best = W.text(b, "GringottsTextSmall", "", 756, -5, 96)
    if b.name.SetWordWrap then b.name:SetWordWrap(false) end
  end, function(b, r)
    b.name:SetText(r.name); b.char:SetText(r.char); b.l:SetText(tostring(r.l))
    b.q:SetText((QN[r.q] or "—") .. (r.cl == 2 and " arme" or " armure"))
    b.de:SetText(r.de and short(r.de) or W.col(C.grey, "—")); b.s:SetText(short(r.sell)); b.ah:SetText(r.ah and short(r.ah) or W.col(C.grey, "—"))
    local col = BESTC[r.best] or C.grey
    b.best:SetText(W.col(col, r.best))
  end)
  P.list.frame:SetPoint("TOPLEFT", pane, "TOPLEFT", 0, -76)
  local right = CreateFrame("Frame", nil, pane); right:SetPoint("TOPRIGHT", pane, "TOPRIGHT", 0, 0); right:SetPoint("BOTTOMRIGHT", pane, "BOTTOMRIGHT", 0, 0); right:SetWidth(520)
  ns.theme.panel(right, "panel", "line")
  W.text(right, "GringottsH2", "Prix d'achat maximal pour désenchanter", 12, -10, 496)
  P.rnote = W.text(right, "GringottsTextSmall", "", 12, -34, 496)
  local cx = { 12, 84, 192, 300, 408 }
  for i, t in ipairs({ "Tranche", "Armure verte", "Arme verte", "Bleu", "Épique" }) do W.text(right, "GringottsLabelSmall", t, cx[i], -72, i == 1 and 70 or 100, i == 1 and "LEFT" or "RIGHT") end
  P.ref = {}
  for i = 1, #BR do
    local r = {}
    r.t = W.text(right, "GringottsText", BR[i][1] .. "–" .. (BR[i][2] == 999 and "65+" or BR[i][2]), cx[1], -94 - (i - 1) * 26, 70)
    for j = 2, 5 do r[j] = W.text(right, "GringottsTextSmall", "", cx[j], -96 - (i - 1) * 26, 100, "RIGHT") end
    P.ref[i] = r
  end
  P.foot = W.text(right, "GringottsTextSmall", "", 12, -94 - #BR * 26 - 10, 496)
  P.empty = W.text(pane, "GringottsText", "", 6, -90, 800)
  function P:Refresh()
    local rows = deRows()
    DE.rows = rows
    self.list:SetData(rows, true)
    local tot = { ["Désenchanter"] = 0, HV = 0, Marchand = 0 }
    for _, r in ipairs(rows) do if tot[r.best] then tot[r.best] = tot[r.best] + r.gain end end
    local s = E().cfg()
    self.sub:SetText(W.col(C.grey, ("%d objets verts, bleus ou épiques dans tes sacs et banques. Désenchanter : composants au prix HV, taxe déduite %s ; Marchand %s ; HV %s."):format(
      #rows, short(tot["Désenchanter"]), short(tot.Marchand), short(tot.HV))))
    if #rows == 0 then self.empty:SetText(W.col(C.orange, "Aucun objet relevé : ouvre tes sacs et ta banque en jeu, les objets verts, bleus et épiques sont relevés automatiquement.")) else self.empty:SetText("") end
    self.rnote:SetText(W.col(C.grey, ("Au-dessus de ce prix, l'objet rapporte moins qu'il ne coûte (ROI mini %d %%)."):format(math.floor(s.roiOk * 100 + .5))))
    for i, b in ipairs(BR) do
      local function cell(q, cls)
        local v = ns.deValue and ns.deValue(b[1], q, cls)
        return v and short(math.floor(v / (1 + s.roiOk))) or W.col(C.grey, "—")
      end
      local r = self.ref[i]
      r[2]:SetText(cell(2, 4)); r[3]:SetText(cell(2, 2)); r[4]:SetText(cell(3, 4)); r[5]:SetText(cell(4, 4))
    end
    self.foot:SetText(W.col(C.grey, "Vert : armure 75 % poussière, 20 % essence, 5 % éclat ; arme 20 / 75 / 5. Bleu : 1 éclat. Épique : 3 éclats, ou 1 Cristal de nexus dès l'ilvl 56."))
  end
  return P
end

------------------------------------------------------------------------
-- Journal des ventes et achats HV (45 j) : par semaine de reset (mercredi -> mardi) et jour par jour
------------------------------------------------------------------------
local function weekKey(t)
  local d = date("*t", t)
  local back = ((d.wday or 1) - 4) % 7
  return date("%d/%m", t - back * 86400), t - back * 86400
end

function X.journal()
  local trades = A().db().trades or {}
  local weeks, wk = {}, {}
  local days = {}
  for _, tr in ipairs(trades) do
    local lbl, ts = weekKey(tr.t)
    local w = wk[lbl]
    if not w then w = { lbl = lbl, ts = ts, v = 0, a = 0, nv = 0, na = 0, dep = 0 }; wk[lbl] = w; weeks[#weeks + 1] = w end
    local dk = date("%Y-%m-%d", tr.t)
    local d = days[dk]; if not d then d = { v = 0, a = 0 }; days[dk] = d end
    if tr.k == "V" then w.v = w.v + tr.c; w.nv = w.nv + 1; d.v = d.v + tr.c
    elseif tr.k == "A" then w.a = w.a + tr.c; w.na = w.na + 1; d.a = d.a + tr.c
    elseif tr.k == "L" then w.dep = w.dep + (tr.d or 0) end
  end
  table.sort(weeks, function(a, b) return a.ts > b.ts end)
  return weeks, days
end

function X.buildJournal(f, y0, P)
  W.text(f, "GringottsLabel", "Journal HV · par semaine (mercredi → mardi)", 0, y0, 600)
  local hx = { 0, 150, 290, 430 }
  for i, t in ipairs({ "Semaine du", "Ventes", "Achats", "Solde" }) do W.text(f, "GringottsLabelSmall", t, hx[i], y0 - 22, 140, i == 1 and "LEFT" or "RIGHT") end
  P.jw = {}
  for i = 1, 5 do
    local r = {}
    for j = 1, 4 do r[j] = W.text(f, "GringottsTextSmall", "", hx[j], y0 - 40 - (i - 1) * 18, 140, j == 1 and "LEFT" or "RIGHT") end
    P.jw[i] = r
  end
  local y1 = y0 - 40 - 5 * 18 - 14
  W.text(f, "GringottsLabel", "Jour par jour · variation d'or expliquée", 0, y1, 600)
  local dx = { 0, 110, 230, 350, 470 }
  for i, t in ipairs({ "Jour", "Variation", "Ventes", "Achats", "Autre" }) do W.text(f, "GringottsLabelSmall", t, dx[i], y1 - 22, 110, i == 1 and "LEFT" or "RIGHT") end
  P.jd = {}
  for i = 1, 7 do
    local r = {}
    for j = 1, 5 do r[j] = W.text(f, "GringottsTextSmall", "", dx[j], y1 - 40 - (i - 1) * 18, 110, j == 1 and "LEFT" or "RIGHT") end
    P.jd[i] = r
  end
  P.jnote = W.text(f, "GringottsTextSmall", "", 0, y1 - 40 - 7 * 18 - 6, 600)
end

local function signed(c)
  if not c or c == 0 then return "0" end
  return (c > 0 and W.col(C.green, "+") or W.col(C.red, "-")) .. short(math.abs(c))
end

function X.refreshJournal(P, g)
  if not P.jw then return end
  local weeks, days = X.journal()
  for i, r in ipairs(P.jw) do
    local w = weeks[i]
    if w then
      r[1]:SetText(w.lbl); r[2]:SetText(("%s (%d)"):format(short(w.v), w.nv)); r[3]:SetText(("%s (%d)"):format(short(w.a), w.na)); r[4]:SetText(signed(w.v - w.a))
    else for j = 1, 4 do r[j]:SetText("") end end
  end
  local s, n = g.total, #g.total
  local any = false
  for i, r in ipairs(P.jd) do
    local idx = n - 7 + i
    local dk = g.dates and g.dates[idx]
    if idx > 1 and dk and (s[idx] or 0) > 0 and (s[idx - 1] or 0) > 0 then
      local delta = s[idx] - s[idx - 1]
      local d = days[dk] or { v = 0, a = 0 }
      r[1]:SetText(dk:sub(6)); r[2]:SetText(signed(delta)); r[3]:SetText(d.v > 0 and short(d.v) or "—"); r[4]:SetText(d.a > 0 and short(d.a) or "—")
      r[5]:SetText(signed(delta - d.v + d.a)); any = true
    else for j = 1, 5 do r[j]:SetText("") end end
  end
  P.jnote:SetText(W.col(C.grey, any and "Autre = variation d'or moins les ventes, plus les achats HV : butin, quêtes, marchands, réparations, courrier."
    or "Journal disponible après quelques jours de relevé (ventes et achats lus dans le courrier de l'HV)."))
end
