-- Gringotts : portée, ligne de vue, retard du tir, barres de mêlée et lueurs (chasseur).
-- Logique reprise de « UPDOG's Forever Hunter Swing Timer » (sans les sons).
-- /gt tir portee|melee|offhand|retard|lueurs|fondu on|off
local ADDON, ns = ...
local Sh = ns.shot
if not Sh then return end
local R = {}
Sh.range = R

local MAIN, OFF, RANGED = 0, 1, 2
local WINDOW = 0.5
local shotMin, shotMax = 8, 35
local SNIPER_SPELLS = { 1310786, 1310785, 1310687 }
local MELEE_CHECK = { 5, 8149, 15826, 16308, 17117, 22259, 22432 }
local DISTANCE_CHECKS = {
  { 3, 42732 }, MELEE_CHECK, { 8, 34368, 33278 }, { 10, 9606, 9618, 9619, 9620, 9621, 10699, 17626, 17689, 32321 }, { 15, 4559, 33069 },
  { 20, 10645 }, { 25, 13289, 24268, 41509, 31463 }, { 30, 835, 7734, 34191 }, { 35, 24269, 18904 }, { 40, 28767 }, { 45, 23836 },
}
local BANDS = {
  { "MELEE", .3, 1, .15 }, { "DEAD ZONE", 1, .15, .12 }, { "SWEET SPOT", 1, 1, 0 },
  { "RANGED", .1, .85, 1 }, { "TOO FAR", 1, .08, .08 }, { "SNIPER RANGE", .72, .38, 1 },
}
local BAND_FR = { ["MELEE"] = "MÊLÉE", ["DEAD ZONE"] = "ZONE MORTE", ["SWEET SPOT"] = "POINT IDÉAL", ["RANGED"] = "À DISTANCE",
  ["TOO FAR"] = "TROP LOIN", ["SNIPER RANGE"] = "PORTÉE SNIPER", ["SNIPER UNAVAILABLE"] = "SNIPER INDISPO" }

------------------------------------------------------------------------ utilitaires
local function secret(v) if issecretvalue then local ok, r = pcall(issecretvalue, v); return not ok or r == true end return false end
local function isNum(v) return not secret(v) and type(v) == "number" and v == v and v ~= math.huge and v ~= -math.huge end
local function validDur(v) return isNum(v) and v > 0 and v <= 3600 end
local function normB(v) if secret(v) then return nil end if v == true or v == 1 then return true end if v == false or v == 0 then return false end return nil end
local function boolCall(fn, ...) if type(fn) ~= "function" then return nil end local ok, v = pcall(fn, ...); if ok then return normB(v) end return nil end
local function tableCall(fn, id)
  if type(fn) ~= "function" then return nil end
  local ok, v = pcall(fn, id)
  if ok and not secret(v) then if type(v) == "table" then return v, true end if v == nil then return nil, true end end
end
local function itemCheck(check)
  for i = 2, #check do
    local a = boolCall(C_Item and C_Item.IsItemInRange, check[i], "target")
    if a ~= nil then return a end
  end
end
local function rangeBand(melee, ranged, near)
  melee, ranged, near = normB(melee), normB(ranged), normB(near)
  if melee == true then return "MELEE" end
  if ranged == true then return "RANGED" end
  if ranged == false and near == false then return "TOO FAR" end
  if melee == false and ranged == false then if near == true then return "DEAD ZONE" end return "OUT OF RANGE" end
  return "RANGE UNKNOWN"
end
local function smooth(cur, vel, target, el, resp)
  if cur == nil then return target, 0 end
  el = math.max(0, el); local w = 2 / resp
  local off = cur - target; local term = (vel or 0) + w * off; local decay = math.exp(-w * el)
  local pos = target + (off + term * el) * decay; local sp = ((vel or 0) - w * term * el) * decay
  if off * (pos - target) < 0 then return target, 0 end
  if pos < 0 then return 0, 0 end
  if pos > 1 then return 1, 0 end
  return pos, sp
end
local function isHunter() local _, c = UnitClass("player"); return c == "HUNTER" end

------------------------------------------------------------------------ état
local targetState = "NO TARGET"
local near
local rangedRange, meleeRange, offRange
local eventRange = {}          -- [type] = { v, at }
local sniper = {}
local distLow, distHigh
local prevCue
local combat = false
local sweetCombat, sweetUsed, sweetAt = false, false, nil
local meleeSince
-- ligne de vue / tir
local autoRepeat, autoFired, lastAuto = false, false, nil
local stallSince, stallWarn = nil, false
local losUntil, losAt = 0, nil
local failSince, failLast
-- retard
local due, lastShot, shotSpeed, lastCast, lastTarget
local clipUntil, clipLabel
-- barres de mêlée
local mb = {}                 -- [0],[1] = { frame, endsAt, duration, available }
local panel, wash, clipFS, f
local glowAt, glowCol
local alphaNow = 1

local function cfg() return Sh.cfg() end
local function displayMax() return sniper.maximum or shotMax end

local function readTarget()
  if boolCall(UnitIsDeadOrGhost, "player") == true then return "DEAD" end
  if boolCall(UnitExists, "target") == false then return "NO TARGET" end
  if boolCall(UnitIsDeadOrGhost, "target") == true then return "TARGET DEAD" end
  if boolCall(UnitCanAttack, "player", "target") ~= true then return "NO ENEMY" end
  return nil
end

------------------------------------------------------------------------ portée du tir et Sniper Shot
local function layout() if R.layout then R.layout() end end
local function refreshShot()
  if not C_Spell or type(C_Spell.GetSpellInfo) ~= "function" then return false end
  local ok, info = pcall(C_Spell.GetSpellInfo, 75)
  if not ok or secret(info) or type(info) ~= "table" then return false end
  local mn, mx = info.minRange, info.maxRange
  if not isNum(mn) or not isNum(mx) or mn <= 5 or mn >= 15 or mx <= mn or mx >= 100 then return false end
  if mn == shotMin and mx == shotMax then return false end
  shotMin, shotMax = mn, mx; distLow, distHigh, prevCue = nil, nil, nil
  if panel then panel.pos, panel.tpos, panel.vel, panel.pl, panel.ph = nil, nil, 0, nil, nil end
  layout(); return true
end

local function refreshSniper()
  local id
  for _, c in ipairs(SNIPER_SPELLS) do
    local known = boolCall(C_SpellBook and C_SpellBook.IsSpellKnown, c)
    if known == nil then known = boolCall(IsPlayerSpell, c) end
    if known == true then id = c; break end
  end
  local oldID, oldN, oldM = sniper.id, sniper.normal, sniper.maximum
  if not id then sniper = {}
  else
    local now = GetTime()
    local info = tableCall(C_Spell and C_Spell.GetSpellInfo, id)
    local maximum = info and info.maxRange
    if not isNum(maximum) or maximum <= shotMin or maximum >= 100 then maximum = nil end
    local aura, readable = tableCall(C_UnitAuras and C_UnitAuras.GetPlayerAuraBySpellID, id)
    local exp = aura and aura.expirationTime
    local active = aura ~= nil and isNum(exp) and exp > now
    if boolCall(UnitIsDeadOrGhost, "player") == true then sniper.observed, sniper.flashAt = nil, nil
    elseif active then sniper.observed = true
    elseif sniper.observed and readable and (aura == nil or isNum(exp)) then sniper.observed, sniper.flashAt = nil, now end
    if sniper.active and not active then sniper.settleUntil, sniper.lingering = now + .5, sniper.normal + 10 end
    if shotMax ~= sniper.lingering then sniper.lingering = nil end
    if not sniper.normal then sniper.normal = active and math.max(shotMin + 1, shotMax - 10) or shotMax
    elseif not active and not sniper.lingering and (not sniper.settleUntil or now >= sniper.settleUntil) then
      if shotMax ~= sniper.normal then
        if sniper.pending ~= shotMax then sniper.pending, sniper.pendingAt = shotMax, now end
        if now - sniper.pendingAt >= .3 then sniper.normal, sniper.pending = shotMax, nil end
      else sniper.pending = nil end
    else sniper.pending = nil end
    sniper.id, sniper.active, sniper.spellMax = id, active, maximum
    sniper.maximum = math.max(sniper.normal + 10, maximum or sniper.normal)
    local cd = tableCall(C_Spell and C_Spell.GetSpellCooldown, id)
    local st, du = cd and cd.startTime, cd and cd.duration
    local rate = cd and cd.modRate; if not isNum(rate) or rate <= 0 then rate = 1 end
    sniper.ready = cd ~= nil and normB(cd.isEnabled) == true and isNum(st) and isNum(du) and (du == 0 or st + du / rate <= now)
    if not sniper.ready and cd and isNum(st) and isNum(du) then
      local g = tableCall(C_Spell and C_Spell.GetSpellCooldown, 61304)
      if g and isNum(g.startTime) and isNum(g.duration) and du > 0 and st == g.startTime and du == g.duration and normB(cd.isEnabled) == true then sniper.ready = true end
    end
    sniper.available = math.max(sniper.normal, sniper.ready and maximum or 0, active and sniper.normal + 10 or 0)
    sniper.inRange = nil
    if not targetState then sniper.inRange = boolCall(C_Spell and C_Spell.IsSpellInRange, id, "target") end
  end
  if panel and (oldID ~= sniper.id or oldN ~= sniper.normal or oldM ~= sniper.maximum) then
    panel.pos, panel.tpos, panel.vel, panel.pl, panel.ph = nil, nil, 0, nil, nil
    layout()
  end
end

------------------------------------------------------------------------ lecture de la portée (toutes les 0,1 s)
local function armChecks()
  if not C_SwingTimer or not C_SwingTimer.EnableRangeCheck then return end
  for _, t in ipairs({ MAIN, OFF, RANGED }) do pcall(C_SwingTimer.EnableRangeCheck, t, true) end
end

local function readRange(t, ranged)
  if targetState then return nil end
  local v
  if C_SwingTimer then v = boolCall(C_SwingTimer.IsTargetWithinSwingRange, t) end
  local e = eventRange[t]
  if v == nil and e and GetTime() - e[2] < .3 then v = e[1] end
  if v == nil and t ~= RANGED and C_Spell then
    v = boolCall(C_Spell.IsSpellInRange, 2974, "target")
    if v == nil then v = boolCall(C_Spell.IsSpellInRange, 1495, "target") end
  end
  if v == nil and t ~= RANGED then
    if ranged == true or near == false then v = false else v = itemCheck(MELEE_CHECK) end
  end
  if v == nil and t == RANGED and C_Spell then v = boolCall(C_Spell.IsSpellInRange, 75, "target") end
  return v
end

local function refreshRange()
  targetState = readTarget()
  refreshSniper()
  near = nil
  if not targetState then near = boolCall(CheckInteractDistance, "target", 4) end
  local now = GetTime()
  rangedRange = readRange(RANGED)
  meleeRange = readRange(MAIN, rangedRange)
  offRange = readRange(OFF, rangedRange)
  if offRange == nil and mb[OFF] and mb[OFF].available then offRange = meleeRange end
  if not targetState and meleeRange == true and rangedRange == false and combat then meleeSince = meleeSince or now else meleeSince = nil end
  local cue
  if not targetState then cue = rangeBand(meleeRange, rangedRange, near) end
  -- lueurs d'entrée dans une zone (même cible)
  if R.glowOn and cue ~= prevCue and prevCue ~= nil then
    if cue == "RANGED" then glowAt, glowCol = now, { .1, .85, 1 }
    elseif cue == "MELEE" then glowAt, glowCol = now, { .3, 1, .15 } end
  end
  prevCue = cue
  distLow, distHigh = nil, nil
  if cue then
    if cue == "MELEE" then distLow, distHigh = 0, 5
    elseif cue == "DEAD ZONE" then distLow, distHigh = 5, shotMin
    elseif cue == "TOO FAR" then
      distLow, distHigh = shotMax, displayMax() + 5
      if sniper.inRange == true and sniper.spellMax and sniper.spellMax > shotMax then distHigh = sniper.spellMax
      elseif sniper.inRange == false and sniper.spellMax then distLow = math.max(distLow, sniper.spellMax) end
    elseif cue == "RANGED" then
      local lo, hi = shotMin, math.max(shotMax, sniper.active and sniper.available or 0)
      if near == true then hi = math.min(hi, 28) elseif near == false then lo = math.max(lo, 28) end
      if lo >= hi then lo, hi = shotMin, shotMax end
      distLow, distHigh = lo, hi
    end
    if distLow ~= nil then
      local lo, hi = distLow, distHigh
      for _, c in ipairs(DISTANCE_CHECKS) do
        if c[1] > distLow and c[1] < distHigh then
          local a = itemCheck(c)
          if a == true then hi = math.min(hi, c[1]) elseif a == false then lo = math.max(lo, c[1]) end
        end
      end
      if lo < hi then distLow, distHigh = lo, hi end
    end
  end
end

------------------------------------------------------------------------ interface
local function mkTex(parent, layer, sub) return parent:CreateTexture(nil, layer or "ARTWORK", nil, sub or 0) end

local function build()
  f = _G.GringottsShotBar
  if not f then return end
  local T = ns.theme
  local function outlined(fs, size)
    if T and fs.SetFont then pcall(fs.SetFont, fs, T.fontPath("bold"), size, "OUTLINE") end
  end
  -- retard du tir, à droite de la barre
  clipFS = f:CreateFontString(nil, "OVERLAY", "GringottsOutline")
  clipFS:SetPoint("LEFT", f, "RIGHT", 8, 0); outlined(clipFS, 14); clipFS:SetTextColor(1, .12, .12, 1); clipFS:SetText("")
  -- lueur d'entrée
  wash = f:CreateTexture(nil, "OVERLAY", nil, 5); wash:SetAllPoints(); wash:Hide()
  -- panneau de portée, au-dessus de la barre
  panel = CreateFrame("Frame", "GringottsRangePanel", UIParent)
  panel:SetFrameStrata("MEDIUM")
  panel.caption = panel:CreateFontString(nil, "OVERLAY", "GringottsOutline")
  panel.caption:SetPoint("CENTER", panel, "TOP", 0, -10); outlined(panel.caption, 12)
  panel.cells = {}
  for i = 1, #BANDS do
    local c = CreateFrame("Frame", nil, panel)
    c.back = c:CreateTexture(nil, "BACKGROUND"); c.back:SetAllPoints(); c.back:SetColorTexture(.04, .05, .07, .95)
    c.tint = c:CreateTexture(nil, "ARTWORK"); c.tint:SetAllPoints()
    panel.cells[i] = c
  end
  panel.sniperReady = panel.cells[6]:CreateTexture(nil, "OVERLAY"); panel.sniperReady:SetPoint("TOPLEFT"); panel.sniperReady:SetColorTexture(.72, .38, 1, .9)
  panel.unc = panel:CreateTexture(nil, "OVERLAY"); panel.unc:SetColorTexture(1, 1, 1, .22); panel.unc:Hide()
  panel.mo = CreateFrame("Frame", nil, panel); panel.mo:SetAllPoints(); panel.mo:SetFrameLevel(panel:GetFrameLevel() + 8)
  panel.marker = panel.mo:CreateTexture(nil, "OVERLAY"); panel.marker:SetColorTexture(1, 1, 1, 1); panel.marker:Hide()
  panel.sweetEdge = panel.mo:CreateTexture(nil, "OVERLAY"); panel.sweetEdge:Hide()
  panel.h = 5; panel.vel = 0
  -- barres de mêlée au-dessus du panneau
  for _, t in ipairs({ MAIN, OFF }) do
    local b = CreateFrame("Frame", nil, UIParent)
    b.bg = b:CreateTexture(nil, "BACKGROUND"); b.bg:SetAllPoints(); b.bg:SetColorTexture(.025, .035, .05, .94)
    b.fill = CreateFrame("StatusBar", nil, b); b.fill:SetPoint("TOPLEFT", 1, -1); b.fill:SetPoint("BOTTOMRIGHT", -1, 1)
    b.fill:SetStatusBarTexture("Interface\\Buttons\\WHITE8X8"); b.fill:SetMinMaxValues(0, 1); b.fill:SetValue(0)
    if t == MAIN then b.fill:SetStatusBarColor(.3, 1, .15, .9) else b.fill:SetStatusBarColor(.95, .6, .2, .9) end
    b.left = b.fill:CreateFontString(nil, "OVERLAY", "GringottsOutlineSmall"); b.left:SetPoint("LEFT", 5, 0); outlined(b.left, 10)
    b.right = b.fill:CreateFontString(nil, "OVERLAY", "GringottsOutlineSmall"); b.right:SetPoint("RIGHT", -5, 0); outlined(b.right, 10)
    b.left:SetText(t == MAIN and "Mêlée" or "Main gauche")
    b.t = t; b.alpha = 1
    mb[t] = b
  end
  function R.layout()
    local c = cfg()
    local w = c.w
    local bh = math.max(10, math.floor(c.h * .6))
    panel:SetSize(w, 34 + panel.h); panel:ClearAllPoints()
    panel:SetPoint("BOTTOMLEFT", f, "TOPLEFT", 0, 6)
    panel.marker:SetSize(3, 18 + panel.h - 5); panel.unc:SetHeight(panel.h + 3)
    local mx = displayMax()
    local normMax = sniper.normal or shotMax
    local bounds = { 0, 5, shotMin, math.max(shotMin, math.min(10, normMax)), normMax, mx + 5 }
    for i, cell in ipairs(panel.cells) do
      local lo, hi = bounds[i], bounds[i + 1]
      if i == 5 then lo, hi = mx, mx + 5 end
      if i == 6 then lo, hi = normMax, mx end
      cell:SetShown(i ~= 6 or sniper.id ~= nil)
      cell:ClearAllPoints(); cell:SetPoint("TOPLEFT", panel, "TOPLEFT", w * lo / (mx + 5), -29)
      cell:SetSize(math.max(1, w * (hi - lo) / (mx + 5) - 1), panel.h)
    end
    panel.caption:SetWidth(w)
    local anchor = panel
    for _, t in ipairs({ MAIN, OFF }) do
      local b = mb[t]
      local vis = (t == MAIN and c.melee) or (t == OFF and c.offhand and b.available)
      b:SetShown(vis and true or false)
      b:SetSize(w, bh)
      b:ClearAllPoints(); b:SetPoint("BOTTOMLEFT", anchor, "TOPLEFT", 0, 2)
      if vis then anchor = b end
    end
  end
  R.layout()
end

local function bandNow()
  if targetState then return targetState end
  if not mb[MAIN] then return "RANGE UNKNOWN" end
  return rangeBand(meleeRange, rangedRange, near)
end

local function drawPanel(now, el, demo)
  local c = cfg()
  if not c.range then panel:Hide(); return end
  local band = demo and ({ "MELEE", "RANGED", "DEAD ZONE" })[math.floor(now / 4) % 3 + 1] or bandNow()
  local lo, hi = distLow, distHigh
  if demo then
    if band == "MELEE" then lo, hi = 0, 5 elseif band == "DEAD ZONE" then lo, hi = 5, shotMin else lo, hi = shotMin, shotMax end
  end
  if targetState and not demo then lo, hi = nil, nil end
  if not demo and not targetState and sniper.id then
    if band == "TOO FAR" and sniper.inRange == true then band = sniper.ready and "SNIPER RANGE" or "SNIPER UNAVAILABLE"
    elseif band == "RANGED" and lo and lo >= sniper.normal then band = "SNIPER RANGE" end
  end
  local known = lo ~= nil and hi ~= nil
  panel.marker:SetShown(known); panel.unc:SetShown(known)
  local w, mx = c.w, displayMax()
  if known then
    local tp = (lo + hi) / 2 / (mx + 5)
    if panel.pl and lo <= panel.pl and hi >= panel.ph and panel.tpos then tp = panel.tpos end
    panel.pl, panel.ph, panel.tpos = lo, hi, tp
    panel.pos, panel.vel = smooth(panel.pos, panel.vel, tp, el, .1)
    panel.marker:ClearAllPoints(); panel.marker:SetPoint("CENTER", panel, "TOPLEFT", panel.pos * w, -29 - panel.h / 2)
    panel.unc:ClearAllPoints(); panel.unc:SetPoint("TOPLEFT", panel, "TOPLEFT", lo / (mx + 5) * w, -28)
    panel.unc:SetWidth(math.max(2, (hi - lo) / (mx + 5) * w))
  else panel.pos, panel.vel, panel.tpos, panel.pl, panel.ph = nil, 0, nil, nil, nil end
  local sweet = band == "RANGED" and known and lo >= shotMin and hi <= 10
  if sweet then band = "SWEET SPOT" end
  if sweetCombat and sweet and not demo and not sweetUsed then
    sweetUsed, sweetAt = true, now
    if R.glowOn then glowAt, glowCol = now, { 1, 1, 0 } end
  end
  local caption = (band == "OUT OF RANGE" or band == "NO TARGET" or band == "TARGET DEAD" or band == "NO ENEMY" or band == "DEAD" or band == "RANGE UNKNOWN") and "" or (BAND_FR[band] or band)
  panel.caption:SetText(caption)
  if band == "DEAD ZONE" or band == "TOO FAR" then panel.caption:SetTextColor(1, .08, .08, 1)
  elseif band == "MELEE" then panel.caption:SetTextColor(.3, 1, .15, 1)
  elseif band == "SNIPER RANGE" or band == "SNIPER UNAVAILABLE" then panel.caption:SetTextColor(.72, .38, 1, 1)
  elseif sweet then panel.caption:SetTextColor(1, 1, 0, 1)
  else panel.caption:SetTextColor(1, 1, 1, 1) end
  if not demo and not targetState and now < losUntil then
    local p = .5 + .5 * math.cos((now - (losAt or now)) * math.pi * 2 / .6)
    panel.caption:SetText("LIGNE DE VUE")
    panel.caption:SetTextColor(1, 1, 0, .55 + .45 * p)
  elseif targetState then losUntil, losAt = 0, nil end
  if targetState or rangedRange ~= true then failSince, failLast = nil, nil end
  panel.caption:SetShown(c.rangeText)
  for i, cell in ipairs(panel.cells) do
    local s = BANDS[i]
    local active = band == s[1]
    cell.tint:SetColorTexture(s[2], s[3], s[4], active and (s[1] == "SWEET SPOT" and 1 or .85) or .1)
    if active and band == "TOO FAR" then cell.tint:SetColorTexture(1, .08, .08, 1) end
    if i == 6 then cell.tint:SetColorTexture(s[2], s[3], s[4], .15) end
  end
  local aw = sniper.id and math.max(0, math.min(sniper.maximum, sniper.available) - sniper.normal) or 0
  panel.sniperReady:SetShown(aw > 0)
  panel.sniperReady:SetSize(math.max(1, aw / (mx + 5) * w - 1), panel.h)
  -- liseré clignotant : fin du bonus Sniper (rouge) ou premier point idéal du combat (or)
  local sn = not demo and sniper.flashAt and math.max(0, 1 - (now - sniper.flashAt)) or 0
  local sw = sweetCombat and not demo and sweetAt and math.max(0, 1 - (now - sweetAt)) or 0
  if sn > 0 or sw > 0 then
    panel.sweetEdge:SetColorTexture(1, sn > 0 and .06 or 1, 0, sn > 0 and sn or sw)
    panel.sweetEdge:ClearAllPoints(); panel.sweetEdge:SetPoint("TOPLEFT", panel, "TOPLEFT", 0, -26); panel.sweetEdge:SetPoint("BOTTOMRIGHT", panel, "TOPRIGHT", 0, -29 - panel.h - 2)
    panel.sweetEdge:Show()
  else panel.sweetEdge:Hide() end
end

local function drawMelee(b, now, el, demo)
  local c = cfg()
  if not b:IsShown() then return end
  local remain, prog = 0, 0
  if b.endsAt and b.duration and now < b.endsAt then remain = b.endsAt - now; prog = 1 - remain / b.duration end
  if b.available == false then b.right:SetText(""); b.left:SetText("Pas d'arme"); b.fill:SetValue(0); b:SetAlpha(c.fade); return end
  b.left:SetText(b.t == MAIN and "Mêlée" or "Main gauche")
  local inRange = b.t == MAIN and meleeRange or offRange
  local expired = b.endsAt and inRange == false and now >= b.endsAt + 3 and combat
  local idle = not combat and (boolCall(UnitExists, "target") ~= true or boolCall(UnitCanAttack, "player", "target") ~= true)
  local a = 1
  if idle then a = c.idleFade elseif expired or inRange == false then a = c.fade end
  if not R.fadeOn then a = 1 end
  b.alpha = b.alpha + (a - b.alpha) * math.min(el * 14, 1)
  b:SetAlpha(b.alpha)
  b.fill:SetValue(expired and 0 or prog)
  b.right:SetText(remain > 0 and ("%.1f"):format(remain) or "")
end

function R.update(now, el)
  local c = cfg()
  local demo = Sh.demo
  if not panel then return end
  drawPanel(now, el, demo)
  for _, t in ipairs({ MAIN, OFF }) do drawMelee(mb[t], now, el, demo) end
  -- fondu de la barre du tir : hors combat sans cible, ou trop loin / collé en mêlée depuis 3 s
  local idle = not combat and (boolCall(UnitExists, "target") ~= true or boolCall(UnitCanAttack, "player", "target") ~= true)
  local factor = 1
  if R.fadeOn and not demo then
    local emptyRanged = (meleeSince and now - meleeSince >= 3) or (not targetState and rangeBand(meleeRange, rangedRange, near) == "TOO FAR")
    if idle then factor = c.idleFade elseif emptyRanged then factor = c.fade end
  end
  if c.hideInMelee and not demo and meleeRange == true then factor = 0 end
  alphaNow = alphaNow + (factor - alphaNow) * math.min(el * 14, 1)
  f:SetAlpha(c.alpha * alphaNow)
  panel:SetAlpha(idle and R.fadeOn and not demo and c.idleFade or 1)
  -- lueur d'entrée
  local g = glowAt and R.glowOn and math.max(0, 1 - (now - glowAt)) or 0
  if g > 0 then wash:SetColorTexture(glowCol[1], glowCol[2], glowCol[3], .45 * g); wash:Show() else wash:Hide() end
  -- retard du tir
  clipFS:SetText((c.clip and clipUntil and now < clipUntil and not demo) and clipLabel or "")
  -- détection de ligne de vue : tir auto actif, immobile, pas d'incantation, cible à portée, cycle terminé sans tir
  local stationary = false
  if GetUnitSpeed then local ok, s = pcall(GetUnitSpeed, "player"); stationary = ok and isNum(s) and s == 0 end
  local casting = false
  for _, q in ipairs({ UnitCastingInfo, UnitChannelInfo }) do
    local ok, n = pcall(q, "player")
    if not ok or secret(n) or n ~= nil then casting = true end
  end
  local S = Sh.S
  local endsAt = S.start and S.speed and (S.start + S.speed)
  local eligible = not demo and autoRepeat and autoFired and stationary and not casting and not targetState
    and rangedRange == true and S.start > 0 and endsAt
  if eligible then
    stallSince = stallSince or now
    local recent = failSince and failLast and now - failLast <= .5 and now - failSince >= .1
    if now - stallSince >= .1 and (recent or now >= endsAt + .05) then
      if now >= losUntil then losAt = now end
      losUntil, stallWarn = now + 1.5, true
    end
  else
    stallSince = nil
    if stallWarn then losUntil, losAt = 0, nil end
    stallWarn = false
  end
end

------------------------------------------------------------------------ retard du tir
local function readSpeed()
  if not UnitAttackSpeed then return nil end
  local ok, _, _, s = pcall(UnitAttackSpeed, "player")
  if ok and validDur(s) then return s end
end
local function clearCycle() lastShot, due, shotSpeed, lastCast = nil, nil, nil, nil end
local function shotFired(now, speed, castGUID)
  autoFired, lastAuto = true, now
  stallSince, stallWarn = nil, false; losUntil, losAt = 0, nil; failSince, failLast = nil, nil
  if not cfg().clip or not validDur(speed) then return end
  if secret(castGUID) or type(castGUID) ~= "string" or castGUID == "" then castGUID = nil end
  if castGUID and castGUID == lastCast then return end
  if lastShot and now - lastShot < .05 then return end
  local tg = boolCall and UnitGUID and UnitGUID("target")
  if tg and lastTarget and tg ~= lastTarget then clearCycle() end
  local delay = due and math.max(0, now - due)
  if delay and delay >= .1 then clipUntil, clipLabel = now + 1.5, ("-%.2f"):format(delay) end
  lastShot, due, shotSpeed = now, now + speed, speed
  lastCast, lastTarget = castGUID, tg
end

------------------------------------------------------------------------ événements
local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
local EVENTS = { "PLAYER_SWING", "PLAYER_SWING_RANGE_UPDATE", "PLAYER_TARGET_CHANGED", "PLAYER_ENTERING_WORLD", "PLAYER_DEAD",
  "WEAPON_SLOT_CHANGED", "PLAYER_EQUIPMENT_CHANGED", "START_AUTOREPEAT_SPELL", "STOP_AUTOREPEAT_SPELL", "PLAYER_REGEN_ENABLED",
  "PLAYER_REGEN_DISABLED", "UI_ERROR_MESSAGE", "UNIT_ATTACK_SPEED", "UNIT_AURA", "UNIT_SPELLCAST_SUCCEEDED", "UNIT_SPELLCAST_FAILED",
  "UNIT_SPELLCAST_FAILED_QUIET", "SPELLS_CHANGED", "LEARNED_SPELL_IN_TAB", "CHARACTER_POINTS_CHANGED", "PLAYER_TALENT_UPDATE",
  "PLAYER_LEVEL_UP", "CVAR_UPDATE" }
local function refreshSpeeds()
  if not UnitAttackSpeed then return end
  local ok, m, o = pcall(UnitAttackSpeed, "player")
  if not ok then return end
  local changed
  for t, sp in pairs({ [MAIN] = m, [OFF] = o }) do
    local b = mb[t]
    if b and not secret(sp) then
      local av = validDur(sp) and true or false
      if b.available ~= av then b.available = av; changed = true end
      if av then if not (b.endsAt and GetTime() < b.endsAt) then b.duration = sp end
      else b.endsAt = nil end
    end
  end
  if changed then layout() end
end

ev:SetScript("OnEvent", function(self, e, ...)
  if e == "PLAYER_LOGIN" then
    if not isHunter() then return end
    local c = cfg()
    for k, v in pairs({ melee = true, offhand = false, range = true, rangeText = true, clip = true, glow = true, hideInMelee = false, fade = .25, idleFade = .1, fadeOn = true }) do
      if c[k] == nil then c[k] = v end
    end
    R.glowOn, R.fadeOn = c.glow, c.fadeOn
    build()
    for _, n in ipairs(EVENTS) do pcall(self.RegisterEvent, self, n) end
    combat = boolCall(UnitAffectingCombat, "player") == true
    armChecks(); refreshShot(); refreshSpeeds(); refreshRange()
    local acc = 0
    local last = GetTime()
    panel:SetScript("OnUpdate", function()
      local now = GetTime(); local el = now - last; last = now
      acc = acc + el
      if acc >= .1 then acc = 0; refreshRange() end
      R.update(now, el)
    end)
    -- métadonnées de sort / objets chargées en différé
    if C_Item and C_Item.RequestLoadItemDataByID then
      for _, ck in ipairs(DISTANCE_CHECKS) do for i = 2, #ck do pcall(C_Item.RequestLoadItemDataByID, ck[i]) end end
    end
    if C_Timer and C_Timer.NewTicker then C_Timer.NewTicker(1, function() armChecks(); if refreshShot() then refreshRange() end end) end
    return
  end
  local now = GetTime()
  if e == "PLAYER_SWING" then
    local duration, kind = ...
    if secret(kind) then return end
    local b = mb[kind]
    if b and validDur(duration) then b.endsAt, b.duration = now + duration, duration; b.available = true; if not b:IsShown() then layout() end end
    if kind == RANGED and validDur(duration) then
      -- un reset de tir déclenché par la mêlée affine un tir tout juste confirmé, sans le confirmer
      if lastShot and now >= lastShot and now - lastShot < .1 then due, shotSpeed = lastShot + duration, duration end
    end
  elseif e == "PLAYER_SWING_RANGE_UPDATE" then
    local kind, inR, checks = ...
    if secret(kind) then return end
    if normB(checks) == true then eventRange[kind] = { normB(inR), now } else eventRange[kind] = nil end
  elseif e == "PLAYER_TARGET_CHANGED" then
    eventRange = {}; meleeSince = nil; prevCue = nil; autoFired = false; lastAuto = nil
    stallSince, stallWarn = nil, false; losUntil, losAt = 0, nil; failSince, failLast = nil, nil
    local g = UnitGUID and UnitGUID("target")
    if not g or not lastTarget or g ~= lastTarget then clearCycle() end
    lastTarget = g
    if panel then panel.pos, panel.tpos, panel.vel, panel.pl, panel.ph = nil, nil, 0, nil, nil end
    refreshRange()
  elseif e == "PLAYER_REGEN_DISABLED" then combat = true; sweetCombat = true
  elseif e == "PLAYER_REGEN_ENABLED" then combat = false; sweetCombat = false; sweetUsed = false; sweetAt = nil; clearCycle()
  elseif e == "START_AUTOREPEAT_SPELL" then
    if not autoRepeat then
      local d = (Sh.S and Sh.S.dur) or 3
      autoFired = lastAuto ~= nil and now - lastAuto <= d + .5
      failSince, failLast, stallSince = nil, nil, nil
    end
    autoRepeat = true
  elseif e == "STOP_AUTOREPEAT_SPELL" then
    autoFired, autoRepeat, stallSince, stallWarn = false, false, nil, false
    losUntil, losAt, failSince, failLast = 0, nil, nil, nil
  elseif e == "UI_ERROR_MESSAGE" then
    local id, msg = ...
    local name
    if isNum(id) and GetGameMessageInfo then local ok, n = pcall(GetGameMessageInfo, id); if ok and not secret(n) and type(n) == "string" then name = n end end
    local readable = not secret(msg) and type(msg) == "string"
    if (name == "SPELL_FAILED_LINE_OF_SIGHT" or (readable and type(SPELL_FAILED_LINE_OF_SIGHT) == "string" and msg == SPELL_FAILED_LINE_OF_SIGHT)) and not readTarget() then
      losUntil, losAt = now + 1.5, now
    elseif readable then losUntil, losAt = 0, nil; failSince, failLast = nil, nil end
  elseif e == "UNIT_SPELLCAST_FAILED" or e == "UNIT_SPELLCAST_FAILED_QUIET" then
    local unit, _, id = ...
    if not secret(unit) and unit == "player" and isNum(id) and id == 75 and not readTarget() and rangedRange == true then
      local d = ((Sh.S and Sh.S.dur) or 3) + .5
      if not failLast or now - failLast > d then failSince = now end
      failLast = now
      if now < losUntil or (autoFired and now - failSince >= d) then
        if now >= losUntil then losAt = now end
        losUntil = now + 1.5
      end
    end
  elseif e == "UNIT_SPELLCAST_SUCCEEDED" then
    local unit, guid, id = ...
    if not secret(unit) and unit == "player" then
      sniper.refreshUntil = now + 1
      if isNum(id) and id == 75 then shotFired(now, readSpeed() or (Sh.S and Sh.S.dur), guid) end
    end
  elseif e == "UNIT_ATTACK_SPEED" then
    local unit = ...
    if secret(unit) or unit ~= "player" then return end
    local sp = readSpeed()
    if sp and shotSpeed and math.abs(sp - shotSpeed) > .001 then
      if due and due > now then due = now + (due - now) * sp / shotSpeed end
      shotSpeed = sp
    end
    refreshSpeeds()
  elseif e == "UNIT_AURA" then
    local unit = ...
    if not secret(unit) and unit == "player" then refreshSniper() end
  elseif e == "WEAPON_SLOT_CHANGED" or e == "PLAYER_EQUIPMENT_CHANGED" then
    refreshSpeeds()
  elseif e == "PLAYER_ENTERING_WORLD" or e == "PLAYER_DEAD" then
    sniper.flashAt, sniper.observed = nil, nil
    autoRepeat, autoFired, lastAuto = false, false, nil
    meleeSince = nil; clearCycle(); clipUntil = nil
    for _, t in ipairs({ MAIN, OFF }) do if mb[t] then mb[t].endsAt = nil end end
    eventRange = {}
    armChecks(); refreshShot(); refreshSpeeds(); refreshRange()
  elseif e == "CVAR_UPDATE" then if C_Timer then C_Timer.After(0, armChecks) end
  else
    -- sorts / talents / niveau : portées et vitesses à relire
    refreshShot(); refreshSpeeds(); refreshRange()
  end
end)

function R.set(k, v)
  local c = cfg()
  c[k] = v
  if k == "glow" then R.glowOn = v elseif k == "fadeOn" then R.fadeOn = v end
  if R.layout then R.layout() end
end
