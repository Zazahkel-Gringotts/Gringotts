-- Gringotts : collecteur pour le dashboard Gringotts (WoW Forever).
-- Collecte : sacs + banque de chaque perso, banque de guilde, recettes apprises, prix Auctionator.
-- Sortie : texte « WFC1 » à coller dans le dashboard (onglet Importer).
local ADDON, ns = ...
local VERSION = "1.12.4"
local GTI_FORMAT = 2        -- version du texte « Envoyer au jeu » comprise par cet addon
local CALLER = "Gringotts"

local db, char, realm, faction, charName
local syncShoppingList   -- défini plus bas (liste Auctionator)
local tracked, trackedName = {}, {}   -- nom normalisé -> true / nom affiché
local reagents = {}                    -- nom normalisé -> true (composants de métier)

------------------------------------------------------------------------
-- Normalisation identique au dashboard (accents, apostrophes, casse)
------------------------------------------------------------------------
local ACC = {}
do
  local up = "aaaaaaaceeeeiiiidnooooo-ouuuuyts"   -- U+00C0..U+00DF
  local lo = "aaaaaaaceeeeiiiidnooooo-ouuuuyty"   -- U+00E0..U+00FF
  for i = 0, 31 do
    ACC["\195" .. string.char(0x80 + i)] = up:sub(i + 1, i + 1)
    ACC["\195" .. string.char(0xA0 + i)] = lo:sub(i + 1, i + 1)
  end
end
local function norm(s)
  s = tostring(s or "")
  s = s:gsub("\226\128\153", "'"):gsub("\226\128\152", "'"):gsub("`", "'"):gsub("\194\160", " ")
  s = s:gsub("\197\147", "oe"):gsub("\197\146", "oe")
  s = s:gsub("\195[\128-\191]", function(c) return ACC[c] or c end)
  s = s:lower():gsub("%s+", " "):gsub("^ ", ""):gsub(" $", "")
  return s
end
ns.norm = norm

local function cleanName(n)
  if not n then return nil end
  n = n:gsub("|A.-|a", ""):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
  n = n:gsub("^%s+", ""):gsub("%s+$", "")
  return n ~= "" and n or nil
end
local function nameFromLink(link) return link and cleanName(link:match("%[(.-)%]")) end
local function idFromLink(link) return link and tonumber(link:match("item:(%d+)")) end

local function say(msg) print("|cffe4b84eGringotts|r " .. msg) end
local function ago(t)
  if not t or t == 0 then return "jamais" end
  local s = time() - t
  if s < 3600 then return math.floor(s / 60) .. " min" end
  if s < 86400 then return math.floor(s / 3600) .. " h" end
  return math.floor(s / 86400) .. " j"
end

------------------------------------------------------------------------
-- Base de données (SavedVariables, partagée entre les persos du compte)
------------------------------------------------------------------------
local function initDB()
  GringottsDB = GringottsDB or {}
  db = GringottsDB
  db.v = 1
  db.chars = db.chars or {}
  db.guilds = db.guilds or {}
  db.ids = db.ids or {}          -- nom normalisé -> itemID
  db.checked = db.checked or {}  -- itemID Auctionator déjà résolus
  db.extra = db.extra or {}      -- objets ajoutés au suivi depuis les recettes vues en jeu
  db.reagents = db.reagents or {} -- composants découverts en jeu
  if db.highlight == nil then db.highlight = true end
  db.trades = db.trades or {}     -- ventes / achats / annonces HV
  db.tradeSeen = db.tradeSeen or {}
  db.dash = db.dash or {}         -- décisions reçues du dashboard (/gt import)
  db.vendor = db.vendor or {}     -- prix d'achat chez les marchands PNJ (relevés à l'ouverture)
  realm = GetRealmName() or "?"
  charName = UnitName("player") or "?"
  faction = UnitFactionGroup("player") or "?"
  local key = charName .. "-" .. realm
  db.chars[key] = db.chars[key] or {}
  char = db.chars[key]
  char.name, char.realm, char.faction = charName, realm, faction
  char.bags = char.bags or {}
  char.bank = char.bank or {}
  char.recipes = char.recipes or {}
  char.skills = char.skills or {}
  char.cds = char.cds or {}
  char.goldDays = char.goldDays or {}
  for _, n in ipairs(ns.TRACKED or {}) do
    local k = norm(n)
    tracked[k] = true
    trackedName[k] = trackedName[k] or n
  end
  for k, n in pairs(db.extra) do tracked[k] = true; trackedName[k] = trackedName[k] or n end
  for _, n in ipairs(ns.REAGENTS or {}) do reagents[norm(n)] = true end
  for k in pairs(db.reagents) do reagents[k] = true end
end

local function learnID(name, id)
  if not name or not id then return end
  local k = norm(name)
  if tracked[k] then
    db.ids[k] = id
    trackedName[k] = name   -- orthographe du jeu
  end
end

------------------------------------------------------------------------
-- Sacs et banque
------------------------------------------------------------------------
local function safeSlots(bag)
  local ok, n = pcall(C_Container.GetContainerNumSlots, bag)
  return ok and n or 0
end

local function scanContainers(bags)
  local counts, equip = {}, {}
  for _, bag in ipairs(bags) do
    for slot = 1, safeSlots(bag) do
      local info = C_Container.GetContainerItemInfo(bag, slot)
      if info and info.itemID then
        local name = nameFromLink(info.hyperlink) or C_Item.GetItemNameByID(info.itemID)
        if name then
          learnID(name, info.itemID)
          local k = norm(name)
          counts[k] = (counts[k] or 0) + (info.stackCount or 1)
          if info.quality and info.quality >= 2 and info.quality <= 4 and ns.equipInfo then
            local en, il, q, cl, sp = ns.equipInfo(info.hyperlink)
            if en then equip[#equip + 1] = { n = en, l = il, q = q, c = cl, s = sp, link = info.hyperlink } end
          end
        end
      end
    end
  end
  return counts, equip
end

local function bagIDs()
  local t = {}
  local last = NUM_TOTAL_EQUIPPED_BAG_SLOTS or ((NUM_BAG_SLOTS or 4) + 1)  -- inclut le sac de composants
  for i = 0, last do t[#t + 1] = i end
  return t
end

local function bankIDs()
  local t, seen = {}, {}
  local function push(b) if b and not seen[b] then seen[b] = true; t[#t + 1] = b end end
  local E = (Enum and Enum.BagIndex) or {}
  push(E.Bank or -1)
  push(E.Reagentbank)
  local first = (NUM_TOTAL_EQUIPPED_BAG_SLOTS or 5) + 1
  for i = first, first + (NUM_BANKBAGSLOTS or 7) - 1 do push(i) end
  for i = 1, 6 do push(E["CharacterBankTab_" .. i]) end
  return t
end

local bankOpen, guildOpen = false, false

-- Or : dernier montant connu par jour (perso et banque de guilde), 180 jours
local function prune(t) local lim = date("%Y-%m-%d", time() - 180 * 86400); for d in pairs(t) do if d < lim then t[d] = nil end end end
local loginT = 0
local function scanGold()
  if not char or not GetMoney then return end
  local m = GetMoney()
  if type(m) ~= "number" then return end
  -- Juste après la connexion le client peut renvoyer 0 avant d'avoir chargé l'or : on ne remplace pas un montant connu
  if m == 0 and (char.gold or 0) > 0 and time() - loginT < 120 then return end
  char.gold = m; char.goldT = time()
  char.goldDays[date("%Y-%m-%d")] = char.gold
  prune(char.goldDays)
end
local function scanGuildGold()
  if not GetGuildBankMoney or not GetGuildInfo then return end
  local g = GetGuildInfo("player"); if not g then return end
  local G = db.guilds[g .. "-" .. realm] or { tabs = {} }; db.guilds[g .. "-" .. realm] = G
  G.name, G.realm, G.faction = g, realm, faction
  G.goldDays = G.goldDays or {}
  local m = GetGuildBankMoney(); if not m then return end
  G.goldDays[date("%Y-%m-%d")] = m
  prune(G.goldDays)
end

local function scanBags()
  char.bags, char.equipBags = scanContainers(bagIDs())
  char.bagsT = time()
  if ns.checkLowStock then pcall(ns.checkLowStock) end
end

local function scanBank()
  if not bankOpen then return end
  char.bank, char.equipBank = scanContainers(bankIDs())
  char.bankT = time()
end

------------------------------------------------------------------------
-- Banque de guilde : interrogation onglet par onglet
------------------------------------------------------------------------
local gb = { queue = {}, loaded = {}, waiting = nil }

local function guildKey()
  local g = GetGuildInfo and GetGuildInfo("player")
  return g and (g .. "-" .. realm) or nil
end

local function scanGuildTab(tab)
  local gk = guildKey(); if not gk then return end
  local G = db.guilds[gk] or { tabs = {} }; db.guilds[gk] = G
  G.name, G.realm, G.faction = GetGuildInfo("player"), realm, faction
  local counts = {}
  for slot = 1, (MAX_GUILDBANK_SLOTS_PER_TAB or 98) do
    local link = GetGuildBankItemLink(tab, slot)
    if link then
      local _, count = GetGuildBankItemInfo(tab, slot)
      local name, id = nameFromLink(link), idFromLink(link)
      if name then
        learnID(name, id)
        local k = norm(name)
        counts[k] = (counts[k] or 0) + (count or 1)
      end
    end
  end
  G.tabs[tab] = { c = counts, t = time() }
  G.t = time()
  G.numTabs = GetNumGuildBankTabs()
  gb.loaded[tab] = true
end

local function guildNext()
  if not guildOpen then gb.queue = {}; gb.waiting = nil; return end
  local tab = table.remove(gb.queue, 1)
  if not tab then
    gb.waiting = nil
    local G = db.guilds[guildKey() or ""]
    if G then G.t = time() end
    say("Banque de guilde relevée.")
    return
  end
  gb.waiting = tab
  QueryGuildBankTab(tab)
  local token = {}
  gb.token = token
  C_Timer.After(2, function()        -- pas de réponse : onglet ignoré, on garde l'ancien relevé
    if gb.token == token and gb.waiting == tab then guildNext() end
  end)
end

local function startGuildScan()
  gb.queue, gb.loaded = {}, {}
  for tab = 1, (GetNumGuildBankTabs() or 0) do
    local _, _, viewable = GetGuildBankTabInfo(tab)
    if viewable then gb.queue[#gb.queue + 1] = tab end
  end
  guildNext()
end

local function onGuildSlotsChanged()
  if gb.waiting then
    local tab = gb.waiting
    C_Timer.After(0.2, function() scanGuildTab(tab); guildNext() end)
  elseif guildOpen then
    for tab in pairs(gb.loaded) do scanGuildTab(tab) end   -- objets déplacés après le relevé
  end
end

------------------------------------------------------------------------
-- Recettes apprises (fenêtre de métier)
------------------------------------------------------------------------
-- Ajoute un objet au suivi (prix + stock) avec son itemID
local function track(name, id)
  local k = norm(name)
  if not tracked[k] then
    tracked[k] = true; trackedName[k] = name; db.extra[k] = name
    ns.listDirty = true
  end
  if id then db.ids[k] = id end
end

local function itemName(id)
  local n = C_Item.GetItemNameByID(id)
  if not n and C_Item.RequestLoadItemDataByID then C_Item.RequestLoadItemDataByID(id) end
  return n
end

local BASIC = Enum and Enum.CraftingReagentType and Enum.CraftingReagentType.Basic
-- Composants obligatoires d'une recette + produit ; incomplete = un nom d'objet pas encore chargé
local function readSchematic(T, id)
  if not T.GetRecipeSchematic then return nil end
  local ok, sch = pcall(T.GetRecipeSchematic, id, false)
  if not ok or not sch then return nil end
  local reag, incomplete = {}, false
  for _, slot in ipairs(sch.reagentSlotSchematics or {}) do
    local basic = (BASIC == nil or slot.reagentType == nil or slot.reagentType == BASIC) and slot.required ~= false
    local r1 = slot.reagents and slot.reagents[1]
    if basic and r1 and r1.itemID then
      local rn = itemName(r1.itemID)
      if rn then
        reag[#reag + 1] = { rn, slot.quantityRequired or 1 }; track(rn, r1.itemID)
        local rk = norm(rn)
        if not reagents[rk] then reagents[rk] = true; db.reagents[rk] = true end
      else incomplete = true end
    end
  end
  local out
  if sch.outputItemID then
    out = itemName(sch.outputItemID)
    if out then track(out, sch.outputItemID) else incomplete = true end
  end
  return { o = out, q = sch.quantityMin or 1, r = reag }, incomplete
end

local profRetry = false
local function scanProfession()
  local T = C_TradeSkillUI
  if not T or not T.GetAllRecipeIDs then return end
  if (T.IsTradeSkillLinked and T.IsTradeSkillLinked()) or (T.IsTradeSkillGuild and T.IsTradeSkillGuild())
     or (T.IsNPCCrafting and T.IsNPCCrafting()) then return end
  local base = T.GetBaseProfessionInfo and T.GetBaseProfessionInfo()
  local prof = base and base.professionName
  if (not prof or prof == "") and T.GetChildProfessionInfo then
    local child = T.GetChildProfessionInfo()
    prof = child and (child.parentProfessionName or child.professionName)
  end
  if not prof or prof == "" then return end
  local list, all, incomplete = {}, {}, false
  for _, id in ipairs(T.GetAllRecipeIDs() or {}) do
    local info = T.GetRecipeInfo(id)
    if info and info.name then
      local d = type(info.relativeDifficulty) == "number" and info.relativeDifficulty or nil
      if info.learned then
        list[#list + 1] = { n = info.name, d = d }
        if T.GetRecipeCooldown then             -- temps de recharge (transmutations…)
          local ok, cd, isDay = pcall(T.GetRecipeCooldown, id)
          if ok and ((cd and cd > 0) or isDay) then char.cds[info.name] = { r = time() + (cd or 0) }
          elseif ok and char.cds[info.name] then char.cds[info.name].r = math.min(char.cds[info.name].r, time()) end
        end
      end
      local sch, inc = readSchematic(T, id)
      if inc then incomplete = true end
      if sch then sch.n, sch.d, sch.l = info.name, d, info.learned and 1 or 0; all[#all + 1] = sch end
    end
  end
  if #list > 0 or #all > 0 then char.recipes[prof] = { list = list, all = all, t = time() } end
  if ns.listDirty then ns.listDirty = false; C_Timer.After(2, function() syncShoppingList() end) end
  if base and base.skillLevel and base.maxSkillLevel and base.maxSkillLevel > 0 then
    char.skills[prof] = { l = base.skillLevel, m = base.maxSkillLevel, t = time() }
  end
  -- Objets pas encore en cache : un second passage quand ils sont chargés
  if incomplete and not profRetry then
    profRetry = true
    C_Timer.After(3, function() profRetry = false; scanProfession() end)
  end
end

-- Niveaux de métier sans ouvrir la fenêtre (API moderne, sinon liste de compétences historique)
local function scanSkills()
  if GetProfessions and GetProfessionInfo then
    for _, idx in pairs({ GetProfessions() }) do
      local name, _, lvl, max = GetProfessionInfo(idx)
      if name and lvl and max and max > 0 then char.skills[name] = { l = lvl, m = max, t = time() } end
    end
  elseif GetNumSkillLines and GetSkillLineInfo then
    for i = 1, GetNumSkillLines() do
      local name, header, _, rank, _, _, max = GetSkillLineInfo(i)
      if name and not header and rank and max and max > 1 then char.skills[name] = { l = rank, m = max, t = time() } end
    end
  end
end

------------------------------------------------------------------------
-- Prix Auctionator + résolution des itemID depuis sa base de prix
------------------------------------------------------------------------
local function auctionatorAPI()
  return Auctionator and Auctionator.API and Auctionator.API.v1
end

local function priceOf(id)
  local api = auctionatorAPI(); if not api or not id then return end
  local ok, p = pcall(api.GetAuctionPriceByItemID, CALLER, id)
  local ok2, age = false, nil
  if api.GetAuctionAgeByItemID then ok2, age = pcall(api.GetAuctionAgeByItemID, CALLER, id) end
  return (ok and type(p) == "number") and p or nil, (ok2 and type(age) == "number") and age or nil
end

local function auctionatorKeys()
  local src
  if Auctionator and Auctionator.Database and type(Auctionator.Database.db) == "table" then
    src = Auctionator.Database.db
  elseif type(AUCTIONATOR_PRICE_DATABASE) == "table" then
    local best = 0                                   -- plus grande base royaume
    for k, v in pairs(AUCTIONATOR_PRICE_DATABASE) do
      if type(v) == "table" and k ~= "__dbversion" then
        local n = 0; for _ in pairs(v) do n = n + 1 end
        if n > best then best, src = n, v end
      end
    end
  end
  local ids = {}
  if src then
    for k in pairs(src) do
      local id = tonumber(k)
      if id and not db.checked[id] then ids[#ids + 1] = id end
    end
  end
  return ids
end

local resolver = { busy = false, pending = {}, cb = nil }

local function resolveOne(id)
  local name = C_Item.GetItemNameByID(id)
  if name then
    learnID(name, id); db.checked[id] = true; resolver.pending[id] = nil
    return true
  end
  resolver.pending[id] = true
  if C_Item.RequestLoadItemDataByID then C_Item.RequestLoadItemDataByID(id) end
  return false
end

local function missingCount()
  local n = 0
  for k in pairs(tracked) do if not db.ids[k] then n = n + 1 end end
  return n
end

local function resolveIDs(cb)
  -- tentative rapide par nom (objets en cache)
  for k in pairs(tracked) do
    if not db.ids[k] and C_Item.GetItemInfoInstant then
      local id = C_Item.GetItemInfoInstant(trackedName[k])
      if id then db.ids[k] = id end
    end
  end
  if resolver.busy then resolver.cb = cb or resolver.cb; return end
  local ids = auctionatorKeys()
  if #ids == 0 or missingCount() == 0 then if cb then cb() end; return end
  resolver.busy, resolver.cb = true, cb
  local i, total = 1, #ids
  say(("Identification de %d objets de la base Auctionator…"):format(total))
  local ticker
  ticker = C_Timer.NewTicker(0.1, function(self)
    for _ = 1, 250 do
      if i > total then break end
      resolveOne(ids[i]); i = i + 1
    end
    if i > total then
      (self or ticker):Cancel()
      C_Timer.After(2, function()                     -- laisse arriver les chargements asynchrones
        for id in pairs(resolver.pending) do resolveOne(id) end
        resolver.pending = {}                           -- les restants seront retentés plus tard
        resolver.busy = false
        local f = resolver.cb; resolver.cb = nil
        if f then f() end
      end)
    end
  end)
end

------------------------------------------------------------------------
-- Contour orange (légendaire) sur les composants de métier : sacs, banque, banque de guilde.
-- Bagnon et les sacs Blizzard appellent SetItemButtonQuality pour chaque case : on s'y accroche
-- et on pose notre propre cadre par-dessus, sans modifier la vraie qualité de l'objet.
------------------------------------------------------------------------
ns.reagentCache = {}
local LEG = { 1, 0.5, 0 }          -- composant : orange légendaire
local RED = { 1, 0.12, 0.08 }      -- réservé pour la montée (dashboard) : rouge
local function keyOf(itemIDOrLink)
  local id = type(itemIDOrLink) == "number" and itemIDOrLink or tonumber(tostring(itemIDOrLink):match("item:(%d+)"))
  local c = id and ns.reagentCache[id]
  if c then return c end
  local name = type(itemIDOrLink) == "string" and nameFromLink(itemIDOrLink) or (id and C_Item.GetItemNameByID(id))
  if not name then return nil end
  local k = norm(name)
  if id then ns.reagentCache[id] = k end
  return k
end
local function markColor(itemIDOrLink)
  if not itemIDOrLink or not db or not db.highlight then return nil end
  local k = keyOf(itemIDOrLink); if not k then return nil end
  local res = db.dash and db.dash.reserve and db.dash.reserve[k]
  if res and res > 0 then return RED end
  if reagents[k] then return LEG end
  return nil
end

local function markButton(button, col)
  local m = button.GringottsMark
  if not col then if m then m:Hide() end return end
  if not m then
    m = CreateFrame("Frame", nil, button)
    m:SetAllPoints(button); m:SetFrameLevel(button:GetFrameLevel() + 3)
    m.border = m:CreateTexture(nil, "OVERLAY", nil, 7)
    m.border:SetTexture("Interface\\Common\\WhiteIconFrame"); m.border:SetAllPoints(m)
    m.glow = m:CreateTexture(nil, "OVERLAY", nil, 6)
    m.glow:SetTexture("Interface\\Buttons\\UI-ActionButton-Border"); m.glow:SetBlendMode("ADD")
    m.glow:SetPoint("CENTER"); m.glow:SetSize(button:GetWidth() * 1.85, button:GetHeight() * 1.85)
    button.GringottsMark = m
  end
  m.border:SetVertexColor(col[1], col[2], col[3])
  m.glow:SetVertexColor(col[1], col[2], col[3], 0.55)
  m:Show()
end

local function onQuality(button, quality, itemIDOrLink)
  if not button or not db then return end
  markButton(button, markColor(itemIDOrLink))
end
if SetItemButtonQuality then hooksecurefunc("SetItemButtonQuality", onQuality) end

------------------------------------------------------------------------
-- Liste d'achats Auctionator « Gringotts - Suivi » (créée/mise à jour automatiquement)
------------------------------------------------------------------------
local LIST_NAME = "Gringotts - Suivi"
local listWarned = false
syncShoppingList = function(force)
  local api = auctionatorAPI()
  if not api or not api.CreateShoppingList then
    if force or not listWarned then
      listWarned = true
      say("Auctionator ne permet pas la création automatique de liste : utilisez le bouton « Liste Auctionator de suivi » du dashboard.")
    end
    return
  end
  local names = {}
  for k in pairs(tracked) do names[#names + 1] = trackedName[k] end
  table.sort(names)
  local sig = #names .. ":" .. table.concat(names, "|"):len()
  if not force and db.listSig == sig then return end
  local terms = {}
  for _, n in ipairs(names) do
    local term
    if api.ConvertToSearchString then
      local ok, t = pcall(api.ConvertToSearchString, CALLER, { searchString = n, isExact = true })
      if ok and type(t) == "string" then term = t end
    end
    terms[#terms + 1] = term or ('"' .. n .. '"')
  end
  local ok, err = pcall(api.CreateShoppingList, CALLER, LIST_NAME, terms)
  if ok then
    db.listSig = sig
    say(("Liste Auctionator « %s » à jour : %d objets."):format(LIST_NAME, #terms))
  else
    say("Échec de la création de la liste Auctionator : " .. tostring(err))
  end
end

------------------------------------------------------------------------
-- Ventes et achats HV : factures du courrier + annonces postées
------------------------------------------------------------------------
local function subjPattern(fmt)
  if type(fmt) ~= "string" then return nil end
  local p = fmt:gsub("[%(%)%.%+%-%*%?%[%]%^%$]", "%%%0")
  p = p:gsub("%%s", "(.+)")
  return "^" .. p .. "$"
end
local MAILPAT = {
  sold = subjPattern(AUCTION_SOLD_MAIL_SUBJECT), won = subjPattern(AUCTION_WON_MAIL_SUBJECT),
  expired = subjPattern(AUCTION_EXPIRED_MAIL_SUBJECT), removed = subjPattern(AUCTION_REMOVED_MAIL_SUBJECT),
}
local KIND = { sold = "V", won = "A", expired = "E", removed = "X", listed = "L" }

local function addTrade(kind, name, qty, copper, deposit)
  if not name or name == "" then return end
  db.trades[#db.trades + 1] = { t = time(), k = KIND[kind], n = name, q = qty or 1, c = copper or 0, w = charName, d = deposit }
end

local function scanMail()
  if not GetInboxNumItems then return end
  local now = time()
  for i = 1, (GetInboxNumItems() or 0) do
    local _, _, _, subject, money, _, daysLeft = GetInboxHeaderInfo(i)
    if subject then
      local kind, item
      for kd, pat in pairs(MAILPAT) do
        local m = pat and subject:match(pat)
        if m then kind, item = kd, m; break end
      end
      if kind then
        local _, invItem, _, bid, _, _, _, _, _, _, count = GetInboxInvoiceInfo(i)
        local qty = count
        if not qty or qty == 0 then local _, _, _, c = GetInboxItem(i, 1); qty = c end
        qty = (qty and qty > 0) and qty or 1
        -- Identifiant stable du courrier : type, objet, montant, quantité, date d'expiration (à 15 min près)
        local key = table.concat({ kind, item, bid or money or 0, qty, math.floor((now + (daysLeft or 0) * 86400) / 900) }, ":")
        if not db.tradeSeen[key] then
          db.tradeSeen[key] = now
          local copper = (kind == "sold" or kind == "won") and (bid or money or 0) or 0
          addTrade(kind, cleanName(invItem) or item, qty, copper)
        end
      end
    end
  end
  local keep, lim = {}, now - 45 * 86400        -- purge : 45 jours
  for _, tr in ipairs(db.trades) do if tr.t >= lim then keep[#keep + 1] = tr end end
  db.trades = keep
  for k, t in pairs(db.tradeSeen) do if t < lim then db.tradeSeen[k] = nil end end
end

-- Annonces postées (vélocité = vendu / mis en vente). Post-hook : l'objet est encore en sac (verrouillé).
local function locName(loc)
  local ok, n = pcall(C_Item.GetItemName, loc)
  return ok and n or nil
end
-- Dépôt réel de la mise en vente (cuivre, total) : relevé pour estimer le coût des invendus
local function depositFor(loc, duration, qty, commodity)
  if not C_AuctionHouse then return nil end
  local ok, d
  if commodity and C_AuctionHouse.CalculateCommodityDeposit then
    local id = C_Item.GetItemID and C_Item.GetItemID(loc)
    if id then ok, d = pcall(C_AuctionHouse.CalculateCommodityDeposit, id, duration, qty or 1) end
  elseif C_AuctionHouse.CalculateItemDeposit then
    ok, d = pcall(C_AuctionHouse.CalculateItemDeposit, loc, duration, qty or 1)
  end
  return (ok and type(d) == "number" and d >= 0) and d or nil
end
if C_AuctionHouse then
  if C_AuctionHouse.PostCommodity then
    hooksecurefunc(C_AuctionHouse, "PostCommodity", function(loc, duration, quantity, unitPrice)
      if db then addTrade("listed", locName(loc), quantity, (unitPrice or 0) * (quantity or 1), depositFor(loc, duration, quantity, true)) end
    end)
  end
  if C_AuctionHouse.PostItem then
    hooksecurefunc(C_AuctionHouse, "PostItem", function(loc, duration, quantity, bid, buyout)
      if db then addTrade("listed", locName(loc), quantity, buyout or bid or 0, depositFor(loc, duration, quantity, false)) end
    end)
  end
end

------------------------------------------------------------------------
-- Marchands PNJ : prix unitaire de tout ce qu'ils vendent (achat contre or uniquement)
------------------------------------------------------------------------
local function merchantInfo(i)
  if C_MerchantFrame and C_MerchantFrame.GetItemInfo then
    local ok, info = pcall(C_MerchantFrame.GetItemInfo, i)
    if ok and type(info) == "table" then return info.name, info.price, info.stackCount, info.hasExtendedCost end
  end
  if GetMerchantItemInfo then
    local name, _, price, quantity, _, _, _, extended = GetMerchantItemInfo(i)
    return name, price, quantity, extended
  end
end

local function scanMerchant()
  if not GetMerchantNumItems then return end
  local n = 0
  for i = 1, (GetMerchantNumItems() or 0) do
    local name, price, stack, extended = merchantInfo(i)
    local link = GetMerchantItemLink and GetMerchantItemLink(i)
    name = cleanName(name) or nameFromLink(link)
    if name and price and price > 0 and not extended then
      local k = norm(name)
      db.vendor[k] = { n = name, c = price / math.max(1, stack or 1), t = time() }
      local id = idFromLink(link)
      if id and (tracked[k] or reagents[k]) then db.ids[k] = id end
      n = n + 1
    end
  end
  if n > 0 then ns.vendorSeen = n end
end

-- Prix de revente au marchand (sellPrice) d'un objet
local function sellPriceOf(id)
  if not id or not C_Item.GetItemInfo then return nil end
  local ok, a1, _, _, _, _, _, _, _, _, _, sp = pcall(C_Item.GetItemInfo, id)
  if ok and type(a1) == "table" then return a1.sellPrice end   -- certaines versions renvoient une table
  return ok and sp or nil
end

local function salesOf(k, days)
  local lim, sold, listed, exp, rev = time() - (days or 30) * 86400, 0, 0, 0, 0
  for _, tr in ipairs(db.trades) do
    if tr.t >= lim and norm(tr.n) == k then
      if tr.k == "V" then sold = sold + tr.q; rev = rev + tr.c
      elseif tr.k == "L" then listed = listed + tr.q
      elseif tr.k == "E" then exp = exp + tr.q end
    end
  end
  return sold, listed, exp, rev
end

------------------------------------------------------------------------
-- Import des décisions du dashboard (/gt import) : texte « GTI1 »
------------------------------------------------------------------------
local function parseImport(text)
  local lines = {}
  for l in (text or ""):gmatch("[^\r\n]+") do lines[#lines + 1] = l end
  if not lines[1] or not lines[1]:match("^GTI1;") then return nil end
  local d = { t = tonumber(lines[1]:match("^GTI1;(%d+)")) or time(), reserve = {}, maxBuy = {}, target = {}, net = {}, buy = {}, floor = {}, logi = {} }
  local fmt = tonumber(lines[1]:match("^GTI1;%d+;(%d+)")) or 1
  if fmt > GTI_FORMAT then say("|cffff5555Le dashboard est plus récent que l'addon : installez la dernière version de Gringotts.|r") end
  for _, l in ipairs(lines) do
    local f = {}
    for x in (l .. ";"):gmatch("(.-);") do f[#f + 1] = x end
    local k = f[2] and norm(f[2])
    if f[1] == "R" then d.reserve[k] = tonumber(f[3])
    elseif f[1] == "M" then d.maxBuy[k] = tonumber(f[3])
    elseif f[1] == "C" then d.target[k] = { tonumber(f[3]) or 0, tonumber(f[4]) or 0 }
    elseif f[1] == "N" then d.net[k] = { tonumber(f[3]) or 0, tonumber(f[4]) }
    elseif f[1] == "B" then d.buy[#d.buy + 1] = { f[2], tonumber(f[3]) or 1, tonumber(f[4]) }
    elseif f[1] == "F" then d.floor[k] = tonumber(f[3])
    elseif f[1] == "LG" then d.logi[#d.logi + 1] = { f[2], f[3], f[4], tonumber(f[5]) or 0 } end
  end
  return d
end
ns.parseImport = parseImport

local function syncBuyList()
  local api = auctionatorAPI()
  if not api or not api.CreateShoppingList or not db.dash.buy or #db.dash.buy == 0 then return end
  local terms = {}
  for _, b in ipairs(db.dash.buy) do
    local term
    if api.ConvertToSearchString then
      local ok, t = pcall(api.ConvertToSearchString, CALLER, { searchString = b[1], isExact = true, maxPrice = b[3], quantity = b[2] })
      if ok and type(t) == "string" then term = t end
    end
    terms[#terms + 1] = term or ('"' .. b[1] .. '"')
  end
  if pcall(api.CreateShoppingList, CALLER, "Gringotts - Réassort", terms) then
    say(("Liste Auctionator « Gringotts - Réassort » : %d achats (quantité et prix max du dashboard)."):format(#terms))
  end
end

local function applyImport(text)
  local d = parseImport(text)
  if not d then say("Texte non reconnu : copiez le bloc « Envoyer au jeu » du dashboard."); return false end
  db.dash = d; ns.reagentCache = {}
  local nr = 0; for _ in pairs(d.reserve) do nr = nr + 1 end
  say(("Décisions du dashboard importées : %d composants réservés, %d achats, %d envois entre persos. Rouvrez les sacs pour le contour rouge."):format(nr, #d.buy, #d.logi))
  db.lowWarned = {}
  syncBuyList()
  return true
end

-- Décisions déposées par le dashboard dans Dash.lua (chargé au /reload) : appliquées au connexion si plus récentes
local function applyDashFile()
  local txt = ns.DASH_TEXT
  if type(txt) ~= "string" or #txt < 10 then return end
  local t = tonumber(txt:match("^%s*GTI1;(%d+)"))
  if not t or t <= ((db.dash and db.dash.t) or 0) then return end
  say("Décisions du dashboard détectées (fichier local) : application…")
  applyImport(txt)
end

local importFrame
local function showImport()
  ns.showImport = showImport
  if not importFrame then
    local f = CreateFrame("Frame", "GringottsImportFrame", UIParent, "BasicFrameTemplateWithInset")
    f:SetSize(520, 380); f:SetPoint("CENTER"); f:SetFrameStrata("DIALOG")
    f:SetMovable(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving); f:SetScript("OnDragStop", f.StopMovingOrSizing)
    f.title = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    f.title:SetPoint("TOP", 0, -5); f.title:SetText("Gringotts — collez le bloc « Envoyer au jeu » du dashboard")
    local sf = CreateFrame("ScrollFrame", nil, f, "UIPanelScrollFrameTemplate")
    sf:SetPoint("TOPLEFT", 12, -32); sf:SetPoint("BOTTOMRIGHT", -32, 44)
    local eb = CreateFrame("EditBox", nil, sf)
    eb:SetMultiLine(true); eb:SetAutoFocus(true); eb:SetFontObject(ChatFontNormal); eb:SetWidth(460)
    eb:SetScript("OnEscapePressed", function() f:Hide() end)
    sf:SetScrollChild(eb); f.eb = eb
    local b = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
    b:SetSize(120, 24); b:SetPoint("BOTTOMRIGHT", -14, 12); b:SetText("Importer")
    b:SetScript("OnClick", function() if applyImport(eb:GetText()) then f:Hide() end end)
    tinsert(UISpecialFrames, "GringottsImportFrame")
    importFrame = f
  end
  importFrame.eb:SetText(""); importFrame:Show(); importFrame.eb:SetFocus()
end

------------------------------------------------------------------------
-- Infobulle : stock total, cible, réserve, prix max, marge, ventes
------------------------------------------------------------------------
local function totalStock(k)
  local n = 0
  for _, c in pairs(db.chars) do
    if c.realm == realm and c.faction == faction then n = n + ((c.bags or {})[k] or 0) + ((c.bank or {})[k] or 0) end
  end
  for _, G in pairs(db.guilds) do
    if G.realm == realm and G.faction == faction then for _, tb in pairs(G.tabs or {}) do n = n + ((tb.c or {})[k] or 0) end end
  end
  return n
end
local function coins(c) return GetCoinTextureString and GetCoinTextureString(math.floor(math.abs(c) + 0.5)) or tostring(c) end

local function addTooltip(tt, link)
  if not db or not link then return end
  local k = keyOf(link); if not k or not (tracked[k] or reagents[k]) then return end
  local D = db.dash or {}
  tt:AddLine(" ")
  tt:AddLine("Gringotts", 0.89, 0.72, 0.31)
  local tg = D.target and D.target[k]
  tt:AddDoubleLine("Stock total", tostring(totalStock(k)) .. (tg and ("  ·  cible " .. tg[1]) or ""), 0.8, 0.8, 0.8, 1, 1, 1)
  if tg and tg[2] > 0 then tt:AddDoubleLine("À acheter", tostring(tg[2]), 0.8, 0.8, 0.8, 1, 0.82, 0) end
  local res = D.reserve and D.reserve[k]
  if res and res > 0 then tt:AddDoubleLine("Réservé montée", tostring(res), 1, 0.3, 0.25, 1, 0.3, 0.25) end
  local mb = D.maxBuy and D.maxBuy[k]
  if mb then tt:AddDoubleLine("Achat max", coins(mb), 0.8, 0.8, 0.8, 1, 1, 1) end
  local nt = D.net and D.net[k]
  if nt then
    local pos = nt[1] >= 0
    tt:AddDoubleLine("Marge nette du craft", (pos and "" or "-") .. coins(nt[1]) .. (nt[2] and ("  (" .. nt[2] .. " %)") or ""),
      0.8, 0.8, 0.8, pos and 0.3 or 1, pos and 0.85 or 0.3, 0.3)
  end
  local fl = D.floor and D.floor[k]
  if fl then tt:AddDoubleLine("Prix plancher (ne pas vendre sous)", coins(fl), 0.8, 0.8, 0.8, 1, 0.82, 0) end
  local sold, listed, exp = salesOf(k, 30)
  if sold + listed + exp > 0 then
    tt:AddDoubleLine("Ventes 30 j", ("%d vendus / %d mis en vente%s"):format(sold, listed, exp > 0 and (" · " .. exp .. " expirés") or ""), 0.8, 0.8, 0.8, 1, 1, 1)
  end
  if reagents[k] and not (res and res > 0) then tt:AddLine("Composant suivi : vérifier le dashboard avant de vendre", 1, 0.5, 0) end
  if D.t and D.t > 0 then tt:AddLine(("Décisions du dashboard : il y a %s"):format(ago(D.t)), 0.5, 0.5, 0.5) end
end
ns.addTooltip = addTooltip

------------------------------------------------------------------------
-- Désenchantement : valeur estimée d'un objet (tables du dashboard) vs marchand vs HV
------------------------------------------------------------------------
-- Tranches d'ilvl : poussière, quantité moyenne, essence, quantité moyenne, éclat
local DE_BR = {
  { 5, 10, "Poussière étrange", 1.5, "Essence de magie inférieure", 1.5, nil },
  { 11, 15, "Poussière étrange", 2.5, "Essence de magie supérieure", 1.5, nil },
  { 16, 20, "Poussière étrange", 5, "Essence astrale inférieure", 1.5, "Petit éclat scintillant" },
  { 21, 25, "Poussière d'âme", 1.5, "Essence astrale supérieure", 1.5, "Petit éclat scintillant" },
  { 26, 30, "Poussière d'âme", 3.5, "Essence mystique inférieure", 1.5, "Gros éclat scintillant" },
  { 31, 35, "Poussière de vision", 1.5, "Essence mystique supérieure", 1.5, "Petit éclat luminescent" },
  { 36, 40, "Poussière de vision", 3.5, "Essence du néant inférieure", 1.5, "Gros éclat luminescent" },
  { 41, 45, "Poussière de rêve", 1.5, "Essence du néant supérieure", 1.5, "Petit éclat irradiant" },
  { 46, 50, "Poussière de rêve", 3.5, "Essence éternelle inférieure", 1.5, "Gros éclat irradiant" },
  { 51, 55, "Poudre d'illusion", 1.5, "Essence éternelle supérieure", 1.5, "Petit éclat brillant" },
  { 56, 999, "Poudre d'illusion", 3.5, "Essence éternelle supérieure", 2, "Grand éclat brillant" },
}
-- Compétence d'enchantement requise selon l'ilvl (Classic)
local DE_SKILL = { { 20, 1 }, { 25, 25 }, { 30, 50 }, { 35, 75 }, { 40, 100 }, { 45, 125 }, { 50, 150 }, { 55, 175 }, { 60, 200 }, { 999, 225 } }

local function deSkill(ilvl)
  for _, s in ipairs(DE_SKILL) do if ilvl <= s[1] then return s[2] end end
  return 225
end

local function matPrice(name)
  local id = db.ids[norm(name)]
  local p = id and priceOf(id)
  return p
end

-- Renvoie : valeur (cuivre, net de taxe HV) ou nil, détail texte, compétence requise, composants sans prix
local function deValue(ilvl, quality, classID)
  local b
  for _, x in ipairs(DE_BR) do if ilvl >= x[1] and ilvl <= x[2] then b = x; break end end
  if not b then return nil end
  local parts = {}
  if quality == 3 then
    if not b[7] then return nil end
    parts = { { b[7], 1, 1 } }
  elseif quality == 4 then
    if ilvl < 36 then return nil end
    parts = (ilvl >= 56) and { { "Cristal de nexus", 1, 1 } } or { { b[7], 1, 3 } }
  else
    local dust, ess, shard = 0.75, 0.20, 0.05                 -- armure verte
    if classID == 2 then dust, ess = 0.20, 0.75 end           -- arme verte
    if not b[7] then if classID == 2 then ess = ess + shard else dust = dust + shard end; shard = 0 end
    parts = { { b[3], dust, b[4] }, { b[5], ess, b[6] } }
    if shard > 0 then parts[#parts + 1] = { b[7], shard, 1 } end
  end
  local v, miss, txt = 0, {}, {}
  for _, p in ipairs(parts) do
    local pr = matPrice(p[1])
    if pr then v = v + pr * p[2] * p[3] else miss[#miss + 1] = p[1] end
    txt[#txt + 1] = ("%d%% %s ×%s"):format(math.floor(p[2] * 100 + 0.5), p[1], tostring(p[3]))
  end
  return (#miss == 0) and v * 0.95 or nil, table.concat(txt, " · "), deSkill(ilvl), miss
end
ns.deValue = deValue

local function enchanterSkill()
  local best, who
  for _, c in pairs(db.chars) do
    if c.realm == realm and c.faction == faction then
      for p, s in pairs(c.skills or {}) do
        if norm(p) == "enchantement" and (not best or s.l > best) then best, who = s.l, c.name end
      end
    end
  end
  return best, who
end

-- Infos d'équipement désenchantable : ilvl, qualité, classe, prix marchand (nil si non désenchantable)
local function equipInfo(link)
  if not link or not C_Item.GetItemInfoInstant then return nil end
  local _, _, _, equipLoc, _, classID = C_Item.GetItemInfoInstant(link)
  if (classID ~= 2 and classID ~= 4) or not equipLoc or equipLoc == "" or equipLoc == "INVTYPE_TABARD" or equipLoc == "INVTYPE_BODY" then return nil end
  local ok, name, _, quality, ilvl, _, _, _, _, _, _, sell = pcall(C_Item.GetItemInfo, link)
  if not ok or not name or not quality or quality < 2 or quality > 4 then return nil end
  if C_Item.GetDetailedItemLevelInfo then local d = C_Item.GetDetailedItemLevelInfo(link); if d then ilvl = d end end
  return name, ilvl or 0, quality, classID, sell or 0
end
ns.equipInfo = equipInfo

local function ahPriceOfLink(link)
  local api = auctionatorAPI()
  if not api or not api.GetAuctionPriceByItemLink then return nil end
  local ok, p = pcall(api.GetAuctionPriceByItemLink, CALLER, link)
  return ok and type(p) == "number" and p or nil
end

local function addDETooltip(tt, link)
  if not db or type(link) ~= "string" then return end
  local name, ilvl, quality, classID, sell = equipInfo(link)
  if not name then return end
  local ev, txt, req, miss = deValue(ilvl, quality, classID)
  local ah = ahPriceOfLink(link)
  local ahNet = ah and ah * 0.95 or nil
  tt:AddLine(" ")
  tt:AddLine("Gringotts — désenchantement", 0.89, 0.72, 0.31)
  if ev then tt:AddDoubleLine("Valeur DE estimée", coins(ev), 0.8, 0.8, 0.8, 1, 1, 1)
  elseif txt then tt:AddDoubleLine("Valeur DE estimée", "prix manquant : " .. table.concat(miss or {}, ", "), 0.8, 0.8, 0.8, 1, 0.5, 0)
  else tt:AddDoubleLine("Valeur DE estimée", "pas de donnée", 0.8, 0.8, 0.8, 0.6, 0.6, 0.6) end
  if txt then tt:AddLine("  " .. txt, 0.6, 0.6, 0.6, true) end
  tt:AddDoubleLine("Vente au marchand", sell > 0 and coins(sell) or "—", 0.8, 0.8, 0.8, 1, 1, 1)
  if ahNet then tt:AddDoubleLine("Prix HV de l'objet (net)", coins(ahNet), 0.8, 0.8, 0.8, 1, 1, 1) end
  local best, label = sell, "Marchand"
  if ev and ev > best then best, label = ev, "Désenchanter" end
  if ahNet and ahNet > best then best, label = ahNet, "Vendre à l'HV" end
  if best > 0 then tt:AddDoubleLine("→ Meilleur choix", label, 0.3, 0.85, 0.3, 0.3, 0.85, 0.3) end
  if req then
    local sk, who = enchanterSkill()
    if not sk then tt:AddLine(("Requiert Enchantement %d (compétence de votre enchanteur inconnue)"):format(req), 0.6, 0.6, 0.6)
    elseif sk < req then tt:AddLine(("Requiert Enchantement %d — %s : %d"):format(req, who, sk), 1, 0.3, 0.25) end
  end
end
ns.addDETooltip = addDETooltip

------------------------------------------------------------------------
-- Logistique : courrier pré-rempli vers le perso qui craft (lignes LG du dashboard)
------------------------------------------------------------------------
local function pendingSends()
  local out = {}
  for _, l in ipairs((db.dash and db.dash.logi) or {}) do
    if l[1] == charName then out[#out + 1] = l end
  end
  return out
end

-- Emplacements des sacs contenant l'objet (nom normalisé)
local function bagSlotsOf(k)
  local t = {}
  for _, bag in ipairs(bagIDs()) do
    for slot = 1, safeSlots(bag) do
      local info = C_Container.GetContainerItemInfo(bag, slot)
      if info and info.hyperlink and not info.isLocked and norm(nameFromLink(info.hyperlink) or "") == k then
        t[#t + 1] = { bag, slot, info.stackCount or 1 }
      end
    end
  end
  table.sort(t, function(a, b) return a[3] > b[3] end)
  return t
end

local function freeAttachment()
  for i = 1, (ATTACHMENTS_MAX_SEND or 12) do if not HasSendMailItem(i) then return i end end
end

local function prepareMail()
  local list = pendingSends()
  if #list == 0 then say("Aucun envoi prévu pour ce perso dans les décisions du dashboard."); return end
  local to = list[1][2]
  if MailFrameTab_OnClick then pcall(MailFrameTab_OnClick, nil, 2) end
  if SendMailNameEditBox then SendMailNameEditBox:SetText(to) end
  if SendMailSubjectEditBox then SendMailSubjectEditBox:SetText("Gringotts") end
  local done, short = {}, {}
  for _, l in ipairs(list) do
    if l[2] == to then
      local need = l[4]
      for _, s in ipairs(bagSlotsOf(norm(l[3]))) do
        if need <= 0 then break end
        local slotIdx = freeAttachment(); if not slotIdx then break end
        ClearCursor()
        if s[3] <= need then
          C_Container.PickupContainerItem(s[1], s[2]); need = need - s[3]
        else
          C_Container.SplitContainerItem(s[1], s[2], need); need = 0
        end
        ClickSendMailItemButton(slotIdx)
      end
      done[#done + 1] = l[3] .. " ×" .. (l[4] - need)
      if need > 0 then short[#short + 1] = l[3] .. " (manque " .. need .. " en sacs)" end
    end
  end
  say(("Courrier pour %s préparé : %s. Vérifiez puis cliquez sur Envoyer."):format(to, table.concat(done, ", ")))
  if #short > 0 then say("Pas assez en sacs (sortez-les de la banque) : " .. table.concat(short, ", ")) end
  if not freeAttachment() then say("Pièces jointes pleines : envoyez puis recliquez pour la suite.") end
end

local mailBtn
local function mailButton()
  if not MailFrame then return end
  if not mailBtn then
    mailBtn = CreateFrame("Button", "GringottsMailButton", MailFrame, "UIPanelButtonTemplate")
    mailBtn:SetSize(190, 22); mailBtn:SetPoint("TOPRIGHT", MailFrame, "BOTTOMRIGHT", 0, -2)
    mailBtn:SetScript("OnClick", prepareMail)
  end
  local n = #pendingSends()
  mailBtn:SetText(("Gringotts : préparer l'envoi (%d)"):format(n))
  mailBtn:SetShown(n > 0)
end

-- Rappel des retraits de la banque de guilde prévus par le dashboard
local function guildReminder()
  local t = {}
  for _, l in ipairs((db.dash and db.dash.logi) or {}) do
    if l[1] == "Guilde" then t[#t + 1] = ("%s ×%d pour %s"):format(l[3], l[4], l[2]) end
  end
  if #t > 0 then say("À retirer de la banque de guilde : " .. table.concat(t, ", ")) end
end

-- Alerte de stock bas (une fois par objet, jusqu'à retour au-dessus de la cible)
local function checkLowStock()
  local T = db.dash and db.dash.target
  if not T then return end
  db.lowWarned = db.lowWarned or {}
  local low = {}
  for k, tg in pairs(T) do
    if tg[1] and tg[1] > 0 then
      local n = totalStock(k)
      if n < tg[1] then
        if not db.lowWarned[k] then db.lowWarned[k] = true; low[#low + 1] = ("%s %d/%d"):format(trackedName[k] or k, n, tg[1]) end
      else db.lowWarned[k] = nil end
    end
  end
  if #low > 0 then
    table.sort(low)
    say(("Stock bas (%d) : %s%s"):format(#low, table.concat(low, ", ", 1, math.min(#low, 6)), #low > 6 and "…" or ""))
  end
end

ns.checkLowStock = checkLowStock

if TooltipDataProcessor and Enum and Enum.TooltipDataType and Enum.TooltipDataType.Item then
  TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Item, function(tt, data)
    if not tt or not tt.AddLine then return end
    local link = tt.GetItem and select(2, tt:GetItem())
    if not link and data and data.id then link = data.id end
    pcall(addTooltip, tt, link)
    pcall(addDETooltip, tt, type(link) == "string" and link or nil)
  end)
elseif GameTooltip then
  GameTooltip:HookScript("OnTooltipSetItem", function(tt) local _, link = tt:GetItem(); pcall(addTooltip, tt, link); pcall(addDETooltip, tt, link) end)
end

------------------------------------------------------------------------
-- Export
------------------------------------------------------------------------
local function buildExport()
  local L = {}
  local stock = {}
  local function add(c) for k, n in pairs(c or {}) do if tracked[k] then stock[k] = (stock[k] or 0) + n end end end

  L[#L + 1] = ("WFC1;%d;%s;%s"):format(time(), realm, VERSION)
  for _, c in pairs(db.chars) do
    if c.realm == realm and c.faction == faction then
      add(c.bags); add(c.bank)
      L[#L + 1] = ("C;%s;%d;%d"):format(c.name, c.bagsT or 0, c.bankT or 0)
      for prof, r in pairs(c.recipes or {}) do
        for _, it in ipairs(r.list) do
          if type(it) == "table" then L[#L + 1] = ("Q;%s;%s;%s"):format(prof, it.d or "", it.n)
          else L[#L + 1] = ("R;%s;%s"):format(prof, it) end      -- relevé v1.0
        end
        -- Composants de chaque recette vue (apprise ou non) : X;métier;apprise;couleur;recette;produit;qté;compo*qté+…
        for _, x in ipairs(r.all or {}) do
          local parts = {}
          for _, rg in ipairs(x.r) do parts[#parts + 1] = rg[1] .. "*" .. rg[2] end
          L[#L + 1] = ("X;%s;%d;%s;%s;%s;%d;%s"):format(prof, x.l, x.d or "", x.n, x.o or "", x.q or 1, table.concat(parts, "+"))
        end
      end
      for prof, k in pairs(c.skills or {}) do
        L[#L + 1] = ("K;%s;%s;%d;%d"):format(c.name, prof, k.l, k.m)
      end
      for rn, cd in pairs(c.cds or {}) do
        L[#L + 1] = ("D;%s;%d;%s"):format(c.name, cd.r or 0, rn)
      end
      -- Or par jour : GD;date;perso;cuivre
      for d, m in pairs(c.goldDays or {}) do L[#L + 1] = ("GD;%s;%s;%d"):format(d, c.name, m) end
      -- Stock par perso (sacs + banque) : SC;perso;objet;qté
      local per = {}
      for k, n in pairs(c.bags or {}) do if tracked[k] then per[k] = (per[k] or 0) + n end end
      for k, n in pairs(c.bank or {}) do if tracked[k] then per[k] = (per[k] or 0) + n end end
      for k, n in pairs(per) do L[#L + 1] = ("SC;%s;%s;%d"):format(c.name, trackedName[k] or k, n) end
      -- Équipement désenchantable : E;perso;ilvl;qualité;classe;marchand;HV;objet
      for _, lst in ipairs({ c.equipBags or {}, c.equipBank or {} }) do
        for _, e in ipairs(lst) do
          local ah = (c.name == charName) and ahPriceOfLink(e.link) or nil
          L[#L + 1] = ("E;%s;%d;%d;%d;%d;%s;%s"):format(c.name, e.l or 0, e.q or 2, e.c or 4, e.s or 0, ah and tostring(ah) or "", e.n)
        end
      end
    end
  end
  for _, G in pairs(db.guilds) do
    if G.realm == realm and G.faction == faction then
      local nt = 0
      for d, m in pairs(G.goldDays or {}) do L[#L + 1] = ("GD;%s;Banque de guilde;%d"):format(d, m) end
      local gs = {}
      for _, tb in pairs(G.tabs or {}) do add(tb.c); nt = nt + 1; for k, n in pairs(tb.c or {}) do if tracked[k] then gs[k] = (gs[k] or 0) + n end end end
      for k, n in pairs(gs) do L[#L + 1] = ("SG;%s;%d"):format(trackedName[k] or k, n) end
      L[#L + 1] = ("G;%s;%d;%d/%d"):format(G.name or "?", G.t or 0, nt, G.numTabs or nt)
    end
  end

  -- Prix marchands PNJ relevés : V;objet;cuivre par unité
  for _, v in pairs(db.vendor or {}) do
    if tracked[norm(v.n)] or reagents[norm(v.n)] then L[#L + 1] = ("V;%s;%s"):format(v.n, (math.floor(v.c * 100 + 0.5) / 100)) end
  end
  -- Transactions HV (45 j) : T;type;horodatage;qté;cuivre;objet  (V vendu, A acheté, E expiré, X annulé, L mis en vente)
  for _, tr in ipairs(db.trades or {}) do
    L[#L + 1] = ("T;%s;%d;%d;%d;%s"):format(tr.k, tr.t, tr.q, tr.c, tr.n)
    if tr.k == "L" and tr.d then L[#L + 1] = ("DP;%d;%d;%d;%s"):format(tr.t, tr.q, tr.d, tr.n) end   -- DP;horodatage;qté;dépôt total;objet
  end

  local keys = {}
  for k in pairs(tracked) do keys[#keys + 1] = k end
  table.sort(keys)
  local np, nu = 0, 0
  for _, k in ipairs(keys) do
    local name = trackedName[k]
    local id = db.ids[k]
    if id then
      local p, age = priceOf(id)
      if p and p > 0 then L[#L + 1] = ("P;%s;%d;%s;%d"):format(name, p, age or "", id); np = np + 1 end   -- id : rapprochement avec l'API Blizzard
    else
      L[#L + 1] = ("U;%s"):format(name); nu = nu + 1
    end
    if stock[k] and stock[k] > 0 then L[#L + 1] = ("S;%s;%d"):format(name, stock[k]) end
    local sp = id and sellPriceOf(id)
    if sp and sp > 0 then L[#L + 1] = ("W;%s;%d"):format(name, sp) end
  end
  return table.concat(L, "\n"), np, nu
end

local frame
local function showExport(text, info)
  if not frame then
    frame = CreateFrame("Frame", "GringottsExportFrame", UIParent, "BasicFrameTemplateWithInset")
    frame:SetSize(520, 380); frame:SetPoint("CENTER"); frame:SetFrameStrata("DIALOG")
    frame:SetMovable(true); frame:EnableMouse(true); frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", frame.StartMoving); frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
    frame.title = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    frame.title:SetPoint("TOP", 0, -5); frame.title:SetText("Gringotts — export dashboard")
    frame.info = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    frame.info:SetPoint("TOPLEFT", 14, -32); frame.info:SetPoint("TOPRIGHT", -14, -32); frame.info:SetJustifyH("LEFT")
    local sf = CreateFrame("ScrollFrame", nil, frame, "UIPanelScrollFrameTemplate")
    sf:SetPoint("TOPLEFT", 12, -52); sf:SetPoint("BOTTOMRIGHT", -32, 12)
    local eb = CreateFrame("EditBox", nil, sf)
    eb:SetMultiLine(true); eb:SetAutoFocus(false); eb:SetFontObject(ChatFontNormal); eb:SetWidth(460)
    eb:SetScript("OnEscapePressed", function() frame:Hide() end)
    eb:SetScript("OnTextChanged", function(self, user) if user then self:SetText(frame.text or ""); self:HighlightText() end end)
    sf:SetScrollChild(eb)
    frame.eb = eb
    tinsert(UISpecialFrames, "GringottsExportFrame")
  end
  frame.text = text
  frame.info:SetText(info .. "  |cffaaaaaaCtrl+C puis collez dans le dashboard.|r")
  frame:Show()
  frame.eb:SetText(text); frame.eb:SetFocus(); frame.eb:HighlightText()
end

local function export()
  if not auctionatorAPI() then say("Auctionator introuvable : export du stock et des recettes seulement.") end
  scanBags(); scanBank(); scanSkills(); scanGold()
  resolveIDs(function()
    local text, np, nu = buildExport()
    showExport(text, ("%d prix · %d objets sans identifiant"):format(np, nu))
  end)
end
ns.export = export

------------------------------------------------------------------------
-- Synchro automatique : l'addon ne peut pas écrire de fichier ni joindre Internet.
-- Il range donc le dernier export complet dans GringottsDB.syncText (écrit sur disque
-- au /reload ou à la déconnexion) ; le script Windows Gringotts-Sync le chiffre et l'envoie.
------------------------------------------------------------------------
local function snapshot()
  if not db then return false end
  local ok, text = pcall(buildExport)
  if ok and type(text) == "string" and #text > 0 then db.syncText = text; db.syncT = time(); db.syncWhy = "sync"; db.syncErr = nil; return true end
  db.syncErr = tostring(text):sub(1, 200)
  return false
end

-- Relevé complet, export prêt, puis /reload prérempli dans le chat (ReloadUI est interdit aux addons :
-- WoW affiche « Échec d'une action d'interface » ; une commande tapée par le joueur, elle, passe).
local function syncAndReload()
  scanBags(); scanBank(); scanSkills(); scanGold()
  resolveIDs(function()
    if not snapshot() then say("Export impossible."); return end
    say("Export prêt. Appuie sur |cffe4b84eEntrée|r pour recharger (/reload), puis lance Envoyer.bat sur le PC.")
    C_Timer.After(0.3, function() if not pcall(ChatFrame_OpenChat, "/reload") then say("Tape |cffe4b84e/reload|r pour finir.") end end)
  end)
end
ns.syncAndReload = syncAndReload

StaticPopupDialogs["GRINGOTTS_SYNC"] = {
  text = "Gringotts : le scan de l'Hôtel des ventes est terminé.\nPréparer l'export pour le dashboard ? (le /reload sera prérempli : appuie sur Entrée)",
  button1 = "Préparer",
  button2 = "Plus tard",
  OnAccept = function() if ns.syncAndReload then ns.syncAndReload() end end,
  timeout = 0, whileDead = true, hideOnEscape = true, preferredIndex = 3,
}
local lastPrompt = 0
local function promptSync()
  if time() - lastPrompt < 120 then return end
  lastPrompt = time()
  if not snapshot() then return end
  say("Scan terminé : clique sur « Préparer » (ou /gt sync) puis Entrée pour envoyer les données au dashboard.")
  pcall(StaticPopup_Show, "GRINGOTTS_SYNC")
end

-- Fin du scan complet Auctionator : événement de son bus interne (nom lu dynamiquement)
local scanHooked = false
local function hookFullScan()
  if scanHooked then return end
  local A = Auctionator
  if not (A and A.EventBus and A.FullScan and type(A.FullScan.Events) == "table") then return end
  local names = {}
  for k, v in pairs(A.FullScan.Events) do
    if type(k) == "string" and type(v) == "string" and k:lower():find("complete") then names[#names + 1] = v end
  end
  if #names == 0 then return end
  local listener = {}
  function listener:ReceiveEvent() C_Timer.After(2, promptSync) end
  scanHooked = pcall(function()
    A.EventBus:RegisterSource(listener, "Gringotts")
    A.EventBus:Register(listener, names)
  end)
end

-- Secours si l'événement n'existe pas : à la fermeture de l'HV, des prix relevés « aujourd'hui »
-- bien plus nombreux qu'à l'ouverture = un scan a eu lieu.
local freshAtOpen = 0
local function countFresh()
  local n = 0
  for _, id in pairs(db.ids or {}) do local _, age = priceOf(id); if age == 0 then n = n + 1 end end
  return n
end
local function ahOpened() hookFullScan(); freshAtOpen = countFresh() end
local function ahClosed()
  if scanHooked then return end
  if countFresh() > freshAtOpen + 5 then promptSync() end
end

------------------------------------------------------------------------
-- Bouton sur l'Hôtel des ventes
------------------------------------------------------------------------
local function addAHButton()
  if not AuctionHouseFrame or GringottsAHButton then return end
  local b = CreateFrame("Button", "GringottsAHButton", AuctionHouseFrame, "UIPanelButtonTemplate")
  b:SetSize(150, 22); b:SetText("Sync Gringotts")
  b:SetPoint("TOPRIGHT", AuctionHouseFrame, "TOPRIGHT", -30, -1)
  b:SetScript("OnClick", syncAndReload)
  b:SetScript("OnEnter", function(self) GameTooltip:SetOwner(self, "ANCHOR_BOTTOM"); GameTooltip:SetText("Gringotts"); GameTooltip:AddLine("Prépare l'export et préremplit /reload dans le chat : appuie sur Entrée.\nLance ensuite Envoyer.bat sur le PC.", 1, 1, 1, true); GameTooltip:Show() end)
  b:SetScript("OnLeave", function() GameTooltip:Hide() end)
end

------------------------------------------------------------------------
-- Statut
------------------------------------------------------------------------
local function status()
  say(("v%s — royaume %s (%s)"):format(VERSION, realm, faction))
  for _, c in pairs(db.chars) do
    if c.realm == realm and c.faction == faction then
      local profs = {}
      for p, k in pairs(c.skills or {}) do profs[#profs + 1] = ("%s %d/%d"):format(p, k.l, k.m) end
      print(("  %s : sacs %s · banque %s%s"):format(c.name, ago(c.bagsT), ago(c.bankT),
        #profs > 0 and (" · " .. table.concat(profs, ", ")) or ""))
    end
  end
  for _, G in pairs(db.guilds) do
    if G.realm == realm and G.faction == faction then print(("  Guilde %s : %s"):format(G.name or "?", ago(G.t))) end
  end
  for _, c in pairs(db.chars) do
    for rn, cd in pairs(c.cds or {}) do
      local left = (cd.r or 0) - time()
      print(("  Recharge %s · %s : %s"):format(c.name, rn, left <= 0 and "|cff55ff55prêt|r" or (math.floor(left / 3600) .. " h " .. math.floor(left % 3600 / 60) .. " min")))
    end
  end
  local n = 0; for _ in pairs(tracked) do n = n + 1 end
  print(("  Objets identifiés : %d / %d"):format(n - missingCount(), n))
  local nv = 0; for _ in pairs(db.vendor or {}) do nv = nv + 1 end
  print(("  Prix marchands PNJ relevés : %d objets"):format(nv))
  print("  Auctionator : " .. (auctionatorAPI() and "OK" or "|cffff5555absent|r"))
  if db.syncT then
    local m = math.floor((time() - db.syncT) / 60)
    print(("  Dernier export : il y a %d min (%s)"):format(m, db.syncWhy or "?"))
  else
    print("  Dernier export : |cffff5555aucun|r")
  end
  if db.syncErr then print("  |cffff5555Erreur d'export : " .. db.syncErr .. "|r") end
end

------------------------------------------------------------------------
-- Événements
------------------------------------------------------------------------
local ev = CreateFrame("Frame")
local function reg(e) pcall(ev.RegisterEvent, ev, e) end
for _, e in ipairs({ "ADDON_LOADED", "PLAYER_LOGIN", "PLAYER_LOGOUT", "BAG_UPDATE_DELAYED",
  "PLAYERBANKSLOTS_CHANGED", "PLAYERREAGENTBANKSLOTS_CHANGED", "BANKFRAME_OPENED", "BANKFRAME_CLOSED",
  "GUILDBANKFRAME_OPENED", "GUILDBANKFRAME_CLOSED", "GUILDBANKBAGSLOTS_CHANGED",
  "PLAYER_INTERACTION_MANAGER_FRAME_SHOW", "PLAYER_INTERACTION_MANAGER_FRAME_HIDE",
  "TRADE_SKILL_SHOW", "TRADE_SKILL_LIST_UPDATE", "TRADE_SKILL_DATA_SOURCE_CHANGED",
  "ITEM_DATA_LOAD_RESULT", "AUCTION_HOUSE_SHOW", "AUCTION_HOUSE_CLOSED", "SKILL_LINES_CHANGED", "MAIL_INBOX_UPDATE", "MAIL_SHOW", "MERCHANT_SHOW", "MERCHANT_UPDATE", "PLAYER_MONEY", "GUILDBANK_UPDATE_MONEY" }) do reg(e) end

local timers = {}
local function debounce(key, delay, fn)
  if timers[key] then return end
  timers[key] = true
  C_Timer.After(delay, function() timers[key] = nil; fn() end)
end

local PIT = (Enum and Enum.PlayerInteractionType) or {}
local function openBank() bankOpen = true; C_Timer.After(0.5, scanBank) end
local function openGuild() if not guildOpen then guildOpen = true; C_Timer.After(0.5, startGuildScan); C_Timer.After(1, guildReminder); C_Timer.After(1, scanGuildGold) end end

ev:SetScript("OnEvent", function(_, e, a1, a2)
  if e == "ADDON_LOADED" then
    if a1 == ADDON then initDB() end
  elseif e == "PLAYER_LOGIN" then
    loginT = time()
    C_Timer.After(3, function() scanBags(); scanSkills(); scanGold() end)
    for _, d in ipairs({ 10, 30, 60 }) do C_Timer.After(d, scanGold) end   -- l'or n'est pas toujours chargé à +3 s
    C_Timer.After(15, function() resolveIDs() end)
    C_Timer.After(8, function() syncShoppingList() end)
    C_Timer.After(5, hookFullScan)
    C_Timer.After(10, applyDashFile)
    addAHButton()
  elseif e == "PLAYER_LOGOUT" then
    if db then
      -- chaque relevé est isolé : une erreur d'API à la déconnexion ne doit pas empêcher l'export
      pcall(scanBags); pcall(scanGold)
      pcall(snapshot)
      db.syncWhy = "logout"
    end
  elseif e == "PLAYER_MONEY" then
    debounce("gold", 2, scanGold)
  elseif e == "GUILDBANK_UPDATE_MONEY" then
    debounce("ggold", 1, scanGuildGold)
  elseif e == "BAG_UPDATE_DELAYED" then
    debounce("bags", 1, function() scanBags(); scanBank() end)
  elseif e == "PLAYERBANKSLOTS_CHANGED" or e == "PLAYERREAGENTBANKSLOTS_CHANGED" then
    debounce("bank", 1, scanBank)
  elseif e == "BANKFRAME_OPENED" then openBank()
  elseif e == "BANKFRAME_CLOSED" then bankOpen = false
  elseif e == "GUILDBANKFRAME_OPENED" then openGuild()
  elseif e == "GUILDBANKFRAME_CLOSED" then guildOpen = false
  elseif e == "PLAYER_INTERACTION_MANAGER_FRAME_SHOW" then
    if a1 == PIT.Banker then openBank()
    elseif a1 == PIT.GuildBanker then openGuild()
    elseif a1 == PIT.Auctioneer then C_Timer.After(0.2, addAHButton); C_Timer.After(1, ahOpened) end
  elseif e == "PLAYER_INTERACTION_MANAGER_FRAME_HIDE" then
    if a1 == PIT.Banker then bankOpen = false
    elseif a1 == PIT.GuildBanker then guildOpen = false
    elseif a1 == PIT.Auctioneer then debounce("ahclose", 1, ahClosed) end
  elseif e == "GUILDBANKBAGSLOTS_CHANGED" then
    onGuildSlotsChanged()
  elseif e == "TRADE_SKILL_SHOW" or e == "TRADE_SKILL_LIST_UPDATE" or e == "TRADE_SKILL_DATA_SOURCE_CHANGED" then
    debounce("prof", 1, scanProfession)
  elseif e == "ITEM_DATA_LOAD_RESULT" then
    if a2 and resolver.pending[a1] then resolveOne(a1) end
  elseif e == "MERCHANT_SHOW" or e == "MERCHANT_UPDATE" then
    debounce("merchant", 0.5, scanMerchant)
  elseif e == "MAIL_INBOX_UPDATE" or e == "MAIL_SHOW" then
    debounce("mail", 0.5, scanMail)
    if e == "MAIL_SHOW" then C_Timer.After(0.3, mailButton) end
  elseif e == "SKILL_LINES_CHANGED" then
    debounce("skills", 1, scanSkills)
  elseif e == "AUCTION_HOUSE_SHOW" then
    C_Timer.After(0.2, addAHButton); C_Timer.After(1, ahOpened)
  elseif e == "AUCTION_HOUSE_CLOSED" then
    debounce("ahclose", 1, ahClosed)
  end
end)

------------------------------------------------------------------------
-- Commandes
------------------------------------------------------------------------
SLASH_GRINGOTTS1 = "/gringotts"
SLASH_GRINGOTTS2 = "/gt"
SlashCmdList.GRINGOTTS = function(msg)
  msg = (msg or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
  if msg == "" or msg == "export" then export()
  elseif msg == "sync" then syncAndReload()
  elseif msg == "status" then status()
  elseif msg == "liste" then syncShoppingList(true); syncBuyList()
  elseif msg == "import" then showImport()
  elseif msg == "contour" then
    db.highlight = not db.highlight
    say("Contour orange des composants : " .. (db.highlight and "activé" or "désactivé") .. " (fermez/rouvrez les sacs).")
  elseif msg == "ids" then db.checked = {}; resolveIDs(function() say("Identification terminée.") ; status() end)
  elseif msg == "reset" then
    GringottsDB = nil; initDB(); scanBags(); say("Données effacées pour tous les persos. Reconnectez chaque perso et rouvrez les banques.")
  else
    say("/gt — export · /gt sync — préparer l'export (puis Entrée pour le /reload) · /gt status — état des relevés · /gt import — décisions du dashboard · /gt liste — recréer les listes Auctionator · /gt contour — activer/désactiver le contour orange · /gt ids — réidentifier les objets · /gt reset — tout effacer")
  end
end
