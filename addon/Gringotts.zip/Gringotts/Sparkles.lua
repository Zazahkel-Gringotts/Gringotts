-- Gringotts : scintillement des objets de quête / ramassables (équivalent de Forever Loot Sparkles).
-- Active la variable de console outlineModeShowLootEffectWhenDisabled. Désactivable : /gt scintille
local ADDON, ns = ...
local CVAR = "outlineModeShowLootEffectWhenDisabled"

local function say(m) print("|cffe4b84eGringotts|r " .. m) end

local function apply(on)
  if SetCVar then pcall(SetCVar, CVAR, on and "1" or "0") end
end

function ns.sparklesSet(on)
  GringottsDB = GringottsDB or {}
  GringottsDB.sparkles = on and true or false
  apply(on)
end

function ns.sparklesGet()
  return GringottsDB and GringottsDB.sparkles ~= false   -- activé par défaut
end

function ns.sparklesCmd()
  ns.sparklesSet(not ns.sparklesGet())
  say("Scintillement des objets ramassables : " .. (ns.sparklesGet() and "activé" or "désactivé") .. ".")
end

-- Le client Forever relit mal les réglages : on réapplique à chaque connexion / rechargement.
local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_ENTERING_WORLD")
f:SetScript("OnEvent", function() apply(ns.sparklesGet()) end)
