-- Gringotts : bouton de minimap + menu (Business, Métiers, Récolte, Pêche, Bêtes pour un chasseur, Options).
-- Clic gauche : menu · glisser : déplacer autour de la minimap · /gt bouton : afficher/masquer
local ADDON, ns = ...

local ENTRIES = {
  { "Business", "stock" },
  { "Métiers", "crafts" },
  { "Récolte", "gathering" },
  { "Pêche", "peche" },
  { "Options", "settings" },
}

local btn, menu

local function place()
  local a = math.rad((GringottsDB and GringottsDB.mini and GringottsDB.mini.angle) or 215)
  btn:ClearAllPoints()
  btn:SetPoint("CENTER", Minimap, "CENTER", 80 * math.cos(a), 80 * math.sin(a))
end

local function buildMenu()
  if ns.pets and ns.pets.isHunter and ns.pets.isHunter() then table.insert(ENTRIES, #ENTRIES, { "Bêtes", "pets" }) end
  menu = CreateFrame("Frame", "GringottsMenu", UIParent, "BackdropTemplate")
  menu:SetSize(130, #ENTRIES * 24 + 12)
  menu:SetFrameStrata("DIALOG")
  menu:SetBackdrop({ bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 12, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
  menu:SetBackdropColor(0, 0, 0, 0.9)
  for i, e in ipairs(ENTRIES) do
    local b = CreateFrame("Button", nil, menu)
    b:SetSize(118, 22); b:SetPoint("TOPLEFT", menu, "TOPLEFT", 6, -6 - (i - 1) * 24)
    local t = b:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    t:SetPoint("LEFT", b, "LEFT", 6, 0); t:SetText(e[1])
    b:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight")
    b:SetScript("OnClick", function() menu:Hide(); if ns.uiOpen then ns.uiOpen(e[2]) end end)
  end
  menu:Hide()
  if UISpecialFrames then tinsert(UISpecialFrames, "GringottsMenu") end
end

local function toggleMenu()
  if not menu then buildMenu() end
  if menu:IsShown() then menu:Hide() return end
  menu:ClearAllPoints()
  menu:SetPoint("TOPRIGHT", btn, "BOTTOMLEFT", 0, 0)
  menu:Show()
end

local function build()
  btn = CreateFrame("Button", "GringottsMinimapButton", Minimap)
  btn:SetSize(31, 31)
  btn:SetFrameStrata("MEDIUM"); btn:SetFrameLevel(8)
  btn:RegisterForClicks("LeftButtonUp")
  btn:RegisterForDrag("LeftButton")
  local icon = btn:CreateTexture(nil, "ARTWORK")
  icon:SetTexture("Interface\\Icons\\INV_Misc_Coin_02")
  icon:SetSize(20, 20); icon:SetPoint("CENTER")
  local border = btn:CreateTexture(nil, "OVERLAY")
  border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
  border:SetSize(53, 53); border:SetPoint("TOPLEFT")
  btn:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
  btn:SetScript("OnClick", toggleMenu)
  btn:SetScript("OnDragStart", function(self)
    self:SetScript("OnUpdate", function()
      local mx, my = Minimap:GetCenter()
      local cx, cy = GetCursorPosition()
      local s = Minimap:GetEffectiveScale()
      cx, cy = cx / s, cy / s
      GringottsDB.mini = GringottsDB.mini or {}
      GringottsDB.mini.angle = math.deg(math.atan2(cy - my, cx - mx))
      place()
    end)
  end)
  btn:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
  btn:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_LEFT")
    GameTooltip:SetText("Gringotts"); GameTooltip:AddLine("Clic : menu · glisser : déplacer", 1, 1, 1)
    GameTooltip:Show()
  end)
  btn:SetScript("OnLeave", function() GameTooltip:Hide() end)
  place()
  if GringottsDB.mini and GringottsDB.mini.hidden then btn:Hide() end
end

function ns.launcherCmd()
  if not btn then return end
  GringottsDB.mini = GringottsDB.mini or {}
  GringottsDB.mini.hidden = not GringottsDB.mini.hidden
  if GringottsDB.mini.hidden then btn:Hide() else btn:Show() end
end

function ns.launcherShow(on)
  if not btn then return end
  GringottsDB.mini = GringottsDB.mini or {}
  GringottsDB.mini.hidden = not on
  if on then btn:Show() else btn:Hide() end
end
function ns.launcherReset()
  if not btn then return end
  GringottsDB.mini = GringottsDB.mini or {}
  GringottsDB.mini.angle = 215; GringottsDB.mini.hidden = false
  btn:Show(); place()
end

local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", function()
  GringottsDB = GringottsDB or {}
  build()
end)
