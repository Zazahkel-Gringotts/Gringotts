-- Gringotts : onglet Options. Sections à gauche (Général, Business, Récolte, Pêche, Chasseur, Données), réglages au centre,
-- un bouton « Réinitialiser » par section. Section Chasseur : visible seulement pour un chasseur, avec démonstration de la barre en direct.
local ADDON, ns = ...
local O = {}
ns.opt = O

local W = ns.W
local function api() return ns.api end
local function db() return api() and api().db() end
local function say(m) print("|cffe4b84eGringotts|r " .. m) end

-- Réglages d'interface (valeurs par défaut) : format des prix, échelle, position, ouverture à la connexion, infobulle des objets
local UI_DEF = { fmt = 1, scale = 100, remember = true, openLogin = false, tipItems = true }
function O.ui()
  local d = db(); if not d then return {} end
  d.ui = d.ui or {}
  for k, v in pairs(UI_DEF) do if d.ui[k] == nil then d.ui[k] = v end end
  return d.ui
end
function O.resetGeneral()
  local d = db(); if not d then return end
  local u = O.ui()
  for k, v in pairs(UI_DEF) do u[k] = v end
  d.highlight = true
  if ns.sparklesSet then ns.sparklesSet(true) end
  if GringottsDB.mini then GringottsDB.mini.hidden = false end
  if ns.launcherShow then ns.launcherShow(true) end
  if ns.uiApplyLook then ns.uiApplyLook() end
end
-- Business : valeurs par défaut du moteur (on vide les clés, E.cfg() les recrée)
local BIZ_KEYS = { "sellGap", "spec", "specGap", "specQty", "fee", "floorPct", "spikeX" }
function O.resetBusiness()
  local E = ns.engine; if not E then return end
  local s = E.cfg()
  for _, k in ipairs(BIZ_KEYS) do s[k] = nil end
  local d = db(); if d then d.staleDays = 3 end
  E.cfg()
end
function O.resetGather()
  local d = db(); if not d then return end
  d.arrow = d.arrow or {}
  d.arrow.sound = false; d.arrow.alertDist = 100
  if d.arrow.on == false and ns.arrowCmd then ns.arrowCmd("") end
end
function O.resetFish()
  if ns.fishing then local s = ns.fishing.st(); s.auto = true; s.lure = true; if ns.fishing.sync then ns.fishing.sync() end end
end
function O.resetHunter()
  local Sh = ns.shot; if not Sh then return end
  local c = Sh.cfg()
  c.on, c.w, c.h, c.alpha, c.text, c.aim, c.ammo, c.pos = true, 260, 22, 1, true, 0.5, true, nil
  Sh.applyLook(); Sh.recenter(); Sh.refreshShow()
  if ns.pets and ns.pets.setTip then ns.pets.setTip(true) end
end

local SECTIONS = {
  { key = "general", label = "Général", sub = "affichage, prix, bouton" },
  { key = "business", label = "Business", sub = "achats, ventes, alertes" },
  { key = "gather", label = "Récolte", sub = "flèche, son, distance" },
  { key = "fish", label = "Pêche", sub = "mode auto, leurre" },
  { key = "hunter", label = "Chasseur", sub = "tir auto, bêtes", hunter = true },
  { key = "data", label = "Données", sub = "version, commandes, positions" },
}

function O.build(pane)
  local isHunter = ns.pets and ns.pets.isHunter and ns.pets.isHunter()
  local left = CreateFrame("Frame", nil, pane); left:SetPoint("TOPLEFT", 0, 0); left:SetPoint("BOTTOMLEFT", 0, 0); left:SetWidth(230)
  local pages, btns, order = {}, {}, {}
  local current

  local function newPage()
    local p = CreateFrame("Frame", nil, pane)
    p:SetPoint("TOPLEFT", left, "TOPRIGHT", 12, 0); p:SetPoint("BOTTOMRIGHT", 0, 0); p:Hide()
    p.y, p.refs = -8, {}
    return p
  end
  local function head(p, t, sub)
    local fs = p:CreateFontString(nil, "OVERLAY", "GringottsH1"); fs:SetPoint("TOPLEFT", 8, p.y); fs:SetText(t)
    p.y = p.y - 26
    if sub then local s = p:CreateFontString(nil, "OVERLAY", "GringottsMuted"); s:SetPoint("TOPLEFT", 8, p.y); s:SetText(sub); p.y = p.y - 20 end
  end
  local function sec(p, t) p.y = p.y - 8; local fs = p:CreateFontString(nil, "OVERLAY", "GringottsH2"); fs:SetPoint("TOPLEFT", 8, p.y); fs:SetText(t); p.y = p.y - 26 end
  local function chk(p, label, get, set, subtext)
    local cb = ns.theme.check(p, label)
    cb:SetPoint("TOPLEFT", 8, p.y)
    cb:SetScript("OnClick", function(self) set(self:GetChecked() and true or false) end)
    p.refs[#p.refs + 1] = function() cb:SetChecked(get() and true or false) end
    p.y = p.y - 26
    if subtext then local s = p:CreateFontString(nil, "OVERLAY", "GringottsMuted"); s:SetPoint("TOPLEFT", 36, p.y + 3); s:SetText(subtext); p.y = p.y - 14 end
    return cb
  end
  local function lbl(p, t, y) local l = p:CreateFontString(nil, "OVERLAY", "GringottsText"); l:SetPoint("TOPLEFT", 12, y - 4); l:SetText(t) end
  -- ligne « libellé + 1 ou 2 champs numériques » ; get/set reçoivent la valeur affichée
  local function num(p, label, g1, s1, g2, s2)
    lbl(p, label, p.y)
    local e1 = W.edit(p, 54, true); e1:SetPoint("TOPLEFT", 420, p.y)
    e1:SetScript("OnEditFocusLost", function(self) s1(tonumber(self:GetText())); p.refresh() end)
    local e2
    if g2 then e2 = W.edit(p, 54, true); e2:SetPoint("TOPLEFT", 484, p.y); e2:SetScript("OnEditFocusLost", function(self) s2(tonumber(self:GetText())); p.refresh() end) end
    p.refs[#p.refs + 1] = function() e1:SetText(tostring(g1())); if e2 then e2:SetText(tostring(g2())) end end
    p.y = p.y - 30
  end
  local function button(p, text, w, onclick, x, y)
    local b = ns.theme.button(p, text, w, 22, onclick)
    b:SetPoint("TOPLEFT", x or 8, y or p.y); return b
  end
  local function resetRow(p, name, fn)
    p.y = p.y - 14
    local ln = p:CreateTexture(nil, "ARTWORK"); ln:SetColorTexture(ns.theme.c.line[1], ns.theme.c.line[2], ns.theme.c.line[3], 1); ln:SetPoint("TOPLEFT", 8, p.y); ln:SetSize(660, 1); p.y = p.y - 12
    button(p, "Réinitialiser « " .. name .. " »", 220, function() fn(); p.refresh(); say("Section « " .. name .. " » remise aux valeurs par défaut.") end)
    local s = p:CreateFontString(nil, "OVERLAY", "GringottsMuted"); s:SetPoint("TOPLEFT", 240, p.y - 6); s:SetText("Remet uniquement cette section aux valeurs par défaut.")
    p.y = p.y - 30
  end
  local function finish(p) p.refresh = function() for _, f in ipairs(p.refs) do f() end end; p.refresh() end

  ---------------------------------------------------------------- Général
  local g = newPage(); pages.general = g
  head(g, "Général", "S'applique à tout l'addon")
  chk(g, "Scintillement des objets ramassables (quête, etc.)", function() return ns.sparklesGet and ns.sparklesGet() end,
    function(v) if ns.sparklesSet then ns.sparklesSet(v) end end, "Remplace l'addon Forever Loot Sparkles (même variable de console) : tu peux le désinstaller.")
  chk(g, "Contour orange des composants dans les sacs", function() return db().highlight end, function(v) db().highlight = v end)
  chk(g, "Infobulle des objets : prix et conseil d'achat", function() return O.ui().tipItems end, function(v) O.ui().tipItems = v end)
  sec(g, "Affichage")
  lbl(g, "Format des prix", g.y)
  local fmtBtns = {}
  for i, t in ipairs({ "12 34 56", "12,34 po", "12g 34s 56c" }) do
    local b = button(g, t, 96, function() O.ui().fmt = i; g.refresh() end, 280 + (i - 1) * 100, g.y + 1); fmtBtns[i] = b
  end
  g.refs[#g.refs + 1] = function() for i, b in ipairs(fmtBtns) do if O.ui().fmt == i then b:Disable() else b:Enable() end end end
  g.y = g.y - 30
  num(g, "Échelle de la fenêtre (50 à 150 %)", function() return O.ui().scale end,
    function(v) if v and v >= 50 and v <= 150 then O.ui().scale = v; if ns.uiApplyLook then ns.uiApplyLook() end end end)
  num(g, "Taille du texte (80 à 140 %)", function() return O.ui().fontScale or 100 end,
    function(v) if v and v >= 80 and v <= 140 then O.ui().fontScale = v; if ns.theme and ns.theme.applyLook then ns.theme.applyLook() end end end)
  chk(g, "Texte plus contrasté (lisibilité)", function() return O.ui().contrast end,
    function(v) O.ui().contrast = v and true or nil; if ns.theme and ns.theme.applyLook then ns.theme.applyLook() end end, "Éclaircit le texte principal et le texte atténué ; s'applique tout de suite.")
  num(g, "Taille du bouton Gringotts (60 à 160 %)", function() return (GringottsDB.mini and GringottsDB.mini.scale) or 100 end,
    function(v) if v and v >= 60 and v <= 160 then GringottsDB.mini = GringottsDB.mini or {}; GringottsDB.mini.scale = v; if ns.launcherApply then ns.launcherApply() end end end)
  chk(g, "Mémoriser la position de la fenêtre", function() return O.ui().remember end, function(v) O.ui().remember = v end)
  chk(g, "Ouvrir la fenêtre à la connexion", function() return O.ui().openLogin end, function(v) O.ui().openLogin = v end)
  sec(g, "Bouton Gringotts")
  chk(g, "Afficher le bouton", function() return not (GringottsDB.mini and GringottsDB.mini.hidden) end,
    function(v) if ns.launcherShow then ns.launcherShow(v) end end)
  button(g, "Recentrer le bouton", 150, function() if ns.launcherReset then ns.launcherReset() end end)
  button(g, "Recentrer la fenêtre", 150, function() if ns.uiResetPos then ns.uiResetPos() end end, 168)
  g.y = g.y - 30
  resetRow(g, "Général", O.resetGeneral); finish(g)

  ---------------------------------------------------------------- Business
  local b = newPage(); pages.business = b
  local E = ns.engine
  head(b, "Business", "Seuils d'achat, de vente et d'alerte")
  num(b, "Vendre quand le prix dépasse la médiane 30 j de (%)", function() return math.floor(E.cfg().sellGap * 100 + .5) end,
    function(v) if v and v >= 0 then E.cfg().sellGap = v / 100 end end)
  chk(b, "Achat spéculatif : proposer d'acheter sous la médiane, même sans recette", function() return E.cfg().spec end, function(v) E.cfg().spec = v end)
  num(b, "Achat spéculatif : écart sous la médiane (%) / quantité", function() return math.floor(E.cfg().specGap * 100 + .5) end,
    function(v) if v and v > 0 then E.cfg().specGap = v / 100 end end, function() return E.cfg().specQty end, function(v) if v and v > 0 then E.cfg().specQty = v end end)
  num(b, "Alerte si les prix ont plus de (jours)", function() return db().staleDays or 3 end, function(v) if v and v > 0 then db().staleDays = v end end)
  num(b, "Commission de l'HV (%) / plancher de vente (% de la médiane)", function() return math.floor(E.cfg().fee * 100 + .5) end,
    function(v) if v and v >= 0 and v < 100 then E.cfg().fee = v / 100 end end, function() return math.floor(E.cfg().floorPct * 100 + .5) end,
    function(v) if v and v > 0 and v <= 100 then E.cfg().floorPct = v / 100 end end)
  num(b, "Prix anormal : écart de x fois la médiane (pic ou creux)", function() return E.cfg().spikeX end, function(v) if v and v >= 2 then E.cfg().spikeX = v end end)
  resetRow(b, "Business", O.resetBusiness); finish(b)

  ---------------------------------------------------------------- Récolte
  local r = newPage(); pages.gather = r
  head(r, "Récolte", "Flèche, boussole et réglages GatherMate2")
  if ns.gatherUI and ns.gatherUI.buildSettings then
    local sf = ns.gatherUI.buildSettings(r)
    sf:SetPoint("TOPLEFT", r, "TOPLEFT", 8, r.y + 190)
    r.y = r.y - 500
    r.refs[#r.refs + 1] = function() ns.gatherUI.refreshSettings() end
  end
  resetRow(r, "Récolte", O.resetGather); finish(r)

  ---------------------------------------------------------------- Pêche
  local f = newPage(); pages.fish = f
  head(f, "Pêche")
  chk(f, "Mode pêche automatique (canne équipée = session, touche unique lancer / ramasser)", function() return ns.fishing and ns.fishing.st().auto ~= false end,
    function(v) if ns.fishing then ns.fishing.st().auto = v; ns.fishing.sync() end end)
  chk(f, "Leurre automatique : applique un leurre de ton sac quand la canne n'en a plus", function() return ns.fishing and ns.fishing.st().lure ~= false end,
    function(v) if ns.fishing then ns.fishing.st().lure = v end end)
  resetRow(f, "Pêche", O.resetFish); finish(f)

  ---------------------------------------------------------------- Chasseur
  if isHunter and ns.shot then
    local h = newPage(); pages.hunter = h
    local Sh = ns.shot
    head(h, "Chasseur", "Visible seulement quand le personnage est un chasseur")
    sec(h, "Tir automatique : barre de swing")
    chk(h, "Barre du tir automatique", function() return Sh.cfg().on end, function(v) Sh.set("on", v) end, "Se remplit puis change de couleur quand il ne faut plus bouger.")
    chk(h, "Texte sur la barre (temps restant et vitesse)", function() return Sh.cfg().text end, function(v) Sh.set("text", v) end)
    chk(h, "Icône de munitions sous la barre", function() return Sh.cfg().ammo end, function(v) Sh.set("ammo", v) end, "Quantité dans les sacs : orange sous 100, rouge à 0.")
    num(h, "Largeur / hauteur (px)", function() return Sh.cfg().w end, function(v) Sh.set("size", { v, Sh.cfg().h }) end,
      function() return Sh.cfg().h end, function(v) Sh.set("size", { Sh.cfg().w, v }) end)
    num(h, "Opacité (10 à 100 %) / zone de visée (ms)", function() return math.floor(Sh.cfg().alpha * 100 + .5) end, function(v) Sh.set("alpha", v) end,
      function() return math.floor(Sh.cfg().aim * 1000 + .5) end, function(v) Sh.set("aim", v) end)
    sec(h, "Corps à corps, portée et indicateurs")
    local function rset(k, v) if Sh.range then Sh.range.set(k, v) else Sh.cfg()[k] = v end end
    local function rget(k, d) local v = Sh.cfg()[k]; if v == nil then return d end return v end
    chk(h, "Barre de swing au corps à corps", function() return rget("melee", true) end, function(v) rset("melee", v) end, "Décoche pour ne plus voir le swing de mêlée.")
    chk(h, "Barre de la main gauche", function() return rget("offhand", false) end, function(v) rset("offhand", v) end)
    chk(h, "Masquer la barre du tir au corps à corps", function() return rget("hideInMelee", false) end, function(v) rset("hideInMelee", v) end, "La barre du tir automatique disparaît tant qu'une cible est à portée de mêlée.")
    chk(h, "Indicateur de portée (mêlée, zone morte, point idéal)", function() return rget("range", true) end, function(v) rset("range", v) end)
    chk(h, "Retard du tir (-0,24)", function() return rget("clip", true) end, function(v) rset("clip", v) end)
    chk(h, "Lueurs d'entrée en portée", function() return rget("glow", true) end, function(v) rset("glow", v) end)
    chk(h, "Fondu hors combat / hors portée", function() return rget("fadeOn", true) end, function(v) rset("fadeOn", v) end)
    button(h, "Meilleures munitions", 150, function() if ns.ammo then ns.ammo.report() end end)
    button(h, "Flèche vers le vendeur", 150, function() if ns.ammo then ns.ammo.goVendor() end end, 168)
    h.y = h.y - 30
    button(h, "Recentrer la barre", 150, function() Sh.recenter() end)
    local demo = button(h, "Démonstration", 150, function() Sh.setDemo(not Sh.demo) end, 168)
    local hn = h:CreateFontString(nil, "OVERLAY", "GringottsMuted"); hn:SetPoint("TOPLEFT", 330, h.y - 6); hn:SetText("Maj + glisser : déplace la barre de tir et, séparément, l'indicateur de portée")
    h.y = h.y - 34
    sec(h, "Bêtes")
    chk(h, "Infobulle des bêtes domptables", function() return not ns.pets or ns.pets.tipOn() end, function(v) if ns.pets then ns.pets.setTip(v) end end,
      "Armure, endurance, vitesse d'attaque, compétences ; seulement si tu es chasseur et que la bête est domptable.")
    resetRow(h, "Chasseur", O.resetHunter); finish(h)
    h:SetScript("OnShow", function() Sh.setDemo(true) end)
    h:SetScript("OnHide", function() Sh.setDemo(false) end)
  end

  ---------------------------------------------------------------- Données
  local d = newPage(); pages.data = d
  head(d, "Données", "Informations et commandes")
  local ver = (C_AddOns and C_AddOns.GetAddOnMetadata or GetAddOnMetadata)
  local v = ver and ver(ADDON, "Version") or "?"
  local info = d:CreateFontString(nil, "OVERLAY", "GringottsText"); info:SetPoint("TOPLEFT", 8, d.y); info:SetJustifyH("LEFT"); info:SetWidth(660)
  info:SetText("Gringotts " .. v .. "\nCommandes : /gt ui · /gt tir · /gt fleche · /gt scintille · /gt bouton\nLes options sont enregistrées par compte (GringottsDB) ; les réglages de la barre du tir automatique et des bêtes par personnage.")
  d.y = d.y - 80
  sec(d, "Positions")
  button(d, "Recentrer la fenêtre", 170, function() if ns.uiResetPos then ns.uiResetPos() end end)
  button(d, "Recentrer le bouton Gringotts", 220, function() if ns.launcherReset then ns.launcherReset() end end, 188)
  d.y = d.y - 30
  sec(d, "Diagnostic")
  button(d, "Journal d'erreurs", 170, function() if ns.errorsCmd then ns.errorsCmd("copier") end end)
  button(d, "Vider le journal", 170, function() if ns.errorsCmd then ns.errorsCmd("vider") end end, 188)
  d.y = d.y - 30
  finish(d)

  ---------------------------------------------------------------- Liste à gauche
  local function show(key)
    if not pages[key] then key = "general" end
    current = key; O.cur = key
    for k, p in pairs(pages) do if k == key then p:Show(); if p.refresh then p.refresh() end else p:Hide() end end
    for k, b in pairs(btns) do if k == key then b:Disable() else b:Enable() end end
  end
  O.show = show
  local y = -8
  for _, s in ipairs(SECTIONS) do
    if pages[s.key] then
      local bt = ns.theme.tab(left, s.label .. (s.hunter and "  " .. ns.theme.code("ok", "(chasseur)") or ""), 214, 34, function() show(s.key) end, true)
      bt:SetPoint("TOPLEFT", 8, y)
      btns[s.key] = bt; y = y - 42
    end
  end
  show("general")
end

function O.refresh() if O.show then O.show(O.cur or "general") end end
