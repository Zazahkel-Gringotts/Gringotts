-- Gringotts : flèche et boussole vers les plantes / minerais suivis (données GatherMate2).
-- /gt arrow : active / désactive · on · off · fleche | boussole | both · mode best|near · size N · opacity N
--             respawn N (secondes) · sound on|off · alert N (mètres) · reset
local ADDON, ns = ...

local REFRESH = 0.5        -- recherche des cibles (s)
local VISIT_RADIUS = 10    -- à moins de 10 m d'un point : cueilli, ou absent → la flèche passe au suivant
local GATHER_WINDOW = 25   -- s : une cueillette (fenêtre de butin) dans ce délai = point cueilli ; sinon point absent, pas de minuteur
local HERE = 15            -- « ici » (vert) à moins de 15 m
local RUN_SPEED = 7        -- m/s, estimation du temps de trajet
local COMP_RANGE = 400     -- portée de la boussole (m)
local COMP_W = 440         -- largeur de la boussole (px), champ de vision 180°
local MAX_MARK = 16

local atan2 = math.atan2 or function(y, x) return math.atan(y, x) end
local sqrt, pi = math.sqrt, math.pi

local function say(msg) print("|cffe4b84eGringotts|r " .. msg) end

-- Angle de rotation de la texture (anti-horaire, radians) pour pointer vers la cible.
-- Carte : x vers l'est, y vers le sud. facing = GetPlayerFacing() (anti-horaire depuis le nord).
local function arrowRotation(px, py, nx, ny, w, h, facing)
  local dx, dy = (nx - px) * w, (ny - py) * h
  local bearing = atan2(dx, -dy)          -- horaire depuis le nord
  return -bearing - (facing or 0), sqrt(dx * dx + dy * dy)
end
ns.arrowRotation = arrowRotation

-- Angle relatif cible / direction du regard, dans ]-pi, pi] (0 = droit devant, > 0 = à droite)
local function relAngle(px, py, nx, ny, w, h, facing)
  local dx, dy = (nx - px) * w, (ny - py) * h
  local bearing = atan2(dx, -dy)
  local rel = bearing + (facing or 0)
  while rel > pi do rel = rel - 2 * pi end
  while rel <= -pi do rel = rel + 2 * pi end
  return rel
end
ns.arrowRelAngle = relAngle

local GM, HBD
local function libs()
  if GM and HBD then return true end
  local ace = LibStub and LibStub("AceAddon-3.0", true)
  GM = GM or (ace and ace:GetAddon("GatherMate2", true))
  HBD = HBD or (LibStub and LibStub("HereBeDragons-2.0", true))
  return GM ~= nil and HBD ~= nil
end

local function cfg()
  GringottsDB = GringottsDB or {}
  GringottsDB.arrow = GringottsDB.arrow or {}
  return GringottsDB.arrow
end
local function respawnSecs() return cfg().respawn or 180 end

local visited = {}   -- "zone:coord" -> GetTime()
local resp = {}      -- minuteurs de réapparition : { key, name, t }
local alerted = {}   -- "zone:coord" -> vrai (son déjà joué)
local route          -- parcours de farm : { plan, idx, laps, gathered, t0 }
local manual         -- cible posée à la main (onglet Bêtes) : { zone = uiMapID, x, y (0-1), name, key }
local target, nexts  -- cible principale et les 2 suivantes : { zone, coord, x, y, name, color, key, type }
local marks = {}     -- points proches pour la boussole : { rel, dist, color }

------------------------------------------------------------------------
-- Flèche
------------------------------------------------------------------------
local f = CreateFrame("Frame", "GringottsArrow", UIParent)
f:SetSize(64, 64)
f:SetPoint("CENTER", UIParent, "CENTER", 0, 180)
f:SetFrameStrata("MEDIUM")
f:SetClampedToScreen(true)
f:SetMovable(true)
f:EnableMouse(true)
f:RegisterForDrag("LeftButton")
f:Hide()

local tex = f:CreateTexture(nil, "ARTWORK")
tex:SetAllPoints()
tex:SetTexture("Interface\\Minimap\\ROTATING-MINIMAPARROW")

local lblDist = f:CreateFontString(nil, "OVERLAY", "GringottsH2")
lblDist:SetPoint("TOP", f, "BOTTOM", 0, -2)
local lblName = f:CreateFontString(nil, "OVERLAY", "GringottsTextSmall")
lblName:SetPoint("TOP", lblDist, "BOTTOM", 0, -1)
local lblTip = f:CreateFontString(nil, "OVERLAY", "GringottsTextSmall")
lblTip:SetPoint("TOP", lblName, "BOTTOM", 0, -1)
local lblNext = f:CreateFontString(nil, "OVERLAY", "GringottsTextSmall")
lblNext:SetPoint("TOP", lblTip, "BOTTOM", 0, -4)
local lblResp = f:CreateFontString(nil, "OVERLAY", "GringottsTextSmall")
lblResp:SetPoint("TOP", lblNext, "BOTTOM", 0, -4)

f:SetScript("OnDragStart", function(self) if IsShiftKeyDown() then self:StartMoving() end end)
f:SetScript("OnDragStop", function(self)
  self:StopMovingOrSizing()
  local p, _, rp, x, y = self:GetPoint()
  cfg().pos = { p, rp, x, y }
end)

------------------------------------------------------------------------
-- Boussole : tous les points suivis autour de toi (champ de vision 180°, couleur = difficulté)
------------------------------------------------------------------------
local COMP_H = 40
local comp = CreateFrame("Frame", "GringottsCompass", UIParent)
comp:SetSize(COMP_W, COMP_H)
comp:SetPoint("CENTER", UIParent, "CENTER", 0, 260)
comp:SetFrameStrata("MEDIUM")
comp:SetClampedToScreen(true)
comp:SetMovable(true)
comp:EnableMouse(true)
comp:RegisterForDrag("LeftButton")
comp:Hide()
-- fond sombre, filets haut et bas, repère central
local cbg = comp:CreateTexture(nil, "BACKGROUND"); cbg:SetAllPoints(); cbg:SetColorTexture(.04, .05, .07, .72)
local ctop = comp:CreateTexture(nil, "BORDER"); ctop:SetPoint("TOPLEFT"); ctop:SetPoint("TOPRIGHT"); ctop:SetHeight(1); ctop:SetColorTexture(.8, .85, .95, .28)
local cbot = comp:CreateTexture(nil, "BORDER"); cbot:SetPoint("BOTTOMLEFT"); cbot:SetPoint("BOTTOMRIGHT"); cbot:SetHeight(1); cbot:SetColorTexture(.8, .85, .95, .28)
local cmid = comp:CreateTexture(nil, "ARTWORK", nil, 2); cmid:SetSize(2, COMP_H - 2); cmid:SetPoint("CENTER", comp, "CENTER", 0, 0); cmid:SetColorTexture(.95, .85, .45, .9)
local cdeg = comp:CreateFontString(nil, "OVERLAY", "GringottsLabelSmall"); cdeg:SetPoint("BOTTOM", comp, "TOP", 0, 3); cdeg:SetTextColor(.95, .85, .45)
comp:SetScript("OnDragStart", function(self) if IsShiftKeyDown() then self:StartMoving() end end)
comp:SetScript("OnDragStop", function(self)
  self:StopMovingOrSizing()
  local p, _, rp, x, y = self:GetPoint()
  cfg().cpos = { p, rp, x, y }
end)

-- points cardinaux : bearing horaire depuis le nord (rad)
local CARD = { { "N", 0 }, { "NE", pi / 4 }, { "E", pi / 2 }, { "SE", 3 * pi / 4 }, { "S", pi }, { "SO", -3 * pi / 4 }, { "O", -pi / 2 }, { "NO", -pi / 4 } }
local cardLbl = {}
for i, c in ipairs(CARD) do
  local fs = comp:CreateFontString(nil, "OVERLAY", #c[1] == 1 and "GringottsLabel" or "GringottsLabelSmall")
  fs:SetText(c[1]); cardLbl[i] = fs
  if c[1] == "N" then fs:SetTextColor(1, .45, .35) else fs:SetTextColor(.85, .9, 1) end
end
-- graduations tous les 15° (plus longues à 45°)
local ticks = {}
for i = 0, 23 do
  local t = comp:CreateTexture(nil, "ARTWORK"); t:SetColorTexture(.8, .85, .95, 1); t:Hide(); ticks[i + 1] = { tex = t, rad = math.rad(i * 15), big = (i % 3 == 0) }
  t:SetSize(1, ticks[i + 1].big and 9 or 5)
end
-- marqueurs : losange coloré avec liseré sombre ; le premier (cible principale) est plus gros
local markTex, markBd, markTxt = {}, {}, {}
for i = 1, MAX_MARK do
  local bd = comp:CreateTexture(nil, "ARTWORK", nil, 3); bd:SetColorTexture(0, 0, 0, .9); bd:Hide(); markBd[i] = bd
  local t = comp:CreateTexture(nil, "ARTWORK", nil, 4); t:Hide(); markTex[i] = t
  if bd.SetRotation then bd:SetRotation(pi / 4); t:SetRotation(pi / 4) end
end
for i = 1, 3 do
  local fs = comp:CreateFontString(nil, "OVERLAY", "GringottsTextSmall"); fs:Hide(); markTxt[i] = fs
end

local COLRGB = { orange = { 1, .5, 0 }, yellow = { 1, .82, 0 }, green = { .3, .73, .09 } }
local COLTXT = { orange = "|cffff8000fait monter|r", yellow = "|cffffd100fait monter (chance)|r", green = "|cff4dba17faible gain|r" }
-- rang : orange avant jaune avant vert ; un point gris ou pas encore cueillable n'est jamais choisi
local RANK = { orange = 0, yellow = 1, green = 2 }

local function updateCompass(facing)
  local half = COMP_W / 2 - 6
  local deg = (-math.deg(facing or 0)) % 360
  cdeg:SetText(("%d°"):format(math.floor(deg + .5) % 360))
  for i, c in ipairs(CARD) do
    local rel = c[2] + (facing or 0)
    while rel > pi do rel = rel - 2 * pi end
    while rel <= -pi do rel = rel + 2 * pi end
    if math.abs(rel) <= pi / 2 then
      cardLbl[i]:ClearAllPoints(); cardLbl[i]:SetPoint("TOP", comp, "TOP", rel / (pi / 2) * half, -4)
      cardLbl[i]:SetAlpha(1 - .6 * math.abs(rel) / (pi / 2)); cardLbl[i]:Show()
    else cardLbl[i]:Hide() end
  end
  for _, tk in ipairs(ticks) do
    local rel = tk.rad + (facing or 0)
    while rel > pi do rel = rel - 2 * pi end
    while rel <= -pi do rel = rel + 2 * pi end
    if math.abs(rel) <= pi / 2 and not tk.big then
      tk.tex:ClearAllPoints(); tk.tex:SetPoint("BOTTOM", comp, "BOTTOM", rel / (pi / 2) * half, 3)
      tk.tex:SetAlpha(.55 * (1 - .7 * math.abs(rel) / (pi / 2))); tk.tex:Show()
    elseif math.abs(rel) <= pi / 2 then
      tk.tex:ClearAllPoints(); tk.tex:SetPoint("BOTTOM", comp, "BOTTOM", rel / (pi / 2) * half, 3)
      tk.tex:SetAlpha(.9 * (1 - .6 * math.abs(rel) / (pi / 2))); tk.tex:Show()
    else tk.tex:Hide() end
  end
  local used, txt = 0, 0
  for idx, m in ipairs(marks) do
    if used < MAX_MARK then
      used = used + 1
      local inView = math.abs(m.rel) <= pi / 2
      local rel = inView and m.rel or (m.rel > 0 and pi / 2 or -pi / 2)   -- hors du champ : collé au bord, atténué
      local x = rel / (pi / 2) * half
      local rgb = COLRGB[m.color or ""] or { 1, 1, 1 }
      local sz = (idx == 1) and 11 or 8
      local t, bd = markTex[used], markBd[used]
      t:SetColorTexture(rgb[1], rgb[2], rgb[3], 1); t:SetSize(sz, sz)
      bd:SetSize(sz + 4, sz + 4)
      t:ClearAllPoints(); t:SetPoint("CENTER", comp, "CENTER", x, -6)
      bd:ClearAllPoints(); bd:SetPoint("CENTER", comp, "CENTER", x, -6)
      local al = inView and 1 or .45
      t:SetAlpha(al); bd:SetAlpha(al); t:Show(); bd:Show()
      if txt < 3 then
        txt = txt + 1
        local label = string.format("%d m", math.floor(m.dist + .5))
        if idx == 1 and m.name then label = m.name .. " · " .. label end
        markTxt[txt]:ClearAllPoints(); markTxt[txt]:SetPoint("TOP", comp, "BOTTOM", x, -3)
        markTxt[txt]:SetText(label); markTxt[txt]:SetAlpha(al); markTxt[txt]:Show()
      end
    end
  end
  for i = used + 1, MAX_MARK do markTex[i]:Hide(); markBd[i]:Hide() end
  for i = txt + 1, 3 do markTxt[i]:Hide() end
end

------------------------------------------------------------------------
-- Recherche des cibles : la meilleure, les 2 suivantes, et les points proches pour la boussole
------------------------------------------------------------------------
local function scan(zone, px, py, w, h)
  if not GM then return {}, {} end
  local now = GetTime()
  local mode = cfg().mode or "best"
  local G = ns.gather
  local ttl = respawnSecs()
  local top, close = {}, {}
  for _, ty in ipairs(G and G.arrowTypes() or { "Herb Gathering" }) do
    for coord, nodeID in GM:GetNodesForZone(zone, ty) do
      local key = zone .. ":" .. coord
      local t = visited[key]
      if t and now - t < ttl then
        -- point récemment cueilli : ignoré
      else
        if t then visited[key] = nil; alerted[key] = nil end
        local info = G and G.nodeInfo(ty, nodeID)
        local ok, rank = true, 3
        if info then
          ok = info.followed and RANK[info.color] ~= nil
          rank = RANK[info.color] or 9
        elseif G and G.st().only then ok = false end   -- « uniquement mes plantes cochées » : un point inconnu n'est pas suivi
        if ok then
          local nx, ny = GM:DecodeLoc(coord)
          local dx, dy = (nx - px) * w, (ny - py) * h
          local d2 = dx * dx + dy * dy
          local k = (mode == "best") and (rank * 1e12 + d2) or d2
          local c = { zone = zone, coord = coord, x = nx, y = ny, id = nodeID, key = key, type = ty, color = info and info.color, name = info and info.entry.fr, k = k, d2 = d2 }
          -- garde les 3 meilleurs (insertion dans un petit tableau trié)
          local n = #top
          if n < 3 or k < top[n].k then
            top[#top + 1] = c
            table.sort(top, function(a, b) return a.k < b.k end)
            if #top > 3 then top[#top] = nil end
          end
          if d2 <= COMP_RANGE * COMP_RANGE then close[#close + 1] = c end
        end
      end
    end
  end
  for _, c in ipairs(top) do if not c.name then c.name = GM:GetNameForNode(c.type, c.id) end end
  return top, close
end

local function fmtMin(s) s = math.max(0, math.floor(s)); return string.format("%d:%02d", math.floor(s / 60), s % 60) end

local lootAt   -- dernière ouverture de butin (cueillette)
local acc = 0
local drv = CreateFrame("Frame", "GringottsArrowDriver", UIParent)
drv:Hide()
drv:SetScript("OnUpdate", function(self, elapsed)
  local c = cfg()
  local px, py, zone = HBD:GetPlayerZonePosition()
  local w, h
  if px and zone then w, h = HBD:GetZoneSize(zone) end
  local usable = px and zone and w and w > 0
  local facing = GetPlayerFacing and GetPlayerFacing() or 0
  local now = GetTime()
  -- minuteurs de réapparition (3 plus proches de la fin)
  for i = #resp, 1, -1 do if now - resp[i].t >= respawnSecs() then table.remove(resp, i) end end
  local rt = {}
  for i = 1, math.min(1, #resp) do rt[#rt + 1] = string.format("%s · %s", resp[i].name or "point", fmtMin(respawnSecs() - (now - resp[i].t))) end
  lblResp:SetText(#rt > 0 and ("|cff8c8c8cRéapparition|r  " .. rt[1]) or "")
  if not usable then f:SetAlpha(0); comp:SetAlpha(0); return end   -- instance / position inconnue
  comp:SetAlpha(1)
  acc = acc + elapsed
  if acc >= REFRESH or (target and target.zone ~= zone) then
    acc = 0
    local top, close
    if manual then
      if manual.zone == zone then
        local dx, dy = (manual.x - px) * w, (manual.y - py) * h
        manual.d2 = dx * dx + dy * dy
        top = { manual }
        if route and manual.route then
          -- parcours : la boussole montre aussi les 2 points suivants de la boucle
          local pts = route.plan.pts
          for kx = 1, math.min(2, #pts - 1) do
            local p = pts[(route.idx + kx - 1) % #pts + 1]
            local ddx, ddy = (p.x - px) * w, (p.y - py) * h
            top[#top + 1] = { zone = zone, x = p.x, y = p.y, name = p.name, color = p.color, key = "route:" .. p.key, d2 = ddx * ddx + ddy * ddy }
          end
        end
        close = top
      else top, close = {}, {} end
    else top, close = scan(zone, px, py, w, h) end
    target, nexts = top[1], { top[2], top[3] }
    for _, p in ipairs(close) do
      local nx, ny = p.x, p.y
      p.rel = relAngle(px, py, nx, ny, w, h, facing); p.dist = sqrt(p.d2)
    end
    -- boussole : seulement les 3 prochains points (ceux de la flèche), pas tous les points proches
    marks = {}
    for i = 1, math.min(3, #top) do marks[i] = top[i] end
    for _, p in ipairs(marks) do if not p.rel then p.rel = relAngle(px, py, p.x, p.y, w, h, facing); p.dist = sqrt(p.d2) end end
  end
  -- boussole
  if comp:IsShown() then updateCompass(facing) end
  -- flèche
  if not f:IsShown() then return end
  local a = c.alpha or 1
  if not target then
    f:SetAlpha(0.35 * a); lblDist:SetText("—"); lblTip:SetText(""); lblNext:SetText("")
    lblName:SetText(manual and ("va en : " .. (manual.zoneName or "autre zone")) or "aucune cible suivie ici")
    return
  end
  local rot, dist = arrowRotation(px, py, target.x, target.y, w, h, facing)
  if manual and target == manual then
    if dist <= VISIT_RADIUS then
      if route and manual.route then
        if lootAt and now - lootAt <= GATHER_WINDOW then route.gathered = route.gathered + 1 end
        local pts = route.plan.pts
        route.idx = route.idx + 1
        if route.idx > #pts then
          route.idx = 1; route.laps = route.laps + 1
          local mins = (now - route.t0) / 60
          say(("Boucle %d terminée : %d plantes cueillies en %.1f min (%.0f / h)."):format(route.laps, route.gathered, mins, mins > 0 and route.gathered / mins * 60 or 0))
        end
        local p = pts[route.idx]
        manual = { zone = route.plan.zone, x = p.x, y = p.y, name = p.name, zoneName = route.plan.zoneName, key = "route:" .. p.key, color = p.color, route = true }
        target = nil; acc = REFRESH; return
      end
      say(("Arrivé : %s."):format(manual.name or "cible"))
      manual = nil; target = nil; acc = REFRESH; return
    end
  elseif dist <= VISIT_RADIUS then
    visited[target.key] = now
    if lootAt and now - lootAt <= GATHER_WINDOW then   -- cueilli : minuteur de réapparition
      table.insert(resp, { key = target.key, name = target.name, t = now })
      table.sort(resp, function(x, y) return x.t < y.t end)
    end                                                  -- sinon : rien à cueillir ici, on passe directement au suivant
    target = nil; acc = REFRESH; return
  end
  f:SetAlpha(a)
  tex:SetRotation(rot)
  if dist <= HERE then
    tex:SetVertexColor(.3, 1, .3); lblDist:SetText("|cff4dff4dici|r")
  else
    tex:SetVertexColor(1, 1, 1); lblDist:SetText(string.format("%d m", math.floor(dist + 0.5)))
  end
  lblName:SetText((target.name or "Cible") .. ((dist > HERE) and string.format(" · ~ %d s", math.max(1, math.floor(dist / RUN_SPEED + .5))) or ""))
  lblTip:SetText(COLTXT[target.color or ""] or "")
  -- la cible suivante seulement
  local n = nexts and nexts[1]
  if n then
    local _, d = arrowRotation(px, py, n.x, n.y, w, h, facing)
    lblNext:SetText(string.format("|cff8c8c8cEnsuite|r  %s · %d m", n.name or "point", math.floor(d + .5)))
  else lblNext:SetText("") end
  -- son : une fois par point, quand il passe à portée d'alerte
  if c.sound and dist <= (c.alertDist or 100) and not alerted[target.key] then
    alerted[target.key] = true
    local snd = (SOUNDKIT and SOUNDKIT.MAP_PING) or 3175
    if PlaySound then pcall(PlaySound, snd) end
  end
end)

------------------------------------------------------------------------
-- État et commandes
------------------------------------------------------------------------
local function applyLook()
  local s = cfg().size or 64
  f:SetSize(s, s)
end

local function refreshShow()
  local c = cfg()
  local on, d = c.on and true or false, c.display or "arrow"
  f:SetShown(on and d ~= "compass")
  comp:SetShown(on and d ~= "arrow")
  drv:SetShown(on)
end

local function setOn(on)
  if on and not libs() and not (manual and HBD) then
    say("Flèche impossible : GatherMate2 (et HereBeDragons) introuvable. Activez GatherMate2.")
    on = false
  end
  cfg().on = on and true or false
  if not on then manual = nil; route = nil end
  if on then target = nil; acc = REFRESH; applyLook() end
  refreshShow()
end
function ns.arrowSet(on) setOn(on and true or false) end
-- Cible manuelle : t = { zone = uiMapID, x, y en % (0-100), name, zoneName }. nil la retire.
function ns.arrowGoto(t)
  route = nil
  if not t then manual = nil; target = nil; acc = REFRESH; return true end
  libs()
  if not HBD then say("Flèche impossible : HereBeDragons introuvable (activez GatherMate2)."); return false end
  manual = { zone = t.zone, x = (t.x or 0) / 100, y = (t.y or 0) / 100, name = t.name, zoneName = t.zoneName, key = "manual", color = nil }
  target = nil; acc = REFRESH
  cfg().on = true; applyLook(); refreshShow()
  return true
end
function ns.arrowManual() return manual end
-- Parcours de farm : plan = Gather.buildRoute(...). Le premier point devient la cible, les suivants s'enchaînent en boucle.
function ns.arrowRoute(plan)
  if not (plan and plan.pts and #plan.pts > 0) then return false end
  libs()
  if not HBD then say("Flèche impossible : HereBeDragons introuvable (activez GatherMate2)."); return false end
  route = { plan = plan, idx = 1, laps = 0, gathered = 0, t0 = GetTime() }
  local p = plan.pts[1]
  manual = { zone = plan.zone, x = p.x, y = p.y, name = p.name, zoneName = plan.zoneName, key = "route:" .. p.key, color = p.color, route = true }
  target = nil; acc = REFRESH
  cfg().on = true; applyLook(); refreshShow()
  say(("Parcours dans %s : %d points, %.1f km, boucle d'environ %.0f min."):format(plan.zoneName or "?", #plan.pts, plan.length / 1000, plan.secs / 60))
  return true
end
function ns.arrowRouteStop() if route then route = nil; manual = nil; target = nil; acc = REFRESH; say("Parcours arrêté.") end end
function ns.arrowRouteInfo() return route end
function ns.arrowOn() return cfg().on and true or false end
function ns.arrowGetMode() return cfg().mode or "best" end
function ns.arrowSetMode(m) cfg().mode = (m == "near") and "near" or "best"; target = nil; acc = REFRESH end
function ns.arrowGetDisplay() return cfg().display or "arrow" end
function ns.arrowSetDisplay(d)
  if d ~= "arrow" and d ~= "compass" and d ~= "both" then return false end
  cfg().display = d; refreshShow(); return true
end
function ns.arrowSetSize(n) n = tonumber(n); if n and n >= 24 and n <= 200 then cfg().size = n; applyLook(); return true end end
function ns.arrowSetAlpha(n) n = tonumber(n); if n and n >= 10 and n <= 100 then cfg().alpha = n / 100; return true end end
function ns.arrowSetRespawn(n) n = tonumber(n); if n and n >= 30 and n <= 1800 then cfg().respawn = n; return true end end
function ns.arrowSetSound(on) cfg().sound = on and true or false end
function ns.arrowSetAlertDist(n) n = tonumber(n); if n and n >= 15 and n <= 400 then cfg().alertDist = n; return true end end
function ns.arrowCfg() return cfg() end

ns.arrowCmd = function(arg)
  arg = (arg or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
  local cmd, rest = arg:match("^(%S+)%s*(.*)$")
  if cmd == "reset" then
    f:ClearAllPoints(); f:SetPoint("CENTER", UIParent, "CENTER", 0, 180)
    comp:ClearAllPoints(); comp:SetPoint("CENTER", UIParent, "CENTER", 0, 260)
    cfg().pos = nil; cfg().cpos = nil
    say("Flèche et boussole recentrées.")
    return
  elseif cmd == "move" then
    say("Flèche / boussole : Maj + glisser pour les déplacer.")
    return
  elseif cmd == "size" then
    say(ns.arrowSetSize(rest) and ("Taille de la flèche : " .. rest) or "Taille : un nombre entre 24 et 200.")
    return
  elseif cmd == "opacity" then
    say(ns.arrowSetAlpha(rest) and ("Opacité de la flèche : " .. rest .. " %") or "Opacité : un nombre entre 10 et 100.")
    return
  elseif cmd == "mode" then
    ns.arrowSetMode(rest)
    say("Cible de la flèche : " .. (ns.arrowGetMode() == "near" and "la plus proche." or "meilleure valeur (orange avant jaune, puis distance)."))
    return
  elseif cmd == "fleche" or cmd == "boussole" or cmd == "both" or cmd == "les" then
    local d = (cmd == "fleche") and "arrow" or (cmd == "boussole") and "compass" or "both"
    ns.arrowSetDisplay(d); say("Affichage : " .. (d == "arrow" and "flèche seule" or d == "compass" and "boussole seule" or "flèche et boussole") .. ".")
    return
  elseif cmd == "respawn" then
    say(ns.arrowSetRespawn(rest) and ("Durée de réapparition : " .. rest .. " s") or "Réapparition : une durée entre 30 et 1800 secondes.")
    return
  elseif cmd == "sound" then
    ns.arrowSetSound(rest ~= "off"); say("Son à l'approche d'une cible : " .. (cfg().sound and "activé" or "désactivé") .. ".")
    return
  elseif cmd == "alert" then
    say(ns.arrowSetAlertDist(rest) and ("Distance d'alerte : " .. rest .. " m") or "Alerte : une distance entre 15 et 400 m.")
    return
  end
  local on
  if cmd == "on" then on = true elseif cmd == "off" then on = false else on = not cfg().on end
  setOn(on)
  if cfg().on then say("Flèche / boussole vers les cibles suivies : activées (Maj + glisser pour les déplacer).")
  else say("Flèche / boussole : désactivées.") end
end

local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
ev:SetScript("OnEvent", function()
  local a = GringottsDB and GringottsDB.arrow
  if a and a.pos then f:ClearAllPoints(); f:SetPoint(a.pos[1], UIParent, a.pos[2], a.pos[3], a.pos[4]) end
  if a and a.cpos then comp:ClearAllPoints(); comp:SetPoint(a.cpos[1], UIParent, a.cpos[2], a.cpos[3], a.cpos[4]) end
  applyLook()
  if a and a.on then setOn(true) end
end)

-- cueillette : l'ouverture d'une fenêtre de butin près d'un point = point cueilli
local lf = CreateFrame("Frame")
lf:RegisterEvent("LOOT_OPENED")
lf:SetScript("OnEvent", function() lootAt = GetTime() end)

-- gardes : une erreur est journalisée (/gt erreurs) au lieu d'ouvrir le popup de Blizzard
if ns.safe then
  drv:SetScript("OnUpdate", ns.safe(drv:GetScript("OnUpdate"), "flèche"))
  ev:SetScript("OnEvent", ns.safe(ev:GetScript("OnEvent"), "flèche"))
end
