-- Gringotts : onglet « Gains » = sélecteur interne : Session & marges · Que farmer ? · Mise en vente · Sacs · Minuteries · Persos.
local ADDON, ns = ...
local W = ns.W
local C = W.C
local G = ns.gring
local Pl = ns.plus

local function coins(c) return c and ns.api.coins(c) or W.col(C.grey, "—") end
local function remain(sec)
  if sec <= 0 then return W.col(C.green, "prêt") end
  sec = math.floor(sec)
  if sec < 3600 then return ("%d min %02d s"):format(math.floor(sec / 60), sec % 60) end
  if sec < 86400 then return ("%d h %02d"):format(math.floor(sec / 3600), math.floor(sec % 3600 / 60)) end
  return ("%d j %d h"):format(math.floor(sec / 86400), math.floor(sec % 86400 / 3600))
end

local ROW_W = 1400

-- Tableau générique : cols = { { titre, x, largeur, "LEFT"/"RIGHT" } } ; entrée = { cells = {...}, id = itemID?, onClick = fn?, chk = bool? }
local function mkTable(parent, y, cols, listH, opts)
  opts = opts or {}
  local P = {}
  local x0 = opts.icon and 28 or 0
  if opts.check then x0 = 24 + (opts.icon and 28 or 0) end
  for _, c in ipairs(cols) do W.text(parent, "GringottsLabelSmall", c[1], x0 + c[2], y, c[3], c[4] or "LEFT") end
  P.list = W.list(parent, opts.w or ROW_W, listH, 22, function(b)
    if opts.check then
      b.chk = CreateFrame("Button", nil, b); b.chk:SetSize(18, 18); b.chk:SetPoint("LEFT", b, "LEFT", 2, 0)
      b.chkBg = W.fill(b.chk, .059, .075, .098, 1); b.chkBg:SetAllPoints()
      b.chkOn = W.fill(b.chk, W.C.gold[1], W.C.gold[2], W.C.gold[3], 1, "OVERLAY"); b.chkOn:SetPoint("CENTER"); b.chkOn:SetSize(10, 10)
      b.chk:SetScript("OnClick", function() local e = b.entry; if e and e.toggle then e.toggle() end end)
    end
    if opts.icon then W.rowIcon(b, opts.check and 24 or 0) end
    b.c = {}
    for i, c in ipairs(cols) do b.c[i] = W.text(b, "GringottsTextSmall", "", x0 + c[2], -5, c[3], c[4] or "LEFT") end
    b:SetScript("OnClick", function(self) if self.entry and self.entry.onClick then self.entry.onClick(self.entry) end end)
  end, function(b, e)
    b.entry = e
    for i = 1, #cols do b.c[i]:SetText(e.cells[i] or "") end
    if opts.icon then W.setRowIcon(b, e.id) end
    if opts.check then if e.chk then b.chkOn:Show() else b.chkOn:Hide() end end
    b.sel:Hide()
  end)
  P.list.frame:SetPoint("TOPLEFT", parent, "TOPLEFT", 0, y - 20)
  return P
end

------------------------------------------------------------------------
-- Que farmer maintenant ?
------------------------------------------------------------------------
local function buildFarmNow(pane)
  local P = {}
  W.text(pane, "GringottsH2", "Que farmer maintenant ?", 0, 0, 500)
  W.text(pane, "GringottsTextSmall", "Mesuré : d'après tes sessions de farm. Estimé : prix HV × ce qui te manque pour tes cibles de stock, tant que tu n'as pas farmé l'objet.", 0, -26, 1100)
  local T = mkTable(pane, -54, { { "Cible", 0, 300 }, { "Source", 310, 80 }, { "Or / heure", 400, 140, "RIGHT" }, { "Détail", 560, 780 } }, 560)
  P.t = T
  P.empty = W.text(pane, "GringottsTextSmall", "", 0, -90, 800)
  function P:Refresh()
    local rows = Pl.farmNow()
    local data = {}
    for _, r in ipairs(rows) do
      local label = r.kind == "spot" and (W.col(C.gold, "Lieu · ") .. r.name) or (r.kind == "item" and ("Objet · " .. r.name .. (r.zone and ("  → " .. r.zone) or "")) or ("Objet · " .. r.name))
      data[#data + 1] = { cells = { label, r.src == "mesuré" and W.col(C.green, "mesuré") or W.col(C.orange, "estimé"),
        r.gph and (coins(r.gph) .. "/h") or W.col(C.grey, "—"), r.detail or "" } }
    end
    T.list:SetData(data)
    self.empty:SetText(#data == 0 and W.col(C.grey, "Rien à proposer : lance une session de farm (bouton Farm du menu) ou fixe des cibles de stock.") or "")
  end
  return P
end

------------------------------------------------------------------------
-- Aide à la mise en vente
------------------------------------------------------------------------
local function buildSell(pane)
  local P = {}
  W.text(pane, "GringottsH2", "Aide à la mise en vente", 0, 0, 500)
  W.text(pane, "GringottsTextSmall", "Ce qui est dans tes sacs. Prix conseillé : juste sous le moins cher, plafonné à la médiane. Clique une ligne : la vente s'ouvre dans l'onglet Hôtel des ventes, tu valides.", 0, -26, 1300)
  local T = mkTable(pane, -54, { { "Objet", 0, 250 }, { "Qté", 260, 50, "RIGHT" }, { "Prix HV", 320, 110, "RIGHT" }, { "Conseillé", 440, 110, "RIGHT" }, { "Net total", 560, 120, "RIGHT" }, { "Alerte", 700, 640 } }, 560, { icon = true })
  P.t = T
  P.empty = W.text(pane, "GringottsTextSmall", "", 0, -90, 800)
  function P:Refresh()
    local rows = Pl.sellList()
    local data = {}
    for _, r in ipairs(rows) do
      local al = r.alerts[1]
      local txt = ""
      if al then txt = W.col(al[1] == "good" and C.green or (al[1] == "low" and C.red or C.orange), al[2]) end
      data[#data + 1] = { id = r.id, cells = { r.name, tostring(r.qty), coins(r.price), coins(r.sug), coins(r.net), txt }, onClick = function() if r.id then G.hvOpenSell(r.id) end end }
    end
    T.list:SetData(data)
    self.empty:SetText(#data == 0 and W.col(C.grey, "Rien à vendre dans tes sacs au-dessus de tes cibles de stock (ou prix HV inconnus : lance un scan).") or "")
  end
  return P
end

------------------------------------------------------------------------
-- Minuteries
------------------------------------------------------------------------
local function buildTimers(pane)
  local P = {}
  W.text(pane, "GringottsH2", "Minuteries", 0, 0, 400)
  W.text(pane, "GringottsTextSmall", "Réapparition des nœuds cueillis (boussole) et cooldowns de métier de tous tes personnages. Un message te prévient quand un cooldown est prêt.", 0, -26, 1300)
  local T = mkTable(pane, -54, { { "Perso", 0, 180 }, { "Type", 190, 120 }, { "Nom", 320, 420 }, { "Reste", 760, 160, "RIGHT" } }, 560)
  P.t = T
  P.empty = W.text(pane, "GringottsTextSmall", "", 0, -90, 900)
  function P:Refresh()
    local data = {}
    for _, t in ipairs(Pl.timers()) do
      data[#data + 1] = { cells = { t.who or "", t.kind == "cd" and "cooldown métier" or "repop nœud", t.name, remain(t.remain) } }
    end
    T.list:SetData(data, true)
    self.empty:SetText(#data == 0 and W.col(C.grey, "Aucune minuterie. Ouvre la fenêtre de ton métier une fois pour relever les cooldowns ; cueille avec la boussole pour les repops.") or "")
  end
  local acc = 0
  pane:SetScript("OnUpdate", function(_, dt) acc = acc + dt; if acc >= 1 then acc = 0; if pane:IsVisible() then P:Refresh() end end end)
  return P
end

------------------------------------------------------------------------
-- Multi-persos : tableau + courrier de matériaux
------------------------------------------------------------------------
local function buildChars(pane)
  local P = { crafts = 5 }
  W.text(pane, "GringottsH2", "Mes personnages", 0, 0, 400)
  P.tot = W.tile(pane, 230, 64); P.tot.frame:SetPoint("TOPLEFT", pane, "TOPLEFT", 0, -30)
  local T = mkTable(pane, -108, { { "Perso", 0, 200 }, { "Or", 210, 130, "RIGHT" }, { "Objets en sacs", 350, 110, "RIGHT" }, { "Banque", 470, 90, "RIGHT" }, { "Recettes", 570, 80, "RIGHT" }, { "Métiers", 670, 600 } }, 160)
  P.t = T
  W.text(pane, "GringottsH2", "Envoyer des matériaux", 0, -312, 500)
  P.who = W.text(pane, "GringottsTextSmall", "", 0, -338, 900)
  P.btns = {}
  for i = 1, 6 do
    local b = W.button(pane, "", 150, 24, function(self) P.sel = self.char; P.plan = nil; P:Refresh() end)
    b:SetPoint("TOPLEFT", pane, "TOPLEFT", (i - 1) * 154, -362); b:Hide(); P.btns[i] = b
  end
  P.minus = W.button(pane, "−", 30, 24, function() P.crafts = math.max(1, P.crafts - 1); P.plan = nil; P:Refresh() end); P.minus:SetPoint("TOPLEFT", pane, "TOPLEFT", 950, -362)
  P.cl = W.text(pane, "GringottsLabel", "", 986, -366, 110, "CENTER")
  P.plus = W.button(pane, "+", 30, 24, function() P.crafts = P.crafts + 1; P.plan = nil; P:Refresh() end); P.plus:SetPoint("TOPLEFT", pane, "TOPLEFT", 1100, -362)
  local M = mkTable(pane, -398, { { "Matériau", 0, 300 }, { "À envoyer", 310, 90, "RIGHT" }, { "Manque chez lui", 410, 130, "RIGHT" } }, 240)
  P.m = M
  P.prep = W.button(pane, "Préparer le courrier", 220, 28, function()
    if not (P.sel and P.plan and #P.plan > 0) then return end
    local ok, msg = Pl.mailPrepare(P.sel, P.plan)
    print("|cffe4b84eGringotts|r " .. msg)
  end); P.prep:SetPoint("TOPLEFT", pane, "TOPLEFT", 0, -664)
  P.note = W.text(pane, "GringottsTextSmall", "", 236, -670, 900)
  function P:Refresh()
    local rows, tot = Pl.chars()
    local data = {}
    local me = UnitName("player")
    local others, i = {}, 0
    for _, c in ipairs(rows) do
      data[#data + 1] = { cells = { c.name .. (c.name == me and W.col(C.grey, "  (connecté)") or ""), coins(c.gold), tostring(c.bags), tostring(c.bank), tostring(c.recipes), c.skills } }
      if c.name ~= me then others[#others + 1] = c.name end
    end
    T.list:SetData(data, true)
    self.tot:Set("Or total", coins(tot.gold), #rows .. " personnages", { tone = "gold" })
    for j, b in ipairs(self.btns) do
      local n = others[j]
      if n then b.char = n; b:SetText(n); b:Show(); if n == self.sel then b:Disable() else b:Enable() end else b:Hide() end
    end
    if not self.sel and others[1] then self.sel = others[1]; self.btns[1]:Disable() end
    self.cl:SetText(self.crafts .. " crafts")
    self.who:SetText(self.sel and ("Destinataire : " .. self.sel .. " · matériaux des recettes rentables qu'il connaît, pris dans les sacs de " .. me) or "Connecte un second personnage pour préparer un envoi.")
    self.plan = self.plan or (self.sel and Pl.mailPlan(self.sel, self.crafts)) or {}
    local md = {}
    for _, l in ipairs(self.plan) do md[#md + 1] = { cells = { l.name, tostring(l.qty), tostring(math.max(0, l.missing)) } } end
    M.list:SetData(md, true)
    self.note:SetText(#self.plan == 0 and W.col(C.grey, "Rien à envoyer pour l'instant (aucune recette rentable connue de lui, ou rien en sacs).") or W.col(C.grey, "Ouvre la boîte aux lettres, clique, puis vérifie et envoie toi-même."))
    if #self.plan > 0 then self.prep:Enable() else self.prep:Disable() end
  end
  return P
end

------------------------------------------------------------------------
-- Conteneur de l'onglet Gains
------------------------------------------------------------------------
function G.buildGainsTab(pane)
  local T = { mode = "session", btn = {}, sub = {} }
  local defs = {
    { "session", "Session & marges", G.buildGains }, { "now", "Que farmer ?", buildFarmNow }, { "sell", "Mise en vente", buildSell },
    { "chars", "Persos", buildChars },
  }
  local x = 0
  for _, d in ipairs(defs) do
    local b = W.button(pane, d[2], 150, 24, function() T.show(d[1]) end)
    b:SetPoint("TOPLEFT", pane, "TOPLEFT", x, 0); T.btn[d[1]] = b; x = x + 154
    local f = CreateFrame("Frame", nil, pane)
    f:SetPoint("TOPLEFT", pane, "TOPLEFT", 0, -34); f:SetPoint("BOTTOMRIGHT", pane, "BOTTOMRIGHT", 0, 0); f:Hide()
    T.sub[d[1]] = { frame = f, obj = d[3](f) }
  end
  function T.show(m)
    T.mode = m
    for k, p in pairs(T.sub) do if k == m then p.frame:Show() else p.frame:Hide() end end
    for k, b in pairs(T.btn) do if k == m then b:Disable() else b:Enable() end end
    local o = T.sub[m].obj; if o and o.Refresh then o:Refresh() end
  end
  function T.Refresh() T.show(T.mode) end
  -- ouverture de l'onglet : on repart sur la vue Session si rien d'autre n'a été choisi
  T.show(T.mode)
  return T
end

function ns.gringUI.onPlus(e)
  if ns.merchantUI and ns.merchantUI.onEvent then ns.merchantUI.onEvent(e) end
end
--[[
end
]]

ns.plusUI = { mkTable = mkTable, buildTimers = buildTimers, coins = coins }
