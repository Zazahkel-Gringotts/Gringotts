-- Gringotts : où acheter les recettes. Base intégrée (RecipeVendors.lua : Alchimie, Enchantement, Cuisine, Alliance + Horde)
-- + capture en jeu : chaque marchand visité qui vend des recettes est mémorisé (nom, zone, position, prix) dans GringottsDB.rv.
local ADDON, ns = ...
local R = {}
ns.rv = R

local function db() return ns.api and ns.api.db() end
local function norm(s) return ns.norm(s) end
local function flat(s) return (norm(s):gsub("[^%w]", "")) end   -- clé tolérante : sans espaces, ponctuation, accents

-- ---------- index de la base intégrée ----------
local idx, built
local function build()
  built = true; idx = {}
  local D = ns.rvData
  if not D then return end
  for _, r in ipairs(D.recipes) do
    for _, nm in ipairs(r.n) do
      idx[norm(nm)] = r; idx["~" .. flat(nm)] = r
    end
  end
end

local function staticFor(name)
  if not built then build() end
  return idx[norm(name)] or idx["~" .. flat(name)]
end

-- ---------- ordre d'affichage ----------
local FORDER = { A = 1, H = 2, N = 3, R = 4, S = 5 }
R.FNAME = { A = "Alliance", H = "Horde", N = "Neutre", R = "Réputation", S = "Vu en jeu" }

local function posStr(v)
  if v.x and v.y then return ("%s %.1f/%.1f"):format(v.z or "?", v.x, v.y) end
  return v.z or "?"
end

-- Liste des sources d'une recette : { { f, vendor, where, note, price, skill, seen } ... } triées Alliance, Horde, Neutre, Réputation, Vu en jeu
function R.sources(name)
  local out = {}
  local r = name and staticFor(name)
  if r then
    for _, ref in ipairs(r.v) do
      local v = ns.rvData.vendors[ref[1]]
      if v then out[#out + 1] = { f = v.f, vendor = v.n, where = posStr(v), loc = v.l, note = ref[2], skill = r.sk } end
    end
  end
  local d = db()
  local seen = d and d.rv and name and d.rv[norm(name)]
  if seen then
    local known = {}
    for _, s in ipairs(out) do known[norm(s.vendor)] = true end
    for vend, s in pairs(seen.s or {}) do
      -- un marchand déjà dans la base intégrée n'est ajouté que pour compléter le prix
      if known[norm(vend)] then
        for _, o in ipairs(out) do if norm(o.vendor) == norm(vend) and s.p then o.price = s.p end end
      else
        out[#out + 1] = { f = "S", vendor = vend, where = posStr(s), price = s.p, seenBy = s.fac, seen = true, skill = r and r.sk }
      end
    end
  end
  table.sort(out, function(a, b)
    if (FORDER[a.f] or 9) ~= (FORDER[b.f] or 9) then return (FORDER[a.f] or 9) < (FORDER[b.f] or 9) end
    return a.vendor < b.vendor
  end)
  return out, r
end

-- Texte compact : maxPer vendeurs par camp. colors : table { A=hex, H=hex, N=hex, R=hex, S=hex } (optionnel)
function R.lines(name, maxPer, colors, coinsFn)
  local src = R.sources(name)
  if #src == 0 then return {} end
  maxPer = maxPer or 2
  local cnt, more, lines = {}, {}, {}
  for _, s in ipairs(src) do
    cnt[s.f] = (cnt[s.f] or 0) + 1
    if cnt[s.f] <= maxPer then
      local l = ("%s : %s (%s)"):format(R.FNAME[s.f], s.vendor, s.where)
      if s.note and s.note ~= "" then l = l .. " · " .. s.note end
      if s.price and coinsFn then l = l .. " · " .. coinsFn(s.price) end
      if colors and colors[s.f] then l = "|cff" .. colors[s.f] .. l .. "|r" end
      lines[#lines + 1] = l
    else more[s.f] = (more[s.f] or 0) + 1 end
  end
  for f, n in pairs(more) do lines[#lines + 1] = ("   + %d autre(s) vendeur(s) %s"):format(n, R.FNAME[f]:lower()) end
  return lines
end

-- Compte des sources par camp (pour la liste)
function R.count(name)
  local src = R.sources(name)
  local a, h, n = 0, 0, 0
  for _, s in ipairs(src) do
    if s.f == "A" then a = a + 1 elseif s.f == "H" then h = h + 1 else n = n + 1 end
  end
  return a, h, n
end

-- ---------- capture en jeu ----------
local PREFIX_CLASS_RECIPE = 9

local function isRecipe(link, name)
  if link then
    local f = (C_Item and C_Item.GetItemInfoInstant) or GetItemInfoInstant
    if f then
      local ok, _, _, _, _, _, classID = pcall(f, link)
      if ok and classID then return classID == PREFIX_CLASS_RECIPE end
    end
  end
  return name and name:find(":") ~= nil
end

local function recipeName(name)
  name = name:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
  local after = name:match("^[^:]+%s*:%s*(.+)$")   -- « Recette : X », « Formule : X », « Plan : X »...
  return after or name
end

local function playerPos()
  if not (C_Map and C_Map.GetBestMapForUnit and C_Map.GetPlayerMapPosition) then return nil end
  local m = C_Map.GetBestMapForUnit("player")
  local p = m and C_Map.GetPlayerMapPosition(m, "player")
  if p and p.GetXY then
    local x, y = p:GetXY()
    if x and y and (x > 0 or y > 0) then return math.floor(x * 1000 + .5) / 10, math.floor(y * 1000 + .5) / 10 end
  end
end

function R.capture()
  if not GetMerchantNumItems then return 0 end
  local d = db(); if not d then return 0 end
  local npc = UnitName and UnitName("npc")
  if not npc then return 0 end
  d.rv = d.rv or {}
  local zone = GetRealZoneText and GetRealZoneText() or nil
  local x, y = playerPos()
  local fac = UnitFactionGroup and UnitFactionGroup("player") or nil
  local n = 0
  for i = 1, (GetMerchantNumItems() or 0) do
    local link = GetMerchantItemLink and GetMerchantItemLink(i)
    local name, _, price = GetMerchantItemInfo(i)
    name = name or (link and link:match("%[(.-)%]"))
    if name and isRecipe(link, name) then
      local rn = recipeName(name)
      local k = norm(rn)
      local e = d.rv[k]; if not e then e = { n = rn, s = {} }; d.rv[k] = e end
      e.s[npc] = { z = zone, x = x, y = y, fac = fac, p = price, t = time and time() or 0 }
      n = n + 1
    end
  end
  if n > 0 then R.lastCapture = { npc = npc, n = n } end
  return n
end

local f = CreateFrame("Frame")
f:RegisterEvent("MERCHANT_SHOW")
f:SetScript("OnEvent", function()
  if C_Timer and C_Timer.After then C_Timer.After(0.6, function() pcall(R.capture) end) else pcall(R.capture) end
end)
