-- Gringotts : lecture des annonces en direct et achat de composants (commodités) à l'HV.
-- Garde-fou : on demande le prix réel à l'HV avant d'acheter et on annule si le total dépasse le prix max.
-- StartCommoditiesPurchase exige un clic réel : appeler B.buy depuis un OnClick.
local ADDON, ns = ...
local B = {}
ns.buy = B

local AH = function() return C_AuctionHouse end
local function say(m) print("|cffe4b84eGringotts|r " .. m) end

function B.available()
  local a = AH()
  return a and a.StartCommoditiesPurchase and a.ConfirmCommoditiesPurchase and a.SendSearchQuery and true or false
end
function B.ahOpen() return AuctionHouseFrame and AuctionHouseFrame:IsShown() or false end

B.book = {}          -- [itemID] = { levels = { {q=, p=}, ... }, t = time }
B.state = nil        -- achat en cours : { id, qty, maxUnit, stage = quote|await|confirming, total }
local pendingQuery, queued = nil, nil
local TIMEOUT = 6

local function notify(msg, ok)
  B.lastMsg = msg; B.lastOk = ok
  say(msg)
  if ns.gring and ns.gring.onBuyUpdate then ns.gring.onBuyUpdate() end
end

------------------------------------------------------------------------
-- Annonces en direct
------------------------------------------------------------------------
local function readBook(id)
  local a = AH()
  local n = a.GetNumCommoditySearchResults and a.GetNumCommoditySearchResults(id) or 0
  local by, order = {}, {}
  for i = 1, n do
    local r = a.GetCommoditySearchResultInfo(id, i)
    if r and r.unitPrice then
      local e = by[r.unitPrice]
      if not e then e = { p = r.unitPrice, q = 0 }; by[r.unitPrice] = e; order[#order + 1] = e end
      e.q = e.q + (r.quantity or 0)
    end
  end
  table.sort(order, function(x, y) return x.p < y.p end)
  B.book[id] = { levels = order, t = time() }
end

local lastTry = {}
local function refreshUI() if ns.gring and ns.gring.onBuyUpdate then ns.gring.onBuyUpdate() end end

local function sendQuery(id)
  local a = AH()
  local key = a.MakeItemKey and a.MakeItemKey(id)
  if not key then return false end
  if a.IsThrottledMessageSystemReady and not a.IsThrottledMessageSystemReady() then queued = id; return true end
  local ok = pcall(a.SendSearchQuery, key, {}, true)
  if ok then pendingQuery = id end
  return ok
end

-- Objets non empilables (armes, armures, carquois...) : annonces une à une, événement ITEM_SEARCH_RESULTS_UPDATED
local function readItemBook(itemKey)
  local a = AH()
  local id = itemKey and itemKey.itemID
  if not id then return end
  local n = a.GetNumItemSearchResults and a.GetNumItemSearchResults(itemKey) or 0
  local by, order = {}, {}
  for i = 1, n do
    local r = a.GetItemSearchResultInfo(itemKey, i)
    local p = r and (r.buyoutAmount or r.minBid)
    if p and p > 0 then
      local e = by[p]
      if not e then e = { p = p, q = 0 }; by[p] = e; order[#order + 1] = e end
      e.q = e.q + (r.quantity or 1)
    end
  end
  table.sort(order, function(x, y) return x.p < y.p end)
  B.book[id] = { levels = order, t = time(), item = true }
  return id
end

-- Demande les annonces d'un objet. Si rien n'arrive en 5 s (HV vide, objet non lisible...), on le note
-- « sans annonce » : l'interface arrête d'attendre et la mise en vente reste possible.
function B.query(id)
  if not (B.available() and B.ahOpen() and id and id > 0) then return false end
  if lastTry[id] and time() - lastTry[id] < 4 then return true end
  lastTry[id] = time()
  local t0 = lastTry[id]
  local ok = sendQuery(id)
  if C_Timer then C_Timer.After(5, function()
    local bk = B.book[id]
    if lastTry[id] == t0 and not (bk and bk.t >= t0) then
      B.book[id] = { levels = {}, t = time(), none = true }
      if pendingQuery == id then pendingQuery = nil end
      if B.q and B.q.fetching and B.q.fetching.id == id then B.qBookArrived(id) end
      refreshUI()
    end
  end) end
  return ok
end

-- Unités disponibles jusqu'à un prix unitaire donné
function B.availableUnder(id, maxUnit)
  local bk = B.book[id]; if not bk then return nil end
  local n = 0
  for _, l in ipairs(bk.levels) do if l.p <= maxUnit then n = n + l.q end end
  return n
end

------------------------------------------------------------------------
-- Achat
------------------------------------------------------------------------
local function finish(ok, msg) B.state = nil; if B.qResult then B.qResult(ok, msg) end end

function B.cancel()
  local a = AH()
  if B.state and a.CancelCommoditiesPurchase then pcall(a.CancelCommoditiesPurchase) end
  finish()
end

-- Premier clic : demande le prix. En mode « un clic », l'achat est confirmé dès que le prix est vérifié.
function B.buy(id, qty, maxUnit, oneClick)
  if not B.available() then notify("Achat direct indisponible sur ce client : utilise la recherche Auctionator.", false); return false end
  if not B.ahOpen() then notify("Ouvre la fenêtre de l'HV pour acheter.", false); return false end
  qty = math.floor(tonumber(qty) or 0)
  if not id or id <= 0 or qty <= 0 or not maxUnit or maxUnit <= 0 then return false end
  -- Second clic du mode « deux clics » : confirmer le prix déjà vérifié
  if B.state and B.state.stage == "await" and B.state.id == id and B.state.qty == qty then
    B.state.stage = "confirming"
    local ok, err = pcall(AH().ConfirmCommoditiesPurchase, id, qty)
    if not ok then notify("Achat refusé : " .. tostring(err), false); finish() end
    return ok
  end
  if B.state then B.cancel() end
  B.state = { id = id, qty = qty, maxUnit = maxUnit, oneClick = oneClick, stage = "quote", t0 = time() }
  local ok, err = pcall(AH().StartCommoditiesPurchase, id, qty)
  if not ok then notify("Demande de prix refusée : " .. tostring(err), false); finish(); return false end
  if C_Timer then C_Timer.After(TIMEOUT, function()
    if B.state and B.state.stage == "quote" and B.state.t0 and time() - B.state.t0 >= TIMEOUT then
      notify("L'HV n'a pas répondu : achat annulé.", false); B.cancel()
    end
  end) end
  if ns.gring and ns.gring.onBuyUpdate then ns.gring.onBuyUpdate() end
  return true
end

local ev = CreateFrame("Frame")
for _, e in ipairs({ "COMMODITY_SEARCH_RESULTS_UPDATED", "ITEM_SEARCH_RESULTS_UPDATED", "COMMODITY_PRICE_UPDATED", "COMMODITY_PRICE_UNAVAILABLE",
                     "COMMODITY_PURCHASE_SUCCEEDED", "COMMODITY_PURCHASE_FAILED", "AUCTION_HOUSE_THROTTLED_SYSTEM_READY",
                     "AUCTION_HOUSE_CLOSED" }) do pcall(ev.RegisterEvent, ev, e) end
ev:SetScript("OnEvent", function(_, e, a1, a2)
  local S = B.state
  if e == "COMMODITY_SEARCH_RESULTS_UPDATED" then
    local id = a1 or pendingQuery
    if id then pcall(readBook, id) end
    pendingQuery = nil
    if id and B.qBookArrived then B.qBookArrived(id) end
    if ns.gring and ns.gring.onBuyUpdate then ns.gring.onBuyUpdate() end
  elseif e == "ITEM_SEARCH_RESULTS_UPDATED" then
    local ok, id = pcall(readItemBook, a1)
    pendingQuery = nil
    if ok and id then
      if B.qBookArrived then B.qBookArrived(id) end
      refreshUI()
    end
  elseif e == "AUCTION_HOUSE_THROTTLED_SYSTEM_READY" then
    if queued then local id = queued; queued = nil; sendQuery(id) end
  elseif e == "COMMODITY_PRICE_UPDATED" and S and S.stage == "quote" then
    local unit, total = a1, a2
    S.total = total
    if (unit and unit > S.maxUnit) or (total and total > S.maxUnit * S.qty) then
      notify(("Prix monté : %s l'unité pour %d (max %s). Achat annulé."):format(ns.api.coins(unit or 0), S.qty, ns.api.coins(S.maxUnit)), false)
      if B.qResult then B.qResult(false, "prix monté") end; B.cancel()
    elseif S.oneClick then
      S.stage = "confirming"
      local ok, err = pcall(AH().ConfirmCommoditiesPurchase, S.id, S.qty)
      if not ok then notify("Achat refusé : " .. tostring(err), false); finish() end
    else
      S.stage = "await"
      notify(("Prix vérifié : %d pour %s. Clique à nouveau pour confirmer."):format(S.qty, ns.api.coins(total or 0)), true)
    end
  elseif e == "COMMODITY_PRICE_UNAVAILABLE" and S then
    notify("Ces annonces ne sont plus disponibles. Achat annulé.", false); finish(false, "annonces disparues")
  elseif e == "COMMODITY_PURCHASE_SUCCEEDED" then
    if S then notify(("Acheté : %d pour %s."):format(S.qty, ns.api.coins(S.total or 0)), true) end
    finish(true)
    if ns.gring and ns.gring.afterBuy then ns.gring.afterBuy() end
  elseif e == "COMMODITY_PURCHASE_FAILED" then
    notify("L'achat a échoué (quelqu'un a été plus rapide ?).", false); finish(false, "échec")
  elseif e == "AUCTION_HOUSE_CLOSED" then
    if S then finish() end
    if ns.gring and ns.gring.onBuyUpdate then ns.gring.onBuyUpdate() end
  end
end)

------------------------------------------------------------------------
-- Scan de l'HV intégré (remplace le scan Auctionator) : prix mini par objet suivi
------------------------------------------------------------------------
B.scanning = false
B.scanPct = nil          -- nil : pas de scan ; 0-100 : avancement
B.scanPhase = nil        -- "wait" : attente de l'HV ; "read" : lecture des annonces
local function trackedIds()
  local set = {}
  local gp = _G.GringottsPrices
  if gp and gp.items then for _, r in pairs(gp.items) do if r.id and r.id ~= 0 then set[r.id] = true end end end
  local d = ns.api and ns.api.db and ns.api.db()
  if d and d.ids then for _, id in pairs(d.ids) do set[id] = true end end
  return set
end

local function scanUI() if ns.gring and ns.gring.onScanProgress then ns.gring.onScanProgress() end end

function B.scan()
  local a = AH()
  if not (a and a.ReplicateItems) then notify("Scan intégré indisponible sur ce client : utilise Auctionator.", false); return false end
  if not B.ahOpen() then notify("Ouvre l'HV pour scanner.", false); return false end
  if B.scanning then return false end
  local ok, err = pcall(a.ReplicateItems)
  if not ok then notify("Scan refusé : " .. tostring(err), false); return false end
  B.scanning = true; B.scanT0 = time(); B.scanPhase = "wait"; B.scanPct = 0
  notify("Scan de l'HV lancé...", true)
  scanUI()
  -- l'HV ne répond pas : on abandonne au bout de 90 s au lieu de rester bloqué
  if C_Timer then C_Timer.After(90, function()
    if B.scanning and B.scanPhase == "wait" and time() - (B.scanT0 or 0) >= 89 then
      B.scanning = false; B.scanPhase = nil; B.scanPct = nil
      notify("L'HV n'a pas répondu au scan : réessaie (une seule demande par 15 min environ).", false); scanUI()
    end
  end) end
  return true
end

-- Lecture découpée en tranches : l'écran ne gèle pas et on peut afficher le pourcentage.
local CHUNK = 4000
local function readScan()
  local a = AH()
  local n = a.GetNumReplicateItems and a.GetNumReplicateItems() or 0
  local want, best = trackedIds(), {}
  B.scanPhase = "read"; B.scanPct = 0
  local i = 0
  local function step()
    local last = math.min(i + CHUNK - 1, n - 1)
    local okc = pcall(function()
      for k = i, last do
        local _, _, count, _, _, _, _, _, _, buyout, _, _, _, _, _, _, id = a.GetReplicateItemInfo(k)
        if id and want[id] and buyout and buyout > 0 and count and count > 0 then
          local u = math.floor(buyout / count)
          if not best[id] or u < best[id] then best[id] = u end
        end
      end
    end)
    if not okc then B.scanning = false; B.scanPhase = nil; B.scanPct = nil; notify("Lecture du scan interrompue (erreur de l'HV).", false); scanUI(); return end
    i = last + 1
    B.scanPct = n > 0 and math.floor(i / n * 100) or 100
    scanUI()
    if i < n then
      if C_Timer then C_Timer.After(0, step) else step() end
    else
      local d = ns.api.db()
      d.scan = { t = time(), p = best }
      local c = 0; for _ in pairs(best) do c = c + 1 end
      B.scanning = false; B.scanPhase = nil; B.scanPct = nil
      notify(("Scan terminé : %d objets suivis relevés (%d annonces lues)."):format(c, n), true)
      scanUI()
      if ns.onScan then ns.onScan() end
    end
  end
  step()
end

local sf = CreateFrame("Frame")
pcall(sf.RegisterEvent, sf, "REPLICATE_ITEM_LIST_UPDATE")
sf:SetScript("OnEvent", function()
  if B.scanning and B.scanPhase == "wait" then pcall(readScan) end
end)

-- Texte du bouton / de l'état : "Scan 42 %" ou nil
function B.scanLabel()
  if not B.scanning then return nil end
  if B.scanPhase == "wait" then return ("Scan : attente de l'HV (%d s)"):format(time() - (B.scanT0 or time())) end
  return ("Scan en cours : %d %%"):format(B.scanPct or 0)
end

-- Prix issu du scan intégré : prix, âge en jours
function B.scanPrice(id)
  local d = ns.api and ns.api.db and ns.api.db()
  local s = d and d.scan
  if not (s and s.p and s.p[id]) then return nil end
  return s.p[id], (time() - s.t) / 86400
end

------------------------------------------------------------------------
-- Mise en vente (commodités) : un clic = une pile postée
------------------------------------------------------------------------
local function bagStacks(id)
  local out, total = {}, 0
  local CC = C_Container
  if not (CC and CC.GetContainerNumSlots) then return out, 0 end
  for bag = 0, 4 do
    for slot = 1, CC.GetContainerNumSlots(bag) do
      local info = CC.GetContainerItemInfo(bag, slot)
      if info and info.itemID == id then out[#out + 1] = { bag = bag, slot = slot, n = info.stackCount or 1 }; total = total + (info.stackCount or 1) end
    end
  end
  return out, total
end
function B.bagCount(id) local _, t = bagStacks(id); return t end

function B.canSell() local a = AH(); return a and a.PostCommodity and ItemLocation and B.ahOpen() and true or false end

function B.sell(id, qty, unit, duration)
  if not B.canSell() then notify("Ouvre l'HV pour vendre.", false); return false end
  qty = math.floor(tonumber(qty) or 0)
  if not id or qty <= 0 or not unit or unit <= 0 then return false end
  local stacks, total = bagStacks(id)
  if total == 0 then notify("Aucun exemplaire dans tes sacs (ils sont peut-être en banque).", false); return false end
  local s = stacks[1]
  local n = math.min(qty, s.n)
  local loc = ItemLocation:CreateFromBagAndSlot(s.bag, s.slot)
  local status = AH().GetItemCommodityStatus and AH().GetItemCommodityStatus(loc)
  local ok, err
  if status == 1 and AH().PostItem then         -- objet non empilable : une annonce à la fois, prix d'achat immédiat
    n = 1
    ok, err = pcall(AH().PostItem, loc, duration or 2, 1, nil, math.floor(unit))
  else
    ok, err = pcall(AH().PostCommodity, loc, duration or 2, n, math.floor(unit))
  end
  if not ok then notify("Mise en vente refusée : " .. tostring(err), false); return false end
  B.lastSold = { id = id, n = n, left = qty - n }
  notify(("Mis en vente : %d à %s l'unité. Reste %d à poster."):format(n, ns.api.coins(unit), math.max(0, qty - n)), true)
  return true
end

------------------------------------------------------------------------
-- File d'achats / de ventes groupés : un clic ou une touche = une étape (règle Blizzard)
------------------------------------------------------------------------
B.q = nil   -- { mode, items = { {id,name,qty,limit,state,msg,left} }, cur }

local function qMoney() return GetMoney and GetMoney() or math.huge end

-- Lecture des annonces de chaque objet, l'une après l'autre
local function qPrefetch()
  local q = B.q; if not q then return end
  for _, e in ipairs(q.items) do
    if e.state == "need" then
      if B.book[e.id] and time() - B.book[e.id].t < 30 then e.state = "ready"
      else
        q.fetching = e
        if not B.query(e.id) then e.state = "ready" end   -- sans annonces : on se base sur le prix connu
        C_Timer.After(3, function() if q.fetching == e then e.state = "ready"; q.fetching = nil; qPrefetch() end end)
        return
      end
    end
  end
  q.fetching = nil
end
B.qPrefetch = qPrefetch

function B.qBookArrived(id)
  local q = B.q; if not q or not q.fetching or q.fetching.id ~= id then return end
  q.fetching.state = "ready"; q.fetching = nil
  qPrefetch()
  if ns.gring and ns.gring.onQueueUpdate then ns.gring.onQueueUpdate() end
end

-- entries : { id, name, qty, limit (prix max unitaire pour acheter / prix de vente pour vendre), floor (prix min en vente) }
function B.qStart(mode, entries)
  B.qStop()
  local items = {}
  for _, e in ipairs(entries) do items[#items + 1] = { id = e.id, name = e.name, qty = e.qty, limit = e.limit, floor = e.floor, fixed = e.fixed, state = "need", left = e.qty } end
  B.q = { mode = mode, items = items }
  qPrefetch()
  if ns.gring and ns.gring.onQueueUpdate then ns.gring.onQueueUpdate() end
end

function B.qStop()
  if B.state then B.cancel() end
  B.q = nil
  if ns.gring and ns.gring.onQueueUpdate then ns.gring.onQueueUpdate() end
end

function B.qActive() return B.q ~= nil end
function B.qPending()
  local n = 0
  if B.q then for _, e in ipairs(B.q.items) do if e.state == "need" or e.state == "ready" then n = n + 1 end end end
  return n
end

function B.qResult(ok, msg)
  local q = B.q; if not q or not q.running then return end
  local e = q.running; q.running = nil
  if ok then e.state = "done"; e.msg = "acheté"
  elseif ok == false then e.state = "skip"; e.msg = msg or "échec"
  else e.state = "skip"; e.msg = msg or "annulé" end
  if ns.gring and ns.gring.onQueueUpdate then ns.gring.onQueueUpdate() end
end

-- Un pas : à appeler depuis un clic ou une touche
function B.qStep()
  local q = B.q; if not q then return end
  if B.state then
    -- deux clics : le second confirme
    if B.state.stage == "await" then B.buy(B.state.id, B.state.qty, B.state.maxUnit, false) end
    return
  end
  for _, e in ipairs(q.items) do
    if e.state == "ready" or (e.state == "need" and not (q.fetching == e)) then
      local limit = e.limit
      if q.mode == "buy" then
        local av = B.availableUnder(e.id, limit)
        if av == nil then local bk = B.book[e.id]; av = bk and 0 or e.qty end   -- pas d'annonces lues : on tente, le garde-fou vérifiera
        local n = math.min(e.qty, av, math.floor(qMoney() / math.max(limit, 1)))
        if n <= 0 then e.state = "skip"; e.msg = (av == 0) and "rien sous ton prix max" or "pas assez d'or"
        else
          q.running = e; e.state = "running"
          if not B.buy(e.id, n, limit, ns.api.db().set.snipeOneClick ~= false) then q.running = nil; e.state = "skip"; e.msg = "refusé"
          else return end
        end
      else
        -- vente : prix = limit (conseillé), jamais sous le plancher
        if e.state == "need" and not e.limit then   -- annonces pas encore lues : on attend (la lecture avance toute seule), pas de saut
          e.msg = "lecture des annonces..."
          if not q.fetching then qPrefetch() end
          if ns.gring and ns.gring.onQueueUpdate then ns.gring.onQueueUpdate() end
          return
        end
        if q.nextAt and GetTime() < q.nextAt then return end   -- laisse l'HV finir la mise en vente précédente
        local unit = e.limit
        local bk = B.book[e.id]
        if bk and bk.levels[1] and not e.fixed then unit = math.max(bk.levels[1].p - 1, 1) end
        if not unit and B.scanPrice then unit = B.scanPrice(e.id) end
        if not unit and ns.sellPriceOf then local v = ns.sellPriceOf(e.id); if v and v > 0 then unit = v * 2 end end
        if not unit then e.state = "skip"; e.msg = "pas de prix"
        elseif e.floor and unit < e.floor then e.state = "skip"; e.msg = "marché sous ton plancher"
        elseif B.bagCount(e.id) <= 0 then e.state = "skip"; e.msg = "plus rien en sac"
        else
          local want = math.min(e.left, B.bagCount(e.id))
          if B.sell(e.id, want, unit, ns.api.db().set.sellDuration or 2) then
            q.nextAt = GetTime() + 0.8
            e.left = (B.lastSold and B.lastSold.left) or 0
            e.msg = e.left > 0 and (e.left .. " restants") or "mis en vente"
            if e.left <= 0 then e.state = "done" else e.state = "ready" end
            if ns.gring and ns.gring.onQueueUpdate then ns.gring.onQueueUpdate() end
            return
          else e.state = "skip"; e.msg = "refusé" end
        end
      end
    end
  end
  if ns.gring and ns.gring.onQueueUpdate then ns.gring.onQueueUpdate() end
end
