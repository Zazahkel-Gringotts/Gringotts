-- Gringotts : récolte. Plantes et minerais : couleur selon ton skill, plantes suivies, filtres réglés dans GatherMate2.
-- Le suivi passe par GatherMate2.db.profile.filter[type][nodeID] (même table que ses options « Herb filter » / « Mining filter »).
local ADDON, ns = ...
local G = {}
ns.gather = G

local function db() return ns.api and ns.api.db() end
local function norm(s) return ns.norm(s or "") end
local function flat(s) return (norm(s):gsub("[^%w]", "")) end

------------------------------------------------------------------------
-- Skills lus en jeu (Core les stocke dans chars[x].skills[nom localisé])
------------------------------------------------------------------------
local SK = { herb = { "herboristerie", "herbalism" }, mine = { "minage", "mining" }, fish = { "peche", "fishing" }, cook = { "cuisine", "cooking" } }
-- Renvoie niveau, max, vrai si c'est le personnage connecté. Sinon le meilleur niveau de tous les personnages.
function ns.skillOf(kind)
  local d = db(); if not d then return 0, 0, false end
  local want = {}
  for _, a in ipairs(SK[kind] or {}) do want[a] = true end
  local me = UnitName and UnitName("player")
  local lvl, max, mine = 0, 0, nil
  for _, c in pairs(d.chars or {}) do
    for name, s in pairs(c.skills or {}) do
      if want[norm(name)] and s.l then
        if c.name == me then mine = s end
        if s.l > lvl then lvl, max = s.l, s.m or 0 end
      end
    end
  end
  if mine then return mine.l, mine.m or 0, true end
  return lvl, max, false
end

------------------------------------------------------------------------
-- Données : plantes et minerais (noms FR du dashboard / client frFR, noms EN, skill requis)
------------------------------------------------------------------------
G.kinds = {
  herb = { type = "Herb Gathering", label = "Herboristerie", noun = "plante", list = {
    { fr = "Pacifique", en = "Peacebloom", req = 1 },
    { fr = "Feuillargent", en = "Silverleaf", req = 1 },
    { fr = "Terrestrine", en = "Earthroot", req = 15 },
    { fr = "Mage royal", en = "Mageroyal", req = 50 },
    { fr = "Églantine", en = "Briarthorn", req = 70 },
    { fr = "Étouffante", en = "Stranglekelp", req = 85, alt = { "Varech d'étrangleronce" } },
    { fr = "Doulourante", en = "Bruiseweed", req = 100 },
    { fr = "Aciérite sauvage", en = "Wild Steelbloom", req = 115 },
    { fr = "Tombeline", en = "Grave Moss", req = 120 },
    { fr = "Sang-royal", en = "Kingsblood", req = 125 },
    { fr = "Vietérule", en = "Liferoot", req = 150 },
    { fr = "Pâlerette", en = "Fadeleaf", req = 160 },
    { fr = "Dorépine", en = "Goldthorn", req = 170 },
    { fr = "Moustache de Khadgar", en = "Khadgar's Whisker", req = 185 },
    { fr = "Hivernale", en = "Wintersbite", req = 195 },
    { fr = "Fleur de feu", en = "Firebloom", req = 205 },
    { fr = "Lotus pourpre", en = "Purple Lotus", req = 210 },
    { fr = "Larmes d'Arthas", en = "Arthas' Tears", req = 220 },
    { fr = "Soleillette", en = "Sungrass", req = 230 },
    { fr = "Aveuglette", en = "Blindweed", req = 235 },
    { fr = "Champignon fantôme", en = "Ghost Mushroom", req = 245 },
    { fr = "Gromsang", en = "Gromsblood", req = 250 },
    { fr = "Sansam doré", en = "Golden Sansam", req = 260 },
    { fr = "Feuillerêve", en = "Dreamfoil", req = 270 },
    { fr = "Sauge-argent des montagnes", en = "Mountain Silversage", req = 280 },
    { fr = "Fleur de peste", en = "Plaguebloom", req = 285 },
    { fr = "Calot de glace", en = "Icecap", req = 290 },
    { fr = "Lotus noir", en = "Black Lotus", req = 300 },
  } },
  mine = { type = "Mining", label = "Minage", noun = "minerai", list = {
    { fr = "Filon de cuivre", en = "Copper Vein", req = 1 },
    { fr = "Filon d'étain", en = "Tin Vein", req = 65 },
    { fr = "Filon d'argent", en = "Silver Vein", req = 75 },
    { fr = "Gisement de fer", en = "Iron Deposit", req = 125 },
    { fr = "Filon d'or", en = "Gold Vein", req = 155 },
    { fr = "Gisement de mithril", en = "Mithril Deposit", req = 175 },
    { fr = "Gisement de vrai-argent", en = "Truesilver Deposit", req = 230 },
    { fr = "Petit filon de thorium", en = "Small Thorium Vein", req = 245 },
    { fr = "Riche filon de thorium", en = "Rich Thorium Vein", req = 275 },
  } },
}
G.order = { "herb", "mine" }

-- Seuils de couleur (règle générale des plantes) : orange dès le skill requis, jaune +25, vert +50, gris +100
G.COLORS = { orange = "orange", yellow = "jaune", green = "vert", gray = "gris", locked = "pas encore" }
function G.color(req, skill)
  local d = (skill or 0) - req
  if d < 0 then return "locked" end
  if d >= 100 then return "gray" elseif d >= 50 then return "green" elseif d >= 25 then return "yellow" end
  return "orange"
end

------------------------------------------------------------------------
-- Réglages (SavedVariables) : db.gather = { only, level, green, herb = {en = true}, mine = {...} }
------------------------------------------------------------------------
function G.st()
  local d = db(); if not d then return { herb = {}, mine = {} } end
  d.gather = d.gather or {}
  local s = d.gather
  s.herb = s.herb or {}; s.mine = s.mine or {}
  return s
end

function G.status(kind, e, skill)
  local s = G.st()
  skill = skill or ns.skillOf(kind)
  local col = G.color(e.req, skill)
  local climbs = col == "orange" or col == "yellow" or (col == "green" and s.green == true)
  local checked = s[kind][e.en] == true
  local followed = checked and (not s.level or climbs)
  return col, climbs, followed, checked
end

function G.setChecked(kind, en, on) G.st()[kind][en] = on and true or nil end
function G.checkAll(kind, on) for _, e in ipairs(G.kinds[kind].list) do G.setChecked(kind, e.en, on) end end
function G.checkClimbing(kind)
  local skill = ns.skillOf(kind)
  local s = G.st()
  for _, e in ipairs(G.kinds[kind].list) do
    local col = G.color(e.req, skill)
    s[kind][e.en] = (col == "orange" or col == "yellow" or (col == "green" and s.green == true)) or nil
  end
end

-- Noms des plantes suivies (pour le résumé)
function G.followedNames(kind)
  local out, skill = {}, ns.skillOf(kind)
  for _, e in ipairs(G.kinds[kind].list) do
    local _, _, followed = G.status(kind, e, skill)
    if followed then out[#out + 1] = e.fr end
  end
  return out
end

------------------------------------------------------------------------
-- GatherMate2
------------------------------------------------------------------------
local function gm() return LibStub and LibStub("AceAddon-3.0", true) and LibStub("AceAddon-3.0"):GetAddon("GatherMate2", true) or nil end
G.gm = gm

-- id GatherMate2 d'une entrée : on teste le nom FR, ses variantes et le nom EN, sans accents ni ponctuation
local function resolveIDs(GM, kind)
  local k = G.kinds[kind]
  local ids = GM.nodeIDs and GM.nodeIDs[k.type]
  if type(ids) ~= "table" then return nil end
  local byFlat = {}
  for name, id in pairs(ids) do if type(name) == "string" then byFlat[flat(name)] = id end end
  local out = {}
  for _, e in ipairs(k.list) do
    local id = byFlat[flat(e.fr)] or byFlat[flat(e.en)]
    if not id and e.alt then for _, a in ipairs(e.alt) do id = id or byFlat[flat(a)] end end
    if id then out[e.en] = id end
  end
  return out
end

-- Index inverse : type -> nodeID -> entrée (pour la flèche)
local rev
function G.reverse()
  if rev then return rev end
  local GM = gm(); if not GM then return nil end
  local r = {}
  for _, kind in ipairs(G.order) do
    local ids = resolveIDs(GM, kind)
    if ids then
      local t = {}
      for _, e in ipairs(G.kinds[kind].list) do if ids[e.en] then t[ids[e.en]] = { kind = kind, e = e } end end
      r[G.kinds[kind].type] = t
    end
  end
  rev = r
  return r
end

-- Règle les filtres de GatherMate2 : suivies = affichées, les autres masquées (si « suivre uniquement mes plantes cochées »)
function G.apply()
  local GM = gm()
  if not GM then return false, "GatherMate2 introuvable" end
  local prof = GM.db and GM.db.profile
  if not (prof and type(prof.filter) == "table") then return false, "réglages GatherMate2 illisibles" end
  local s, n = G.st(), 0
  for _, kind in ipairs(G.order) do
    local type_ = G.kinds[kind].type
    local ids = resolveIDs(GM, kind)
    if ids then
      prof.filter[type_] = prof.filter[type_] or {}
      local skill = ns.skillOf(kind)
      for _, e in ipairs(G.kinds[kind].list) do
        local id = ids[e.en]
        if id then
          local _, _, followed = G.status(kind, e, skill)
          prof.filter[type_][id] = (not s.only) or followed
          n = n + 1
        end
      end
    end
  end
  -- GatherMate2 redessine la carte et la minimap sur ce message (même appel que ses options)
  if GM.SendMessage then pcall(GM.SendMessage, GM, "GatherMate2ConfigChanged") end
  local C = GM.GetModule and GM:GetModule("Config", true)
  if C and C.UpdateConfig then pcall(C.UpdateConfig, C) end
  G.lastApply = n
  return true, n
end

-- Réglages d'affichage de GatherMate2 relayés depuis Gringotts (mêmes champs que ses options, db.profile.*)
-- trackDistance 50-240 m · scale (icônes carte) et miniscale (icônes minimap) 0,5-5 · alpha (carte) 0,1-1 · showMinimap / showWorldMap · trackShow
-- GatherMate2 n'a aucune option de son : l'alerte sonore est dans la flèche de Gringotts.
G.GMRANGE = { trackDistance = { 50, 240 }, scale = { .5, 5 }, miniscale = { .5, 5 }, alpha = { .1, 1 } }
G.TRACKSHOW = { "always", "with_profession", "active", "never" }
G.TRACKSHOW_FR = { always = "Toujours", with_profession = "Avec la profession", active = "Pistage actif", never = "Jamais" }

local function gmNotify(GM)
  if GM.SendMessage then pcall(GM.SendMessage, GM, "GatherMate2ConfigChanged") end
  local C = GM.GetModule and GM:GetModule("Config", true)
  if C and C.UpdateConfig then pcall(C.UpdateConfig, C) end
end

function G.gmGet(field)
  local GM = gm(); local p = GM and GM.db and GM.db.profile
  return p and p[field]
end

function G.gmSet(field, v)
  local GM = gm(); local p = GM and GM.db and GM.db.profile
  if not p then return false, "GatherMate2 introuvable" end
  local r = G.GMRANGE[field]
  if r then
    v = tonumber(v)
    if not v or v < r[1] or v > r[2] then return false, ("valeur entre %s et %s"):format(r[1], r[2]) end
  elseif field == "trackShow" then
    local ok = false; for _, x in ipairs(G.TRACKSHOW) do if x == v then ok = true end end
    if not ok then return false, "valeur inconnue" end
  elseif field == "showMinimap" or field == "showWorldMap" then v = v and true or false
  else return false, "réglage non relayé" end
  p[field] = v
  gmNotify(GM)
  return true
end

function G.gmCycleTrackShow()
  local cur = G.gmGet("trackShow") or "always"
  local nxt = G.TRACKSHOW[1]
  for i, x in ipairs(G.TRACKSHOW) do if x == cur then nxt = G.TRACKSHOW[i % #G.TRACKSHOW + 1] end end
  return G.gmSet("trackShow", nxt), nxt
end

-- Info sur un point de la carte (pour la flèche) : nil si inconnu
function G.nodeInfo(typeName, nodeID)
  local r = G.reverse(); local t = r and r[typeName]; local x = t and t[nodeID]
  if not x then return nil end
  local col, climbs, followed = G.status(x.kind, x.e)
  return { kind = x.kind, entry = x.e, color = col, climbs = climbs, followed = followed or not G.st().only }
end

-- Types de points à parcourir pour la flèche : herbes par défaut, minerais si au moins un minerai est coché
function G.arrowTypes()
  local out, s = { G.kinds.herb.type }, G.st()
  if next(s.mine) then out[#out + 1] = G.kinds.mine.type end
  return out
end

-- Réapplique à la connexion et quand le skill monte (les couleurs changent)
local ev = CreateFrame("Frame")
for _, e in ipairs({ "PLAYER_LOGIN", "CHAT_MSG_SKILL", "SKILL_LINES_CHANGED" }) do pcall(ev.RegisterEvent, ev, e) end
local pending
ev:SetScript("OnEvent", function(_, e)
  if pending then return end
  pending = true
  local function go() pending = nil; rev = nil; if G.st().only then pcall(G.apply) end; if ns.gatherUI and ns.gatherUI.refresh then pcall(ns.gatherUI.refresh) end end
  if C_Timer and C_Timer.After then C_Timer.After(e == "PLAYER_LOGIN" and 5 or 1.5, go) else go() end
end)
