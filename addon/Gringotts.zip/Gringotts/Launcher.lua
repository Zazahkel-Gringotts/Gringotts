-- Gringotts : bouton rond flottant + menu radial (Business, Métiers, Récolte, Pêche, Bêtes pour un chasseur, Options).
-- Clic gauche : ouvre/ferme les boutons autour · glisser : déplacer où tu veux · /gt bouton : afficher/masquer
local ADDON, ns = ...

local ENTRIES = {
  { "Business", "stock", "Interface\\Icons\\INV_Misc_Coin_02" },
  { "Métiers", "crafts", "Interface\\Icons\\Trade_BlackSmithing" },
  { "Récolte", "gathering", "Interface\\Icons\\INV_Misc_Herb_07" },
  { "Pêche", "peche", "Interface\\Icons\\Trade_Fishing" },
  { "Options", "settings", "Interface\\Icons\\INV_Gizmo_01" },
}

local btn, menu
local MAIN, SAT, RADIUS = 46, 34, 52

local function ring(p, size, icon, iconSize)
  local ic = p:CreateTexture(nil, "ARTWORK")
  ic:SetTexture(icon); ic:SetSize(iconSize, iconSize); ic:SetPoint("CENTER", 0, 0)
  ic:SetTexCoord(.08, .92, .08, .92)
  local border = p:CreateTexture(nil, "OVERLAY")
  border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
  border:SetSize(size * 1.7, size * 1.7); border:SetPoint("TOPLEFT", p, "TOPLEFT", 0, 0)
  border:SetDesaturated(true); border:SetVertexColor(.82, .86, .92)   -- anneau sobre, pas de violet
  local hl = p:CreateTexture(nil, "HIGHLIGHT")
  hl:SetTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight"); hl:SetBlendMode("ADD")
  hl:SetSize(size * 1.7, size * 1.7); hl:SetPoint("TOPLEFT", p, "TOPLEFT", 0, 0)
  return ic
end

local function place()
  btn:ClearAllPoints()
  local pos = GringottsDB and GringottsDB.mini and GringottsDB.mini.pos
  if pos and pos[1] then btn:SetPoint(pos[1], UIParent, pos[2], pos[3], pos[4])
  else btn:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", -230, -230) end
end

local function layoutMenu()
  -- les boutons s'ouvrent en arc au-dessus du bouton principal (en dessous s'il est trop haut sur l'écran)
  local top, ptop = btn:GetTop(), UIParent:GetTop()
  local up = not (top and ptop and top * btn:GetEffectiveScale() > (ptop - 140) * UIParent:GetEffectiveScale())
  local n = #menu.sats
  local span = math.min(150, 40 * (n - 1) + 20)
  for i, b in ipairs(menu.sats) do
    local a = n == 1 and 90 or (90 + span / 2 - (i - 1) * span / (n - 1))
    local r = math.rad(a)
    local dy = RADIUS * math.sin(r) * (up and 1 or -1)
    b:ClearAllPoints()
    b:SetPoint("CENTER", btn, "CENTER", RADIUS * math.cos(r), dy)
  end
end

local function buildMenu()
  if ns.pets and ns.pets.isHunter and ns.pets.isHunter() then table.insert(ENTRIES, #ENTRIES, { "Bêtes", "pets", "Interface\\Icons\\Ability_Hunter_BeastCall" }) end
  menu = CreateFrame("Frame", "GringottsMenu", UIParent)
  menu:SetSize(1, 1); menu:SetFrameStrata("DIALOG"); menu:SetPoint("CENTER", btn, "CENTER")
  menu.sats = {}
  for i, e in ipairs(ENTRIES) do
    local b = CreateFrame("Button", nil, menu)
    b:SetSize(SAT, SAT)
    ring(b, SAT, e[3], SAT * .62)
    b:RegisterForClicks("LeftButtonUp")
    b:SetScript("OnClick", function() menu:Hide(); if ns.uiOpen then ns.uiOpen(e[2]) end end)
    b:SetScript("OnEnter", function(self) GameTooltip:SetOwner(self, "ANCHOR_TOP"); GameTooltip:SetText(e[1]); GameTooltip:Show() end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    menu.sats[i] = b
  end
  menu:Hide()
  if UISpecialFrames then tinsert(UISpecialFrames, "GringottsMenu") end
end

local function toggleMenu()
  if not menu then buildMenu() end
  if menu:IsShown() then menu:Hide() return end
  layoutMenu()
  menu:Show()
end

local function build()
  btn = CreateFrame("Button", "GringottsMinimapButton", UIParent)
  btn:SetSize(MAIN, MAIN)
  btn:SetFrameStrata("MEDIUM"); btn:SetFrameLevel(8)
  btn:SetMovable(true); btn:SetClampedToScreen(true)
  btn:RegisterForClicks("LeftButtonUp")
  btn:RegisterForDrag("LeftButton")
  ring(btn, MAIN, "Interface\\Icons\\INV_Misc_Coin_02", MAIN * .62)
  btn:SetScript("OnClick", toggleMenu)
  btn:SetScript("OnDragStart", function(self) if menu then menu:Hide() end self:StartMoving() end)
  btn:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
    local p, _, rp, x, y = self:GetPoint()
    GringottsDB.mini = GringottsDB.mini or {}
    GringottsDB.mini.pos = { p, rp, x, y }
  end)
  btn:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_LEFT")
    GameTooltip:SetText("Gringotts"); GameTooltip:AddLine("Clic : ouvrir le menu · glisser : déplacer", 1, 1, 1)
    GameTooltip:Show()
  end)
  btn:SetScript("OnLeave", function() GameTooltip:Hide() end)
  place()
  if ns.launcherApply then ns.launcherApply() end
  if GringottsDB.mini and GringottsDB.mini.hidden then btn:Hide() end
end

function ns.launcherApply()
  if not btn then return end
  local sc = ((GringottsDB.mini and GringottsDB.mini.scale) or 100) / 100
  btn:SetScale(math.max(.6, math.min(1.6, sc)))
  if menu then menu:SetScale(math.max(.6, math.min(1.6, sc))) end
end

function ns.launcherCmd()
  if not btn then return end
  if menu then menu:Hide() end
  GringottsDB.mini = GringottsDB.mini or {}
  GringottsDB.mini.hidden = not GringottsDB.mini.hidden
  if GringottsDB.mini.hidden then btn:Hide() else btn:Show() end
end

function ns.launcherShow(on)
  if not btn then return end
  GringottsDB.mini = GringottsDB.mini or {}
  GringottsDB.mini.hidden = not on
  if on then btn:Show() else btn:Hide() end
end
function ns.launcherReset()
  if not btn then return end
  GringottsDB.mini = GringottsDB.mini or {}
  GringottsDB.mini.pos = nil; GringottsDB.mini.hidden = false
  btn:Show(); place()
end

local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", function()
  GringottsDB = GringottsDB or {}
  build()
end)
