-- Gringotts : conseil de munitions (chasseur). Dégâts par seconde lus dans l'infobulle du jeu, meilleure munition utilisable,
-- vendeur de munitions le plus proche (flèche). Données de vendeurs : AmmoDB.lua (ForeverDB.net via Hunter Forever, GPL-3.0).
-- /gt tir meilleure   : état et conseil      /gt tir vendeur : flèche vers le vendeur le plus proche de la munition conseillée
local ADDON, ns = ...
local A = {}
ns.ammo = A

local SLOT_RANGED, SLOT_AMMO = 18, 0
local AV_ONLY = { [19316] = true, [19317] = true }   -- vallée d'Alterac : jamais la munition à acheter
local dpsCache = {}

local function say(m) print("|cffe4b84eGringotts|r " .. m) end
local function num(v) return type(v) == "number" and v or nil end
local function isHunter() local _, c = UnitClass("player"); return c == "HUNTER" end

local function itemInstant(id)
  local fn = (C_Item and C_Item.GetItemInfoInstant) or GetItemInfoInstant
  if not fn then return nil end
  local ok, _, _, _, _, icon, classID, sub = pcall(fn, id)
  if ok then return num(classID), num(sub), icon end
end
local function itemInfo(id)
  local fn = (C_Item and C_Item.GetItemInfo) or GetItemInfo
  local ok, a, link, _, _, minLevel = pcall(fn, id)
  if ok and type(a) == "table" then return a.itemName, a.itemLink, a.itemMinLevel end
  if ok then return type(a) == "string" and a or nil, link, num(minLevel) end
end

-- "a" flèches (arc, arbalète), "b" balles (arme à feu), nil sans arme à distance
function A.kind()
  local id = GetInventoryItemID and GetInventoryItemID("player", SLOT_RANGED)
  if not id then return nil end
  local cls, sub = itemInstant(id)
  if cls ~= 2 then return nil end
  if sub == 2 or sub == 18 then return "a" end
  if sub == 3 then return "b" end
end

-- ligne « Ajoute X points de dégâts par seconde » du jeu, dans la langue du client
local dpsPattern
do
  local t = type(AMMO_DAMAGE_TEMPLATE) == "string" and AMMO_DAMAGE_TEMPLATE
  if t then
    local a, b = t:match("^(.-)%%[%d%.]*[sgfd](.*)$")
    local function esc(x) return (x:gsub("[%^%$%(%)%%%.%[%]%*%+%-%?]", "%%%0")) end
    if a and b then dpsPattern = esc(a) .. "([%d]+[%.,]?%d*)" .. esc(b) end
  end
end

-- dégâts par seconde ajoutés ; nil tant que le jeu n'a pas chargé l'objet
function A.dps(id)
  if dpsCache[id] then return dpsCache[id] end
  local found
  pcall(function()
    if not (C_TooltipInfo and C_TooltipInfo.GetItemByID) then return end
    local data = C_TooltipInfo.GetItemByID(id)
    for _, line in ipairs(data and data.lines or {}) do
      local text = type(line.leftText) == "string" and line.leftText
      if text and not found then
        local w = dpsPattern and text:match(dpsPattern)
        if not w and (text:find("par seconde", 1, true) or text:lower():find("per second", 1, true)) then w = text:match("([%d]+[%.,]?%d*)") end
        if w then found = tonumber((w:gsub(",", "."))) end
      end
    end
  end)
  if found then dpsCache[id] = found
  elseif C_Item and C_Item.RequestLoadItemDataByID then pcall(C_Item.RequestLoadItemDataByID, id); A.waiting = true end
  return found
end

local function bagAmmo(kind)
  local out = {}
  local CC = C_Container
  if not (CC and CC.GetContainerNumSlots) then return out end
  for bag = 0, 4 do
    for slot = 1, CC.GetContainerNumSlots(bag) do
      local info = CC.GetContainerItemInfo(bag, slot)
      if info and info.itemID then
        local cls, sub = itemInstant(info.itemID)
        if cls == 6 and ((kind == "a" and sub == 2) or (kind == "b" and sub == 3)) then out[info.itemID] = (out[info.itemID] or 0) + (info.stackCount or 1) end
      end
    end
  end
  return out
end

-- position du joueur : uiMapID, x, y en %
local function playerPos()
  if not (C_Map and C_Map.GetBestMapForUnit) then return nil end
  local m = C_Map.GetBestMapForUnit("player")
  if not m then return nil end
  local p = C_Map.GetPlayerMapPosition(m, "player")
  if not p then return m end
  local x, y = p:GetXY()
  return m, x and x * 100, y and y * 100
end
local function zoneName(m) local i = C_Map and C_Map.GetMapInfo and C_Map.GetMapInfo(m); return i and i.name or tostring(m) end

-- vendeurs d'une munition, du plus proche au plus loin (même carte d'abord)
function A.vendors(itemID)
  local out = {}
  if not ns.ammoVendors then return out end
  local m, x, y = playerPos()
  local f = UnitFactionGroup and UnitFactionGroup("player")
  local mine = f == "Alliance" and "A" or f == "Horde" and "H" or ""
  for id, v in pairs(ns.ammoVendors) do
    if v[5] == "" or v[5] == mine or mine == "" then
      for _, it in ipairs(v[7]) do
        if it == itemID then
          local d = 1e9
          if m == v[2] and x then d = math.sqrt((v[3] - x) ^ 2 + (v[4] - y) ^ 2) end
          out[#out + 1] = { id = id, name = v[1], m = v[2], x = v[3], y = v[4], seen = v[6] == 1, d = d }
        end
      end
    end
  end
  table.sort(out, function(a, b)
    if a.d ~= b.d then return a.d < b.d end
    local za, zb = zoneName(a.m), zoneName(b.m)
    if za ~= zb then return za < zb end
    return a.name < b.name
  end)
  return out
end

-- l'ensemble : { kind, equipped = {id, count, dps}, options, best, next }
function A.state()
  local kind = A.kind()
  if not kind then return nil end
  local my = UnitLevel("player") or 1
  local s = { kind = kind, options = {} }
  local eq = GetInventoryItemID and GetInventoryItemID("player", SLOT_AMMO)
  if eq and eq > 0 then s.equipped = { id = eq, count = GetInventoryItemCount("player", SLOT_AMMO) or 0, dps = A.dps(eq) } end
  local bags = bagAmmo(kind)
  local seen = {}
  local function add(id, level, vendor)
    if seen[id] then return end
    seen[id] = true
    local _, _, minLevel = itemInfo(id)
    level = level or minLevel or 1
    s.options[#s.options + 1] = { id = id, level = level, dps = A.dps(id), bags = bags[id] or 0, vendor = vendor, usable = level <= my, hard = vendor and AV_ONLY[id] or nil }
  end
  for id, v in pairs(ns.vendorAmmo or {}) do if v[1] == kind then add(id, v[2], true) end end
  for id in pairs(bags) do add(id, nil, false) end
  if s.equipped then add(s.equipped.id, nil, false) end
  table.sort(s.options, function(a, b)
    if (a.dps or 0) ~= (b.dps or 0) then return (a.dps or 0) > (b.dps or 0) end
    return a.level > b.level
  end)
  for _, o in ipairs(s.options) do
    if o.usable and ((o.vendor and not o.hard) or o.bags > 0 or (s.equipped and s.equipped.id == o.id)) then s.best = o; break end
  end
  for _, o in ipairs(s.options) do
    if o.vendor and not o.hard and not o.usable and (not s.next or o.level < s.next.level) then s.next = o end
  end
  return s
end

-- conseil en clair (chat) ; retourne la munition conseillée si elle vaut mieux que l'équipée
function A.report(quiet)
  local s = A.state()
  if not s then if not quiet then say("Aucune arme à distance équipée.") end return end
  local eq, best = s.equipped, s.best
  if not best then if not quiet then say("Aucune munition utilisable trouvée.") end return end
  local bname = itemInfo(best.id) or ("objet " .. best.id)
  if eq and best.id == eq.id then
    if not quiet then say(("Tes munitions équipées sont déjà les meilleures disponibles (%s%s)."):format(bname, best.dps and (", " .. ("%.1f"):format(best.dps) .. " dégâts/s") or "")) end
    return
  end
  if best.dps and eq and eq.dps and best.dps <= eq.dps then return end
  local gain = (best.dps and eq and eq.dps) and (" (+%.1f dégâts/s)"):format(best.dps - eq.dps) or ""
  local where
  if best.bags > 0 then where = "elles sont dans tes sacs : équipe-les."
  else
    local v = A.vendors(best.id)[1]
    where = v and ("vendeur le plus proche : %s, %s (%.0f, %.0f) — /gt tir vendeur pour la flèche."):format(v.name, zoneName(v.m), v.x, v.y) or "à acheter chez un vendeur."
  end
  say(("Meilleures munitions : %s%s — %s"):format(bname, gain, where))
  if s.next and (not quiet) then say(("Prochaine munition de vendeur : %s au niveau %d."):format(itemInfo(s.next.id) or ("objet " .. s.next.id), s.next.level)) end
  return best
end

-- flèche vers le vendeur le plus proche de la munition conseillée
function A.goVendor()
  local s = A.state()
  local best = s and s.best
  if not best then say("Pas de munition à acheter."); return end
  if s.equipped and best.id == s.equipped.id and (s.equipped.count or 0) > 100 then
    -- déjà la meilleure et assez en stock : on propose quand même un vendeur pour la recharger
  end
  local v = A.vendors(best.id)[1]
  if not v then say("Aucun vendeur connu pour cette munition."); return end
  if ns.arrowGoto and ns.arrowGoto({ zone = v.m, x = v.x, y = v.y, name = v.name .. " (munitions)", zoneName = zoneName(v.m) }) then
    say(("Flèche vers %s, %s."):format(v.name, zoneName(v.m)))
  end
end

local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN"); ev:RegisterEvent("PLAYER_LEVEL_UP"); ev:RegisterEvent("GET_ITEM_INFO_RECEIVED")
ev:SetScript("OnEvent", function(_, e)
  if not isHunter() then return end
  if e == "PLAYER_LOGIN" then if C_Timer then C_Timer.After(9, function() A.report(true) end) end
  elseif e == "PLAYER_LEVEL_UP" then if C_Timer then C_Timer.After(3, function() A.report(true) end) end
  elseif e == "GET_ITEM_INFO_RECEIVED" then A.waiting = nil end
end)
