-- Gringotts : fenêtre en jeu à onglets. /gt ui pour l'ouvrir.
-- Onglets : Business (tour de contrôle, stock & achats, finances), Métiers, Récolte (herbes, minerais, pêche), Bêtes (chasseur seulement), Options.
local ADDON, ns = ...

local frame, tabs, panes = nil, {}, {}

local function api() return ns.api end
local W = ns.W

local function makeCheck(parent, label, y, get, set)
  local cb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
  cb:SetPoint("TOPLEFT", parent, "TOPLEFT", 8, y)
  cb.text = cb.text or cb:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  cb.text:SetPoint("LEFT", cb, "RIGHT", 4, 0)
  cb.text:SetText(label)
  cb:SetChecked(get())
  cb:SetScript("OnClick", function(self) set(self:GetChecked() and true or false) end)
  return cb
end

local function title(pane, text, y)
  local t = pane:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
  t:SetPoint("TOPLEFT", pane, "TOPLEFT", 8, y); t:SetText(text)
  return t
end
local function note(pane, text, y)
  local t = pane:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  t:SetPoint("TOPLEFT", pane, "TOPLEFT", 8, y); t:SetWidth(700); t:SetJustifyH("LEFT"); t:SetText(text)
  return t
end

local function buildSettings(pane)
  local E = ns.engine
  local y = -8
  title(pane, "Général", y); y = y - 28
  makeCheck(pane, "Scintillement des objets ramassables (quête, etc.)", y,
    function() return ns.sparklesGet and ns.sparklesGet() end,
    function(v) if ns.sparklesSet then ns.sparklesSet(v) end end)
  y = y - 28
  makeCheck(pane, "Contour orange des composants dans les sacs", y,
    function() local d = api().db(); return d.highlight end,
    function(v) api().db().highlight = v end)
  y = y - 36
  title(pane, "Gringotts : achats et ventes", y); y = y - 30
  local s = E.cfg()
  local lbl = pane:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  lbl:SetPoint("TOPLEFT", pane, "TOPLEFT", 12, y - 4); lbl:SetText("Vendre quand le prix dépasse la médiane 30 j de (%)")
  local e1 = W.edit(pane, 50, true, function(self) local v = tonumber(self:GetText()); if v and v >= 0 then E.cfg().sellGap = v / 100 end end)
  e1:SetPoint("TOPLEFT", pane, "TOPLEFT", 420, y); e1:SetText(tostring(math.floor(s.sellGap * 100 + .5)))
  e1:SetScript("OnEditFocusLost", function(self) local v = tonumber(self:GetText()); if v and v >= 0 then E.cfg().sellGap = v / 100 end end)
  y = y - 30
  makeCheck(pane, "Achat spéculatif : proposer d'acheter sous la médiane, même sans recette", y,
    function() return E.cfg().spec end, function(v) E.cfg().spec = v end)
  y = y - 30
  local lbl2 = pane:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  lbl2:SetPoint("TOPLEFT", pane, "TOPLEFT", 12, y - 4); lbl2:SetText("Achat spéculatif : écart sous la médiane (%) / quantité")
  local e2 = W.edit(pane, 50, true); e2:SetPoint("TOPLEFT", pane, "TOPLEFT", 420, y); e2:SetText(tostring(math.floor(s.specGap * 100 + .5)))
  e2:SetScript("OnEditFocusLost", function(self) local v = tonumber(self:GetText()); if v and v > 0 then E.cfg().specGap = v / 100 end end)
  local e3 = W.edit(pane, 50, true); e3:SetPoint("TOPLEFT", pane, "TOPLEFT", 480, y); e3:SetText(tostring(s.specQty))
  e3:SetScript("OnEditFocusLost", function(self) local v = tonumber(self:GetText()); if v and v > 0 then E.cfg().specQty = v end end)
  y = y - 30
  local lbl3 = pane:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  lbl3:SetPoint("TOPLEFT", pane, "TOPLEFT", 12, y - 4); lbl3:SetText("Alerte si les prix ont plus de (jours)")
  local e4 = W.edit(pane, 50, true); e4:SetPoint("TOPLEFT", pane, "TOPLEFT", 420, y); e4:SetText(tostring(api().db().staleDays or 3))
  e4:SetScript("OnEditFocusLost", function(self) local v = tonumber(self:GetText()); if v and v > 0 then api().db().staleDays = v end end)
  y = y - 30
  local lbl4 = pane:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  lbl4:SetPoint("TOPLEFT", pane, "TOPLEFT", 12, y - 4); lbl4:SetText("Commission de l'HV (%) / plancher de vente (% de la médiane)")
  local e5 = W.edit(pane, 50, true); e5:SetPoint("TOPLEFT", pane, "TOPLEFT", 420, y); e5:SetText(tostring(math.floor(s.fee * 100 + .5)))
  e5:SetScript("OnEditFocusLost", function(self) local v = tonumber(self:GetText()); if v and v >= 0 and v < 100 then E.cfg().fee = v / 100 end end)
  local e6 = W.edit(pane, 50, true); e6:SetPoint("TOPLEFT", pane, "TOPLEFT", 480, y); e6:SetText(tostring(math.floor(s.floorPct * 100 + .5)))
  e6:SetScript("OnEditFocusLost", function(self) local v = tonumber(self:GetText()); if v and v > 0 and v <= 100 then E.cfg().floorPct = v / 100 end end)
  y = y - 30
  local lbl5 = pane:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  lbl5:SetPoint("TOPLEFT", pane, "TOPLEFT", 12, y - 4); lbl5:SetText("Prix anormal : écart de x fois la médiane (pic ou creux)")
  local e7 = W.edit(pane, 50, true); e7:SetPoint("TOPLEFT", pane, "TOPLEFT", 420, y); e7:SetText(tostring(s.spikeX))
  e7:SetScript("OnEditFocusLost", function(self) local v = tonumber(self:GetText()); if v and v >= 2 then E.cfg().spikeX = v end end)
  y = y - 40
  title(pane, "Récolte", y); y = y - 28
  makeCheck(pane, "Flèche vers l'herbe GatherMate2 la plus proche", y,
    function() local d = api().db(); return d.arrow and d.arrow.on end,
    function(v) local d = api().db(); local on = d.arrow and d.arrow.on; if (on and true or false) ~= v and ns.arrowCmd then ns.arrowCmd("") end end)
  y = y - 36
  title(pane, "Pêche", y); y = y - 28
  makeCheck(pane, "Mode pêche automatique (canne équipée = session, touche unique lancer / ramasser)", y,
    function() return ns.fishing and ns.fishing.st().auto ~= false end,
    function(v) if ns.fishing then ns.fishing.st().auto = v; ns.fishing.sync() end end)
  y = y - 28
  makeCheck(pane, "Leurre automatique : applique un leurre de ton sac quand la canne n'en a plus", y,
    function() return ns.fishing and ns.fishing.st().lure ~= false end,
    function(v) if ns.fishing then ns.fishing.st().lure = v; ns.fishing.bind() end end)
  y = y - 28
  note(pane, "La touche de lancer et le Guide / Journey se règlent dans Récolte.", y)
  if ns.pets and ns.pets.isHunter and ns.pets.isHunter() and ns.shot then
    local Sh = ns.shot
    y = y - 36
    title(pane, "Chasseur : tir automatique", y); y = y - 28
    makeCheck(pane, "Barre du tir automatique (se remplit ; change de couleur quand il ne faut plus bouger)", y,
      function() return Sh.cfg().on end, function(v) Sh.set("on", v) end)
    y = y - 28
    makeCheck(pane, "Texte sur la barre (temps restant et vitesse)", y,
      function() return Sh.cfg().text end, function(v) Sh.set("text", v) end)
    y = y - 28
    makeCheck(pane, "Icône de munitions sous la barre (quantité présente dans les sacs)", y,
      function() return Sh.cfg().ammo end, function(v) Sh.set("ammo", v) end)
    y = y - 32
    local function lab(t, yy) local l = pane:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); l:SetPoint("TOPLEFT", pane, "TOPLEFT", 12, yy - 4); l:SetText(t) end
    lab("Largeur / hauteur (px)", y)
    local ew = W.edit(pane, 50, true); ew:SetPoint("TOPLEFT", pane, "TOPLEFT", 420, y); ew:SetText(tostring(Sh.cfg().w))
    local eh = W.edit(pane, 50, true); eh:SetPoint("TOPLEFT", pane, "TOPLEFT", 480, y); eh:SetText(tostring(Sh.cfg().h))
    local function sz() Sh.set("size", { tonumber(ew:GetText()), tonumber(eh:GetText()) }) end
    ew:SetScript("OnEditFocusLost", sz); eh:SetScript("OnEditFocusLost", sz)
    y = y - 30
    lab("Opacité (10-100 %) / zone de visée (ms)", y)
    local eo = W.edit(pane, 50, true); eo:SetPoint("TOPLEFT", pane, "TOPLEFT", 420, y); eo:SetText(tostring(math.floor(Sh.cfg().alpha * 100 + .5)))
    eo:SetScript("OnEditFocusLost", function(self) Sh.set("alpha", self:GetText()) end)
    local ea = W.edit(pane, 50, true); ea:SetPoint("TOPLEFT", pane, "TOPLEFT", 480, y); ea:SetText(tostring(math.floor(Sh.cfg().aim * 1000 + .5)))
    ea:SetScript("OnEditFocusLost", function(self) Sh.set("aim", self:GetText()) end)
    y = y - 30
    note(pane, "Maj + glisser déplace la barre · /gt tir reset la recentre. Si tu bouges pendant la visée : flash rouge, la visée repart du début.", y)
  end
end

local function selectTab(name)
  if frame then frame.current = name end
  for k, p in pairs(panes) do if k == name then p:Show() else p:Hide() end end
  for k, t in pairs(tabs) do if k == name then t:Disable() else t:Enable() end end
  if name == "stock" and ns.gring then ns.gring.select(ns.gring.current or "control") end
  if name == "gathering" and ns.gatherUI then ns.gatherUI.refresh() end
  if name == "pets" and ns.petsUI then ns.petsUI.refresh() end
  if name == "settings" and ns.opt then ns.opt.refresh() end
  if name == "crafts" and ns.craftsUI then ns.craftsUI.refresh() elseif ns.craftsUI and ns.craftsUI.updateBar then ns.craftsUI.updateBar() end
end

-- Échelle et position mémorisées (Options › Général)
function ns.uiApplyLook()
  if not frame then return end
  local o = ns.opt and ns.opt.ui(); if not o then return end
  frame:SetScale(math.max(.5, math.min(1.5, (o.scale or 100) / 100)))
  if o.remember and o.pos then frame:ClearAllPoints(); frame:SetPoint(o.pos[1], UIParent, o.pos[2], o.pos[3], o.pos[4]) end
end
function ns.uiResetPos()
  local o = ns.opt and ns.opt.ui(); if o then o.pos = nil end
  if frame then frame:ClearAllPoints(); frame:SetPoint("CENTER") end
end

local function build()
  frame = CreateFrame("Frame", "GringottsFrame", UIParent, "BasicFrameTemplateWithInset")
  frame:SetSize(1500, 800)
  frame:SetPoint("CENTER")
  frame:SetFrameStrata("HIGH")
  frame:SetMovable(true); frame:EnableMouse(true); frame:RegisterForDrag("LeftButton")
  frame:SetScript("OnDragStart", frame.StartMoving)
  frame:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
    local o = ns.opt and ns.opt.ui()
    if o and o.remember then local p, _, rp, x, y = self:GetPoint(); o.pos = { p, rp, x, y } end
  end)
  frame:SetClampedToScreen(true)
  if frame.TitleText then frame.TitleText:SetText("Gringotts") end
  if UISpecialFrames then tinsert(UISpecialFrames, "GringottsFrame") end   -- Échap ferme la fenêtre
  if ns.uiApplyLook then ns.uiApplyLook() end

  local function tab(name, label, x)
    local b = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    b:SetSize(110, 24); b:SetPoint("TOPLEFT", frame, "TOPLEFT", x, -28); b:SetText(label)
    b:SetScript("OnClick", function() selectTab(name) end)
    tabs[name] = b
  end
  tab("stock", "Business", 10)
  tab("crafts", "Métiers", 124)
  tab("gathering", "Récolte", 238)
  local hunter = ns.pets and ns.pets.isHunter and ns.pets.isHunter()
  if hunter then tab("pets", "Bêtes", 352) end   -- onglet réservé au chasseur
  tab("settings", "Options", hunter and 466 or 352)

  local function pane(name)
    local p = CreateFrame("Frame", nil, frame)
    p:SetPoint("TOPLEFT", frame, "TOPLEFT", 12, -60); p:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -12, 12)
    panes[name] = p
    return p
  end

  -- Gringotts : tour de contrôle, stock & achats, finances
  local s = pane("stock")
  ns.gring.build(s)

  -- Réglages
  if ns.opt then ns.opt.build(pane("settings")) else buildSettings(pane("settings")) end

  ns.craftsUI.build(pane("crafts"))
  ns.gatherUI.build(pane("gathering"))
  if hunter and ns.petsUI then ns.petsUI.build(pane("pets")) end

  if ns.craftsUI and ns.craftsUI.buildBar then ns.craftsUI.buildBar(frame) end
  selectTab("stock")
  frame:Hide()
end

local VALID = { stock = true, crafts = true, gathering = true, settings = true, pets = true }
local ALIAS = { business = "stock", gringotts = "stock", dashboard = "stock", stock = "stock", metiers = "crafts", metier = "crafts", crafts = "crafts",
                peche = "gathering", fishing = "gathering", recolte = "gathering", gathering = "gathering",
                options = "settings", option = "settings",
                betes = "pets", bete = "pets", pets = "pets", familier = "pets", familiers = "pets", ["bêtes"] = "pets", ["bête"] = "pets", competences = "pets", skills = "pets" }

-- Ouvre la fenêtre sur un onglet (ou la ferme si elle est déjà sur cet onglet).
function ns.uiOpen(name)
  if not ns.api or not ns.api.db() then return end
  local want = (name or ""):lower()
  name = ALIAS[want] or (VALID[name or ""] and name) or "stock"
  if not frame then build() end
  if name == "pets" and not tabs.pets then print("|cffe4b84eGringotts|r L'onglet Bêtes est réservé aux chasseurs."); name = "stock" end
  if name == "pets" and ns.petsUI and (want == "competences" or want == "skills") then ns.petsUI.setView("skills") end
  if name == "gathering" and ns.gatherUI then ns.gatherUI.setView((want == "peche" or want == "fishing") and "fish" or "nodes") end
  if frame:IsShown() and frame.current == name then frame:Hide() return end
  frame:Show(); selectTab(name)
end
function ns.uiToggle(arg) ns.uiOpen(arg) end
-- Affiche la fenêtre sur un onglet sans jamais la fermer
function ns.uiShow(name)
  if not ns.api or not ns.api.db() then return end
  if not frame then build() end
  frame:Show(); selectTab(name or "stock")
end

local lg = CreateFrame("Frame")
lg:RegisterEvent("PLAYER_LOGIN")
lg:SetScript("OnEvent", function()
  C_Timer.After(4, function()
    local o = ns.opt and ns.api and ns.api.db() and ns.opt.ui()
    if o and o.openLogin then ns.uiOpen("stock") end
  end)
end)
