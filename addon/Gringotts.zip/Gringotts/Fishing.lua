-- Gringotts : pêche. Mode pêche détecté (canne équipée), touche unique lancer / ramasser, leurre automatique,
-- journal des prises par zone, classement des zones (Guide 1-300 selon la Cuisine) et des poissons (Journey).
-- Un appui de touche = une action (règle de Blizzard) : la touche est liée à un bouton sécurisé, seulement pendant le mode pêche.
local ADDON, ns = ...
local F = {}
ns.fishing = F

local function db() return ns.api and ns.api.db() end
local function norm(s) return ns.norm(s or "") end
local function flat(s) return (norm(s):gsub("[^%w]", "")) end

local FISHING_SPELL = 7620
-- leurres, du meilleur au plus faible (id d'objet)
local LURES = { 6533, 6811, 7307, 6532, 6530, 6529 }

function F.st()
  local d = db(); if not d then return { zones = {}, hist = {} } end
  d.fish = d.fish or {}
  local s = d.fish
  if s.auto == nil then s.auto = true end
  if s.lure == nil then s.lure = true end
  s.key = s.key or "SPACE"
  s.zones = s.zones or {}
  s.hist = s.hist or {}
  return s
end

local function spellName(id)
  if C_Spell and C_Spell.GetSpellName then local ok, n = pcall(C_Spell.GetSpellName, id); if ok and n then return n end end
  if GetSpellInfo then local ok, n = pcall(GetSpellInfo, id); if ok and n then return n end end
  return "Pêche"
end
local fishName
local function fishSpell() fishName = fishName or spellName(FISHING_SPELL); return fishName end

------------------------------------------------------------------------
-- Détection du mode pêche : canne à pêche équipée (classe 2 = arme, sous-classe 20 = canne à pêche)
------------------------------------------------------------------------
function F.poleEquipped()
  if not GetInventoryItemLink then return false end
  local link = GetInventoryItemLink("player", 16)
  if not link then return false end
  local fn = (C_Item and C_Item.GetItemInfoInstant) or GetItemInfoInstant
  if not fn then return false end
  local ok, _, _, _, _, _, classID, subID = pcall(fn, link)
  return ok and classID == 2 and subID == 20
end

-- zone courante : clé de ns.fishZones si on la reconnaît, sinon "z:Nom"
function F.zoneKey()
  local zr = GetRealZoneText and GetRealZoneText() or ""
  local sub = GetSubZoneText and GetSubZoneText() or ""
  local nz, nsub = norm(zr), norm(sub)
  if nz == "azshara" and nsub:find("baie des tempetes", 1, true) then return "bayofstorms" end
  if nz:find("strangleronce", 1, true) and nsub:find("jaguero", 1, true) then return "stv_jaguero" end
  for k, z in pairs(ns.fishZones or {}) do if norm(z.fr) == nz then return k end end
  return "z:" .. zr
end

local function zoneRec(zk)
  local s = F.st()
  local z = s.zones[zk]
  if not z then z = { casts = 0, catches = 0, items = {}, secs = 0 }; s.zones[zk] = z end
  return z
end

local function priceOf(name)
  if not name or not ns.prices then return nil end
  local d = db()
  local id = d and (d.ids or {})[norm(name)]
  return ns.prices.price(name, id)
end

------------------------------------------------------------------------
-- Session
------------------------------------------------------------------------
F.sess = nil
local function now() return (GetTime and GetTime()) or 0 end

function F.startSession()
  if F.sess then return end
  F.sess = { t0 = now(), tw = time and time() or 0, casts = 0, catches = 0, value = 0, items = {}, zone = F.zoneKey() }
end
function F.endSession()
  local s = F.sess; if not s then return end
  local h = F.st().hist
  if s.catches > 0 or s.casts > 0 then
    table.insert(h, 1, { t = s.tw, secs = math.floor(now() - s.t0), casts = s.casts, catches = s.catches, value = s.value, zone = s.zone })
    while #h > 20 do table.remove(h) end
  end
  -- la session de pêche rejoint l'historique des sessions de farm (« Que farmer ? », or/h, spots), sauf si une session de farm
  -- tourne déjà : elle a capté ces prises elle-même (butin du chat), on ne les compte pas deux fois
  local Gn = ns.gains
  if Gn and Gn.addExternal and s.catches > 0 and not (Gn.current and Gn.current()) then
    local items = {}
    for _, it in pairs(s.items) do items[#items + 1] = { n = it.n, q = it.c } end
    pcall(Gn.addExternal, { t0 = s.tw, t1 = time(), zone = "Pêche · " .. tostring(s.zone or "?"), items = items, fallback = s.value, src = "fish" })
  end
  F.sess = nil
end

function F.info()
  local s = F.sess
  local secs = s and math.max(0, math.floor(now() - s.t0)) or 0
  return { active = s ~= nil, casts = s and s.casts or 0, catches = s and s.catches or 0, value = s and s.value or 0, secs = secs,
           perHour = (s and secs > 60) and math.floor(s.value * 3600 / secs) or nil,
           perCatch = (s and s.catches > 0) and math.floor(secs / s.catches) or nil, items = s and s.items or {} }
end

------------------------------------------------------------------------
-- Touche unique : lancer, ramasser (flotteur sous la souris), appliquer un leurre
------------------------------------------------------------------------
local owner, btn
local function ensureFrames()
  if btn then return true end
  if not CreateFrame then return false end
  owner = CreateFrame("Frame", "GringottsFishOwner", UIParent)
  local ok, b = pcall(CreateFrame, "Button", "GringottsFishBtn", UIParent, "SecureActionButtonTemplate")
  if not ok or not b then return false end
  btn = b
  btn:SetAttribute("type", "macro")
  if btn.RegisterForClicks then pcall(btn.RegisterForClicks, btn, "AnyUp", "AnyDown") end
  return true
end

local function inCombat() return InCombatLockdown and InCombatLockdown() end

function F.lureItem()
  if not GetItemCount then return nil end
  for _, id in ipairs(LURES) do
    local ok, n = pcall(GetItemCount, id)
    if ok and n and n > 0 then return id end
  end
end
-- la canne a-t-elle déjà un leurre actif ?
function F.hasLure()
  if not GetWeaponEnchantInfo then return true end
  local ok, has = pcall(GetWeaponEnchantInfo)
  return ok and has and true or false
end

function F.macro()
  local s = F.st()
  if s.lure and not F.hasLure() then
    local id = F.lureItem()
    if id then return ("/use item:%d\n/use 16"):format(id), "lure" end
  end
  return "/cast " .. fishSpell(), "cast"
end

function F.updateMacro()
  if not ensureFrames() or inCombat() then return end
  local m, kind = F.macro()
  btn:SetAttribute("macrotext", m)
  F.macroKind = kind
end

local bobberMode = false
function F.bind()
  if not ensureFrames() or inCombat() then return end
  if ClearOverrideBindings then pcall(ClearOverrideBindings, owner) end
  if not F.sess then bobberMode = false; return end
  local key = F.st().key
  if bobberMode then
    -- pendant la canalisation : la même touche ramasse le flotteur sous la souris
    pcall(SetOverrideBinding, owner, true, key, "INTERACTMOUSEOVER")
  else
    F.updateMacro()
    pcall(SetOverrideBindingClick, owner, true, key, "GringottsFishBtn")
  end
end

function F.setKey(k)
  if not k or k == "" then return end
  F.st().key = k
  F.bind()
end

function F.sync()
  local s = F.st()
  local want = s.auto ~= false and F.poleEquipped()
  if want and not F.sess then F.startSession()
  elseif not want and F.sess then F.endSession() end
  bobberMode = false
  F.bind()
  if ns.gatherUI and ns.gatherUI.refresh then pcall(ns.gatherUI.refresh) end
end

------------------------------------------------------------------------
-- Journal : prises relevées à l'ouverture du butin de pêche
------------------------------------------------------------------------
function F.recordCatch(name, qty, zk)
  local s = F.sess
  qty = qty or 1
  local z = zoneRec(zk or F.zoneKey())
  local k = norm(name)
  local it = z.items[k]; if not it then it = { n = name, c = 0 }; z.items[k] = it end
  it.c = it.c + qty
  z.catches = z.catches + qty
  if s then
    local p = priceOf(name)
    s.catches = s.catches + qty
    if p then s.value = s.value + p * qty end
    local si = s.items[k]; if not si then si = { n = name, c = 0 }; s.items[k] = si end
    si.c = si.c + qty
  end
end

local function onLoot()
  if not F.sess then return end
  if IsFishingLoot and not IsFishingLoot() then return end
  local zk = F.zoneKey()
  local slotItem = LOOT_SLOT_ITEM or 1
  for i = 1, (GetNumLootItems and GetNumLootItems() or 0) do
    local t = GetLootSlotType and GetLootSlotType(i)
    if t == nil or t == slotItem then
      local _, name, qty = GetLootSlotInfo(i)
      if name then F.recordCatch(name, tonumber(qty) or 1, zk) end
    end
  end
  if ns.gatherUI and ns.gatherUI.refresh then pcall(ns.gatherUI.refresh) end
end

function F.myCount(zk, fish)
  local z = F.st().zones[zk]; if not z then return 0 end
  local n = 0
  for _, nm in ipairs({ fish.fr, fish.en }) do
    if nm then local it = z.items[norm(nm)]; if it then n = n + it.c end end
  end
  return n
end

------------------------------------------------------------------------
-- Planification : quels poissons manquent à la Cuisine, quelles zones, quel débouché
------------------------------------------------------------------------
local function isCooking(prof) local n = norm(prof); return n == "cuisine" or n == "cooking" end

-- Poissons manquants pour le plan de craft Cuisine : { [index fishDB] = manque }
function F.needs()
  local out, K = {}, ns.crafts
  if not (K and K.cache and K.plan and ns.engine and ns.engine.stockMap) then return out end
  local plan, stock, need = K.plan(), ns.engine.stockMap(), {}
  for _, e in ipairs(K.cache) do
    local n = plan[e.key]
    if n and n > 0 and isCooking(e.prof) then
      for _, rg in ipairs(e.reag) do need[flat(rg[1])] = (need[flat(rg[1])] or 0) + rg[2] * n end
    end
  end
  for i, fish in ipairs(ns.fishDB or {}) do
    local k = fish.fr and flat(fish.fr) or nil
    local ke = flat(fish.en)
    local total = (k and need[k]) or need[ke]
    if total then
      local have = (fish.fr and stock[norm(fish.fr)]) or stock[norm(fish.en)] or 0
      if total - have > 0 then out[i] = total - have end
    end
  end
  return out
end

-- poisson utile à la Cuisine : sert à une recette de niveau >= ton skill
local function cookLevelOf(fish)
  local n = fish.use and fish.use:match("Cuisine%s+(%d+)")
  return n and tonumber(n) or nil
end

local function hitsOf(fish, zk)
  local z, base = fish.zones or {}, 0
  if type(z[zk]) == "number" then
    -- part de ce poisson pêchée dans la zone (0-100) : les effectifs bruts de Wowhead ne sont pas comparables d'un poisson à l'autre
    local tot = fish._tot
    if not tot then tot = 0; for _, v in pairs(z) do if type(v) == "number" then tot = tot + v end end; fish._tot = tot end
    base = tot > 0 and (z[zk] * 100 / tot) or 0
  else for _, k in ipairs(z) do if k == zk then base = 5 end end end   -- page Forever non relue : poids faible
  local mine = F.myCount(zk, fish)
  return base + mine * 5, base, mine
end
F.hitsOf = hitsOf

function F.fishName(fish) return fish.fr or fish.en end

-- Classement des zones pour le Guide 1-300 (priorité aux poissons de la montée Cuisine)
function F.guideZones()
  local skill = ns.skillOf("fish")
  local cook = ns.skillOf("cook")
  local needs = F.needs()
  local hasNeeds = next(needs) ~= nil
  local rows = {}
  for zk, zinfo in pairs(ns.fishZones or {}) do
    local score, list, covered = 0, {}, {}
    for i, fish in ipairs(ns.fishDB or {}) do
      local cl = cookLevelOf(fish)
      local w = 0
      if needs[i] then w = 3 elseif cl and cl >= cook and cook < 300 and not hasNeeds then w = 1 end
      if w > 0 then
        local h = hitsOf(fish, zk)
        if h > 0 then
          score = score + h * w
          list[#list + 1] = { fish = fish, hits = h, need = needs[i] }
          if needs[i] then covered[#covered + 1] = fish end
        end
      end
    end
    if score > 0 then
      table.sort(list, function(a, b) return a.hits > b.hits end)
      rows[#rows + 1] = { key = zk, name = zinfo.fr, req = zinfo.req, ok = skill >= zinfo.req, miss = math.max(0, zinfo.req - skill),
                          score = score, fishes = list, covered = covered, mine = (F.st().zones[zk] and F.st().zones[zk].catches) or 0 }
    end
  end
  table.sort(rows, function(a, b)
    if a.ok ~= b.ok then return a.ok end
    if a.score ~= b.score then return a.score > b.score end
    return a.name < b.name
  end)
  local bestOk
  for _, r in ipairs(rows) do if r.ok and not bestOk then bestOk = r end end
  for _, r in ipairs(rows) do
    if r == bestOk then r.verdict = "Maintenant · n°1"
    elseif r.ok then r.verdict = "Possible"
    elseif bestOk and r.score > bestOk.score then r.verdict = ("Dès %d · gros volume"):format(r.req)
    elseif r.req - skill > 60 then r.verdict = "Plus tard"
    else r.verdict = ("Dès %d"):format(r.req) end
  end
  -- prochain palier de skill de pêche (plus petit prérequis de zone intéressante au-dessus du skill)
  local nextReq
  for _, r in ipairs(rows) do if not r.ok and (not nextReq or r.req < nextReq) then nextReq = r.req end end
  local nextZone
  for _, r in ipairs(rows) do if r.req == nextReq and (not nextZone or r.score > nextZone.score) then nextZone = r end end
  return rows, { skill = skill, cook = cook, needs = needs, hasNeeds = hasNeeds, best = bestOk, nextReq = nextReq, nextZone = nextZone }
end

-- Journey : poissons classés par valeur (prix HV net de commission ou valeur du craft connu)
function F.journey()
  local K, fee = ns.crafts, (ns.engine and ns.engine.cfg and ns.engine.cfg().fee) or 0.05
  local rows = {}
  for _, fish in ipairs(ns.fishDB or {}) do
    local name = F.fishName(fish)
    local p = priceOf(name)
    local net = p and math.floor(p * (1 - fee)) or nil
    local craft, craftWhat
    if K and K.cache then
      for _, e in ipairs(K.cache) do
        if e.learned and e.outPrice and not e.unpriced then
          for _, rg in ipairs(e.reag) do
            if flat(rg[1]) == flat(name) or (fish.en and flat(rg[1]) == flat(fish.en)) then
              local need = math.max(rg[2], 1)
              local val = (e.q * e.outPrice * (1 - fee) - (e.cost - (p or 0) * need)) / need
              if val > 0 and (not craft or val > craft) then craft, craftWhat = math.floor(val), e.prof end
            end
          end
        end
      end
    end
    local best, kind = net, "HV direct"
    if craft and (not net or craft > net) then best, kind = craft, craftWhat end
    -- zones : les meilleures par nombre de prises
    local zs = {}
    for zk, zinfo in pairs(ns.fishZones or {}) do
      local h = hitsOf(fish, zk)
      if h > 0 then zs[#zs + 1] = { key = zk, name = zinfo.fr, hits = h, req = zinfo.req } end
    end
    table.sort(zs, function(a, b) return a.hits > b.hits end)
    rows[#rows + 1] = { fish = fish, name = name, price = p, net = net, craft = craft, best = best, kind = kind, zones = zs, classic = fish.src ~= "forever" }
  end
  table.sort(rows, function(a, b)
    if (a.best ~= nil) ~= (b.best ~= nil) then return a.best ~= nil end
    if a.best ~= b.best then return (a.best or 0) > (b.best or 0) end
    return a.name < b.name
  end)
  return rows
end

-- Guide tant que la Cuisine monte, Journey ensuite (ou sans Cuisine)
function F.view()
  local cook = ns.skillOf("cook")
  if cook <= 0 or cook >= 300 then return "journey" end
  return "guide"
end

------------------------------------------------------------------------
-- Événements
------------------------------------------------------------------------
local ev = CreateFrame("Frame")
for _, e in ipairs({ "PLAYER_ENTERING_WORLD", "PLAYER_EQUIPMENT_CHANGED", "UNIT_INVENTORY_CHANGED", "LOOT_OPENED",
  "UNIT_SPELLCAST_CHANNEL_START", "UNIT_SPELLCAST_CHANNEL_STOP", "BAG_UPDATE_DELAYED", "PLAYER_REGEN_ENABLED" }) do pcall(ev.RegisterEvent, ev, e) end
ev:SetScript("OnEvent", function(_, e, unit, _, spellID)
  if not db() then return end
  if e == "UNIT_INVENTORY_CHANGED" and unit ~= "player" then return end
  if e == "PLAYER_ENTERING_WORLD" or e == "PLAYER_EQUIPMENT_CHANGED" or e == "UNIT_INVENTORY_CHANGED" then
    if C_Timer and C_Timer.After then C_Timer.After(0.3, F.sync) else F.sync() end
  elseif e == "LOOT_OPENED" then onLoot()
  elseif e == "UNIT_SPELLCAST_CHANNEL_START" then
    if unit == "player" and F.sess and spellName(spellID) == fishSpell() then
      F.sess.casts = F.sess.casts + 1
      zoneRec(F.zoneKey()).casts = zoneRec(F.zoneKey()).casts + 1
      bobberMode = true; F.bind()
    end
  elseif e == "UNIT_SPELLCAST_CHANNEL_STOP" then
    if unit == "player" and F.sess then bobberMode = false; F.bind() end
  elseif e == "BAG_UPDATE_DELAYED" or e == "PLAYER_REGEN_ENABLED" then
    if F.sess then F.bind() end
  end
end)

-- gardes : une erreur est journalisée (/gt erreurs) au lieu d'ouvrir le popup de Blizzard
if ns.safe then ev:SetScript("OnEvent", ns.safe(ev:GetScript("OnEvent"), "pêche")) end
