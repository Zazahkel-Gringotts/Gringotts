-- Gringotts : identifiants d'objets manquants. /gt ids liste les objets du fichier de prix sans identifiant ;
-- /gt ids ajouter [lien] associe le nom de l'objet au lien (Maj + clic) : l'addon l'utilise tout de suite (prix HV, prix PNJ).
local ADDON, ns = ...
local function say(m) print("|cffe4b84eGringotts|r " .. m) end

local function missing()
  local d = ns.api and ns.api.db and ns.api.db()
  local out = {}
  local gp = GringottsPrices
  if type(gp) ~= "table" or type(gp.items) ~= "table" or not d then return out end
  d.ids = d.ids or {}
  for k, r in pairs(gp.items) do
    local id = r.id
    if (not id or id == 0) and not d.ids[k] then
      local n = r.n or k
      local low = ns.norm and ns.norm(n) or n:lower()
      if not low:find("^transmutation") then out[#out + 1] = n end
    end
  end
  table.sort(out)
  return out
end

function ns.idsCmd(arg)
  arg = (arg or ""):gsub("^%s+", "")
  local d = ns.api and ns.api.db and ns.api.db()
  if not d then say("Base non prête."); return end
  if arg:match("^ajouter") or arg:match("^add") then
    local id = tonumber(arg:match("item:(%d+)"))
    if not id then say("Fais Maj + clic sur l'objet dans le chat ou un sac : /gt ids ajouter [lien]"); return end
    local name = (C_Item and C_Item.GetItemNameByID and C_Item.GetItemNameByID(id)) or (GetItemInfo and (GetItemInfo(id)))
    if not name then say("Nom de l'objet pas encore chargé : réessaie dans un instant."); return end
    d.ids = d.ids or {}
    d.ids[ns.norm and ns.norm(name) or name:lower()] = id
    say(("Identifiant enregistré : %s = %d."):format(name, id))
    return
  end
  local list = missing()
  if #list == 0 then say("Aucun objet sans identifiant dans le fichier de prix."); return end
  say(("%d objet(s) sans identifiant : %s"):format(#list, table.concat(list, ", ")))
  say("Maj + clic sur l'objet puis /gt ids ajouter [lien] pour l'enregistrer.")
end
