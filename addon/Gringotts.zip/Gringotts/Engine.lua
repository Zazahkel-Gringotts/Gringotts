-- Gringotts : moteur de décision en jeu (stock, statut achat/vente, liste d'achats, finances).
-- Aucune interface ici : tout est testable hors du jeu. Les prix viennent de HVPrices.lua (ns.prices) et d'Auctionator.
local ADDON, ns = ...
local E = {}
ns.engine = E

local DAY = 86400
local function A() return ns.api end
local function db() return A().db() end

-- Réglages (Options) : seuil de vente, achat spéculatif
function E.cfg()
  local d = db(); d.set = d.set or {}
  local s = d.set
  if s.sellGap == nil then s.sellGap = 0.10 end      -- vendre quand le prix dépasse la médiane 30 j de 10 %
  if s.spec == nil then s.spec = false end           -- achat spéculatif désactivé par défaut
  if s.specGap == nil then s.specGap = 0.20 end      -- ... acheter 20 % sous la médiane
  if s.specQty == nil then s.specQty = 20 end
  if s.fee == nil then s.fee = 0.05 end              -- commission de l'HV (5 %)
  if s.floorPct == nil then s.floorPct = 0.85 end    -- plancher de vente : 85 % de la médiane 30 j
  if s.spikeX == nil then s.spikeX = 3 end           -- prix « anormal » : x3 la médiane (ou /3)
  if s.minHist == nil then s.minHist = 7 end
  if s.snipeGap == nil then s.snipeGap = 0.30 end         -- Sniper : 30 % sous la médiane
  if s.snipeMinGain == nil then s.snipeMinGain = 500 end  -- ... et au moins 5 argent de gain net par unité
  if s.snipeMargin == nil then s.snipeMargin = 0.05 end   -- marge de prix tolérée au moment de l'achat
  if s.snipeOneClick == nil then s.snipeOneClick = true end
  if s.snipeOdd == nil then s.snipeOdd = true end
  if s.craftMinProfit == nil then s.craftMinProfit = 10000 end   -- craft rentable : 1 g de profit minimum
  if s.craftMinMargin == nil then s.craftMinMargin = 0.10 end
  if s.bulkQty == nil then s.bulkQty = 20 end            -- quantité par objet pour un achat groupé sans cible
  if s.sellDuration == nil then s.sellDuration = 2 end   -- 1 = 12 h, 2 = 24 h, 3 = 48 h         -- jours d'historique minimum pour se fier à la médiane
  return s
end

local function sameRealm(c) return c.realm == A().realm() and c.faction == A().faction() end

-- Stock par clé normalisée : persos du royaume/faction (sacs + banque) et banques de guilde
function E.stockMap()
  local m = {}
  for _, c in pairs(db().chars or {}) do
    if sameRealm(c) then
      for k, n in pairs(c.bags or {}) do m[k] = (m[k] or 0) + n end
      for k, n in pairs(c.bank or {}) do m[k] = (m[k] or 0) + n end
    end
  end
  for _, G in pairs(db().guilds or {}) do
    if sameRealm(G) then
      for _, tb in pairs(G.tabs or {}) do for k, n in pairs(tb.c or {}) do m[k] = (m[k] or 0) + n end end
    end
  end
  return m
end

-- Détail par perso pour un objet : { {name=, bags=, bank=}, ... , guild = n }
function E.stockBy(k)
  local out, guild = {}, 0
  for _, c in pairs(db().chars or {}) do
    if sameRealm(c) then
      local b, bk = (c.bags or {})[k] or 0, (c.bank or {})[k] or 0
      if b + bk > 0 then out[#out + 1] = { name = c.name or "?", bags = b, bank = bk } end
    end
  end
  for _, G in pairs(db().guilds or {}) do
    if sameRealm(G) then for _, tb in pairs(G.tabs or {}) do guild = guild + ((tb.c or {})[k] or 0) end end
  end
  table.sort(out, function(a, b) return a.bags + a.bank > b.bags + b.bank end)
  return out, guild
end

-- Cible issue des recettes apprises (branchée par l'onglet Métiers) ; 0 tant qu'aucune recette n'est connue
E.demand = function(k) return 0 end

local STATUS_ORDER = { buy = 1, sell = 2, odd = 3, wait = 4, noprice = 5 }
E.STATUS_ORDER = STATUS_ORDER

function E.evaluate(k, name, id, stock)
  local P, d, s = ns.prices, db(), E.cfg()
  local price, src, age = P.price(name, id)
  local rec = P.rec(name)
  local med = P.median(name)
  if med and rec and (rec.h or 0) < s.minHist then med = nil end      -- historique trop court : pas de médiane fiable
  local gap = (price and med) and (price / med - 1) or nil
  local manual = d.targets and d.targets[k]
  local target = math.max(manual or 0, E.demand(k) or 0)
  local toBuy = math.max(0, target - stock)
  -- Vente : prix conseillé (1 copper sous le marché, jamais sous le plancher), net après commission
  local floorP = med and math.floor(med * s.floorPct) or nil
  local sellAt, netUnit, belowFloor
  if price then
    sellAt = math.max(price - 1, 1)
    if floorP and sellAt < floorP then belowFloor = true; sellAt = floorP end
    netUnit = math.floor(sellAt * (1 - s.fee))
  end
  local ratio = (price and med and med > 0) and price / med or nil
  local odd = ratio and (ratio >= s.spikeX or ratio <= 1 / s.spikeX) or false
  local status, why = "wait", ""
  if not price then
    status, why = "noprice", "pas de prix"
  elseif odd then
    status = "odd"
    why = ratio >= s.spikeX and "pic probable : trop peu d'offres ou prix isolé, vérifie l'HV avant de vendre"
                              or "creux probable : annonce isolée ou erreur de prix, vérifie l'HV avant d'acheter"
  elseif stock > target and gap and gap >= s.sellGap then
    status, why = "sell", (target > 0) and "excédent au-dessus de la médiane" or "au-dessus de la médiane"
  elseif toBuy > 0 then
    if med and price > med then status, why = "wait", "trop cher (au-dessus de la médiane)"
    else status, why = "buy", (manual and manual >= (E.demand(k) or 0)) and "sous ta cible" or "pour tes recettes" end
  elseif s.spec and gap and gap <= -s.specGap then
    status, why, toBuy = "buy", "sous la médiane", s.specQty
  end
  -- Gain estimé à la revente de l'achat (médiane nette de commission moins le prix payé)
  local resaleNet = med and math.floor(med * (1 - s.fee)) or nil
  local profit = (status == "buy" and resaleNet and price) and (resaleNet - price) or nil
  return { k = k, name = name, id = id, stock = stock, price = price, src = src, age = age, med = med, gap = gap, ratio = ratio,
           target = target, manual = manual, toBuy = toBuy, status = status, why = why,
           best = P.bestDay(name, d.minWeeks or 3), sellAt = sellAt, netUnit = netUnit, belowFloor = belowFloor, floor = floorP,
           sellQty = math.max(0, stock - target), netTotal = (netUnit and stock > target) and netUnit * (stock - target) or nil, resaleNet = resaleNet, profit = profit }
end

-- Tous les objets connus : fichier de prix, objets suivis, objets en stock
function E.items()
  local P, A_ = ns.prices, A()
  local stock = E.stockMap()
  local seen, out = {}, {}
  local function add(k, name, id)
    if seen[k] then return end
    seen[k] = true
    out[#out + 1] = E.evaluate(k, name, id, stock[k] or 0)
  end
  local gp = GringottsPrices
  if type(gp) == "table" and type(gp.items) == "table" then
    for k, r in pairs(gp.items) do add(k, r.n or k, r.id ~= 0 and r.id or (db().ids or {})[k]) end
  end
  for k in pairs(A_.tracked or {}) do add(k, (A_.trackedName or {})[k] or k, (db().ids or {})[k]) end
  for k in pairs(stock) do add(k, (A_.trackedName or {})[k] or k, (db().ids or {})[k]) end
  return out
end

-- Tri par urgence : écart absolu à la médiane, puis nom
function E.sortUrgency(list)
  table.sort(list, function(a, b)
    local ga, gb = math.abs(a.gap or 0), math.abs(b.gap or 0)
    if ga ~= gb then return ga > gb end
    return a.name < b.name
  end)
end

function E.summary(items)
  local t = { buy = 0, sell = 0, odd = 0, wait = 0, noprice = 0, value = 0, net = 0 }
  for _, it in ipairs(items) do
    t[it.status] = t[it.status] + 1
    if it.price and it.stock > 0 then t.value = t.value + it.price * it.stock end
    if it.status == "sell" and it.netTotal then t.net = t.net + it.netTotal end
  end
  return t
end

------------------------------------------------------------------------
-- Liste d'achats (db.shop = { [clé] = quantité }) et envoi à Auctionator
------------------------------------------------------------------------
function E.shop() local d = db(); d.shop = d.shop or {}; return d.shop end
function E.addShop(k, qty) qty = math.floor(tonumber(qty) or 0); if qty <= 0 then return end; local s = E.shop(); s[k] = (s[k] or 0) + qty end
function E.setShop(k, qty) qty = math.floor(tonumber(qty) or 0); local s = E.shop(); s[k] = qty > 0 and qty or nil end
function E.clearShop() db().shop = {} end
function E.shopList(items)
  local by = {}; for _, it in ipairs(items) do by[it.k] = it end
  local out, total = {}, 0
  for k, q in pairs(E.shop()) do
    local it = by[k]
    local name = it and it.name or ((A().trackedName or {})[k] or k)
    local price = it and it.price
    out[#out + 1] = { k = k, name = name, qty = q, price = price, max = it and it.med, cost = price and price * q or nil }
    if price then total = total + price * q end
  end
  table.sort(out, function(a, b) return a.name < b.name end)
  return out, total
end

function E.sendShop(items)
  local api = Auctionator and Auctionator.API and Auctionator.API.v1
  if not api or not api.CreateShoppingList then return nil, "Auctionator introuvable" end
  local list = E.shopList(items)
  if #list == 0 then return nil, "liste vide" end
  local terms = {}
  for _, e in ipairs(list) do
    local term
    if api.ConvertToSearchString then
      local ok, t = pcall(api.ConvertToSearchString, "Gringotts", { searchString = e.name, isExact = true, maxPrice = e.max, quantity = e.qty })
      if ok and type(t) == "string" then term = t end
    end
    terms[#terms + 1] = term or ('"' .. e.name .. '"')
  end
  local ok, err = pcall(api.CreateShoppingList, "Gringotts", "Gringotts - Achats", terms)
  if not ok then return nil, tostring(err) end
  return #terms
end

------------------------------------------------------------------------
-- Finances : or par personnage et total sur N jours (valeur reportée quand un jour manque)
------------------------------------------------------------------------
local function dayStr(offset) return date("%Y-%m-%d", time() - offset * DAY) end

function E.gold(days)
  days = days or 30
  local who = {}
  for _, c in pairs(db().chars or {}) do
    if sameRealm(c) then who[#who + 1] = { name = c.name or "?", days = c.goldDays or {}, now = c.gold } end
  end
  for _, G in pairs(db().guilds or {}) do
    if sameRealm(G) and G.goldDays then who[#who + 1] = { name = "Banque de guilde", days = G.goldDays, now = G.gold } end
  end
  local dates = {}
  for i = days - 1, 0, -1 do dates[#dates + 1] = dayStr(i) end
  local total = {}
  for i = 1, #dates do total[i] = 0 end
  local byChar = {}
  for _, w in ipairs(who) do
    local keys = {}
    for d in pairs(w.days) do keys[#keys + 1] = d end
    table.sort(keys)
    local last, ki, series = nil, 1, {}
    for i, d in ipairs(dates) do
      while keys[ki] and keys[ki] <= d do last = w.days[keys[ki]]; ki = ki + 1 end
      series[i] = last or 0
      total[i] = total[i] + series[i]
    end
    byChar[#byChar + 1] = { name = w.name, now = series[#series], series = series }
  end
  table.sort(byChar, function(a, b) return a.now > b.now end)
  return { dates = dates, total = total, byChar = byChar }
end

------------------------------------------------------------------------
-- Sniper : bonnes affaires d'après un scan Auctionator du jour
------------------------------------------------------------------------
function E.snipeMaxUnit(it)
  local s = E.cfg()
  local m = math.floor(it.price * (1 + s.snipeMargin))
  if it.resaleNet then m = math.min(m, it.resaleNet - s.snipeMinGain) end
  if it.med and it.med > 0 then m = math.min(m, it.med) end
  return math.max(m, it.price)
end

function E.snipe(items)
  local s, out = E.cfg(), {}
  for _, it in ipairs(items) do
    if it.price and it.src == "ah" and it.age and it.age < 1 and it.gap and it.gap <= -s.snipeGap and it.resaleNet then
      local gain = it.resaleNet - it.price
      local low = it.status == "odd"
      if gain >= s.snipeMinGain and (not low or s.snipeOdd) then
        it.gain, it.lowOdd = gain, low
        out[#out + 1] = it
      end
    end
  end
  table.sort(out, function(a, b) if a.gain ~= b.gain then return a.gain > b.gain end return a.name < b.name end)
  return out
end

-- Nombre d'objets relevés par Auctionator aujourd'hui (indique si un scan récent existe)
function E.freshCount(items)
  local n = 0
  for _, it in ipairs(items) do if it.src == "ah" and it.age and it.age < 1 then n = n + 1 end end
  return n
end
