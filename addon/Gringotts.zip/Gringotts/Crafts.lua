-- Gringotts : métiers. Rentabilité des recettes apprises (tous les personnages), montée de niveau, plan de craft, file de crafts.
local ADDON, ns = ...
local K = {}
ns.crafts = K

local function db() return ns.api and ns.api.db() end
local function E() return ns.engine end
local function norm(s) return ns.api.norm(s) end

-- difficulté Blizzard : 0 orange, 1 jaune, 2 vert, 3 gris
K.DIFF = { [0] = "orange", [1] = "jaune", [2] = "vert", [3] = "gris" }

local function priceOf(name)
  if not name then return nil end
  local id = (db().ids or {})[norm(name)]
  local p = ns.prices.price(name, id)
  return p, id
end

-- Liste de toutes les recettes vues : apprises (e.learned, avec qui les sait) ou non (e.src = comment les obtenir)
function K.recipes()
  local d, by = db(), {}
  local order = {}
  for _, c in pairs(d.chars or {}) do
    for prof, r in pairs(c.recipes or {}) do
      for _, x in ipairs(r.all or {}) do
        local key = prof .. ":" .. x.n
        local e = by[key]
        if not e then
          e = { key = key, prof = prof, name = x.n, out = x.o, q = x.q or 1, reag = x.r or {}, who = {}, id = x.i, learned = false, dUnknown = x.d }
          by[key] = e; order[#order + 1] = e
        end
        if x.l == 1 then e.learned = true; e.who[c.name] = { d = x.d, id = x.i } end
        if x.s and not e.src then e.src = x.s end
        if x.d and (e.dUnknown == nil or x.d < e.dUnknown) then e.dUnknown = x.d end
      end
    end
  end
  return order
end

-- Calcule coût, vente nette, profit, faisables pour une recette
function K.evaluate(e, stock)
  local s = E().cfg()
  local cost, missingCost, unpriced = 0, 0, false
  local lines, craftable = {}, math.huge
  for _, rg in ipairs(e.reag) do
    local name, need = rg[1], rg[2]
    local p, id = priceOf(name)
    local have = stock[norm(name)] or 0
    local miss = math.max(0, need - have)
    if not p then unpriced = true end
    cost = cost + (p or 0) * need
    missingCost = missingCost + (p or 0) * miss
    craftable = math.min(craftable, math.floor(have / math.max(need, 1)))
    lines[#lines + 1] = { name = name, id = id, need = need, have = have, miss = miss, price = p }
  end
  if craftable == math.huge then craftable = 0 end
  local op = priceOf(e.out)
  local net = op and math.floor(op * e.q * (1 - s.fee)) or nil
  local profit = (net and not unpriced) and (net - cost) or nil
  local margin = (profit and cost > 0) and profit / cost or nil
  e.lines, e.cost, e.net, e.profit, e.margin, e.craftable, e.outPrice = lines, cost, net, profit, margin, craftable, op
  e.missingCost = missingCost
  -- meilleure difficulté parmi ceux qui la connaissent
  local bestD
  for _, w in pairs(e.who) do if w.d and (bestD == nil or w.d < bestD) then bestD = w.d end end
  e.d = bestD or e.dUnknown
  e.unpriced = unpriced
  if not e.learned then e.status = "learn"
  elseif not profit then e.status = "noprice"
  elseif profit >= s.craftMinProfit and (margin or 0) >= s.craftMinMargin then e.status = craftable > 0 and "go" or "buy"
  else e.status = "no" end
  return e
end

K.cache = {}
function K.refresh()
  local stock = E().stockMap()
  K.cache = {}
  for _, e in ipairs(K.recipes()) do K.cache[#K.cache + 1] = K.evaluate(e, stock) end
  return K.cache
end

function K.professions()
  local seen, out = {}, {}
  for _, e in ipairs(K.cache) do if not seen[e.prof] then seen[e.prof] = true; out[#out + 1] = e.prof end end
  table.sort(out)
  return out
end

-- Montée de niveau : orange/jaune (apprises ou non), classées par coût par point de compétence attendu
K.CHANCE = { [0] = 1.0, [1] = 0.5 }
function K.perPoint(e) return e.cost / (K.CHANCE[e.d or 1] or 0.5) end
function K.levelList(prof)
  local out = {}
  for _, e in ipairs(K.cache) do
    if e.prof == prof and e.d and e.d <= 1 then out[#out + 1] = e end
  end
  table.sort(out, function(a, b)
    if a.unpriced ~= b.unpriced then return not a.unpriced end
    return K.perPoint(a) < K.perPoint(b)
  end)
  return out
end

-- Étape de montée : cible N points ; remplit le plan avec la recette connue la moins chère par point
function K.levelStep(prof, points)
  points = math.max(1, math.floor(tonumber(points) or 10))
  local best, learn
  for _, e in ipairs(K.levelList(prof)) do
    if not e.unpriced then
      if e.learned and not best then best = e end
      if not e.learned and not learn then learn = e end
    end
  end
  local info = { points = points }
  if best then
    local n = math.ceil(points / (K.CHANCE[best.d or 1] or 0.5))
    K.setPlan(best.key, (K.plan()[best.key] or 0) + n)
    info.recipe, info.n, info.cost = best, n, best.cost * n
  end
  if learn and (not best or K.perPoint(learn) < K.perPoint(best) * 0.8) then info.learn = learn end
  K.lastStep = info
  return info
end

------------------------------------------------------------------------
-- Guide 1-300 (LevelGuides.lua) : étapes par tranche de compétence, coût HV par point, génération du plan
------------------------------------------------------------------------
local GK = { forge = "blac", blacksmithing = "blac", ingenierie = "eng", engineering = "eng",
             couture = "tail", tailoring = "tail", ["travail du cuir"] = "lthr", leatherworking = "lthr",
             cuisine = "cook", cooking = "cook" }
local function flat(s) return (norm(s or ""):gsub("[^%w]", "")) end
function K.guideKey(prof) return prof and GK[norm(prof)] or nil end
function K.guide(prof)
  local k = K.guideKey(prof)
  return k and ns.levelGuides and ns.levelGuides[k] or nil
end
function K.skillOf(prof)
  local mx = 0
  for _, c in pairs(db().chars or {}) do
    local s = (c.skills or {})[prof]
    if s and s.l and s.l > mx then mx = s.l end
  end
  return mx
end

-- Étapes du guide pour un métier, avec état (done / cur), coût des composants au prix HV (pour les crafts restants),
-- coût par point, recette correspondante si elle a été vue en jeu. Renvoie nil si pas de guide.
function K.guideSteps(prof)
  local g = K.guide(prof); if not g then return nil end
  local lvl = K.skillOf(prof)
  local byName = {}
  for _, e in ipairs(K.cache) do if e.prof == prof then byName[flat(e.name)] = e end end
  local out = {}
  for i, s in ipairs(g) do
    local done = lvl >= s.b
    local left = s.c
    if done then left = 0 elseif lvl > s.a then left = math.max(1, math.ceil(s.c * (s.b - lvl) / (s.b - s.a))) end
    local share = (left > 0 and s.c > 0) and left / s.c or 1
    local cost, unp = 0, 0
    for _, m in ipairs(s.m or {}) do
      local p = priceOf(m[1])
      if p then cost = cost + p * m[2] * share else unp = unp + 1 end
    end
    local pts = math.max(1, s.b - math.max(s.a, math.min(lvl, s.b)))
    if done then pts = math.max(1, s.b - s.a) end
    out[#out + 1] = { i = i, key = "g" .. i, step = true, s = s, done = done, left = left, cost = cost, unpriced = unp,
                      perPoint = cost / pts, recipe = byName[flat(s.n)] }
  end
  for _, x in ipairs(out) do if not x.done and not x.s.par then x.cur = true; break end end
  return out, lvl
end

-- Package 1-300 : tous les matériaux du guide (étapes parallèles exclues), au prix HV, avec le total ; sert une fois le 300 atteint
-- (ou à tout moment via K.package) à savoir quoi acheter et pour combien afin de monter 1 -> 300 / revendre le lot complet.
function K.package(prof)
  local g = K.guide(prof); if not g then return nil end
  local acc, order, nrec = {}, {}, 0
  local rec = {}
  for _, s in ipairs(g) do
    if not s.par then
      if s.src == "v" or s.src == "f" then nrec = nrec + 1; rec[#rec + 1] = s end
      for _, m in ipairs(s.m or {}) do
        local k = norm(m[1])
        local a = acc[k]
        if not a then a = { key = "p" .. k, pkg = true, name = m[1], qty = 0, uses = {} }; acc[k] = a; order[#order + 1] = a end
        a.qty = a.qty + m[2]
        a.uses[#a.uses + 1] = { n = s.n, a = s.a, b = s.b, q = m[2] }
      end
    end
  end
  local stock = ns.engine.stockMap()
  local total, unp = 0, 0
  for _, a in ipairs(order) do
    local p = priceOf(a.name)
    a.price = p
    a.total = p and p * a.qty or nil
    a.have = stock[norm(a.name)] or 0
    a.miss = math.max(0, a.qty - a.have)
    if p then total = total + a.total else unp = unp + 1 end
  end
  table.sort(order, function(x, y)
    if (x.total ~= nil) ~= (y.total ~= nil) then return x.total ~= nil end
    if x.total ~= y.total then return (x.total or 0) > (y.total or 0) end
    return x.name < y.name
  end)
  return { items = order, total = total, unpriced = unp, recipes = rec, nrec = nrec }
end

-- Plan : ajoute au plan de craft les crafts restants des étapes dont la recette est apprise ; liste le reste.
-- Régénérer remplace ce que la génération précédente avait ajouté (le plan manuel n'est pas touché).
function K.guideGen(prof)
  local steps, lvl = K.guideSteps(prof)
  local d = db()
  d.guideAdded = d.guideAdded or {}
  local p = K.plan()
  for key, n in pairs(d.guideAdded[prof] or {}) do
    local v = (p[key] or 0) - n
    p[key] = v > 0 and v or nil
  end
  local info = { planned = 0, crafts = 0, learn = {}, find = {}, cost = 0, unpriced = 0, lvl = lvl or 0 }
  local add = {}
  for _, x in ipairs(steps or {}) do
    if not x.done and not x.s.par then
      info.cost = info.cost + x.cost
      info.unpriced = info.unpriced + x.unpriced
      local e = x.recipe
      if e and e.learned then
        add[e.key] = (add[e.key] or 0) + x.left
        info.planned, info.crafts = info.planned + 1, info.crafts + x.left
      elseif x.s.src == "f" then info.find[#info.find + 1] = x
      elseif x.s.src == "v" or (e and not e.learned) then info.learn[#info.learn + 1] = x end
    end
  end
  for key, n in pairs(add) do p[key] = (p[key] or 0) + n end
  d.guideAdded[prof] = add
  K.demand = nil
  ns.listDirty = true
  K.lastGuide = info
  return info
end

function K.profitList(prof)
  local out = {}
  for _, e in ipairs(K.cache) do if e.prof == prof and e.learned then out[#out + 1] = e end end
  local rank = { go = 1, buy = 2, no = 3, noprice = 4 }
  table.sort(out, function(a, b)
    if rank[a.status] ~= rank[b.status] then return rank[a.status] < rank[b.status] end
    return (a.profit or -1e12) > (b.profit or -1e12)
  end)
  return out
end

------------------------------------------------------------------------
-- Plan de craft : quantités voulues ; alimente les cibles de stock des composants
------------------------------------------------------------------------
function K.plan() local d = db(); d.craftPlan = d.craftPlan or {}; return d.craftPlan end
function K.setPlan(key, n)
  local p = K.plan(); n = math.floor(tonumber(n) or 0)
  p[key] = n > 0 and n or nil
  K.demand = nil
  ns.listDirty = true
end
function K.demandMap()
  if K.demand then return K.demand end
  local m = {}
  for key, n in pairs(K.plan()) do
    for _, e in ipairs(K.cache) do
      if e.key == key then for _, rg in ipairs(e.reag) do local k = norm(rg[1]); m[k] = (m[k] or 0) + rg[2] * n end end
    end
  end
  K.demand = m
  return m
end
ns.engine.demand = function(k) return K.demandMap()[k] or 0 end

------------------------------------------------------------------------
-- Lancer un craft : demande un clic réel ; la fenêtre du métier doit être ouverte sur le bon métier
------------------------------------------------------------------------
function K.available() return C_TradeSkillUI and C_TradeSkillUI.CraftRecipe and true or false end
function K.openProf()
  local T = C_TradeSkillUI
  if not (T and T.GetBaseProfessionInfo) then return nil end
  local ok, b = pcall(T.GetBaseProfessionInfo)
  return ok and b and b.professionName or nil
end
function K.me() return UnitName and UnitName("player") or nil end
function K.canCraft(e)
  if not e.learned then return false, "Recette non apprise : " .. (e.src or "source inconnue") end
  if not K.available() then return false, "API de craft indisponible" end
  local me = K.me()
  local w = me and e.who[me]
  if not w then
    local names = {}
    for n in pairs(e.who) do names[#names + 1] = n end
    table.sort(names)
    return false, "Recette connue de : " .. table.concat(names, ", ")
  end
  if not w.id then return false, "Ouvre la fenêtre du métier une fois (id de recette inconnu)" end
  -- fenêtre du métier fermée ou sur un autre métier : elle sera ouverte en arrière-plan (invisible) par K.craft
  return true, K.openProf() ~= e.prof
end

-- Ouvre la fenêtre du métier sans l'afficher (alpha 0), comme pour l'HV. Un clic réel (bouton, Espace) est requis par Blizzard.
local function profFrame() return _G.ProfessionsFrame or _G.TradeSkillFrame end
function K.hideProfFrame()
  local f = profFrame()
  if f and K.ours then pcall(f.SetAlpha, f, 0); pcall(f.EnableMouse, f, false) end
end
function K.showProfFrame()
  local f = profFrame()
  if f then pcall(f.SetAlpha, f, 1); pcall(f.EnableMouse, f, true) end
  K.ours = false
end
function K.openProfBg(prof)
  if not CastSpellByName then return false end
  K.ours = true
  local ok = pcall(CastSpellByName, prof)
  if ok then K.hideProfFrame() end
  return ok
end

K.busy = false
function K.craft(e, n)
  local ok, why = K.canCraft(e); if not ok then K.msg, K.ok = why, false; return false end
  if why then   -- bon métier pas ouvert : on l'ouvre en arrière-plan, le craft part au clic suivant
    if K.openProfBg(e.prof) then K.msg, K.ok, K.opening = ("Métier %s ouvert en arrière-plan : clique encore (ou Espace) pour crafter."):format(e.prof), true, true
    else K.msg, K.ok = "Impossible d'ouvrir le métier " .. e.prof .. " : ouvre-le à la main.", false end
    return false
  end
  n = math.floor(tonumber(n) or 0); if n <= 0 then return false end
  n = math.min(n, math.max(e.craftable, 0)); if n <= 0 then K.msg, K.ok = "Composants insuffisants en stock.", false; return false end
  local w = e.who[K.me()]
  local okc, err = pcall(C_TradeSkillUI.CraftRecipe, w.id, n)
  if not okc then K.msg, K.ok = "Craft refusé : " .. tostring(err), false; return false end
  K.busy = true; K.msg, K.ok = ("Craft lancé : %d × %s."):format(n, e.name), true
  if C_Timer then C_Timer.After(15, function() K.busy = false end) end
  return true
end

------------------------------------------------------------------------
-- File de crafts : un clic ou Espace = un lot
------------------------------------------------------------------------
K.q = nil
function K.qStart()
  local items = {}
  for key, n in pairs(K.plan()) do
    for _, e in ipairs(K.cache) do if e.key == key then items[#items + 1] = { e = e, left = n, state = "ready" } end end
  end
  table.sort(items, function(a, b) return a.e.name < b.e.name end)
  K.q = { items = items }
end
function K.qStop() K.q = nil end
function K.qPending() local n = 0; if K.q then for _, it in ipairs(K.q.items) do if it.state == "ready" then n = n + 1 end end end return n end
function K.qStep()
  local q = K.q; if not q or K.busy then return end
  for _, it in ipairs(q.items) do
    if it.state == "ready" then
      local e = K.evaluate(it.e, E().stockMap())
      local ok, why = K.canCraft(e)
      if not ok then it.state, it.msg = "skip", why
      elseif e.craftable <= 0 then it.state, it.msg = "skip", "composants insuffisants"
      else
        local n = math.min(it.left, e.craftable)
        K.opening = false
        if K.craft(e, n) then
          it.left = it.left - n
          local p = K.plan(); p[e.key] = it.left > 0 and it.left or nil; K.demand = nil
          if it.left <= 0 then it.state, it.msg = "done", "lancé" end
          if ns.craftsUI then ns.craftsUI.refresh() end
          return
        elseif K.opening then K.opening = false; if ns.craftsUI then ns.craftsUI.refresh() end; return   -- on attend le clic suivant
        else it.state, it.msg = "skip", K.msg end
      end
    end
  end
  if ns.craftsUI then ns.craftsUI.refresh() end
end

local ev = CreateFrame("Frame")
for _, e in ipairs({ "TRADE_SKILL_SHOW", "TRADE_SKILL_CLOSE", "UNIT_SPELLCAST_SUCCEEDED", "UNIT_SPELLCAST_STOP", "UNIT_SPELLCAST_INTERRUPTED", "UNIT_SPELLCAST_FAILED", "TRADE_SKILL_CRAFT_RESULT" }) do pcall(ev.RegisterEvent, ev, e) end
ev:SetScript("OnEvent", function(_, e, unit)
  if e == "TRADE_SKILL_SHOW" then if K.ours then K.hideProfFrame(); if C_Timer then C_Timer.After(0.2, K.hideProfFrame) end end return end
  if e == "TRADE_SKILL_CLOSE" then K.showProfFrame(); return end
  if e == "TRADE_SKILL_CRAFT_RESULT" or unit == "player" then
    if K.busy then K.busy = false; if ns.craftsUI then ns.craftsUI.refresh() end end
  end
end)

-- Achat direct d'un composant à l'HV (mêmes règles de prix que partout : prix lu +5 %, jamais au-dessus de la médiane)
function K.buyLine(l, nCrafts)
  local B = ns.buy
  local n = math.max(l.need * (nCrafts or 1) - l.have, 0)
  if n <= 0 then return false, "rien à acheter" end
  if not l.id or not l.price then return false, "prix inconnu" end
  local med = ns.prices.median(l.name)
  local limit = ns.gring.capMax(l.price, med)
  if l.price > limit then return false, "au-dessus de la médiane" end
  return B.buy(l.id, n, limit, db().set.snipeOneClick ~= false), nil
end
function K.canBuyLine(l)
  local B = ns.buy
  if not (B.available() and B.ahOpen()) then return false end
  if not l.id or not l.price then return false end
  local med = ns.prices.median(l.name)
  return l.price <= ns.gring.capMax(l.price, med)
end
