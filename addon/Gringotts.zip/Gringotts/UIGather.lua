-- Gringotts : onglet Récolte. Deux vues : « Herbes et minerais » (suivi, couleurs, flèche) et la Pêche
-- (Guide 1-300 tant que la Cuisine monte, puis Journey), avec le mode pêche et la session en cours.
local ADDON, ns = ...
local W = ns.W
local C = W.C
local U = {}
ns.gatherUI = U

local S = { view = "nodes", kind = "herb" }
local function A() return ns.api end
local function G() return ns.gather end
local function F() return ns.fishing end
local function coins(c) return c and A().coins(math.floor(c)) or W.col(C.grey, "—") end

local COLN = { orange = W.col(C.orange, "orange"), yellow = W.col(C.gold, "jaune"), green = W.col(C.green, "vert"),
               gray = W.col(C.grey, "gris"), locked = W.col(C.grey, "pas encore") }

local function check(parent, label, x, y, get, set)
  local cb = ns.theme.check(parent, label)
  cb:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
  cb:SetScript("OnClick", function(self) set(self:GetChecked() and true or false); U.refresh() end)
  cb.get = get
  return cb
end

local function fmtTime(s)
  s = math.floor(s or 0)
  if s >= 3600 then return ("%dh %02dm"):format(math.floor(s / 3600), math.floor(s % 3600 / 60)) end
  return ("%dm %02ds"):format(math.floor(s / 60), s % 60)
end

------------------------------------------------------------------------
-- Construction
------------------------------------------------------------------------
function U.build(pane)
  local P = {}
  U.p = P
  P.pane = pane
  P.bNodes = W.button(pane, "Herbes et minerais", 170, 24, function() S.view = "nodes"; U.refresh() end)
  P.bNodes:SetPoint("TOPLEFT", pane, "TOPLEFT", 0, 0)
  P.bFish = W.button(pane, "Guide 1-300", 140, 24, function() S.view = "fish"; U.refresh() end)
  P.bFish:SetPoint("TOPLEFT", pane, "TOPLEFT", 176, 0)
  P.hdr = W.text(pane, "GringottsTextSmall", "", 330, -6, 500)
  P.hdr:ClearAllPoints(); P.hdr:SetPoint("TOPRIGHT", pane, "TOPRIGHT", -4, -6); P.hdr:SetJustifyH("RIGHT")

  ----------------------------------------------------------------------
  -- Vue 1 : herbes et minerais
  ----------------------------------------------------------------------
  local N = CreateFrame("Frame", nil, pane)
  N:SetPoint("TOPLEFT", pane, "TOPLEFT", 0, -34); N:SetPoint("BOTTOMRIGHT", pane, "BOTTOMRIGHT", 0, 0)
  P.N = N
  P.kindBtns = {}
  for i, k in ipairs(G().order) do
    local b = W.button(N, G().kinds[k].label, 140, 24, function() S.kind = k; U.refresh() end)
    b:SetPoint("TOPLEFT", N, "TOPLEFT", (i - 1) * 146, 0); b.kind = k; P.kindBtns[i] = b
  end
  P.skill = W.text(N, "GringottsLabel", "", 300, -4, 500)
  P.cOnly = check(N, "Suivre uniquement mes plantes cochées (les autres sont masquées sur la carte et la minimap)", 0, -34,
    function() return G().st().only end, function(v) G().st().only = v; G().apply() end)
  P.cLevel = check(N, "Filtre montée : seulement celles qui me font monter et que je peux ramasser", 0, -62,
    function() return G().st().level end, function(v) G().st().level = v; G().apply() end)
  P.cGreen = check(N, "Inclure les plantes vertes (faible chance de gain)", 0, -90,
    function() return G().st().green end, function(v) G().st().green = v; G().apply() end)
  P.bAll = W.button(N, "Tout cocher", 120, 22, function() G().checkAll(S.kind, true); G().apply(); U.refresh() end)
  P.bAll:SetPoint("TOPLEFT", N, "TOPLEFT", 0, -126)
  P.bNone = W.button(N, "Aucune", 100, 22, function() G().checkAll(S.kind, false); G().apply(); U.refresh() end)
  P.bNone:SetPoint("TOPLEFT", N, "TOPLEFT", 126, -126)
  P.bClimb = W.button(N, "Cocher celles qui font monter", 230, 22, function() G().checkClimbing(S.kind); G().apply(); U.refresh() end)
  P.bClimb:SetPoint("TOPLEFT", N, "TOPLEFT", 232, -126)
  W.text(N, "GringottsLabelSmall", "Suivi", 6, -158, 40)
  W.text(N, "GringottsLabelSmall", "Nom", 50, -158, 320)
  W.text(N, "GringottsLabelSmall", "Skill requis", 380, -158, 90, "RIGHT")
  W.text(N, "GringottsLabelSmall", "Couleur pour toi", 490, -158, 130)
  W.text(N, "GringottsLabelSmall", "Suivie sur la carte", 640, -158, 160)
  P.list = W.list(N, 820, 480, 24, function(b)
    b.chk = W.text(b, "GringottsText", "", 10, -4, 30)
    b.name = W.text(b, "GringottsText", "", 50, -4, 320)
    if b.name.SetWordWrap then b.name:SetWordWrap(false) end
    b.req = W.text(b, "GringottsText", "", 380, -4, 90, "RIGHT")
    b.col = W.text(b, "GringottsText", "", 490, -4, 130)
    b.fol = W.text(b, "GringottsTextSmall", "", 640, -6, 160)
    b:SetScript("OnClick", function(self)
      local e = self.entry; if not e then return end
      G().setChecked(S.kind, e.en, not G().st()[S.kind][e.en]); G().apply(); U.refresh()
    end)
  end, function(b, e)
    b.entry = e
    local col, climbs, followed, checked = G().status(S.kind, e)
    b.chk:SetText(checked and "|TInterface\\Buttons\\UI-CheckBox-Check:14|t" or "")
    b.name:SetText(e.fr .. W.col(C.grey, "  · " .. e.en))
    b.req:SetText(tostring(e.req))
    b.col:SetText(COLN[col])
    local st = G().st()
    if followed then b.fol:SetText(W.col(C.green, "oui" .. (climbs and " · fait monter" or "")))
    elseif checked and st.level then b.fol:SetText(W.col(C.grey, "cochée, écartée par le filtre montée"))
    elseif checked then b.fol:SetText(W.col(C.green, "oui"))
    else b.fol:SetText(W.col(C.grey, "non cochée")) end
  end)
  P.list.frame:SetPoint("TOPLEFT", N, "TOPLEFT", 0, -178)
  -- colonne de droite
  local R = CreateFrame("Frame", nil, N)
  R:SetPoint("TOPLEFT", N, "TOPLEFT", 850, 0); R:SetPoint("BOTTOMRIGHT", N, "BOTTOMRIGHT", 0, 0)
  ns.theme.panel(R, "panel", "line")
  W.text(R, "GringottsH2", "Résultat", 12, -8, 400)
  P.result = W.text(R, "GringottsText", "", 12, -36, 560)
  P.thresh = W.text(R, "GringottsTextSmall", W.col(C.grey, "Seuils de couleur : jaune à skill requis +25, vert à +50, gris à +100 (règle générale des plantes). Le skill est lu en jeu : les couleurs se mettent à jour à chaque gain."), 12, -150, 560)
  P.info = W.text(R, "GringottsText", "", 12, -190, 560)
  P.info:SetJustifyH("LEFT"); P.info:SetWidth(730)
  W.text(R, "GringottsTextSmall", W.col(C.grey, "Flèche, boussole et réglages GatherMate2 : Options › Récolte."), 12, -700, 700)

  ----------------------------------------------------------------------
  -- Vue 2 : pêche
  ----------------------------------------------------------------------
  local Z = CreateFrame("Frame", nil, pane)
  Z:SetPoint("TOPLEFT", pane, "TOPLEFT", 0, -34); Z:SetPoint("BOTTOMRIGHT", pane, "BOTTOMRIGHT", 0, 0)
  P.Z = Z
  P.zTitle = W.text(Z, "GringottsH2", "", 0, 0, 900)
  P.zSub = W.text(Z, "GringottsTextSmall", "", 0, -26, 1400)
  -- mode pêche + session
  local M = CreateFrame("Frame", nil, Z); M:SetPoint("TOPLEFT", Z, "TOPLEFT", 0, -56); M:SetSize(700, 150)
  ns.theme.panel(M, "panel", "line")
  W.text(M, "GringottsLabel", "Mode pêche", 10, -8, 300)
  P.mode = W.text(M, "GringottsText", "", 10, -30, 680)
  P.cAuto = check(M, "Détecter automatiquement (canne équipée = session démarrée)", 4, -50,
    function() return F().st().auto ~= false end, function(v) F().st().auto = v; F().sync() end)
  P.cLure = check(M, "Leurre automatique (applique un leurre de ton sac quand la canne n'en a plus)", 4, -76,
    function() return F().st().lure ~= false end, function(v) F().st().lure = v; F().bind() end)
  W.text(M, "GringottsTextSmall", "Lancer / ramasser :", 10, -112, 150)
  P.key = W.text(M, "GringottsLabel", "", 160, -110, 120)
  P.bKey = W.button(M, "Changer la touche", 150, 22, function() U.captureKey() end); P.bKey:SetPoint("TOPLEFT", M, "TOPLEFT", 290, -106)
  P.keyHint = W.text(M, "GringottsTextSmall", "", 450, -112, 240)
  local SS = CreateFrame("Frame", nil, Z); SS:SetPoint("TOPLEFT", Z, "TOPLEFT", 710, -56); SS:SetSize(690, 150)
  ns.theme.panel(SS, "panel", "line")
  W.text(SS, "GringottsLabel", "Session en cours", 10, -8, 300)
  P.tiles = {}
  for i = 1, 4 do local t = W.tile(SS, 160, 64); t.frame:SetPoint("TOPLEFT", SS, "TOPLEFT", 10 + (i - 1) * 168, -34); P.tiles[i] = t end
  P.sessNote = W.text(SS, "GringottsTextSmall", "", 10, -108, 670)
  P.zBody = CreateFrame("Frame", nil, Z); P.zBody:SetPoint("TOPLEFT", Z, "TOPLEFT", 0, -216); P.zBody:SetPoint("BOTTOMRIGHT", Z, "BOTTOMRIGHT", 0, 0)
  -- guide : prochaine étape + zones
  local Gd = CreateFrame("Frame", nil, P.zBody); Gd:SetAllPoints(); P.Gd = Gd
  P.gStep = W.text(Gd, "GringottsText", "", 0, 0, 1400)
  W.text(Gd, "GringottsLabelSmall", "Zone", 6, -64, 220)
  W.text(Gd, "GringottsLabelSmall", "Skill requis", 240, -64, 150)
  W.text(Gd, "GringottsLabelSmall", "Poissons utiles à la Cuisine (prises relevées)", 400, -64, 520)
  W.text(Gd, "GringottsLabelSmall", "Besoin couvert", 930, -64, 200)
  W.text(Gd, "GringottsLabelSmall", "Verdict", 1140, -64, 230)
  P.gList = W.list(Gd, 1400, 300, 24, function(b)
    b.z = W.text(b, "GringottsText", "", 6, -4, 230); b.r = W.text(b, "GringottsTextSmall", "", 240, -6, 150)
    b.f = W.text(b, "GringottsTextSmall", "", 400, -6, 520); b.c = W.text(b, "GringottsTextSmall", "", 930, -6, 200)
    b.v = W.text(b, "GringottsTextSmall", "", 1140, -6, 240)
    for _, k in ipairs({ "z", "r", "f", "c", "v" }) do if b[k].SetWordWrap then b[k]:SetWordWrap(false) end end
  end, function(b, r)
    b.z:SetText(r.name)
    b.r:SetText(r.ok and (r.req .. W.col(C.green, " · accessible")) or (r.req .. W.col(C.orange, " · manque " .. r.miss)))
    local t = {}
    for i = 1, math.min(3, #r.fishes) do local x = r.fishes[i]; t[#t + 1] = ("%s (%d %%)"):format(F().fishName(x.fish), math.floor(x.hits + .5)) end
    b.f:SetText(table.concat(t, " · "))
    local cv = {}
    for _, x in ipairs(r.fishes) do if x.need then cv[#cv + 1] = ("%d %s"):format(x.need, F().fishName(x.fish)) end end
    b.c:SetText(#cv > 0 and table.concat(cv, ", ") or W.col(C.grey, "—"))
    b.v:SetText(r.verdict or "")
  end)
  P.gList.frame:SetPoint("TOPLEFT", Gd, "TOPLEFT", 0, -84)
  P.gNote = W.text(Gd, "GringottsTextSmall", W.col(C.grey, "Entre parenthèses : prises relevées par Wowhead Forever (pages des objets) + 5 × tes propres prises du journal. Skill requis par zone : relevés du dashboard."), 0, -392, 1400)
  -- journey : poissons
  local J = CreateFrame("Frame", nil, P.zBody); J:SetAllPoints(); P.J = J
  P.jBest = W.text(J, "GringottsText", "", 0, 0, 1400)
  W.text(J, "GringottsLabelSmall", "Poisson", 6, -64, 230)
  W.text(J, "GringottsLabelSmall", "Prix HV direct", 240, -64, 110, "RIGHT")
  W.text(J, "GringottsLabelSmall", "Net (commission)", 360, -64, 120, "RIGHT")
  W.text(J, "GringottsLabelSmall", "Valeur craft connu", 490, -64, 130, "RIGHT")
  W.text(J, "GringottsLabelSmall", "Meilleur débouché", 640, -64, 130)
  W.text(J, "GringottsLabelSmall", "Où pêcher (prises relevées)", 780, -64, 600)
  P.jList = W.list(J, 1400, 300, 24, function(b)
    b.n = W.text(b, "GringottsText", "", 6, -4, 230); b.p = W.text(b, "GringottsTextSmall", "", 240, -6, 110, "RIGHT")
    b.nt = W.text(b, "GringottsTextSmall", "", 360, -6, 120, "RIGHT"); b.c = W.text(b, "GringottsTextSmall", "", 490, -6, 130, "RIGHT")
    b.d = W.text(b, "GringottsTextSmall", "", 640, -6, 130); b.z = W.text(b, "GringottsTextSmall", "", 780, -6, 600)
    for _, k in ipairs({ "n", "d", "z" }) do if b[k].SetWordWrap then b[k]:SetWordWrap(false) end end
  end, function(b, r)
    b.n:SetText(r.name)
    b.p:SetText(coins(r.price)); b.nt:SetText(coins(r.net)); b.c:SetText(r.craft and coins(r.craft) or W.col(C.grey, "—"))
    b.d:SetText(r.best and (r.kind == "HV direct" and "HV direct" or W.col(C.gold, r.kind)) or W.col(C.grey, "sans prix"))
    local zs = {}
    for i = 1, math.min(4, #r.zones) do local z = r.zones[i]; zs[#zs + 1] = ("%s %d %%"):format(z.name, math.floor(z.hits + .5)) end
    b.z:SetText(#zs > 0 and (table.concat(zs, " · ") .. (r.classic and " *" or "")) or W.col(C.grey, "zones inconnues"))
  end)
  P.jList.frame:SetPoint("TOPLEFT", J, "TOPLEFT", 0, -84)
  W.text(J, "GringottsTextSmall", W.col(C.grey, "Le meilleur débouché prend la valeur la plus haute entre le prix HV net de la commission et la valeur du craft (prix de vente du produit fini − autres composants), pour les recettes que tu connais. * = Wowhead Classic, page Forever pas encore relue. Gain par heure : voir la session."), 0, -392, 1400)
  U.keyFrame = CreateFrame("Frame", nil, pane)
  P.ready = true
end

-- Capture de la prochaine touche pour le lancer / ramasser
function U.captureKey()
  local P = U.p; local kf = U.keyFrame
  if not kf then return end
  U.keyBusy = true
  P.keyHint:SetText(W.col(C.orange, "Appuie sur la touche voulue (Échap : annuler)"))
  kf:EnableKeyboard(true)
  if kf.SetPropagateKeyboardInput then kf:SetPropagateKeyboardInput(false) end
  kf:SetScript("OnKeyDown", function(self, key)
    if key == "LSHIFT" or key == "RSHIFT" or key == "LCTRL" or key == "RCTRL" or key == "LALT" or key == "RALT" then return end
    self:EnableKeyboard(false); self:SetScript("OnKeyDown", nil); U.keyBusy = false
    if key ~= "ESCAPE" then
      local mod = (IsShiftKeyDown() and "SHIFT-" or "") .. (IsControlKeyDown() and "CTRL-" or "") .. (IsAltKeyDown() and "ALT-" or "")
      F().setKey(mod .. key)
    end
    U.refresh()
  end)
end

------------------------------------------------------------------------
-- Affichage
------------------------------------------------------------------------

------------------------------------------------------------------------
-- Réglages (affichés dans Options › Récolte) : flèche, boussole, GatherMate2
------------------------------------------------------------------------
local SP
function U.buildSettings(parent)
  SP = {}
  local R = CreateFrame("Frame", nil, parent)
  R:SetSize(700, 560)
  local function check(p, label, x, y, get, set)
    local cb = ns.theme.check(p, label)
    cb:SetPoint("TOPLEFT", p, "TOPLEFT", x, y)
    cb:SetScript("OnClick", function(self) set(self:GetChecked() and true or false); U.refreshSettings() end)
    cb.get = get
    return cb
  end
  local U_refresh = U.refresh
  W.text(R, "GringottsH2", "Flèche et boussole", 12, -196, 560)
  SP.cArrow = check(R, "Activer (flèche et / ou boussole vers les cibles suivies)", 4, -222,
    function() return ns.arrowOn and ns.arrowOn() end, function(v) if ns.arrowSet then ns.arrowSet(v) end end)
  W.text(R, "GringottsTextSmall", "Affichage", 12, -258, 100)
  SP.dArrow = W.button(R, "Flèche seule", 120, 22, function() ns.arrowSetDisplay("arrow"); U.refreshSettings() end); SP.dArrow:SetPoint("TOPLEFT", R, "TOPLEFT", 110, -254)
  SP.dComp = W.button(R, "Boussole seule", 130, 22, function() ns.arrowSetDisplay("compass"); U.refreshSettings() end); SP.dComp:SetPoint("TOPLEFT", R, "TOPLEFT", 236, -254)
  SP.dBoth = W.button(R, "Les deux", 100, 22, function() ns.arrowSetDisplay("both"); U.refreshSettings() end); SP.dBoth:SetPoint("TOPLEFT", R, "TOPLEFT", 372, -254)
  W.text(R, "GringottsTextSmall", "Quelle cible ?", 12, -288, 100)
  SP.mBest = W.button(R, "Meilleure valeur", 140, 22, function() ns.arrowSetMode("best"); U.refreshSettings() end); SP.mBest:SetPoint("TOPLEFT", R, "TOPLEFT", 110, -284)
  SP.mNear = W.button(R, "Plus proche", 120, 22, function() ns.arrowSetMode("near"); U.refreshSettings() end); SP.mNear:SetPoint("TOPLEFT", R, "TOPLEFT", 256, -284)
  local function numEdit(x, y, apply, decimal)
    local e = W.edit(R, 50, not decimal, function(self) apply(self:GetText()) end); e:SetPoint("TOPLEFT", R, "TOPLEFT", x, y)
    e:SetScript("OnEditFocusLost", function(self) apply(self:GetText()) end)
    return e
  end
  W.text(R, "GringottsTextSmall", "Taille (24-200) · opacité (10-100 %)", 12, -322, 280)
  SP.eSize = numEdit(300, -318, function(t) ns.arrowSetSize(t) end)
  SP.eAlpha = numEdit(360, -318, function(t) ns.arrowSetAlpha(t) end)
  W.text(R, "GringottsTextSmall", "Réapparition : durée affichée (30-1800 s)", 12, -350, 290)
  SP.eResp = numEdit(300, -346, function(t) ns.arrowSetRespawn(t) end)
  SP.cSound = check(R, "Son quand une cible passe à portée (m) :", 4, -372,
    function() return ns.arrowCfg().sound end, function(v) ns.arrowSetSound(v) end)
  SP.eAlert = numEdit(300, -374, function(t) ns.arrowSetAlertDist(t) end)
  W.text(R, "GringottsTextSmall", W.col(C.grey, "Meilleure valeur : orange avant jaune, puis distance ; un point gris n'est jamais choisi. Boussole : tous les points suivis dans les 400 m, devant toi. La durée de réapparition est un réglage (GatherMate2 ne donne pas l'état d'un point). Maj + glisser pour déplacer. Commandes : /gt arrow ..."), 12, -404, 590)

  W.text(R, "GringottsH2", "GatherMate2 (réglages relayés)", 12, -470, 560)
  SP.gmStatus = W.text(R, "GringottsTextSmall", "", 12, -496, 590)
  SP.cMini = check(R, "Icônes sur la minimap", 4, -520, function() return G().gmGet("showMinimap") end, function(v) G().gmSet("showMinimap", v) end)
  SP.cWorld = check(R, "Icônes sur la carte du monde", 250, -520, function() return G().gmGet("showWorldMap") end, function(v) G().gmSet("showWorldMap", v) end)
  W.text(R, "GringottsTextSmall", "Distance de suivi (50-240 m)", 12, -556, 230)
  SP.gDist = numEdit(250, -552, function(t) G().gmSet("trackDistance", t) end)
  W.text(R, "GringottsTextSmall", "Taille icônes : carte · minimap (0,5-5)", 12, -584, 290)
  SP.gScale = numEdit(300, -580, function(t) G().gmSet("scale", t) end, true)
  SP.gMini = numEdit(360, -580, function(t) G().gmSet("miniscale", t) end, true)
  W.text(R, "GringottsTextSmall", "Opacité des icônes de la carte (0,1-1)", 12, -612, 290)
  SP.gAlpha = numEdit(300, -608, function(t) G().gmSet("alpha", t) end, true)
  W.text(R, "GringottsTextSmall", "Cercle de suivi", 12, -640, 120)
  SP.gTrack = W.button(R, "", 200, 22, function() G().gmCycleTrackShow(); U.refreshSettings() end); SP.gTrack:SetPoint("TOPLEFT", R, "TOPLEFT", 130, -636)
  W.text(R, "GringottsTextSmall", W.col(C.grey, "Pas de réglage de son côté GatherMate2 : l'alerte sonore est celle de la flèche, ci-dessus."), 12, -668, 590)

  return R
end

function U.refreshSettings()
  local P, g = SP, G()
  if not P then return end
  local GM = g.gm()
  if not GM then P.gmStatus:SetText(W.col(C.orange, "GatherMate2 non détecté : suivi, flèche et boussole inactifs."))
  elseif g.st().only then P.gmStatus:SetText(W.col(C.green, "Filtres réglés par Gringotts") .. (g.lastApply and (" (" .. g.lastApply .. " entrées)") or "") .. " : seules les cibles suivies s'affichent.")
  else P.gmStatus:SetText(W.col(C.grey, "Suivi désactivé : GatherMate2 affiche tout. Active « Suivre uniquement mes plantes cochées » (page Récolte) pour filtrer.")) end
  P.cArrow:SetChecked(ns.arrowOn and ns.arrowOn() and true or false)
  local d = ns.arrowGetDisplay()
  if d == "arrow" then P.dArrow:Disable() else P.dArrow:Enable() end
  if d == "compass" then P.dComp:Disable() else P.dComp:Enable() end
  if d == "both" then P.dBoth:Disable() else P.dBoth:Enable() end
  local best = ns.arrowGetMode() == "best"
  if best then P.mBest:Disable(); P.mNear:Enable() else P.mNear:Disable(); P.mBest:Enable() end
  local a = ns.arrowCfg()
  P.eSize:SetText(tostring(a.size or 64)); P.eAlpha:SetText(tostring(math.floor((a.alpha or 1) * 100 + .5)))
  P.eResp:SetText(tostring(a.respawn or 180)); P.eAlert:SetText(tostring(a.alertDist or 100)); P.cSound:SetChecked(a.sound and true or false)
  P.cMini:SetChecked(g.gmGet("showMinimap") and true or false); P.cWorld:SetChecked(g.gmGet("showWorldMap") and true or false)
  P.gDist:SetText(tostring(g.gmGet("trackDistance") or "")); P.gScale:SetText(tostring(g.gmGet("scale") or "")); P.gMini:SetText(tostring(g.gmGet("miniscale") or ""))
  P.gAlpha:SetText(tostring(g.gmGet("alpha") or ""))
  P.gTrack:SetText(g.TRACKSHOW_FR[g.gmGet("trackShow") or "always"] or "—")
end


-- Aide à la montée : palier suivant, plantes utiles maintenant, meilleures zones
local function climbInfo(kindKey)
  local g = G()
  local kind = g.kinds[kindKey]
  local skill, max = ns.skillOf(kindKey)
  local out = {}
  out[#out + 1] = W.col(C.gold, ("Pour monter %s (%d / %d)"):format(kind.label, skill, max > 0 and max or 300))
  local now, nxt = {}, nil
  for _, e in ipairs(kind.list) do
    local col = g.color(e.req, skill)
    if col == "orange" or col == "yellow" then now[#now + 1] = ("%s %s (orange jusqu'à %d · jaune jusqu'à %d)"):format(col == "orange" and "|cffff8040●|r" or "|cffffd040●|r", e.fr, e.req + 24, e.req + 49) end
    if not nxt and e.req > skill then nxt = e end
  end
  out[#out + 1] = ""
  out[#out + 1] = W.col(C.gold, "À cueillir maintenant")
  if #now > 0 then for _, l in ipairs(now) do out[#out + 1] = l end else out[#out + 1] = W.col(C.grey, "Aucune plante orange ou jaune : passe au palier suivant.") end
  if nxt then out[#out + 1] = ""; out[#out + 1] = W.col(C.gold, "Palier suivant"); out[#out + 1] = ("%s à %d (encore %d points de skill)"):format(nxt.fr, nxt.req, nxt.req - skill) end
  out[#out + 1] = ""
  out[#out + 1] = W.col(C.gold, "Meilleures zones (points connus de plantes utiles)")
  local z = g.bestZones and g.bestZones(kindKey)
  if z == nil then out[#out + 1] = W.col(C.grey, "GatherMate2 requis.")
  elseif #z == 0 then out[#out + 1] = W.col(C.grey, "Aucun point connu pour ton niveau.")
  else
    for i = 1, math.min(6, #z) do
      local by = {}
      for name, n in pairs(z[i].by) do by[#by + 1] = { name, n } end
      table.sort(by, function(a, b) return a[2] > b[2] end)
      local parts = {}
      for j = 1, math.min(3, #by) do parts[#parts + 1] = ("%s ×%d"):format(by[j][1], by[j][2]) end
      out[#out + 1] = ("%d. %s : %d points · %s"):format(i, z[i].name, z[i].n, W.col(C.grey, table.concat(parts, ", ")))
    end
  end
  return table.concat(out, "\n")
end

local function refreshNodes(P)
  local g = G()
  local kind = g.kinds[S.kind]
  for _, b in ipairs(P.kindBtns) do if b.kind == S.kind then b:Disable() else b:Enable() end end
  local lvl, max, me = ns.skillOf(S.kind)
  P.skill:SetText(lvl > 0 and ("%s : %d / %d%s"):format(kind.label, lvl, max, me and "" or W.col(C.grey, " (meilleur de tes persos)"))
    or W.col(C.grey, kind.label .. " : skill non lu (ouvre la fenêtre du métier une fois)"))
  for _, cb in ipairs({ P.cOnly, P.cLevel, P.cGreen }) do cb:SetChecked(cb.get() and true or false) end
  P.list:SetData(kind.list, true)
  P.info:SetText(climbInfo(S.kind))
  local names = g.followedNames(S.kind)
  P.result:SetText(#names > 0 and ("%d %s(s) suivie(s) : %s"):format(#names, kind.noun, table.concat(names, ", "))
    or W.col(C.grey, "Aucune " .. kind.noun .. " suivie : coche des lignes dans la liste (clic sur la ligne)."))
  U.refreshSettings()
end

local function refreshFish(P)
  local f = F()
  local view = f.view()
  local pl, cook = ns.skillOf("fish"), ns.skillOf("cook")
  P.zTitle:SetText(view == "guide" and "Pêche · Guide 1-300" or "Pêche · Journey")
  P.zSub:SetText(("Pêche %d / 300 · Cuisine %d / 300  ·  %s"):format(pl, cook,
    view == "guide" and "Ce guide dure tant que ta montée en Cuisine n'est pas finie : il choisit la zone selon les poissons dont la Cuisine a besoin. À Cuisine 300, il est remplacé par Journey."
    or "Journey classe les poissons selon ce qui rapporte le plus : prix de vente direct à l'HV ou valeur du craft si tu connais la recette."))
  local info = f.info()
  local st = f.st()
  if info.active then P.mode:SetText(W.col(C.green, "Actif") .. " · canne équipée · détecté automatiquement")
  elseif f.poleEquipped() then P.mode:SetText(W.col(C.orange, "Inactif") .. " · canne équipée, détection automatique désactivée")
  else P.mode:SetText(W.col(C.grey, "Inactif") .. " · équipe une canne à pêche pour démarrer une session") end
  P.cAuto:SetChecked(st.auto ~= false); P.cLure:SetChecked(st.lure ~= false)
  P.key:SetText(st.key or "SPACE")
  if not U.keyBusy then P.keyHint:SetText(W.col(C.grey, "Active seulement pendant le mode pêche (un appui = un lancer ou un ramassage). Pendant la canalisation, place la souris sur le flotteur.")) end
  P.tiles[1]:Set("Prises", tostring(info.catches), info.perCatch and (fmtTime(info.perCatch) .. " par prise") or "—")
  P.tiles[2]:Set("Valeur HV", coins(info.value), "prix HV du moment")
  P.tiles[3]:Set("Lancers", tostring(info.casts), info.active and fmtTime(info.secs) or "—")
  P.tiles[4]:Set("Gain / heure", info.perHour and coins(info.perHour) or "—", info.perHour and "estimé sur la session" or "après 1 min de pêche")
  local last = st.hist[1]
  P.sessNote:SetText(last and W.col(C.grey, ("Dernière session : %d prises, %s, %s"):format(last.catches, fmtTime(last.secs), A().coins(math.floor(last.value or 0)))) or "")
  if view == "guide" then
    P.Gd:Show(); P.J:Hide()
    local rows, ctx = f.guideZones()
    P.gList:SetData(rows, true)
    local t = {}
    if ctx.best then
      t[#t + 1] = ("Zone conseillée : |cff7fe0a0%s|r (skill %d, accessible)"):format(ctx.best.name, ctx.best.req)
    else t[#t + 1] = W.col(C.orange, "Aucune zone accessible ne contient de poisson utile à la Cuisine : monte la Pêche.") end
    if ctx.nextReq then
      t[#t + 1] = ("Prochaine étape : Pêche %d › %d%s"):format(ctx.skill, ctx.nextReq, ctx.nextZone and (" (" .. ctx.nextZone.name .. ")") or "")
    end
    local needs = {}
    for i, n in pairs(ctx.needs) do needs[#needs + 1] = ("%s × %d"):format(f.fishName(ns.fishDB[i]), n) end
    table.sort(needs)
    t[#t + 1] = ctx.hasNeeds and ("Poissons manquants (plan Cuisine) : " .. table.concat(needs, ", "))
      or W.col(C.grey, "Aucun plan Cuisine : zones classées d'après les recettes de niveau >= ton skill de Cuisine (génère l'étape dans Métiers › Montée).")
    P.gStep:SetText(table.concat(t, "\n"))
  else
    P.J:Show(); P.Gd:Hide()
    local rows = f.journey()
    P.jList:SetData(rows, true)
    local bestNet, bestCraft
    for _, r in ipairs(rows) do
      if r.net and (not bestNet or r.net > bestNet.net) then bestNet = r end
      if r.craft and (not bestCraft or r.craft > bestCraft.craft) then bestCraft = r end
    end
    P.jBest:SetText(("Meilleure prise : %s    ·    Meilleur craft : %s"):format(
      bestNet and (bestNet.name .. " " .. coins(bestNet.net) .. " net à l'HV") or W.col(C.grey, "—"),
      bestCraft and (bestCraft.name .. " " .. coins(bestCraft.craft) .. " en " .. bestCraft.kind) or W.col(C.grey, "—")))
  end
end

function U.refresh()
  local P = U.p; if not (P and P.ready) then return end
  if not P.pane:IsShown() then return end
  local view = F().view()
  P.bFish:SetText(view == "guide" and "Guide 1-300" or "Journey")
  if S.view == "nodes" then P.bNodes:Disable(); P.bFish:Enable(); P.N:Show(); P.Z:Hide()
  else P.bFish:Disable(); P.bNodes:Enable(); P.Z:Show(); P.N:Hide() end
  P.hdr:SetText("")
  if S.view == "nodes" then refreshNodes(P) else refreshFish(P) end
end

function U.setView(v) S.view = (v == "fish") and "fish" or "nodes"; U.refresh() end
