-- Gringotts : petits composants d'interface (texte, bouton, tuile, liste à lignes recyclées, barres).
local ADDON, ns = ...
local W = {}
ns.W = W

W.C = { gold = { 1, .83, .42 }, grey = { .55, .52, .44 }, green = { .56, .82, .54 }, red = { 1, .6, .54 },
        orange = { 1, .69, .29 }, blue = { .49, .78, 1 }, white = { .91, .89, .82 } }
local function hx(v) return math.floor(v * 255 + .5) end
function W.col(c, s) return ("|cff%02x%02x%02x%s|r"):format(hx(c[1]), hx(c[2]), hx(c[3]), tostring(s)) end

function W.fill(parent, r, g, b, a, layer)
  local t = parent:CreateTexture(nil, layer or "BACKGROUND")
  t:SetColorTexture(r, g, b, a or 1)
  return t
end

function W.text(parent, font, text, x, y, width, justify, point)
  local f = parent:CreateFontString(nil, "OVERLAY", font or "GameFontHighlight")
  point = point or "TOPLEFT"
  f:SetPoint(point, parent, point, x or 0, y or 0)
  if width then f:SetWidth(width) end
  f:SetJustifyH(justify or "LEFT")
  if text then f:SetText(text) end
  return f
end

function W.button(parent, label, w, h, onclick)
  local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
  b:SetSize(w, h or 22); b:SetText(label)
  if onclick then b:SetScript("OnClick", onclick) end
  return b
end

function W.edit(parent, w, numeric, onenter)
  local e = CreateFrame("EditBox", nil, parent, "InputBoxTemplate")
  e:SetSize(w, 20); e:SetAutoFocus(false)
  if numeric and e.SetNumeric then e:SetNumeric(true) end
  e:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
  e:SetScript("OnEnterPressed", function(self) self:ClearFocus(); if onenter then onenter(self) end end)
  return e
end

-- Tuile : libellé, valeur, sous-texte
function W.tile(parent, w, h)
  local f = CreateFrame("Frame", nil, parent)
  f:SetSize(w, h)
  W.fill(f, .04, .05, .07, 1):SetAllPoints()
  local t = { frame = f }
  t.label = W.text(f, "GameFontNormalSmall", "", 8, -6, w - 16)
  t.value = W.text(f, "GameFontHighlightLarge", "", 8, -22, w - 16)
  t.sub = W.text(f, "GameFontHighlightSmall", "", 8, -(h - 16), w - 16)
  function t:Set(label, value, sub) self.label:SetText(label or ""); self.value:SetText(value or ""); self.sub:SetText(sub or "") end
  return t
end

-- Liste à lignes recyclées : seules les lignes visibles existent, quel que soit le nombre d'entrées.
-- setup(btn) crée le contenu d'une ligne ; fill(btn, entree, index) le remplit.
function W.list(parent, w, h, rowH, setup, fill)
  local L = { data = {}, off = 0, n = math.floor(h / rowH), rows = {} }
  local f = CreateFrame("Frame", nil, parent)
  f:SetSize(w, h); L.frame = f
  local sb = CreateFrame("Slider", nil, f)
  sb:SetPoint("TOPRIGHT", f, "TOPRIGHT", 0, 0); sb:SetSize(12, h)
  sb:SetOrientation("VERTICAL")
  W.fill(sb, .1, .1, .12, 1):SetAllPoints()
  local th = W.fill(sb, .85, .65, .25, .9, "OVERLAY"); th:SetSize(12, 36)
  sb:SetThumbTexture(th)
  sb:SetMinMaxValues(0, 0); sb:SetValueStep(1); sb:SetValue(0)
  L.bar = sb
  for i = 1, L.n do
    local b = CreateFrame("Button", nil, f)
    b:SetSize(w - 16, rowH); b:SetPoint("TOPLEFT", f, "TOPLEFT", 0, -(i - 1) * rowH)
    b.hl = W.fill(b, 1, .83, .42, .10, "HIGHLIGHT"); b.hl:SetAllPoints()
    b.sel = W.fill(b, .89, .72, .31, .14, "BACKGROUND"); b.sel:SetAllPoints(); b.sel:Hide()
    if setup then setup(b) end
    b:Hide()
    L.rows[i] = b
  end
  function L:Refresh()
    for i, b in ipairs(self.rows) do
      local e = self.data[self.off + i]
      if e then b:Show(); fill(b, e, self.off + i) else b:Hide() end
    end
  end
  function L:SetData(d, keepOffset)
    self.data = d or {}
    local maxOff = math.max(0, #self.data - self.n)
    if not keepOffset then self.off = 0 end
    if self.off > maxOff then self.off = maxOff end
    self.busy = true
    sb:SetMinMaxValues(0, maxOff); sb:SetValue(self.off)
    self.busy = false
    if maxOff == 0 then sb:Hide() else sb:Show() end
    self:Refresh()
  end
  sb:SetScript("OnValueChanged", function(_, v)
    if L.busy then return end
    L.off = math.floor((v or 0) + .5); L:Refresh()
  end)
  f:EnableMouseWheel(true)
  f:SetScript("OnMouseWheel", function(_, delta)
    local maxOff = math.max(0, #L.data - L.n)
    local o = math.max(0, math.min(maxOff, L.off - delta * 3))
    if o ~= L.off then L.off = o; L.busy = true; sb:SetValue(o); L.busy = false; L:Refresh() end
  end)
  return L
end

-- Barres verticales (courbe de prix, profil de la semaine) : values[i] > 0, 0 = inconnu
function W.bars(parent, n, bw, gap, h)
  local B = { tex = {}, n = n, h = h }
  local f = CreateFrame("Frame", nil, parent)
  f:SetSize(n * (bw + gap), h); B.frame = f
  W.fill(f, .04, .05, .07, 1):SetAllPoints()
  for i = 1, n do
    local t = f:CreateTexture(nil, "ARTWORK")
    t:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", (i - 1) * (bw + gap) + gap / 2, 2)
    t:SetSize(bw, 1)
    B.tex[i] = t
  end
  B.med = f:CreateTexture(nil, "OVERLAY"); B.med:SetColorTexture(.8, .8, .8, .35); B.med:SetSize(n * (bw + gap), 1); B.med:Hide()
  -- hi : indice de la barre à mettre en valeur ; ref : valeur de référence (médiane) tracée en trait
  function B:Set(values, hi, ref, lowIsGood)
    local lo, mx = math.huge, 0
    for i = 1, self.n do local v = values[i]; if v and v > 0 then lo = math.min(lo, v); mx = math.max(mx, v) end end
    if mx == 0 then for i = 1, self.n do self.tex[i]:Hide() end; self.med:Hide(); return end
    local base = lo * 0.9
    local span = math.max(mx - base, 1)
    for i = 1, self.n do
      local v, t = values[i], self.tex[i]
      if v and v > 0 then
        t:SetHeight(math.max(2, (v - base) / span * (self.h - 8) + 4))
        if i == hi then t:SetColorTexture(.35, .76, .45, 1) else t:SetColorTexture(.89, .72, .31, .9) end
        t:Show()
      else t:Hide() end
    end
    if ref and ref > 0 and ref >= base and ref <= mx then
      self.med:ClearAllPoints()
      self.med:SetPoint("BOTTOMLEFT", self.frame, "BOTTOMLEFT", 0, 2 + (ref - base) / span * (self.h - 8) + 4)
      self.med:Show()
    else self.med:Hide() end
  end
  return B
end
