-- Gringotts : flèche dynamique vers l'herbe connue la plus proche (données GatherMate2).
-- /gt fleche  : active / désactive · Maj + glisser : déplacer · /gt fleche reset : recentrer
local ADDON, ns = ...

local NODE_TYPE = "Herb Gathering"
local REFRESH = 0.5        -- recherche du point le plus proche (s)
local VISIT_RADIUS = 7     -- à moins de 7 m d'un point, on le considère cueilli
local VISIT_TTL = 180      -- et on l'ignore pendant 3 min (repousse)

local atan2 = math.atan2 or function(y, x) return math.atan(y, x) end
local sqrt, pi = math.sqrt, math.pi

local function say(msg) print("|cffe4b84eGringotts|r " .. msg) end

-- Angle de rotation de la texture (anti-horaire, radians) pour pointer vers la cible.
-- Carte : x vers l'est, y vers le sud. facing = GetPlayerFacing() (anti-horaire depuis le nord).
local function arrowRotation(px, py, nx, ny, w, h, facing)
  local dx, dy = (nx - px) * w, (ny - py) * h
  local bearing = atan2(dx, -dy)          -- horaire depuis le nord
  return -bearing - (facing or 0), sqrt(dx * dx + dy * dy)
end
ns.arrowRotation = arrowRotation

local GM, HBD
local function libs()
  if GM and HBD then return true end
  local ace = LibStub and LibStub("AceAddon-3.0", true)
  GM = GM or (ace and ace:GetAddon("GatherMate2", true))
  HBD = HBD or (LibStub and LibStub("HereBeDragons-2.0", true))
  return GM ~= nil and HBD ~= nil
end

local visited = {}   -- "zone:coord" -> GetTime()
local target         -- {zone, coord, x, y, name}

local f = CreateFrame("Frame", "GringottsArrow", UIParent)
f:SetSize(64, 64)
f:SetPoint("CENTER", UIParent, "CENTER", 0, 180)
f:SetFrameStrata("MEDIUM")
f:SetClampedToScreen(true)
f:SetMovable(true)
f:EnableMouse(true)
f:RegisterForDrag("LeftButton")
f:Hide()

local tex = f:CreateTexture(nil, "ARTWORK")
tex:SetAllPoints()
tex:SetTexture("Interface\\Minimap\\ROTATING-MINIMAPARROW")

local lblDist = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
lblDist:SetPoint("TOP", f, "BOTTOM", 0, -2)
local lblName = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
lblName:SetPoint("TOP", lblDist, "BOTTOM", 0, -1)

f:SetScript("OnDragStart", function(self) if IsShiftKeyDown() then self:StartMoving() end end)
f:SetScript("OnDragStop", function(self)
  self:StopMovingOrSizing()
  local p, _, rp, x, y = self:GetPoint()
  GringottsDB = GringottsDB or {}
  GringottsDB.arrow = GringottsDB.arrow or {}
  GringottsDB.arrow.pos = { p, rp, x, y }
end)

local function findNearest(zone, px, py, w, h)
  local now, best, bestD = GetTime(), nil, math.huge
  for coord, nodeID in GM:GetNodesForZone(zone, NODE_TYPE) do
    local key = zone .. ":" .. coord
    local t = visited[key]
    if t and now - t < VISIT_TTL then
      -- point récemment cueilli : ignoré
    else
      if t then visited[key] = nil end
      local nx, ny = GM:DecodeLoc(coord)
      local dx, dy = (nx - px) * w, (ny - py) * h
      local d2 = dx * dx + dy * dy
      if d2 < bestD then bestD, best = d2, { zone = zone, coord = coord, x = nx, y = ny, id = nodeID, key = key } end
    end
  end
  if best then best.name = GM:GetNameForNode(NODE_TYPE, best.id) end
  return best
end

local acc = 0
f:SetScript("OnUpdate", function(self, elapsed)
  local px, py, zone = HBD:GetPlayerZonePosition()
  if not px or not zone then self:SetAlpha(0); return end   -- instance / position inconnue
  local w, h = HBD:GetZoneSize(zone)
  if not w or w == 0 then self:SetAlpha(0); return end
  acc = acc + elapsed
  if acc >= REFRESH or (target and target.zone ~= zone) then
    acc = 0
    target = findNearest(zone, px, py, w, h)
  end
  if not target then self:SetAlpha(0.35); lblDist:SetText("—"); lblName:SetText("aucune herbe connue ici"); return end
  local rot, dist = arrowRotation(px, py, target.x, target.y, w, h, GetPlayerFacing and GetPlayerFacing() or 0)
  if dist <= VISIT_RADIUS then visited[target.key] = GetTime(); target = nil; acc = REFRESH; return end
  self:SetAlpha(1)
  tex:SetRotation(rot)
  lblDist:SetText(string.format("%d m", math.floor(dist + 0.5)))
  lblName:SetText(target.name or "Herbe")
end)

local function setOn(on)
  GringottsDB = GringottsDB or {}
  GringottsDB.arrow = GringottsDB.arrow or {}
  if on and not libs() then
    say("Flèche impossible : GatherMate2 (et HereBeDragons) introuvable. Activez GatherMate2.")
    on = false
  end
  GringottsDB.arrow.on = on and true or false
  f:SetShown(on)
  if on then target = nil; acc = REFRESH end
end

ns.arrowCmd = function(arg)
  arg = (arg or ""):lower()
  if arg == "reset" then
    f:ClearAllPoints(); f:SetPoint("CENTER", UIParent, "CENTER", 0, 180)
    if GringottsDB and GringottsDB.arrow then GringottsDB.arrow.pos = nil end
    say("Flèche recentrée.")
    return
  end
  local on = not f:IsShown()
  setOn(on)
  if f:IsShown() then say("Flèche vers l'herbe la plus proche : activée (Maj + glisser pour la déplacer).")
  else say("Flèche : désactivée.") end
end

local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
ev:SetScript("OnEvent", function()
  local a = GringottsDB and GringottsDB.arrow
  if a and a.pos then f:ClearAllPoints(); f:SetPoint(a.pos[1], UIParent, a.pos[2], a.pos[3], a.pos[4]) end
  if a and a.on then setOn(true) end
end)
