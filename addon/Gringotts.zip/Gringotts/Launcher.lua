-- Gringotts : bouton flottant + dock de pastilles (Business, Farm, Métiers, Récolte, Bêtes pour un chasseur, Options).
-- Clic gauche : ouvre/ferme le dock · glisser : déplacer où tu veux · /gt bouton : afficher/masquer
-- Farm : démarre / arrête l'enregistrement d'une session ; l'or/h s'affiche sous le bouton et sur la pastille Farm.
local ADDON, ns = ...

local ENTRIES = {
  { "Business", "stock", "Interface\\Icons\\INV_Misc_Coin_02" },
  { "Farm", nil, "Interface\\Icons\\INV_Misc_Bag_08", "farm" },     -- démarre / arrête l'enregistrement d'une session de farm
  { "Métiers", "crafts", "Interface\\Icons\\Trade_BlackSmithing" },
  { "Récolte", "gathering", "Interface\\Icons\\INV_Misc_Herb_07" },
  { "Options", "settings", "Interface\\Icons\\INV_Gizmo_01" },
}

local btn, menu, catcher
local MAIN = 56
local PILL_W, PILL_H, CARD_W, CARD_H, GAP, FADE = 168, 36, 224, 54, 6, 0.14

local SEAL = "Interface\\AddOns\\" .. (ADDON or "Gringotts") .. "\\Media\\seal"

local function chat(m) print("|cffe4b84eGringotts|r " .. m) end
local function C() return ns.theme and ns.theme.c or nil end
local function setBorder(f, name)
  local c = C(); local e = f and rawget(f, "_edges")
  if not (c and e and c[name]) then return end
  for _, t in pairs(e) do t:SetColorTexture(c[name][1], c[name][2], c[name][3], 1) end
end
local function setBg(f, name)
  local c = C(); local b = f and rawget(f, "_bg")
  if c and b and c[name] and b.SetColorTexture then b:SetColorTexture(c[name][1], c[name][2], c[name][3], 1) end
end
local function round(f, bg, border, r)
  if ns.theme and ns.theme.panel then ns.theme.panel(f, bg, border, r) end
end
local function hms(sec)
  sec = math.floor(sec or 0)
  return ("%d:%02d:%02d"):format(math.floor(sec / 3600), math.floor(sec % 3600 / 60), sec % 60)
end
local function coins(c) return ns.api and ns.api.coins and ns.api.coins(c) or tostring(c) end

------------------------------------------------------------------------
-- État du farm : bulle sous le bouton, pastille Farm (carte quand ça tourne), anneau rouge
------------------------------------------------------------------------
local layoutMenu

local function farmInfo()
  local Gn = ns.gains
  local cur = Gn and Gn.current()
  if not cur then return nil end
  return cur, Gn.rate(cur), Gn.elapsed(cur), Gn.total(cur)
end

local function updateFarm()
  local cur, rate, secs, total = farmInfo()
  if btn then
    if btn.rec then if cur then btn.rec:Show() else btn.rec:Hide() end end
    setBorder(btn, cur and "bad" or "gold")
    local b = btn.bubble
    if b then
      if cur then
        b.fs:SetText("|cffee6a57●|r " .. (rate and (coins(rate) .. "/h") or "or/h dès 60 s"))
        local w = b.fs:GetStringWidth()
        b:SetWidth(math.max(70, (type(w) == "number" and w or 60) + 20))
        b:Show()
      else b:Hide() end
    end
  end
  if menu and menu.farm then
    local f = menu.farm
    if cur then
      f.label:Hide(); f.title:Show(); f.big:Show(); f.side:Show()
      f.big:SetText(rate and (coins(rate) .. "/h") or "dès 60 s")
      f.side:SetText(hms(secs) .. "\nbutin " .. coins(total))
      f:SetSize(CARD_W, CARD_H)
      setBg(f, "badbg"); setBorder(f, "bad")
    else
      f.label:Show(); f.title:Hide(); f.big:Hide(); f.side:Hide()
      f:SetSize(PILL_W, PILL_H); setBg(f, "panel2"); setBorder(f, "line")
    end
    f.rec = cur ~= nil
    if menu:IsShown() and layoutMenu then layoutMenu(0) end
  end
end
ns.launcherFarmRefresh = updateFarm

local function farmToggle()
  local Gn = ns.gains
  if not Gn then return end
  if Gn.current() then
    local s = Gn.stop()
    local r = s and Gn.rate(s)
    chat("Farm arrêté : " .. (s and coins(Gn.total(s)) or "0") .. (r and (" · " .. coins(r) .. "/h") or " (session trop courte)") .. ". Détail : onglet Gains.")
  elseif Gn.start() then
    chat("Farm : enregistrement démarré (" .. Gn.current().zone .. ").")
  end
  updateFarm()
  if ns.gring and ns.gring.refresh and ns.gring.current == "gains" then ns.gring.refresh() end
end

------------------------------------------------------------------------
-- Bouton principal
------------------------------------------------------------------------
local function place()
  btn:ClearAllPoints()
  local pos = GringottsDB and GringottsDB.mini and GringottsDB.mini.pos
  if pos and pos[1] then btn:SetPoint(pos[1], UIParent, pos[2], pos[3], pos[4])
  else btn:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", -230, -230) end
end

-- Le dock monte au-dessus du bouton (descend s'il est trop haut) et s'aligne du côté où il y a de la place
local function dockSide()
  local top, ptop = btn:GetTop(), UIParent:GetTop()
  local up = not (top and ptop and top * btn:GetEffectiveScale() > (ptop - 330) * UIParent:GetEffectiveScale())
  local cx, pw = btn:GetCenter(), UIParent:GetWidth()
  local left = true
  if type(cx) == "number" and type(pw) == "number" then left = cx * btn:GetEffectiveScale() < pw * UIParent:GetEffectiveScale() / 2 end
  return up, left
end

-- shift : décalage d'animation (px) dans le sens d'ouverture
function layoutMenu(shift)
  if not (menu and btn) then return end
  shift = shift or 0
  local up, left = dockSide()
  local n = #menu.pills
  local bubble = (btn.bubble and btn.bubble:IsShown()) and 26 or 0
  local function off(i) if n <= 1 then return 0 end return math.floor(12 * math.sin(math.pi * (i - 1) / (n - 1)) + .5) end
  if up then
    local y = 8 - shift
    for i = n, 1, -1 do
      local p = menu.pills[i]
      p:ClearAllPoints()
      if left then p:SetPoint("BOTTOMLEFT", btn, "TOPLEFT", off(i), y) else p:SetPoint("BOTTOMRIGHT", btn, "TOPRIGHT", -off(i), y) end
      y = y + (p:GetHeight() or PILL_H) + GAP
    end
  else
    local y = -(8 + bubble) + shift
    for i = 1, n do
      local p = menu.pills[i]
      p:ClearAllPoints()
      if left then p:SetPoint("TOPLEFT", btn, "BOTTOMLEFT", off(i), y) else p:SetPoint("TOPRIGHT", btn, "BOTTOMRIGHT", -off(i), y) end
      y = y - (p:GetHeight() or PILL_H) - GAP
    end
  end
end

local function pillScripts(p, tip)
  p:SetScript("OnEnter", function(self) setBorder(self, "gold"); if tip then tip(self) end end)
  p:SetScript("OnLeave", function(self)
    setBorder(self, self.rec and "bad" or "line"); GameTooltip:Hide()
  end)
end

local function buildMenu()
  if ns.pets and ns.pets.isHunter and ns.pets.isHunter() then table.insert(ENTRIES, #ENTRIES, { "Bêtes", "pets", "Interface\\Icons\\Ability_Hunter_BeastCall" }) end
  catcher = CreateFrame("Button", nil, UIParent)
  catcher:SetAllPoints(UIParent); catcher:SetFrameStrata("DIALOG"); catcher:SetFrameLevel(1)
  catcher:RegisterForClicks("AnyUp"); catcher:Hide()
  menu = CreateFrame("Frame", "GringottsMenu", UIParent)
  menu:SetSize(1, 1); menu:SetFrameStrata("DIALOG"); menu:SetFrameLevel(10); menu:SetPoint("CENTER", btn, "CENTER")
  menu.pills = {}
  catcher:SetScript("OnClick", function() menu:Hide() end)
  for i, e in ipairs(ENTRIES) do
    local p = CreateFrame("Button", nil, menu)
    p:SetSize(PILL_W, PILL_H)
    round(p, "panel2", "line", 16)
    p:RegisterForClicks("LeftButtonUp")
    p.icon = p:CreateTexture(nil, "ARTWORK")
    p.icon:SetTexture(e[3]); p.icon:SetSize(24, 24); p.icon:SetPoint("LEFT", p, "LEFT", 8, 0); p.icon:SetTexCoord(.08, .92, .08, .92)
    p.label = p:CreateFontString(nil, "OVERLAY", "GringottsBold")
    p.label:SetPoint("LEFT", p, "LEFT", 40, 0); p.label:SetText(e[1])
    if e[4] == "farm" then
      menu.farm = p
      p.title = p:CreateFontString(nil, "OVERLAY", "GringottsTextSmall")
      p.title:SetPoint("TOPLEFT", p, "TOPLEFT", 40, -8); p.title:SetText("|cfff4a79cFarm · arrêter|r"); p.title:Hide()
      p.big = p:CreateFontString(nil, "OVERLAY", "GringottsValue")
      p.big:SetPoint("BOTTOMLEFT", p, "BOTTOMLEFT", 40, 7); p.big:Hide()
      p.side = p:CreateFontString(nil, "OVERLAY", "GringottsMuted")
      p.side:SetPoint("RIGHT", p, "RIGHT", -12, 0); p.side:SetJustifyH("RIGHT"); p.side:Hide()
      p:SetScript("OnClick", function() menu:Hide(); farmToggle() end)
      pillScripts(p, function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        if self.rec then GameTooltip:SetText("Arrêter l'enregistrement du farm")
        else
          GameTooltip:SetText("Démarrer l'enregistrement du farm")
          GameTooltip:AddLine("Mesure l'or/h de ton butin.", 1, 1, 1)
        end
        GameTooltip:Show()
      end)
    else
      p:SetScript("OnClick", function() menu:Hide(); if ns.uiOpen then ns.uiOpen(e[2]) end end)
      pillScripts(p)
    end
    menu.pills[i] = p
  end
  -- ouverture : fondu + glissement ; fermeture : le rattrapage de clic disparaît avec le dock
  local t = 0
  menu:SetScript("OnShow", function() t = 0; menu:SetAlpha(0); if catcher then catcher:Show() end end)
  menu:SetScript("OnHide", function() if catcher then catcher:Hide() end; GameTooltip:Hide() end)
  menu:SetScript("OnUpdate", function(_, dt)
    if t >= FADE then return end
    t = t + (dt or 0)
    local p = math.min(1, t / FADE)
    menu:SetAlpha(p)
    layoutMenu((1 - p) * 10)
  end)
  menu:Hide()
  updateFarm()
  if UISpecialFrames then tinsert(UISpecialFrames, "GringottsMenu") end
end

local function toggleMenu()
  if not menu then buildMenu() end
  if menu:IsShown() then menu:Hide() return end
  updateFarm()
  layoutMenu(10)
  menu:Show()
end

local function build()
  btn = CreateFrame("Button", "GringottsMinimapButton", UIParent)
  btn:SetSize(MAIN, MAIN)
  btn:SetFrameStrata("MEDIUM"); btn:SetFrameLevel(8)
  btn:SetMovable(true); btn:SetClampedToScreen(true)
  btn:RegisterForClicks("LeftButtonUp")
  btn:RegisterForDrag("LeftButton")
  round(btn, "panel2", "gold", 18)
  btn.seal = btn:CreateTexture(nil, "ARTWORK")
  btn.seal:SetTexture(SEAL); btn.seal:SetSize(MAIN * .66, MAIN * .66); btn.seal:SetPoint("CENTER", 0, 0)
  -- pastille rouge : farm en cours d'enregistrement
  btn.rec = btn:CreateTexture(nil, "OVERLAY", nil, 7)
  btn.rec:SetTexture("Interface\\Minimap\\UI-Minimap-Background"); btn.rec:SetVertexColor(.93, .2, .17, 1)
  btn.rec:SetSize(13, 13); btn.rec:SetPoint("TOPRIGHT", btn, "TOPRIGHT", 4, 4); btn.rec:Hide()
  -- bulle d'or/h sous le bouton, visible tant que le farm tourne
  btn.bubble = CreateFrame("Frame", nil, btn)
  btn.bubble:SetSize(90, 22); btn.bubble:SetPoint("TOP", btn, "BOTTOM", 0, -4)
  round(btn.bubble, "bg", "bad", 10)
  btn.bubble.fs = btn.bubble:CreateFontString(nil, "OVERLAY", "GringottsBold")
  btn.bubble.fs:SetPoint("CENTER", 0, 0)
  btn.bubble:Hide()
  btn:SetScript("OnClick", toggleMenu)
  btn:SetScript("OnDragStart", function(self) if menu then menu:Hide() end self:StartMoving() end)
  btn:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
    local p, _, rp, x, y = self:GetPoint()
    GringottsDB.mini = GringottsDB.mini or {}
    GringottsDB.mini.pos = { p, rp, x, y }
  end)
  btn:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_LEFT")
    GameTooltip:SetText("Gringotts"); GameTooltip:AddLine("Clic : ouvrir le menu · glisser : déplacer", 1, 1, 1)
    GameTooltip:Show()
  end)
  btn:SetScript("OnLeave", function() GameTooltip:Hide() end)
  -- relevé chaque seconde tant qu'un farm tourne (bulle et carte)
  local acc = 0
  btn:SetScript("OnUpdate", function(_, dt)
    acc = acc + (dt or 0)
    if acc >= 1 then acc = 0; if ns.gains and ns.gains.current() then updateFarm() end end
  end)
  place()
  updateFarm()
  if ns.launcherApply then ns.launcherApply() end
  if GringottsDB.mini and GringottsDB.mini.hidden then btn:Hide() end
end

function ns.launcherApply()
  if not btn then return end
  local sc = ((GringottsDB.mini and GringottsDB.mini.scale) or 100) / 100
  sc = math.max(.6, math.min(1.6, sc))
  btn:SetScale(sc)
  if menu then menu:SetScale(sc) end
end

function ns.launcherCmd()
  if not btn then return end
  if menu then menu:Hide() end
  GringottsDB.mini = GringottsDB.mini or {}
  GringottsDB.mini.hidden = not GringottsDB.mini.hidden
  if GringottsDB.mini.hidden then btn:Hide() else btn:Show() end
end

function ns.launcherShow(on)
  if not btn then return end
  GringottsDB.mini = GringottsDB.mini or {}
  GringottsDB.mini.hidden = not on
  if on then btn:Show() else btn:Hide() end
end
function ns.launcherReset()
  if not btn then return end
  GringottsDB.mini = GringottsDB.mini or {}
  GringottsDB.mini.pos = nil; GringottsDB.mini.hidden = false
  btn:Show(); place()
end

local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", function()
  GringottsDB = GringottsDB or {}
  build()
end)
