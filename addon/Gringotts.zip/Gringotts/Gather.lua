-- Gringotts : récolte. Plantes et minerais : couleur selon ton skill, plantes suivies, filtres réglés dans GatherMate2.
-- Le suivi passe par GatherMate2.db.profile.filter[type][nodeID] (même table que ses options « Herb filter » / « Mining filter »).
local ADDON, ns = ...
local G = {}
ns.gather = G

local function db() return ns.api and ns.api.db() end
local function norm(s) return ns.norm(s or "") end
local function flat(s) return (norm(s):gsub("[^%w]", "")) end

------------------------------------------------------------------------
-- Skills lus en jeu (Core les stocke dans chars[x].skills[nom localisé])
------------------------------------------------------------------------
local SK = { herb = { "herboristerie", "herbalism" }, mine = { "minage", "mining" }, fish = { "peche", "fishing" }, cook = { "cuisine", "cooking" } }
-- Renvoie niveau, max, vrai si c'est le personnage connecté. Sinon le meilleur niveau de tous les personnages.
function ns.skillOf(kind)
  local d = db(); if not d then return 0, 0, false end
  if ns.scanSkills and GetTime and (ns._skT or 0) < GetTime() - 0.5 then ns._skT = GetTime(); pcall(ns.scanSkills) end   -- relecture en direct (max 2 fois / s)
  local want = {}
  for _, a in ipairs(SK[kind] or {}) do want[a] = true end
  local me = UnitName and UnitName("player")
  local lvl, max, mine = 0, 0, nil
  for _, c in pairs(d.chars or {}) do
    for name, s in pairs(c.skills or {}) do
      if want[norm(name)] and s.l then
        if c.name == me and (not mine or (s.t or 0) > (mine.t or 0) or ((s.t or 0) == (mine.t or 0) and s.l > mine.l)) then mine = s end   -- plusieurs clés possibles : la plus récente gagne
        if s.l > lvl then lvl, max = s.l, s.m or 0 end
      end
    end
  end
  if mine then return mine.l, mine.m or 0, true end
  return lvl, max, false
end

------------------------------------------------------------------------
-- Données : plantes et minerais (noms FR du dashboard / client frFR, noms EN, skill requis)
------------------------------------------------------------------------
G.kinds = {
  herb = { type = "Herb Gathering", label = "Herboristerie", noun = "plante", list = {
    { fr = "Pacifique", en = "Peacebloom", req = 1 },
    { fr = "Feuillargent", en = "Silverleaf", req = 1 },
    { fr = "Terrestrine", en = "Earthroot", req = 15 },
    { fr = "Mage royal", en = "Mageroyal", req = 50 },
    { fr = "Églantine", en = "Briarthorn", req = 70 },
    { fr = "Étouffante", en = "Stranglekelp", req = 85, alt = { "Varech d'étrangleronce" } },
    { fr = "Doulourante", en = "Bruiseweed", req = 100 },
    { fr = "Aciérite sauvage", en = "Wild Steelbloom", req = 115 },
    { fr = "Tombeline", en = "Grave Moss", req = 120 },
    { fr = "Sang-royal", en = "Kingsblood", req = 125 },
    { fr = "Vietérule", en = "Liferoot", req = 150 },
    { fr = "Pâlerette", en = "Fadeleaf", req = 160 },
    { fr = "Dorépine", en = "Goldthorn", req = 170 },
    { fr = "Moustache de Khadgar", en = "Khadgar's Whisker", req = 185 },
    { fr = "Hivernale", en = "Wintersbite", req = 195 },
    { fr = "Fleur de feu", en = "Firebloom", req = 205 },
    { fr = "Lotus pourpre", en = "Purple Lotus", req = 210 },
    { fr = "Larmes d'Arthas", en = "Arthas' Tears", req = 220 },
    { fr = "Soleillette", en = "Sungrass", req = 230 },
    { fr = "Aveuglette", en = "Blindweed", req = 235 },
    { fr = "Champignon fantôme", en = "Ghost Mushroom", req = 245 },
    { fr = "Gromsang", en = "Gromsblood", req = 250 },
    { fr = "Sansam doré", en = "Golden Sansam", req = 260 },
    { fr = "Feuillerêve", en = "Dreamfoil", req = 270 },
    { fr = "Sauge-argent des montagnes", en = "Mountain Silversage", req = 280 },
    { fr = "Fleur de peste", en = "Plaguebloom", req = 285 },
    { fr = "Calot de glace", en = "Icecap", req = 290 },
    { fr = "Lotus noir", en = "Black Lotus", req = 300 },
  } },
  mine = { type = "Mining", label = "Minage", noun = "minerai", list = {
    { fr = "Filon de cuivre", en = "Copper Vein", req = 1 },
    { fr = "Filon d'étain", en = "Tin Vein", req = 65 },
    { fr = "Filon d'argent", en = "Silver Vein", req = 75 },
    { fr = "Gisement de fer", en = "Iron Deposit", req = 125 },
    { fr = "Filon d'or", en = "Gold Vein", req = 155 },
    { fr = "Gisement de mithril", en = "Mithril Deposit", req = 175 },
    { fr = "Gisement de vrai-argent", en = "Truesilver Deposit", req = 230 },
    { fr = "Petit filon de thorium", en = "Small Thorium Vein", req = 245 },
    { fr = "Riche filon de thorium", en = "Rich Thorium Vein", req = 275 },
  } },
}
G.order = { "herb", "mine" }

-- Seuils de couleur (règle générale des plantes) : orange dès le skill requis, jaune +25, vert +50, gris +100
G.COLORS = { orange = "orange", yellow = "jaune", green = "vert", gray = "gris", locked = "pas encore" }
function G.color(req, skill)
  local d = (skill or 0) - req
  if d < 0 then return "locked" end
  if d >= 100 then return "gray" elseif d >= 50 then return "green" elseif d >= 25 then return "yellow" end
  return "orange"
end

------------------------------------------------------------------------
-- Réglages (SavedVariables) : db.gather = { only, level, green, herb = {en = true}, mine = {...} }
------------------------------------------------------------------------
function G.st()
  local d = db(); if not d then return { herb = {}, mine = {} } end
  d.gather = d.gather or {}
  local s = d.gather
  s.herb = s.herb or {}; s.mine = s.mine or {}
  return s
end

function G.status(kind, e, skill)
  local s = G.st()
  skill = skill or ns.skillOf(kind)
  local col = G.color(e.req, skill)
  local climbs = col == "orange" or col == "yellow" or (col == "green" and s.green == true)
  local checked = s[kind][e.en] == true
  local followed = checked and (not s.level or climbs)
  return col, climbs, followed, checked
end

function G.setChecked(kind, en, on) G.st()[kind][en] = on and true or nil end
function G.checkAll(kind, on) for _, e in ipairs(G.kinds[kind].list) do G.setChecked(kind, e.en, on) end end
function G.checkClimbing(kind)
  local skill = ns.skillOf(kind)
  local s = G.st()
  for _, e in ipairs(G.kinds[kind].list) do
    local col = G.color(e.req, skill)
    s[kind][e.en] = (col == "orange" or col == "yellow" or (col == "green" and s.green == true)) or nil
  end
end

-- Noms des plantes suivies (pour le résumé)
function G.followedNames(kind)
  local out, skill = {}, ns.skillOf(kind)
  for _, e in ipairs(G.kinds[kind].list) do
    local _, _, followed = G.status(kind, e, skill)
    if followed then out[#out + 1] = e.fr end
  end
  return out
end

------------------------------------------------------------------------
-- GatherMate2
------------------------------------------------------------------------
local function gm() return LibStub and LibStub("AceAddon-3.0", true) and LibStub("AceAddon-3.0"):GetAddon("GatherMate2", true) or nil end
G.gm = gm
-- GatherMate2 range ses zones sous une clé qui peut être le numéro de carte (nombre ou texte) ou le NOM de la zone selon la version
local nameMap
local function flatName(s) return (tostring(s):lower():gsub("[%s%p]", "")) end
function G.nameToMap(name)
  if not nameMap then
    nameMap = {}
    if C_Map and C_Map.GetMapInfo then
      for id = 1, 3000 do
        local ok, info = pcall(C_Map.GetMapInfo, id)
        if ok and info and info.name and (info.mapType == 3 or info.mapType == 4) then
          local f = flatName(info.name)
          if not nameMap[f] then nameMap[f] = id end
        end
      end
    end
  end
  return nameMap[flatName(name)]
end
function G.zoneOfKey(key) return tonumber(key) or G.nameToMap(key) end
local keyCache = setmetatable({}, { __mode = "k" })
local function zoneKeyIn(dbs, zone)
  if type(dbs) ~= "table" then return zone end
  if dbs[zone] ~= nil then return zone end
  if dbs[tostring(zone)] ~= nil then return tostring(zone) end
  local c = keyCache[dbs]; if not c then c = {}; keyCache[dbs] = c end
  if c[zone] == nil then
    c[zone] = false
    for k in pairs(dbs) do if G.zoneOfKey(k) == zone then c[zone] = k; break end end
  end
  return c[zone] or zone
end
function G.zoneKey(GM, zone, ty) return zoneKeyIn(GM.gmdbs and GM.gmdbs[ty], zone) end

-- Base fournie par l'addon GatherMate2_Data (chargé à la demande) : lue directement, sans l'importer dans ta base
local dataLoaded, dataDBs = false, {}
local DATA_NAMES = { ["Herb Gathering"] = { "GatherMateData2HerbDB", "GatherMate2HerbData", "GatherMateHerbData" }, ["Mining"] = { "GatherMateData2MineDB", "GatherMate2MineData", "GatherMateMineData" } }
function G.dataDB(ty)
  if not dataLoaded then
    dataLoaded = true
    local load = (C_AddOns and C_AddOns.LoadAddOn) or LoadAddOn
    if load then pcall(load, "GatherMate2_Data"); pcall(load, "GatherMate2Data"); pcall(load, "GatherMateData") end
  end
  if dataDBs[ty] == nil then
    dataDBs[ty] = false
    for _, n in ipairs(DATA_NAMES[ty] or {}) do
      if type(_G[n]) == "table" then dataDBs[ty] = _G[n]; break end
    end
    if not dataDBs[ty] then   -- repli : un global GatherMate*Data* contenant « Herb » / « Mine »
      local want = (ty == "Herb Gathering") and "herb" or "mine"
      for name, v in pairs(_G) do
        if type(name) == "string" and type(v) == "table" then
          local l = name:lower()
          if l:find("gathermate") and l:find("data") and l:find(want) and not l:find("^gathermate2herbdb$") and not l:find("^gathermate2minedb$") then dataDBs[ty] = v; break end
        end
      end
    end
  end
  return dataDBs[ty] or nil
end

-- Points d'une zone : ta base GatherMate2 + la base fournie (dédoublonnés par position)
function G.nodes(GM, zone, ty)
  local list, seen = {}, {}
  local okI, iter, a1, a2 = pcall(GM.GetNodesForZone, GM, G.zoneKey(GM, zone, ty), ty)
  if okI and type(iter) == "function" then
    for coord, id in iter, a1, a2 do if not seen[coord] then seen[coord] = true; list[#list + 1] = { coord, id } end end
  end
  local d = G.dataDB(ty)
  if d then
    local t = d[zoneKeyIn(d, zone)]
    if type(t) == "table" then for coord, id in pairs(t) do if not seen[coord] then seen[coord] = true; list[#list + 1] = { coord, id } end end end
  end
  local i = 0
  return function() i = i + 1; local e = list[i]; if e then return e[1], e[2] end end
end

-- id GatherMate2 d'une entrée : on teste le nom FR, ses variantes et le nom EN, sans accents ni ponctuation
local function resolveIDs(GM, kind)
  local k = G.kinds[kind]
  local ids = GM.nodeIDs and GM.nodeIDs[k.type]
  if type(ids) ~= "table" then return nil end
  local byFlat = {}
  for name, id in pairs(ids) do if type(name) == "string" then byFlat[flat(name)] = id end end
  local out = {}
  for _, e in ipairs(k.list) do
    local id = byFlat[flat(e.fr)] or byFlat[flat(e.en)]
    if not id and e.alt then for _, a in ipairs(e.alt) do id = id or byFlat[flat(a)] end end
    if id then out[e.en] = id end
  end
  return out
end

-- Index inverse : type -> nodeID -> entrée (pour la flèche)
local rev
function G.reverse()
  if rev then return rev end
  local GM = gm(); if not GM then return nil end
  local r = {}
  for _, kind in ipairs(G.order) do
    local ids = resolveIDs(GM, kind)
    if ids then
      local t = {}
      for _, e in ipairs(G.kinds[kind].list) do if ids[e.en] then t[ids[e.en]] = { kind = kind, e = e } end end
      r[G.kinds[kind].type] = t
    end
  end
  rev = r
  return r
end

-- Règle les filtres de GatherMate2 : suivies = affichées, les autres masquées (si « suivre uniquement mes plantes cochées »)
function G.apply()
  local GM = gm()
  if not GM then return false, "GatherMate2 introuvable" end
  local prof = GM.db and GM.db.profile
  if not (prof and type(prof.filter) == "table") then return false, "réglages GatherMate2 illisibles" end
  local s, n = G.st(), 0
  for _, kind in ipairs(G.order) do
    local type_ = G.kinds[kind].type
    local ids = resolveIDs(GM, kind)
    if ids then
      prof.filter[type_] = prof.filter[type_] or {}
      local skill = ns.skillOf(kind)
      for _, e in ipairs(G.kinds[kind].list) do
        local id = ids[e.en]
        if id then
          local _, _, followed = G.status(kind, e, skill)
          prof.filter[type_][id] = (not s.only) or followed
          n = n + 1
        end
      end
    end
  end
  -- GatherMate2 redessine la carte et la minimap sur ce message (même appel que ses options)
  if GM.SendMessage then pcall(GM.SendMessage, GM, "GatherMate2ConfigChanged") end
  local C = GM.GetModule and GM:GetModule("Config", true)
  if C and C.UpdateConfig then pcall(C.UpdateConfig, C) end
  G.lastApply = n
  return true, n
end

-- Réglages d'affichage de GatherMate2 relayés depuis Gringotts (mêmes champs que ses options, db.profile.*)
-- trackDistance 50-240 m · scale (icônes carte) et miniscale (icônes minimap) 0,5-5 · alpha (carte) 0,1-1 · showMinimap / showWorldMap · trackShow
-- GatherMate2 n'a aucune option de son : l'alerte sonore est dans la flèche de Gringotts.
G.GMRANGE = { trackDistance = { 50, 240 }, scale = { .5, 5 }, miniscale = { .5, 5 }, alpha = { .1, 1 } }
G.TRACKSHOW = { "always", "with_profession", "active", "never" }
G.TRACKSHOW_FR = { always = "Toujours", with_profession = "Avec la profession", active = "Pistage actif", never = "Jamais" }

local function gmNotify(GM)
  if GM.SendMessage then pcall(GM.SendMessage, GM, "GatherMate2ConfigChanged") end
  local C = GM.GetModule and GM:GetModule("Config", true)
  if C and C.UpdateConfig then pcall(C.UpdateConfig, C) end
end

function G.gmGet(field)
  local GM = gm(); local p = GM and GM.db and GM.db.profile
  return p and p[field]
end

function G.gmSet(field, v)
  local GM = gm(); local p = GM and GM.db and GM.db.profile
  if not p then return false, "GatherMate2 introuvable" end
  local r = G.GMRANGE[field]
  if r then
    v = tonumber(v)
    if not v or v < r[1] or v > r[2] then return false, ("valeur entre %s et %s"):format(r[1], r[2]) end
  elseif field == "trackShow" then
    local ok = false; for _, x in ipairs(G.TRACKSHOW) do if x == v then ok = true end end
    if not ok then return false, "valeur inconnue" end
  elseif field == "showMinimap" or field == "showWorldMap" then v = v and true or false
  else return false, "réglage non relayé" end
  p[field] = v
  gmNotify(GM)
  return true
end

function G.gmCycleTrackShow()
  local cur = G.gmGet("trackShow") or "always"
  local nxt = G.TRACKSHOW[1]
  for i, x in ipairs(G.TRACKSHOW) do if x == cur then nxt = G.TRACKSHOW[i % #G.TRACKSHOW + 1] end end
  return G.gmSet("trackShow", nxt), nxt
end

-- Info sur un point de la carte (pour la flèche) : nil si inconnu
function G.nodeInfo(typeName, nodeID)
  local r = G.reverse(); local t = r and r[typeName]; local x = t and t[nodeID]
  if not x then return nil end
  local col, climbs, followed = G.status(x.kind, x.e)
  return { kind = x.kind, entry = x.e, color = col, climbs = climbs, followed = followed or not G.st().only }
end


-- Meilleures zones : points GatherMate2 par zone, pondérés par la couleur (orange 3, jaune 2, vert 1 si « inclure les vertes »).
-- Compte tous les points connus de plantes qui te font monter, qu'elles soient cochées ou non. Résultat mis en cache par état du skill.
local zoneCache = {}
local function zoneName(z)
  local ok, info = pcall(function() return C_Map and C_Map.GetMapInfo and C_Map.GetMapInfo(z) end)
  if ok and info and info.name then return info.name, info.mapType end
  return tostring(z), nil
end
function G.bestZones(kind, limit)
  local GM = gm(); if not GM then return nil end
  local k = G.kinds[kind]; if not k then return nil end
  local skill = ns.skillOf(kind)
  local s = G.st()
  local sig = {}
  for en in pairs(s[kind] or {}) do sig[#sig + 1] = en end
  table.sort(sig)
  local key = kind .. ":" .. skill .. ":" .. tostring(s.green == true) .. ":" .. tostring(s.level == true) .. ":" .. table.concat(sig, ",")
  if zoneCache[key] then return zoneCache[key] end
  local dbs = GM.gmdbs and GM.gmdbs[k.type]
  if type(dbs) ~= "table" then dbs = _G[kind == "herb" and "GatherMate2HerbDB" or "GatherMate2MineDB"] end
  if type(dbs) ~= "table" then dbs = {} end
  local out = {}
  local st = { zones = 0, raw = 0, known = 0, climb = 0, rawdb = 0, mapfilter = 0 }
  G.zoneStats = st
  local zset = {}
  for zkey, zt in pairs(dbs) do local z = G.zoneOfKey(zkey); if z then zset[z] = zt end end
  local dd = G.dataDB(k.type)
  if dd then for zkey, zt in pairs(dd) do local z = G.zoneOfKey(zkey); if z and not zset[z] then zset[z] = zt end end end
  for zone, zt in pairs(zset) do
    if zone then
      st.zones = st.zones + 1
      if type(zt) == "table" then for _ in pairs(zt) do st.rawdb = st.rawdb + 1 end end
      local score, n = 0, 0
      local by = {}
      local okI, iter, a1, a2 = pcall(G.nodes, GM, zone, k.type)
      local f1, s1, c1 = function() end, nil, nil
      if okI and type(iter) == "function" then f1, s1, c1 = iter, a1, a2 end
      for _, nodeID in f1, s1, c1 do
        st.raw = st.raw + 1
        local info = G.nodeInfo(k.type, nodeID)
        if info then st.known = st.known + 1; if info.climbs then st.climb = st.climb + 1 end end
        if info and info.climbs and info.followed then   -- seulement tes plantes cochées (et retenues par le filtre montée)
          local w = (info.color == "orange" and 3) or (info.color == "yellow" and 2) or 1
          score = score + w; n = n + 1
          by[info.entry.fr] = (by[info.entry.fr] or 0) + 1
        end
      end
      if n > 0 then
        local name, mt = zoneName(zone)
        if mt == nil or mt == 3 or mt == 4 then out[#out + 1] = { zone = zone, name = name, score = score, n = n, by = by } else st.mapfilter = st.mapfilter + 1 end
      end
    end
  end
  table.sort(out, function(a, b) return a.score > b.score end)
  zoneCache[key] = out
  return out
end


------------------------------------------------------------------------
-- Parcours de farm : boucle calculée dans une zone (points denses de plantes utiles, plus proche voisin puis 2-opt)
------------------------------------------------------------------------
local function hbd() return LibStub and LibStub("HereBeDragons-2.0", true) end
local ROUTE_SPEED = 7        -- m/s à pied (estimation) ; réglable par GringottsDB.arrow.speed
local ROUTE_PICK = 4         -- s par cueillette (lancer + butin)
local function dist(a, b, w, h) local dx, dy = (a.x - b.x) * w, (a.y - b.y) * h; return math.sqrt(dx * dx + dy * dy) end

local function tourLength(t, w, h)
  local L = 0
  for i = 1, #t do L = L + dist(t[i], t[i % #t + 1], w, h) end
  return L
end
local function twoOpt(t, w, h)
  local n = #t
  if n < 4 then return t end
  local improved, guard = true, 0
  while improved and guard < 60 do
    improved = false; guard = guard + 1
    for i = 1, n - 2 do
      for j = i + 1, n - 1 do
        local a, b, c, d = t[i], t[i + 1], t[j], t[j + 1]
        local delta = dist(a, c, w, h) + dist(b, d, w, h) - dist(a, b, w, h) - dist(c, d, w, h)
        if delta < -0.5 then
          local lo, hi = i + 1, j
          while lo < hi do t[lo], t[hi] = t[hi], t[lo]; lo = lo + 1; hi = hi - 1 end
          improved = true
        end
      end
    end
  end
  return t
end

-- kind : "herb" | "mine" ; zone : uiMapID ; px, py : position de départ (0-1) ou nil ; opts.max : nombre de points (défaut 30)
function G.buildRoute(kind, zone, px, py, opts)
  opts = opts or {}
  local GM, HBD = gm(), hbd()
  if not (GM and HBD) then return nil, "GatherMate2 / HereBeDragons introuvable" end
  local k = G.kinds[kind]; if not k then return nil, "type inconnu" end
  local w, h = HBD:GetZoneSize(zone)
  if not (w and w > 0) then return nil, "taille de zone inconnue" end
  local pts = {}
  local P = ns.prices
  for coord, nodeID in G.nodes(GM, zone, k.type) do
    local info = G.nodeInfo(k.type, nodeID)
    if info and info.climbs and info.followed then
      local x, y = GM:DecodeLoc(coord)
      local wt = (info.color == "orange" and 3) or (info.color == "yellow" and 2) or 1
      local price
      if P and P.price then local okp, v = pcall(P.price, info.entry.fr, nil); if okp and type(v) == "number" then price = v end end
      pts[#pts + 1] = { x = x, y = y, wt = wt, name = info.entry.fr, color = info.color, key = zone .. ":" .. coord, type = k.type, price = price }
    end
  end
  if #pts < 3 then return nil, "pas assez de points connus dans cette zone pour tes plantes (" .. #pts .. ")" end
  -- densité : somme des poids des voisins à moins de 120 m
  for _, p in ipairs(pts) do
    local s = 0
    for _, q in ipairs(pts) do if q ~= p and dist(p, q, w, h) <= 120 then s = s + q.wt end end
    p.dens = s + p.wt
  end
  table.sort(pts, function(a, b) return a.dens > b.dens end)
  local seed = pts[1]
  -- Boucle optimisée : insertion la moins chère point après point, tant que le détour reste rentable
  -- (au lieu d'un nombre fixe de points)
  local speed0 = (GringottsDB and GringottsDB.arrow and GringottsDB.arrow.speed) or ROUTE_SPEED
  local maxN = opts.max or 250
  local maxSecs = opts.maxSecs or 1500      -- ≈ 25 min de boucle
  local maxMarg = opts.maxMarg or 30        -- s : un détour qui coûte plus que ça pour une plante n'est pas rentable
  local cand = {}
  for i, p in ipairs(pts) do if p ~= seed then cand[#cand + 1] = p end end
  local tourC = { seed }
  local L = 0
  -- coût d'insertion minimal de chaque candidat dans la boucle courante
  local function bestIns(p)
    local n = #tourC
    if n == 1 then return 2 * dist(p, tourC[1], w, h), 1 end
    local bc, bp = math.huge, 1
    for i = 1, n do
      local a, b = tourC[i], tourC[i % n + 1]
      local c = dist(a, p, w, h) + dist(p, b, w, h) - dist(a, b, w, h)
      if c < bc then bc, bp = c, i end
    end
    return bc, bp
  end
  for _, p in ipairs(cand) do p.ic, p.ip = bestIns(p) end
  while #cand > 0 and #tourC < maxN do
    local bi, bs = 1, math.huge
    for i, p in ipairs(cand) do local s = p.ic / p.wt; if s < bs then bi, bs = i, s end end
    local p = cand[bi]
    local nn = #tourC
    -- arrêt : détour trop long pour une seule plante, ou boucle plus longue que le budget (repousse des plantes)
    local marg = p.ic / speed0 + ROUTE_PICK
    if nn >= 8 and marg > maxMarg then break end
    if (L + p.ic) / speed0 + (nn + 1) * ROUTE_PICK > maxSecs then break end
    table.insert(tourC, p.ip + 1, p); L = L + p.ic
    cand[bi] = cand[#cand]; cand[#cand] = nil
    -- mise à jour des coûts : on recalcule si la meilleure position a changé, sinon on compare aux 2 nouvelles arêtes
    local n2 = #tourC
    local ip = p.ip
    if n2 <= 3 then
      for _, q in ipairs(cand) do q.ic, q.ip = bestIns(q) end
    else
      local A, Pn, B = tourC[ip], p, tourC[(ip + 1) % n2 + 1]
      for _, q in ipairs(cand) do
        if q.ip == ip then q.ic, q.ip = bestIns(q)          -- son arête a été coupée
        else
          if q.ip > ip then q.ip = q.ip + 1 end            -- décalage d'index
          local c1 = dist(A, q, w, h) + dist(q, Pn, w, h) - dist(A, Pn, w, h)
          if c1 < q.ic then q.ic, q.ip = c1, ip end
          local c2 = dist(Pn, q, w, h) + dist(q, B, w, h) - dist(Pn, B, w, h)
          if c2 < q.ic then q.ic, q.ip = c2, ip + 1 end
        end
      end
    end
  end
  local tour = tourC
  if #tour < 3 then return nil, "pas assez de points connus dans cette zone pour tes plantes (" .. #tour .. ")" end
  twoOpt(tour, w, h)
  -- la boucle démarre au point le plus proche du joueur
  if px and py then
    local bi, bd = 1, math.huge
    for i, p in ipairs(tour) do local d = dist({ x = px, y = py }, p, w, h); if d < bd then bi, bd = i, d end end
    if bi > 1 then
      local rot = {}
      for i = 0, #tour - 1 do rot[#rot + 1] = tour[(bi - 1 + i) % #tour + 1] end
      tour = rot
    end
  end
  local L = tourLength(tour, w, h)
  local speed = (GringottsDB and GringottsDB.arrow and GringottsDB.arrow.speed) or ROUTE_SPEED
  local secs = L / speed + #tour * ROUTE_PICK
  local value, priced = 0, 0
  for _, p in ipairs(tour) do if p.price then value = value + p.price; priced = priced + 1 end end
  local name = (C_Map and C_Map.GetMapInfo and C_Map.GetMapInfo(zone) or {}).name or tostring(zone)
  return { zone = zone, zoneName = name, pts = tour, length = L, secs = secs, perHour = #tour / secs * 3600,
           valueLap = priced > 0 and value or nil, valueHour = priced > 0 and value / secs * 3600 or nil, w = w, h = h, kind = kind }
end

-- Lance un parcours : which = "best" (meilleure zone du classement) ou "here" (zone actuelle)
function G.startRoute(kind, which, idx)
  local HBD = hbd()
  local px, py, zone
  if HBD then px, py, zone = HBD:GetPlayerZonePosition() end
  if which == "best" then
    local z = G.bestZones(kind)
    if z == nil then return false, "GatherMate2 requis (ou aucune donnée de points)" end
    if not z[1] then return false, "aucune de tes plantes cochées n'a de point connu qui te fasse monter (coche-en d'autres, ou « Cocher celles qui font monter »)" end
    local lastErr
    local from, to = 1, math.min(#z, 6)
    if idx then
      if idx < 1 or idx > #z then return false, ("zone n°%d inexistante (le classement en compte %d)"):format(idx, #z) end
      from, to = idx, idx
    end
    for i = from, to do
      local px2, py2 = px, py
      if zone ~= z[i].zone then px2, py2 = nil, nil end
      local plan, err = G.buildRoute(kind, z[i].zone, px2, py2)
      if plan then
        if not ns.arrowRoute then return false, "module flèche non chargé" end
        ns.arrowRoute(plan); return true, plan
      end
      lastErr = err
    end
    return false, lastErr or "aucun parcours possible"
  elseif not zone then return false, "position inconnue (zone sans carte)" end
  local plan, err = G.buildRoute(kind, zone, px, py)
  if not plan then return false, err end
  if not ns.arrowRoute then return false, "module flèche non chargé" end
  ns.arrowRoute(plan)
  return true, plan
end

function ns.routeCmd(arg)
  arg = (arg or ""):lower()
  local function say(m) print("|cffe4b84eGringotts|r " .. m) end
  if arg:match("^stop") or arg:match("^arr") then if ns.arrowRouteStop then ns.arrowRouteStop() end return end
  local kind = (arg:find("min") and "mine") or "herb"
  local ok, r = G.startRoute(kind, arg:find("ici") and "here" or "best")
  if not ok then say("Parcours impossible : " .. tostring(r)) end
end

-- Types de points à parcourir pour la flèche : herbes par défaut, minerais si au moins un minerai est coché
function G.arrowTypes()
  local out, s = { G.kinds.herb.type }, G.st()
  if next(s.mine) then out[#out + 1] = G.kinds.mine.type end
  return out
end

-- Réapplique à la connexion et quand le skill monte (les couleurs changent)
local ev = CreateFrame("Frame")
for _, e in ipairs({ "PLAYER_LOGIN", "CHAT_MSG_SKILL", "SKILL_LINES_CHANGED" }) do pcall(ev.RegisterEvent, ev, e) end
local pending
ev:SetScript("OnEvent", function(_, e)
  if pending then return end
  pending = true
  local function go() pending = nil; rev = nil; if G.st().only then pcall(G.apply) end; if ns.gatherUI and ns.gatherUI.refresh then pcall(ns.gatherUI.refresh) end end
  if C_Timer and C_Timer.After then C_Timer.After(e == "PLAYER_LOGIN" and 5 or 1.5, go) else go() end
end)


-- /gt gathermate : état de GatherMate2 vu par l'addon (diagnostic)
function G.diag()
  local function say(m) print("|cffe4b84eGringotts|r " .. m) end
  local GM = gm()
  say("GatherMate2 : " .. (GM and "trouvé" or "introuvable") .. " · HereBeDragons : " .. (hbd() and "oui" or "non"))
  if not GM then return end
  say("API : gmdbs=" .. type(GM.gmdbs) .. " nodeIDs=" .. type(GM.nodeIDs) .. " GetNodesForZone=" .. type(GM.GetNodesForZone) .. " DecodeLoc=" .. type(GM.DecodeLoc))
  for _, kind in ipairs(G.order) do
    local k = G.kinds[kind]
    local dbs = GM.gmdbs and GM.gmdbs[k.type]
    local nz, nn, kt, samp = 0, 0, {}, {}
    if type(dbs) == "table" then
      for z, t in pairs(dbs) do nz = nz + 1; kt[type(z)] = true; if #samp < 4 then samp[#samp + 1] = tostring(z) end; if type(t) == "table" then for _ in pairs(t) do nn = nn + 1 end end end
    end
    local ids = GM.nodeIDs and GM.nodeIDs[k.type]
    local ni = 0; if type(ids) == "table" then for _ in pairs(ids) do ni = ni + 1 end end
    local kk = {}; for t in pairs(kt) do kk[#kk + 1] = t end
    say(("%s : base=%s · %d zones · %d points · types de clés {%s} · %d noms de points · clés : %s"):format(k.label, type(dbs), nz, nn, table.concat(kk, ","), ni, table.concat(samp, ", ")))
  end
  local isl = (C_AddOns and C_AddOns.IsAddOnLoaded) or IsAddOnLoaded
  local function loaded(n) local ok, v = pcall(isl, n); return ok and v and "chargé" or "non chargé" end
  say("Addon GatherMate2_Data : " .. loaded("GatherMate2_Data"))
  for _, kind in ipairs(G.order) do
    local d = G.dataDB(G.kinds[kind].type); local nz, nn = 0, 0
    if d then for _, t in pairs(d) do nz = nz + 1; if type(t) == "table" then for _ in pairs(t) do nn = nn + 1 end end end end
    say(("Base fournie %s : %s · %d zones · %d points"):format(G.kinds[kind].label, d and "trouvée" or "introuvable", nz, nn))
  end
  local found = {}
  for name, v in pairs(_G) do if type(name) == "string" and name:lower():find("gathermate") and type(v) == "table" then found[#found + 1] = name end end
  table.sort(found); say("Globaux GatherMate* : " .. (#found > 0 and table.concat(found, ", ") or "aucun"))
  for _, n in ipairs({ "GatherMate2HerbDB", "GatherMate2MineDB", "GatherMateData2HerbDB", "GatherMateData2MineDB" }) do
    local t = _G[n]; local c = 0
    if type(t) == "table" then for _ in pairs(t) do c = c + 1 end end
    say(n .. " : " .. type(t) .. (type(t) == "table" and (" · " .. c .. " entrées") or ""))
  end
end
