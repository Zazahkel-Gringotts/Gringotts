-- Gringotts : swing timer du Tir automatique (chasseur uniquement).
-- La barre se remplit sur la vitesse de l'arme à distance. Dans les dernières 0,5 s (la visée) elle change de couleur :
-- il ne faut plus bouger, sinon le tir est annulé. Si tu bouges pendant la visée : flash rouge, la barre revient au début de la visée.
-- /gt tir : on | off | taille L H | opacite N | visee MS | texte on|off | munitions on|off | reset
-- Sous la barre, à gauche : icône des munitions équipées et quantité présente dans les sacs (orange sous 100, rouge à 0).
local ADDON, ns = ...
local Sh = {}
ns.shot = Sh

local AUTO_SHOT = 75
local DEF = { on = true, w = 260, h = 22, alpha = 1, text = true, aim = 0.5, ammo = true }
local AMMO_SLOT = 0               -- emplacement de munitions de l'équipement
local COL_FILL = { .475, .682, .949 }   -- --info du dashboard      -- avant la visée
local COL_AIM = { .922, .659, .271 }    -- --warn       -- visée : ne plus bouger
local COL_BAD = { .933, .416, .341 }    -- --bad       -- tir annulé / tu bouges pendant la visée
local COL_READY = { .310, .776, .553 }  -- --ok        -- arme prête, en attente du tir (cible hors de portée, pas de cible...)

local function say(m) print("|cffe4b84eGringotts|r " .. m) end
local function isHunter() if not UnitClass then return false end; local _, c = UnitClass("player"); return c == "HUNTER" end
function Sh.cfg()
  GringottsDB = GringottsDB or {}
  local c = GringottsDB.shot
  if not c then c = {}; GringottsDB.shot = c end
  for k, v in pairs(DEF) do if c[k] == nil then c[k] = v end end
  return c
end

-- État du cycle
local S = { start = 0, speed = 3, active = false, flash = 0 }
Sh.S = S

local function rangedSpeed()
  -- WoW Forever : UnitAttackSpeed("player") renvoie (main, off, distance)
  if UnitAttackSpeed then
    local ok, _, _, r = pcall(UnitAttackSpeed, "player")
    if ok and type(r) == "number" and not (issecretvalue and issecretvalue(r)) and r > 0 then return r end
  end
  local s = UnitRangedDamage and UnitRangedDamage("player")
  if type(s) == "number" and not (issecretvalue and issecretvalue(s)) and s > 0 then return s end
  return S.speed > 0 and S.speed or 3
end

-- Progression 0-1 du cycle et début de la visée (fraction). Pure : testable.
function Sh.progress(now, start, speed, aim)
  speed = (speed and speed > 0) and speed or 3
  local p = (now - start) / speed
  if p < 0 then p = 0 elseif p > 1 then p = 1 end
  local zf = 1 - (aim or .5) / speed
  if zf < 0 then zf = 0 end
  return p, zf, p >= zf
end

------------------------------------------------------------------------
-- Barre
------------------------------------------------------------------------
local f = CreateFrame("Frame", "GringottsShotBar", UIParent)
f:SetFrameStrata("MEDIUM"); f:SetClampedToScreen(true)
f:SetMovable(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton")
f:SetPoint("CENTER", UIParent, "CENTER", 0, -160)
f:Hide()
-- Habillage : bordure sombre + liseré clair, fond, remplissage avec reflet, zone de visée teintée, étincelle
local edge = f:CreateTexture(nil, "BACKGROUND", nil, -8); edge:SetAllPoints(); edge:SetColorTexture(0, 0, 0, 1)
local rim = f:CreateTexture(nil, "BACKGROUND", nil, -7); rim:SetPoint("TOPLEFT", -1, 1); rim:SetPoint("BOTTOMRIGHT", 1, -1); rim:SetColorTexture(1, 1, 1, .12)
local bg = f:CreateTexture(nil, "BACKGROUND", nil, -5); bg:SetPoint("TOPLEFT", 1, -1); bg:SetPoint("BOTTOMRIGHT", -1, 1); bg:SetColorTexture(.059, .075, .098, .95)
local zone = f:CreateTexture(nil, "BACKGROUND", nil, -4); zone:SetColorTexture(.922, .659, .271, .22)
local fill = f:CreateTexture(nil, "ARTWORK"); fill:SetPoint("TOPLEFT", f, "TOPLEFT", 1, -1); fill:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 1, 1)
local gloss = f:CreateTexture(nil, "ARTWORK", nil, 2); gloss:SetPoint("TOPLEFT", fill, "TOPLEFT", 0, 0); gloss:SetPoint("TOPRIGHT", fill, "TOPRIGHT", 0, 0); gloss:SetColorTexture(1, 1, 1, .26)
local shade = f:CreateTexture(nil, "ARTWORK", nil, 2); shade:SetPoint("BOTTOMLEFT", fill, "BOTTOMLEFT", 0, 0); shade:SetPoint("BOTTOMRIGHT", fill, "BOTTOMRIGHT", 0, 0); shade:SetColorTexture(0, 0, 0, .18)
local mark = f:CreateTexture(nil, "OVERLAY"); mark:SetWidth(1); mark:SetColorTexture(.922, .659, .271, 1)
local spark = f:CreateTexture(nil, "OVERLAY", nil, 3); spark:SetTexture("Interface\\CastingBar\\UI-CastingBar-Spark"); spark:SetBlendMode("ADD")
local function outlined(fs, size, kind)
  local T = ns.theme
  if T and fs.SetFont then pcall(fs.SetFont, fs, T.fontPath(kind or "bold"), size, "OUTLINE") end
end
local txtL = f:CreateFontString(nil, "OVERLAY", "GringottsOutline"); txtL:SetPoint("LEFT", f, "LEFT", 6, 0); outlined(txtL, 12)
local txtR = f:CreateFontString(nil, "OVERLAY", "GringottsOutlineSmall"); txtR:SetPoint("RIGHT", f, "RIGHT", -6, 0); outlined(txtR, 10)
-- Munitions : tuile bordée (icône + quantité incrustée en bas à droite), sous la barre à gauche
local aBd = f:CreateTexture(nil, "ARTWORK", nil, 0); aBd:SetColorTexture(.169, .208, .267, 1)
local aBg = f:CreateTexture(nil, "ARTWORK", nil, 1); aBg:SetColorTexture(.086, .110, .145, 1)
local aIco = f:CreateTexture(nil, "ARTWORK", nil, 2); aIco:SetPoint("TOPLEFT", f, "BOTTOMLEFT", 1, -6)
if aIco.SetTexCoord then aIco:SetTexCoord(.07, .93, .07, .93) end
aBd:SetPoint("TOPLEFT", aIco, "TOPLEFT", -2, 2); aBd:SetPoint("BOTTOMRIGHT", aIco, "BOTTOMRIGHT", 2, -2)
aBg:SetPoint("TOPLEFT", aIco, "TOPLEFT", -1, 1); aBg:SetPoint("BOTTOMRIGHT", aIco, "BOTTOMRIGHT", 1, -1)
local aTxt = f:CreateFontString(nil, "OVERLAY", "GringottsOutline"); aTxt:SetPoint("BOTTOMRIGHT", aIco, "BOTTOMRIGHT", 0, 1); outlined(aTxt, 12)
f:SetScript("OnDragStart", function(self) if IsShiftKeyDown() then self:StartMoving() end end)
f:SetScript("OnDragStop", function(self)
  self:StopMovingOrSizing()
  local p, _, rp, x, y = self:GetPoint()
  Sh.cfg().pos = { p, rp, x, y }
end)

local function applyLook()
  local c = Sh.cfg()
  f:SetSize(c.w, c.h); f:SetAlpha(c.alpha)
  mark:SetHeight(c.h - 2); zone:SetHeight(c.h - 2); gloss:SetHeight(math.max(1, (c.h - 2) * .45)); shade:SetHeight(math.max(1, (c.h - 2) * .25))
  spark:SetSize(16, c.h * 2.2)
  local sz = math.max(28, math.min(44, c.h + 12)); aIco:SetSize(sz, sz)
  if c.pos then f:ClearAllPoints(); f:SetPoint(c.pos[1], UIParent, c.pos[2], c.pos[3], c.pos[4]) end
end
Sh.applyLook = applyLook

local function setColor(c) fill:SetColorTexture(c[1], c[2], c[3], 1) end
local function fmt(x) return (("%.1f"):format(x):gsub("%.", ",")) end

-- Munitions : emplacement 0 si équipées ; sinon (ou si le client ne l'expose pas) on cherche dans les sacs des projectiles
-- adaptés à l'arme à distance (flèches pour arc/arbalète, balles pour arme à feu). Renvoie id, icône, nombre.
local function ammoClassWanted()
  local link = GetInventoryItemLink and GetInventoryItemLink("player", 18)   -- arme à distance
  if not link then return nil end
  local _, _, _, _, _, _, _, _, _, _, _, cls, sub = GetItemInfo(link)
  if cls == nil and GetItemInfoInstant then local _, _, _, _, _, c, s2 = GetItemInfoInstant(link); cls, sub = c, s2 end
  if sub == 2 or sub == 18 then return 2 end     -- arc, arbalète → flèches
  if sub == 3 then return 3 end                    -- arme à feu → balles
  return nil
end
function Sh.ammoInfo()
  local id = GetInventoryItemID and GetInventoryItemID("player", AMMO_SLOT)
  if id and id > 0 then
    local icon = (GetItemIcon and GetItemIcon(id)) or (GetInventoryItemTexture and GetInventoryItemTexture("player", AMMO_SLOT))
    local n = (GetInventoryItemCount and GetInventoryItemCount("player", AMMO_SLOT)) or 0
    local bags = (GetItemCount and GetItemCount(id)) or 0
    return id, icon, math.max(n, bags)
  end
  -- rien dans l'emplacement : projectiles dans les sacs
  local want = ammoClassWanted()
  local CC = C_Container
  local best, total, bestN = nil, 0, 0
  if CC and CC.GetContainerNumSlots then
    for bag = 0, 4 do
      for slot = 1, CC.GetContainerNumSlots(bag) do
        local info = CC.GetContainerItemInfo(bag, slot)
        if info and info.itemID then
          local _, _, _, _, _, _, _, _, _, _, _, cls, sub = GetItemInfo(info.itemID)
          if cls == nil and GetItemInfoInstant then local _, _, _, _, _, c, s2 = GetItemInfoInstant(info.itemID); cls, sub = c, s2 end
          if cls == 6 and (want == nil or sub == want) then
            total = total + (info.stackCount or 1)
            if (info.stackCount or 1) > bestN then bestN = info.stackCount or 1; best = info.itemID end
          end
        end
      end
    end
  end
  if best then return best, (GetItemIcon and GetItemIcon(best)), total, true end
  return nil, nil, 0
end
function Sh.ammoRefresh()
  local c = Sh.cfg()
  if not c.ammo then aIco:Hide(); aBd:Hide(); aBg:Hide(); aTxt:SetText(""); return end
  local id, icon, n, inBags = Sh.ammoInfo()
  aIco:Show(); aBd:Show(); aBg:Show()
  aIco:SetTexture(icon or "Interface\\Icons\\INV_Ammo_Arrow_02")
  if aIco.SetDesaturated then aIco:SetDesaturated(id == nil or inBags == true) end
  if id == nil then aTxt:SetText("|cffee6a570|r")
  elseif n <= 0 then aTxt:SetText("|cffee6a570|r")
  elseif n < 100 then aTxt:SetText("|cffeba845" .. n .. "|r")
  else aTxt:SetText(tostring(n)) end
  Sh.ammoShown = { id = id, n = n }
end

-- Démonstration (onglet Options) : cycle simulé en boucle, une fois sur deux « tu bouges » pendant la visée
function Sh.setDemo(on)
  Sh.demo = on and true or false
  S.demoT0 = GetTime(); S.demoN = 0
  f:SetFrameStrata(Sh.demo and "FULLSCREEN_DIALOG" or "MEDIUM")
  if Sh.refreshShow then Sh.refreshShow() end
  if Sh.ammoRefresh then Sh.ammoRefresh() end
end
function Sh.recenter()
  local c = Sh.cfg(); c.pos = nil; c.rpos = nil
  f:ClearAllPoints(); f:SetPoint("CENTER", UIParent, "CENTER", 0, -160)
  if Sh.range and Sh.range.layout then Sh.range.layout() end
end
local function demoState(now, speed)
  local per = speed + 1.2
  local n = math.floor((now - S.demoT0) / per)
  local t = (now - S.demoT0) - n * per
  S.demoN = n
  return now - math.min(t, speed), n % 2 == 1 and t >= speed - .5 and t < speed + .6
end

local function playerMoving()
  local ok, v = pcall(GetUnitSpeed, "player")
  if not ok or v == nil or (issecretvalue and issecretvalue(v)) then return false end
  return v > 0
end
local function update(now)
  local c = Sh.cfg()
  local speed = S.dur or rangedSpeed(); S.speed = speed   -- S.dur : durée exacte du cycle en cours donnée par le client (PLAYER_SWING)
  local demoMove
  if Sh.demo and not S.active then S.start, demoMove = demoState(now, speed); S.flash = demoMove and now + .05 or S.flash end
  local p, zf, inAim = Sh.progress(now, S.start, speed, c.aim)
  local W = (c.w or 260) - 2
  fill:SetWidth(math.max(.01, W * p))
  mark:ClearAllPoints(); mark:SetPoint("LEFT", f, "LEFT", 1 + W * zf, 0)
  zone:ClearAllPoints(); zone:SetPoint("TOPLEFT", f, "TOPLEFT", 1 + W * zf, -1); zone:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -1, 1)
  spark:ClearAllPoints(); spark:SetPoint("CENTER", fill, "RIGHT", 0, 0); spark:SetShown(p > 0 and p < 1)
  local moving = inAim and ((demoMove) or (not (Sh.demo and not S.active) and GetUnitSpeed and playerMoving()))
  if S.flash > now then setColor(COL_BAD)
  elseif moving then setColor(COL_BAD)
  elseif p >= 1 then setColor(COL_READY)
  elseif inAim then setColor(COL_AIM)
  else setColor(COL_FILL) end
  S.inAim, S.moving = inAim, moving and true or false
  if c.text then
    txtL:SetText(p >= 1 and "prêt" or (fmt(math.max(0, speed - (now - S.start))) .. " s"))
    txtR:SetText(inAim and "" or ("vit. " .. fmt(speed) .. " s"))
  else txtL:SetText(""); txtR:SetText("") end
end
Sh.update = update

f:SetScript("OnUpdate", function() update(GetTime()) end)

local function refreshShow()
  local c = Sh.cfg()
  local function sb(fn, ...)   -- appel protégé : les valeurs masquées ne doivent jamais être testées directement
    if type(fn) ~= "function" then return false end
    local ok, v = pcall(fn, ...)
    if not ok then return false end
    if issecretvalue and issecretvalue(v) then return false end
    return v == true or v == 1
  end
  local hostile = c.keepOnTarget ~= false and sb(UnitExists, "target") and sb(UnitCanAttack, "player", "target") and not sb(UnitIsDead, "target")
  f:SetShown(isHunter() and c.on and (S.active or Sh.demo or hostile and true or false))
  if S.active then Sh.ammoRefresh() end
end
Sh.refreshShow = refreshShow

------------------------------------------------------------------------
-- Événements
------------------------------------------------------------------------
local function isAuto(...)
  -- UNIT_SPELLCAST_* : unit, castGUID, spellID (Classic) ; sinon on compare le nom
  local a, b, c = ...
  if type(c) == "number" then return c == AUTO_SHOT end
  if type(b) == "number" then return b == AUTO_SHOT end
  local name = GetSpellInfo and GetSpellInfo(AUTO_SHOT)
  return name ~= nil and (b == name or c == name)
end

local function dbg(m) if Sh.debug then say("[tir] " .. m) end end
function Sh.onNativeSwing(now, duration)   -- événement natif du client Forever : un tir est parti, durée du cycle suivant fournie
  Sh.native = true; Sh.lastNative = now
  if type(duration) == "number" and duration > 0 and duration < 30 then S.dur = duration; S.speed = duration end
  if not S.active then S.active = true; refreshShow() end
  S.start = now
  dbg(("PLAYER_SWING distance : cycle %.2f s"):format(S.speed))
end
function Sh.onShot(now)           -- tir parti : nouveau cycle
  if Sh.lastNative and now - Sh.lastNative < 0.6 then return end   -- PLAYER_SWING vient d'arriver : on ne double pas (sinon repli sur le tir réussi)
  if not S.active then S.active = true; refreshShow() end
  S.start = now; S.speed = rangedSpeed()
  dbg(("tir parti, cycle relancé (vitesse %.2f s, actif=%s)"):format(S.speed, tostring(S.active)))
end
function Sh.onAim(now)            -- début de la visée (UNIT_SPELLCAST_START du Tir automatique) : recale la barre
  if Sh.lastNative and now - Sh.lastNative < (S.speed or 3) * 2 then return end
  S.speed = rangedSpeed()
  local c = Sh.cfg()
  S.start = now - math.max(0, S.speed - c.aim)
  dbg(("visée commencée (vitesse %.2f s)"):format(S.speed))
end
function Sh.onStart(now)          -- Tir automatique activé
  S.active = true; S.speed = rangedSpeed()
  dbg("tir automatique activé")
  local c = Sh.cfg()
  if now - S.start >= S.speed then S.start = now - math.max(0, S.speed - c.aim) end   -- arme prête : seule la visée reste
  refreshShow()
end
function Sh.onStop() S.active = false; S.dur = nil; dbg("tir automatique arrêté"); refreshShow() end
function Sh.onCancel(now)         -- tir annulé : seulement si on était dans la visée
  local c = Sh.cfg()
  local _, _, inAim = Sh.progress(now, S.start, S.speed, c.aim)
  if not inAim then return false end
  S.flash = now + .4
  S.start = now - math.max(0, S.speed - c.aim)   -- la visée repart du début
  return true
end

-- Filet de sécurité : l'état « tir automatique actif » est relu toutes les 0,25 s, sans dépendre d'un événement manqué
-- (rechargement de l'interface, changement de zone, cible perdue puis retrouvée...).
local function autoRepeatNow()
  if C_Spell and C_Spell.IsAutoRepeatSpell then
    local ok, v = pcall(C_Spell.IsAutoRepeatSpell, AUTO_SHOT)
    if ok and (v == true or v == false) then return v end
  end
  if IsAutoRepeatSpell and GetSpellInfo then
    local ok, n = pcall(GetSpellInfo, AUTO_SHOT)
    if ok and type(n) == "string" then
      local ok2, v = pcall(IsAutoRepeatSpell, n)
      if ok2 and (v == true or v == false or v == 1 or v == nil) then return v == true or v == 1 end
    end
  end
  return nil
end
local pollAcc = 0
local poller = CreateFrame("Frame")
poller:SetScript("OnUpdate", function(_, el)
  pollAcc = pollAcc + el
  if pollAcc < .25 or not isHunter() then return end
  pollAcc = 0
  refreshShow()
  local v = autoRepeatNow()
  if v == nil then return end
  if v and not S.active then
    Sh.pollOK = true
    dbg("tir automatique détecté par relecture (événement de départ manqué)")
    Sh.onStart(GetTime())
  elseif v then Sh.pollOK = true
  elseif not v and S.active and Sh.pollOK and GetTime() - S.start > (S.speed or 3) + 1 then
    S.active = false; S.dur = nil; dbg("tir automatique arrêté (relecture)"); refreshShow()
  end
end)

local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
ev:SetScript("OnEvent", function(self, e, ...)
  if e == "PLAYER_LOGIN" then
    if not isHunter() then return end
    applyLook()
    Sh.ammoRefresh()
    for _, n in ipairs({ "START_AUTOREPEAT_SPELL", "STOP_AUTOREPEAT_SPELL", "UNIT_SPELLCAST_SUCCEEDED", "UNIT_SPELLCAST_INTERRUPTED", "UNIT_SPELLCAST_FAILED",
                         "UNIT_SPELLCAST_START", "UNIT_SPELLCAST_SENT", "PLAYER_SWING", "PLAYER_TARGET_CHANGED", "UNIT_ATTACK_SPEED", "WEAPON_SLOT_CHANGED", "PLAYER_DEAD", "PLAYER_ALIVE", "PLAYER_UNGHOST",
                         "BAG_UPDATE_DELAYED", "PLAYER_EQUIPMENT_CHANGED", "UNIT_INVENTORY_CHANGED", "PLAYER_ENTERING_WORLD", "ITEM_LOCKED" }) do pcall(self.RegisterEvent, self, n) end
    -- l'état de l'arme à distance est connu plus tard au chargement : on relit les munitions un peu après
    if C_Timer then C_Timer.After(3, function() Sh.ammoRefresh() end) end
    return
  end
  if not isHunter() then return end
  local now = GetTime()
  if e == "PLAYER_ENTERING_WORLD" or e == "PLAYER_DEAD" or e == "PLAYER_ALIVE" or e == "PLAYER_UNGHOST" then
    -- exception UPDOG : changement de zone / mort = plus de cycle fiable, on repart de zéro
    S.active = false; S.dur = nil; S.start = 0; refreshShow(); Sh.ammoRefresh(); return
  end
  if e == "PLAYER_SWING" then
    local duration, swingType = ...
    if issecretvalue and (issecretvalue(duration) or issecretvalue(swingType)) then
      -- en combat les valeurs peuvent être masquées : pas d'arithmétique dessus, mais si le tir auto tourne on relance le cycle avec la vitesse lue
      if autoRepeatNow() ~= false then Sh.lastNative = nil; Sh.onShot(now) end
      return
    end
    if swingType == 2 then Sh.onNativeSwing(now, duration) end   -- 0 = main, 1 = main gauche, 2 = distance
    return
  end
  if e == "PLAYER_TARGET_CHANGED" then
    -- changer de cible peut couper puis relancer le tir auto sans nouvel événement de départ : on relit l'état
    if autoRepeatNow() == true and not S.active then Sh.onStart(now) end
    refreshShow(); return
  end
  if e == "UNIT_ATTACK_SPEED" then if ... == "player" and now - S.start >= (S.dur or 0) then S.dur = nil end return end
  if Sh.debug and e:find("UNIT_SPELLCAST") and ... == "player" then say(("[tir] %s : %s"):format(e, table.concat({ tostringall(...) }, ", "))) end
  if e == "UNIT_SPELLCAST_START" then
    local unit = ...
    if unit == "player" and isAuto(...) then Sh.onAim(now) end
    return
  end
  if e == "UNIT_SPELLCAST_SENT" or e == "ITEM_LOCKED" then return end
  if e == "WEAPON_SLOT_CHANGED" or (e == "PLAYER_EQUIPMENT_CHANGED" and (... == 18 or ... == 16)) then
    -- exception UPDOG : arme changée = la vitesse change, le cycle en cours n'est plus valable ; pas d'arme à distance = barre masquée
    S.dur = nil
    local sp = rangedSpeed()
    if S.active and now - S.start < S.speed then S.start = now end
    local hasRanged = GetInventoryItemLink and GetInventoryItemLink("player", 18)
    if not hasRanged then S.active = false; refreshShow() end
    dbg("arme changée, vitesse " .. ("%.2f"):format(sp))
  end
  if e == "BAG_UPDATE_DELAYED" or e == "PLAYER_EQUIPMENT_CHANGED" or (e == "UNIT_INVENTORY_CHANGED" and ... == "player") then Sh.ammoRefresh(); return end
  if e == "START_AUTOREPEAT_SPELL" then Sh.onStart(now)
  elseif e == "STOP_AUTOREPEAT_SPELL" then Sh.onStop()
  else
    local unit = ...
    if unit ~= "player" or not isAuto(...) then return end
    if e == "UNIT_SPELLCAST_SUCCEEDED" then Sh.onShot(now)
    else dbg("tir annulé/échoué : " .. (Sh.onCancel(now) and "dans la visée, barre recalée" or "hors visée, ignoré")) end
  end
end)

------------------------------------------------------------------------
-- Réglages et commande
------------------------------------------------------------------------
function Sh.set(k, v)
  local c = Sh.cfg()
  if k == "on" then c.on = v and true or false
  elseif k == "text" then c.text = v and true or false
  elseif k == "ammo" then c.ammo = v and true or false
  elseif k == "alpha" then v = tonumber(v); if not (v and v >= 10 and v <= 100) then return false end; c.alpha = v / 100
  elseif k == "aim" then v = tonumber(v); if not (v and v >= 100 and v <= 1500) then return false end; c.aim = v / 1000
  elseif k == "size" then local w, h = v[1], v[2]; if not (w and h and w >= 80 and w <= 800 and h >= 8 and h <= 80) then return false end; c.w, c.h = w, h
  else return false end
  applyLook(); refreshShow(); return true
end

ns.shotCmd = function(arg)
  arg = (arg or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
  local cmd, rest = arg:match("^(%S+)%s*(.*)$")
  if not isHunter() then say("Le swing timer du tir automatique est réservé aux chasseurs."); return end
  local c = Sh.cfg()
  if cmd == "taille" or cmd == "size" then
    local w, h = rest:match("^(%d+)%s+(%d+)$")
    say(Sh.set("size", { tonumber(w), tonumber(h) }) and ("Taille : " .. w .. " × " .. h) or "Taille : largeur 80-800 et hauteur 8-80 (ex. /gt tir taille 260 22).")
  elseif cmd == "opacite" or cmd == "opacity" then say(Sh.set("alpha", rest) and ("Opacité : " .. rest .. " %") or "Opacité : un nombre entre 10 et 100.")
  elseif cmd == "visee" or cmd == "aim" then say(Sh.set("aim", rest) and ("Zone de visée : " .. rest .. " ms") or "Visée : une durée en ms entre 100 et 1500 (0,5 s = 500).")
  elseif cmd == "texte" or cmd == "text" then Sh.set("text", rest ~= "off"); say("Texte de la barre : " .. (c.text and "affiché" or "masqué") .. ".")
  elseif cmd == "munitions" or cmd == "ammo" then Sh.set("ammo", rest ~= "off"); say("Icône de munitions : " .. (c.ammo and "affichée" or "masquée") .. ".")
  elseif cmd == "debug" then
    Sh.debug = (rest ~= "off")
    local id = GetInventoryItemID and GetInventoryItemID("player", AMMO_SLOT)
    say("Diagnostic du tir : " .. (Sh.debug and "activé" or "désactivé") .. ". Emplacement munitions : " .. tostring(id) .. " · arme à distance : " .. tostring(GetInventoryItemLink and GetInventoryItemLink("player", 18)))
  elseif cmd == "meilleure" then
    if ns.ammo then ns.ammo.report() end
  elseif cmd == "vendeur" then
    if ns.ammo then ns.ammo.goVendor() end
  elseif cmd == "portee" or cmd == "melee" or cmd == "offhand" or cmd == "retard" or cmd == "lueurs" or cmd == "fondu" then
    local key = ({ portee = "range", melee = "melee", offhand = "offhand", retard = "clip", lueurs = "glow", fondu = "fadeOn" })[cmd]
    local lab = ({ portee = "Indicateur de portée", melee = "Barre de mêlée", offhand = "Barre de main gauche", retard = "Retard du tir (-0,24)", lueurs = "Lueurs d'entrée en portée", fondu = "Fondu hors combat / hors portée" })[cmd]
    local on = (rest ~= "off")
    if Sh.range then Sh.range.set(key, on) else c[key] = on end
    say(lab .. " : " .. (on and "activé" or "désactivé") .. ".")
  elseif cmd == "reset" then
    Sh.recenter(); say("Barre recentrée (Maj + glisser pour la déplacer).")
  else
    local on
    if cmd == "on" then on = true elseif cmd == "off" then on = false else on = not c.on end
    Sh.set("on", on); say("Barre du tir automatique : " .. (c.on and "activée (Maj + glisser pour la déplacer)." or "désactivée."))
  end
end

-- gardes : une erreur est journalisée (/gt erreurs) au lieu d'ouvrir le popup de Blizzard
if ns.safe then
  f:SetScript("OnUpdate", ns.safe(f:GetScript("OnUpdate"), "tir"))
  poller:SetScript("OnUpdate", ns.safe(poller:GetScript("OnUpdate"), "tir"))
  ev:SetScript("OnEvent", ns.safe(ev:GetScript("OnEvent"), "tir"))
end
