-- Gringotts : outils de gains avancés (logique, sans interface) :
--   Que farmer ? · aide à la mise en vente · sacs pleins · minuteries · vue multi-persos · courrier de matériaux.
local ADDON, ns = ...
local Pl = {}
ns.plus = Pl

local function E() return ns.engine end
local function Gn() return ns.gains end
local function db() return ns.api and ns.api.db and ns.api.db() or nil end
local function norm(s) return ns.norm(s) end
local function sameRealm(c) return c.realm == ns.api.realm() and c.faction == ns.api.faction() end
local function say(m) print("|cffe4b84eGringotts|r " .. m) end

------------------------------------------------------------------------
-- 4. Que farmer maintenant ? (mesuré quand il existe, estimé sinon)
------------------------------------------------------------------------
-- Cadence par objet et par lieu d'après tes sessions : { [k] = { name, id, zones = { [zone] = { q, secs } } } }
local function itemRates()
  local g = db() and db().gains
  local by = {}
  if not g then return by end
  for _, s in ipairs(g.sessions or {}) do
    local secs = Gn().elapsed(s)
    if secs >= 60 then
      for k, it in pairs(s.items or {}) do
        local e = by[k]
        if not e then e = { name = it.n, id = it.id, zones = {} }; by[k] = e end
        local z = e.zones[s.zone]
        if not z then z = { q = 0, secs = 0 }; e.zones[s.zone] = z end
        z.q = z.q + it.q
      end
    end
  end
  -- durée par zone = somme des sessions de cette zone (même si l'objet n'y est pas tombé à chaque fois)
  local zsecs = {}
  for _, s in ipairs(g.sessions or {}) do
    local secs = Gn().elapsed(s)
    if secs >= 60 then zsecs[s.zone] = (zsecs[s.zone] or 0) + secs end
  end
  for _, e in pairs(by) do for zone, z in pairs(e.zones) do z.secs = zsecs[zone] or 1 end end
  return by
end

-- Retour : { rows = { {kind="spot"|"item"|"price", name, zone, gph, src, detail} ... }, have = n }
function Pl.farmNow()
  local rows = {}
  for _, z in ipairs(Gn().spots()) do
    if #rows < 6 then rows[#rows + 1] = { kind = "spot", name = z.zone, gph = z.gph, src = "mesuré", detail = ("%d session%s"):format(z.n, z.n > 1 and "s" or "") } end
  end
  local rates = itemRates()
  local items = E().items()
  local priced = {}
  for _, it in ipairs(items) do
    if (it.toBuy or 0) > 0 and it.price and it.price > 0 then
      local unit = Gn().unitValue(it.name, it.id)
      local r = rates[it.k]
      if r then
        local best, bz = 0, nil
        for zone, z in pairs(r.zones) do
          local h = z.secs / 3600
          local rate = h > 0 and z.q / h or 0
          if rate > best then best, bz = rate, zone end
        end
        if best > 0 then
          rows[#rows + 1] = { kind = "item", name = it.name, zone = bz, gph = math.floor(best * unit), src = "mesuré",
            detail = ("manque %d · %.0f/h à %s · %.1f h pour combler"):format(it.toBuy, best, bz, it.toBuy / best) }
        end
      else
        priced[#priced + 1] = { kind = "price", name = it.name, gph = nil, value = unit * it.toBuy, src = "estimé",
          detail = ("manque %d × %s : pas encore farmé"):format(it.toBuy, ns.api.coins(unit)) }
      end
    end
  end
  table.sort(rows, function(a, b) return (a.gph or 0) > (b.gph or 0) end)
  table.sort(priced, function(a, b) return a.value > b.value end)
  for i = 1, math.min(8, #priced) do rows[#rows + 1] = priced[i] end
  return rows
end

------------------------------------------------------------------------
-- 5. Aide à la mise en vente
------------------------------------------------------------------------
-- Prix conseillé : juste sous le moins cher, plafonné à la médiane, jamais sous le plancher. + alertes de saturation.
function Pl.advice(it, qty)
  local s = E().cfg()
  if not (it and it.price) then return nil end
  local sug = math.max(it.price - 1, 1)
  if it.med and it.med > 0 then sug = math.min(sug, it.med) end
  local belowFloor
  if it.floor and sug < it.floor then sug, belowFloor = it.floor, true end
  local net = math.floor(sug * (1 - s.fee))
  local alerts = {}
  if it.gap and it.gap <= -0.15 then alerts[#alerts + 1] = { "low", ("Marché bas : %d %% sous la médiane. Garde-les pour plus tard."):format(math.floor(-it.gap * 100 + .5)) } end
  local state, why, sold, listed = Gn().liq(it.k)
  if state == "slow" then alerts[#alerts + 1] = { "slow", "Se vend lentement : " .. (why or "") } end
  qty = qty or 0
  if qty > 0 and sold and sold > 0 then
    local days = qty / (sold / 30)
    if days > 21 then alerts[#alerts + 1] = { "stock", ("À ton rythme, %d j pour tout écouler."):format(math.floor(days + .5)) } end
  end
  if it.gap and it.gap >= s.sellGap then alerts[#alerts + 1] = { "good", "Bon moment : au-dessus de la médiane." } end
  return { sug = sug, net = net, belowFloor = belowFloor, alerts = alerts }
end

function Pl.sellList()
  local d = db()
  local out = {}
  local me
  for _, c in pairs(d.chars or {}) do if c.name == UnitName("player") and sameRealm(c) then me = c end end
  local bags = me and me.bags or {}
  for _, it in ipairs(E().items()) do
    local have = bags[it.k] or 0
    if have > 0 and it.price and it.status ~= "noprice" and it.status ~= "odd" and not it.vendorBetter then
      local qty = it.target > 0 and math.min(have, math.max(0, it.stock - it.target)) or have
      if qty > 0 then
        local a = Pl.advice(it, qty)
        if a then
          local dep = (ns.hv and ns.hv.deposit and it.id) and select(2, pcall(ns.hv.deposit, it.id, E().cfg().sellDuration, qty)) or 0
          if type(dep) ~= "number" then dep = 0 end
          out[#out + 1] = { k = it.k, name = it.name, id = it.id, qty = qty, price = it.price, sug = a.sug, net = a.net * qty - dep, dep = dep, alerts = a.alerts, it = it }
        end
      end
    end
  end
  table.sort(out, function(a, b) if a.net ~= b.net then return a.net > b.net end return a.name < b.name end)
  return out
end

------------------------------------------------------------------------
-- 6. Sacs pleins : valeur par emplacement, quoi vendre au PNJ / mettre à l'HV
------------------------------------------------------------------------
Pl.merchant = false

function Pl.freeSlots()
  local CC = C_Container
  if not (CC and CC.GetContainerNumFreeSlots) then return 0, 0 end
  local free, total = 0, 0
  for bag = 0, 4 do
    local f = CC.GetContainerNumFreeSlots(bag)
    local n = CC.GetContainerNumSlots(bag)
    if type(f) == "number" then free = free + f end
    if type(n) == "number" then total = total + n end
  end
  return free, total
end

-- Une ligne par emplacement occupé. kind : junk (gris) · pnj (le marchand paie mieux ou pas d'HV) · hv · keep (cible de stock / lié)
function Pl.bagRows()
  local CC = C_Container
  local out = {}
  if not (CC and CC.GetContainerNumSlots) then return out end
  local items = {}
  for _, it in ipairs(E().items()) do items[it.k] = it end
  local fee = E().cfg().fee
  for bag = 0, 4 do
    for slot = 1, (CC.GetContainerNumSlots(bag) or 0) do
      local info = CC.GetContainerItemInfo(bag, slot)
      if info and info.itemID then
        local name = info.hyperlink and info.hyperlink:match("%[(.-)%]") or tostring(info.itemID)
        local k = norm(name)
        local cnt = info.stackCount or 1
        local vend = (ns.sellPriceOf and ns.sellPriceOf(info.itemID)) or 0
        local it = items[k]
        local hv = (it and it.price and it.status ~= "odd") and math.floor(it.price * (1 - fee)) or 0
        local q = info.quality or 1
        local vt, ht = vend * cnt, hv * cnt
        local kind, why
        if it and (it.target or 0) > 0 and (it.stock or 0) <= (it.target or 0) then kind, why = "keep", "sous ta cible de stock"
        elseif info.isBound and q >= 2 then kind, why = "keep", "objet lié"
        elseif q == 0 then kind, why = "junk", "gris"
        elseif ht > vt and ht > 0 then kind, why = "hv", "mieux payé à l'HV"
        elseif vt > 0 then kind, why = "pnj", (ht == 0) and "pas de prix HV" or "le marchand paie mieux"
        else kind, why = "keep", "sans valeur connue" end
        out[#out + 1] = { bag = bag, slot = slot, id = info.itemID, name = name, count = cnt, quality = q, kind = kind, why = why,
          perSlot = math.max(vt, ht), vendorTotal = vt, hvTotal = ht, checked = (kind == "junk") }
      end
    end
  end
  table.sort(out, function(a, b)
    local oa = (a.kind == "keep") and 1 or 0; local ob = (b.kind == "keep") and 1 or 0
    if oa ~= ob then return oa < ob end
    if a.perSlot ~= b.perSlot then return a.perSlot < b.perSlot end
    return a.name < b.name
  end)
  return out
end

-- Vend au marchand les lignes cochées (kind junk/pnj uniquement). Renvoie nombre et or.
function Pl.sellChecked(rows)
  if not Pl.merchant then return 0, 0 end
  local n, gold = 0, 0
  for _, r in ipairs(rows) do
    if r.checked and (r.kind == "junk" or r.kind == "pnj") then
      local info = C_Container.GetContainerItemInfo(r.bag, r.slot)
      if info and info.itemID == r.id and not info.isLocked then
        C_Container.UseContainerItem(r.bag, r.slot)
        n = n + 1; gold = gold + r.vendorTotal
      end
    end
  end
  return n, gold
end

------------------------------------------------------------------------
-- 7. Minuteries : repop de nœuds + cooldowns de métier
------------------------------------------------------------------------
function Pl.timers()
  local out = {}
  local now = time()
  for _, c in pairs((db() and db().chars) or {}) do
    if sameRealm(c) then
      for rn, cd in pairs(c.cds or {}) do
        if cd.r then out[#out + 1] = { kind = "cd", who = c.name, name = rn, remain = cd.r - now } end
      end
    end
  end
  if ns.arrowTimers then
    for _, t in ipairs(ns.arrowTimers()) do out[#out + 1] = { kind = "node", who = UnitName("player"), name = t.name or "point", remain = t.remain } end
  end
  table.sort(out, function(a, b) return a.remain < b.remain end)
  return out
end

-- Prévient une fois quand un cooldown de métier est prêt
function Pl.checkReady()
  local d = db(); if not d then return end
  d.cdWarned = d.cdWarned or {}
  local now = time()
  for _, t in ipairs(Pl.timers()) do
    if t.kind == "cd" and t.remain <= 0 then
      local key = t.who .. ":" .. t.name
      local c
      for _, ch in pairs(d.chars or {}) do if ch.name == t.who then c = ch end end
      local r = c and c.cds and c.cds[t.name] and c.cds[t.name].r
      if r and d.cdWarned[key] ~= r then
        d.cdWarned[key] = r
        say(("%s : %s est prêt."):format(t.who, t.name))
      end
    end
  end
end

------------------------------------------------------------------------
-- 9. Multi-persos : tableau + courrier de matériaux vers le perso artisan
------------------------------------------------------------------------
function Pl.chars()
  local out, tot = {}, { gold = 0 }
  for _, c in pairs((db() and db().chars) or {}) do
    if sameRealm(c) then
      local nb, nk = 0, 0
      for _, n in pairs(c.bags or {}) do nb = nb + n end
      for _, n in pairs(c.bank or {}) do nk = nk + n end
      local nr = 0
      for _ in pairs(c.recipes or {}) do nr = nr + 1 end
      local sk = {}
      for name, lv in pairs(c.skills or {}) do sk[#sk + 1] = { name, type(lv) == "table" and (lv.rank or lv[1]) or lv } end
      table.sort(sk, function(a, b) return (tonumber(a[2]) or 0) > (tonumber(b[2]) or 0) end)
      local sks = {}
      for i = 1, math.min(3, #sk) do sks[#sks + 1] = ("%s %s"):format(sk[i][1], tostring(sk[i][2])) end
      out[#out + 1] = { name = c.name, gold = c.gold or 0, bags = nb, bank = nk, recipes = nr, skills = table.concat(sks, " · "), t = c.goldT }
      tot.gold = tot.gold + (c.gold or 0)
    end
  end
  table.sort(out, function(a, b) return a.gold > b.gold end)
  return out, tot
end

-- Matériaux à envoyer à `who` pour N crafts des recettes rentables qu'il connaît, d'après ce qui est dans MES sacs
function Pl.mailPlan(who, crafts)
  crafts = crafts or 5
  local d = db(); if not d then return {} end
  local target, me
  for _, c in pairs(d.chars or {}) do
    if sameRealm(c) then
      if c.name == who then target = c end
      if c.name == UnitName("player") then me = c end
    end
  end
  if not (target and me) or target == me then return {} end
  local need = {}
  for _, e in ipairs((ns.crafts and ns.crafts.cache) or {}) do
    if e.who and e.who[who] and (e.status == "go" or e.status == "buy") then
      for _, ln in ipairs(e.lines or {}) do
        local k = norm(ln.name)
        need[k] = need[k] or { name = ln.name, q = 0 }
        need[k].q = need[k].q + ln.need * crafts
      end
    end
  end
  local out = {}
  for k, n in pairs(need) do
    local missing = n.q - ((target.bags or {})[k] or 0)
    local mine = (me.bags or {})[k] or 0
    local send = math.min(math.max(missing, 0), mine)
    if send > 0 then out[#out + 1] = { k = k, name = n.name, qty = send, missing = missing } end
  end
  table.sort(out, function(a, b) return a.name < b.name end)
  return out
end

local function bagSlotsOf(k)
  local t = {}
  local CC = C_Container
  for bag = 0, 4 do
    for slot = 1, (CC.GetContainerNumSlots(bag) or 0) do
      local info = CC.GetContainerItemInfo(bag, slot)
      if info and info.hyperlink and not info.isLocked and norm(info.hyperlink:match("%[(.-)%]") or "") == k then
        t[#t + 1] = { bag, slot, info.stackCount or 1 }
      end
    end
  end
  table.sort(t, function(a, b) return a[3] > b[3] end)
  return t
end

-- Prépare le courrier (boîte aux lettres ouverte) : destinataire + pièces jointes ; l'utilisateur clique « Envoyer »
function Pl.mailPrepare(who, list)
  if not (MailFrame and MailFrame:IsShown()) then return false, "Ouvre une boîte aux lettres d'abord." end
  if MailFrameTab_OnClick then pcall(MailFrameTab_OnClick, nil, 2) end
  if SendMailNameEditBox then SendMailNameEditBox:SetText(who) end
  if SendMailSubjectEditBox then SendMailSubjectEditBox:SetText("Gringotts : matériaux") end
  local done = {}
  local function free() for i = 1, (ATTACHMENTS_MAX_SEND or 12) do if not HasSendMailItem(i) then return i end end end
  for _, l in ipairs(list) do
    local need = l.qty
    for _, s in ipairs(bagSlotsOf(l.k)) do
      if need <= 0 then break end
      local idx = free(); if not idx then break end
      ClearCursor()
      if s[3] <= need then C_Container.PickupContainerItem(s[1], s[2]); need = need - s[3]
      else C_Container.SplitContainerItem(s[1], s[2], need); need = 0 end
      ClickSendMailItemButton(idx)
    end
    if l.qty - need > 0 then done[#done + 1] = ("%s ×%d"):format(l.name, l.qty - need) end
  end
  return true, ("Courrier pour %s préparé : %s. Vérifie puis clique sur Envoyer."):format(who, #done > 0 and table.concat(done, ", ") or "rien")
end

------------------------------------------------------------------------
-- Événements : marchand ouvert (vente des sacs), rappel des cooldowns prêts
------------------------------------------------------------------------
local ev = CreateFrame("Frame")
for _, e in ipairs({ "MERCHANT_SHOW", "MERCHANT_CLOSED", "PLAYER_LOGIN" }) do pcall(ev.RegisterEvent, ev, e) end
ev:SetScript("OnEvent", function(_, e)
  if e == "MERCHANT_SHOW" then Pl.merchant = true
  elseif e == "MERCHANT_CLOSED" then Pl.merchant = false
  elseif e == "PLAYER_LOGIN" then
    C_Timer.After(12, function() pcall(Pl.checkReady) end)
    if C_Timer.NewTicker then C_Timer.NewTicker(120, function() pcall(Pl.checkReady) end) end
  end
  if ns.gringUI and ns.gringUI.onPlus then ns.gringUI.onPlus(e) end
end)
