-- Gringotts : hôtel des ventes intégré (recherche, achat, mise en vente, mes ventes).
-- Remplace la fenêtre Blizzard : celle-ci reste ouverte en arrière-plan (alpha 0) car l'API de l'HV en dépend.
local ADDON, ns = ...
local H = {}
ns.hv = H

local function AH() return C_AuctionHouse end
local function db() return ns.api and ns.api.db() end
local function say(m) print("|cffe4b84eGringotts|r " .. m) end
local function itemName(id)
  local n
  if C_Item and C_Item.GetItemNameByID then n = C_Item.GetItemNameByID(id) end
  if not n and GetItemInfo then n = GetItemInfo(id) end
  if not n and C_Item and C_Item.RequestLoadItemDataByID then pcall(C_Item.RequestLoadItemDataByID, id) end
  return n or ("Objet #" .. id)
end
H.itemName = itemName

H.mode = "buy"          -- buy | sell | own
H.results = {}          -- résultats de recherche : { id, name, minPrice, qty }
H.owned = {}            -- mes enchères : { auctionID, id, name, qty, buyout, left }
H.bags = {}             -- objets des sacs : { id, name, count }
H.query = ""

local function changed() if ns.gring and ns.gring.onHVUpdate then ns.gring.onHVUpdate() end end

------------------------------------------------------------------------
-- Recherche
------------------------------------------------------------------------
function H.search(text)
  H.query = text or ""
  local a = AH()
  if not (a and a.SendBrowseQuery and ns.buy.ahOpen()) then H.results = {}; changed(); return false end
  if H.query == "" then H.results = {}; changed(); return true end
  local sorts = (Enum and Enum.AuctionHouseSortOrder) and { { sortOrder = Enum.AuctionHouseSortOrder.Price, reverseSort = false } } or {}
  local ok, err = pcall(a.SendBrowseQuery, { searchString = H.query, sorts = sorts, filters = {}, itemClassFilters = {} })
  if not ok then say("Recherche refusée : " .. tostring(err)) end
  return ok
end

local function readBrowse()
  local a = AH()
  local list = a.GetBrowseResults and a.GetBrowseResults() or {}
  local out = {}
  for _, r in ipairs(list) do
    local id = r.itemKey and r.itemKey.itemID
    if id then out[#out + 1] = { id = id, name = itemName(id), minPrice = r.minPrice, qty = r.totalQuantity, key = r.itemKey } end
  end
  H.results = out
  changed()
end

------------------------------------------------------------------------
-- Sacs : objets vendables
------------------------------------------------------------------------
function H.readBags()
  local CC, by, order = C_Container, {}, {}
  if not (CC and CC.GetContainerNumSlots) then H.bags = {}; return end
  for bag = 0, 4 do
    for slot = 1, CC.GetContainerNumSlots(bag) do
      local info = CC.GetContainerItemInfo(bag, slot)
      if info and info.itemID and not info.isBound and not info.isLocked then
        local e = by[info.itemID]
        if not e then e = { id = info.itemID, name = itemName(info.itemID), count = 0 }; by[info.itemID] = e; order[#order + 1] = e end
        e.count = e.count + (info.stackCount or 1)
      end
    end
  end
  table.sort(order, function(x, y) return x.name < y.name end)
  H.bags = order
  changed()
end

-- Dépôt estimé (non remboursé si la vente échoue)
function H.deposit(id, duration, qty)
  local a = AH()
  if a and a.CalculateCommodityDeposit then
    local ok, d = pcall(a.CalculateCommodityDeposit, id, duration or 2, qty or 1)
    if ok then return d end
  end
end

------------------------------------------------------------------------
-- Mes ventes
------------------------------------------------------------------------
function H.queryOwned()
  local a = AH()
  if not (a and a.QueryOwnedAuctions and ns.buy.ahOpen()) then return false end
  local sorts = (Enum and Enum.AuctionHouseSortOrder) and { { sortOrder = Enum.AuctionHouseSortOrder.Price, reverseSort = false } } or {}
  return pcall(a.QueryOwnedAuctions, sorts)
end

local function readOwned()
  local a = AH()
  local list = a.GetOwnedAuctions and a.GetOwnedAuctions() or {}
  local out = {}
  for _, r in ipairs(list) do
    local id = r.itemKey and r.itemKey.itemID
    if id and (r.status == nil or r.status == 0) then
      out[#out + 1] = { auctionID = r.auctionID, id = id, name = itemName(id), qty = r.quantity or 1, buyout = r.buyoutAmount, left = r.timeLeftSeconds, time = r.timeLeft }
    end
  end
  table.sort(out, function(x, y) return x.name < y.name end)
  H.owned = out
  changed()
end

function H.cancel(auctionID)
  local a = AH()
  if not (a and a.CancelAuction and auctionID) then return false end
  local ok, err = pcall(a.CancelAuction, auctionID)
  if not ok then say("Annulation refusée : " .. tostring(err)) end
  return ok
end

------------------------------------------------------------------------
-- Ouverture / fermeture de l'HV : on prend la place de la fenêtre Blizzard
------------------------------------------------------------------------
H.showBlizzard = false
function H.applyBlizzard()
  if not AuctionHouseFrame then return end
  if H.showBlizzard then AuctionHouseFrame:SetAlpha(1); AuctionHouseFrame:EnableMouse(true)
  else AuctionHouseFrame:SetAlpha(0); AuctionHouseFrame:EnableMouse(false) end
end

local ev = CreateFrame("Frame")
for _, e in ipairs({ "AUCTION_HOUSE_SHOW", "AUCTION_HOUSE_CLOSED", "AUCTION_HOUSE_BROWSE_RESULTS_UPDATED", "OWNED_AUCTIONS_UPDATED",
                     "AUCTION_CANCELED", "AUCTION_HOUSE_AUCTION_CREATED", "BAG_UPDATE_DELAYED", "GET_ITEM_INFO_RECEIVED" }) do pcall(ev.RegisterEvent, ev, e) end
ev:SetScript("OnEvent", function(_, e)
  local d = db(); if not d then return end
  if e == "AUCTION_HOUSE_SHOW" then
    local s = d.set or {}
    if s.hvReplace ~= false then
      C_Timer.After(0.3, function()
        H.showBlizzard = false; H.applyBlizzard()
        H.readBags(); H.queryOwned()
        if ns.uiShow then ns.uiShow("stock") end
        if ns.gring and ns.gring.select then ns.gring.select("hv") end
      end)
    end
  elseif e == "AUCTION_HOUSE_CLOSED" then
    H.results = {}; H.owned = {}; changed()
  elseif e == "AUCTION_HOUSE_BROWSE_RESULTS_UPDATED" then pcall(readBrowse)
  elseif e == "OWNED_AUCTIONS_UPDATED" then pcall(readOwned)
  elseif e == "AUCTION_CANCELED" or e == "AUCTION_HOUSE_AUCTION_CREATED" then
    H.queryOwned(); H.readBags()
  elseif e == "BAG_UPDATE_DELAYED" then
    if ns.buy.ahOpen() and H.mode == "sell" then H.readBags() end
  elseif e == "GET_ITEM_INFO_RECEIVED" then
    if #H.results > 0 or #H.bags > 0 then
      for _, r in ipairs(H.results) do r.name = itemName(r.id) end
      for _, r in ipairs(H.bags) do r.name = itemName(r.id) end
      changed()
    end
  end
end)
