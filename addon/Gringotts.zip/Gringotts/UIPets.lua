-- Gringotts : onglet Bêtes (chasseur uniquement). Deux vues : Apprivoisement (catalogue, flèche) et Compétences (familles, rangs).
local ADDON, ns = ...
local W = ns.W
local C = W.C
local U = {}
ns.petsUI = U

local S = { view = "tame", filter = "all", q = "", sel = nil, fam = nil, pt = 1 }
local function K() return ns.pets end

local FILTERS = { { "all", "Toutes" }, { "level", "À mon niveau" }, { "rare", "Rares / Élites" }, { "missing", "Familles manquantes" } }

local function dim(s) return W.col(C.grey, s) end
local function rarCol(p)
  local r = K().rarity(p)
  if r == "" then return "" end
  return (p.r == "R" or p.r == "ER") and W.col(C.gold, r) or W.col(C.white, r)
end

function U.visible() return U.p and U.p.pane and U.p.pane:IsShown() end

local function section(parent, label, y)
  return W.text(parent, "GameFontNormal", label, 12, y, 520)
end

------------------------------------------------------------------------
-- Construction
------------------------------------------------------------------------
function U.build(pane)
  local P = {}
  U.p = P
  P.pane = pane
  P.bTame = W.button(pane, "Apprivoisement", 150, 24, function() S.view = "tame"; U.refresh() end)
  P.bTame:SetPoint("TOPLEFT", pane, "TOPLEFT", 0, 0)
  P.bSkill = W.button(pane, "Compétences", 140, 24, function() S.view = "skills"; U.refresh() end)
  P.bSkill:SetPoint("TOPLEFT", pane, "TOPLEFT", 156, 0)
  P.hdr = W.text(pane, "GameFontHighlightSmall", "", 330, -6, 500)
  P.hdr:ClearAllPoints(); P.hdr:SetPoint("TOPRIGHT", pane, "TOPRIGHT", -4, -6); P.hdr:SetJustifyH("RIGHT")

  -- colonne gauche : filtres, recherche, liste
  local Lf = CreateFrame("Frame", nil, pane)
  Lf:SetPoint("TOPLEFT", pane, "TOPLEFT", 0, -34); Lf:SetSize(620, 690)
  P.Lf = Lf
  P.title = W.text(Lf, "GameFontNormalLarge", "", 0, -2, 400)
  P.filt = {}
  local x = 0
  for i, f in ipairs(FILTERS) do
    local w = (i == 4) and 170 or 130
    local b = W.button(Lf, f[2], w, 22, function() S.filter = f[1]; U.refresh() end)
    b:SetPoint("TOPLEFT", Lf, "TOPLEFT", x, -30); b.key = f[1]; P.filt[i] = b
    x = x + w + 6
  end
  W.text(Lf, "GameFontHighlightSmall", "Recherche", 0, -62, 70)
  P.eq = W.edit(Lf, 200, false, function(self) S.q = self:GetText(); U.refresh() end)
  P.eq:SetPoint("TOPLEFT", Lf, "TOPLEFT", 76, -58)
  P.eq:SetScript("OnTextChanged", function(self) local t = self:GetText(); if t ~= S.q then S.q = t; U.refresh() end end)
  P.cHead = {
    W.text(Lf, "GameFontNormalSmall", "", 16, -86, 220),
    W.text(Lf, "GameFontNormalSmall", "", 244, -86, 100),
    W.text(Lf, "GameFontNormalSmall", "", 350, -86, 50, "RIGHT"),
    W.text(Lf, "GameFontNormalSmall", "", 410, -86, 130),
    W.text(Lf, "GameFontNormalSmall", "", 540, -86, 60, "RIGHT"),
  }
  P.list = W.list(Lf, 616, 560, 22, function(b)
    b.c1 = W.text(b, "GameFontHighlight", "", 16, -3, 224); if b.c1.SetWordWrap then b.c1:SetWordWrap(false) end
    b.c2 = W.text(b, "GameFontHighlightSmall", "", 244, -4, 100); if b.c2.SetWordWrap then b.c2:SetWordWrap(false) end
    b.c3 = W.text(b, "GameFontHighlight", "", 350, -3, 50, "RIGHT")
    b.c4 = W.text(b, "GameFontHighlightSmall", "", 410, -4, 126); if b.c4.SetWordWrap then b.c4:SetWordWrap(false) end
    b.c5 = W.text(b, "GameFontHighlightSmall", "", 540, -4, 60, "RIGHT")
    b.mark = W.fill(b, .56, .82, .54, 1, "ARTWORK"); b.mark:SetSize(8, 8); b.mark:SetPoint("LEFT", b, "LEFT", 3, 0)
    b:SetScript("OnClick", function(self)
      local e = self.entry; if not e then return end
      if S.view == "tame" then S.sel = e.id; S.pt = 1 else S.fam = e.n end
      U.refresh()
    end)
  end, function(b, e)
    b.entry = e
    if S.view == "tame" then
      local ok = K().canTame(e)
      b.mark:SetShown(true)
      b.mark:SetColorTexture(ok and .56 or .35, ok and .82 or .35, ok and .54 or .35, 1)
      b.c1:SetText(ok and e.n or dim(e.n))
      b.c2:SetText(dim(e.f))
      b.c3:SetText(ok and K().levelText(e) or dim(K().levelText(e)))
      b.c4:SetText(dim(e.z or ""))
      b.c5:SetText(rarCol(e))
      if b.sel then b.sel:SetShown(S.sel == e.id) end
    else
      b.mark:SetShown(true)
      b.mark:SetColorTexture(e.seen and .56 or .35, e.seen and .82 or .35, e.seen and .54 or .35, 1)
      b.c1:SetText(e.n)
      b.c2:SetText(""); b.c3:SetText("")
      b.c4:SetText(dim(e.spec or "—"))
      b.c5:SetText(dim(e.count .. " bêtes"))
      if b.sel then b.sel:SetShown(S.fam == e.n) end
    end
  end)
  P.list.frame:SetPoint("TOPLEFT", Lf, "TOPLEFT", 0, -104)
  P.note = W.text(Lf, "GameFontHighlightSmall", "", 0, -670, 600)

  -- colonne centrale : détail
  local D = CreateFrame("Frame", nil, pane)
  D:SetPoint("TOPLEFT", pane, "TOPLEFT", 632, -34); D:SetSize(560, 690)
  W.fill(D, .05, .06, .09, 1):SetAllPoints()
  P.D = D
  P.dTitle = W.text(D, "GameFontNormalLarge", "", 12, -8, 530)
  P.dSub = W.text(D, "GameFontHighlightSmall", "", 12, -34, 530)
  P.tiles = {}
  for i = 1, 4 do
    local t = W.tile(D, 128, 70)
    t.frame:SetPoint("TOPLEFT", D, "TOPLEFT", 12 + (i - 1) * 136, -56)
    P.tiles[i] = t
  end
  P.s1 = section(D, "", -140)
  P.t1 = W.text(D, "GameFontHighlight", "", 12, -162, 536)
  P.bAim = W.button(D, "Cibler avec la flèche", 180, 22, function()
    local p = K().byId(S.sel); if not p then return end
    local ok, idx = K().aim(p, S.pt)
    if ok then S.pt = idx % #p.p + 1 end
    U.refresh()
  end)
  P.bAim:SetPoint("TOPLEFT", D, "TOPLEFT", 12, -250)
  P.bAimOff = W.button(D, "Arrêter la flèche", 140, 22, function() if ns.arrowGoto then ns.arrowGoto(nil) end; U.refresh() end)
  P.bAimOff:SetPoint("TOPLEFT", D, "TOPLEFT", 198, -250)
  P.bGoal = W.button(D, "Ajouter à « À viser »", 170, 22, function()
    local p = K().byId(S.sel); if p then K().toggleGoal(p.id) end; U.refresh()
  end)
  P.bGoal:SetPoint("TOPLEFT", D, "TOPLEFT", 344, -250)
  P.s2 = section(D, "", -284)
  P.t2 = W.text(D, "GameFontHighlight", "", 12, -306, 536)
  P.s3 = section(D, "", -440)
  P.t3 = W.text(D, "GameFontHighlight", "", 12, -462, 536)
  -- Compétences : bêtes qui enseignent (lignes cliquables)
  P.teach = {}
  for i = 1, 4 do
    local b = CreateFrame("Button", nil, D)
    b:SetSize(536, 20); b:SetPoint("TOPLEFT", D, "TOPLEFT", 12, -(330 + (i - 1) * 22))
    b.hl = W.fill(b, 1, .83, .42, .10, "HIGHLIGHT"); b.hl:SetAllPoints()
    b.txt = W.text(b, "GameFontHighlight", "", 4, -3, 520)
    b:SetScript("OnClick", function(self) if self.petId then S.view = "tame"; S.filter = "all"; S.sel = self.petId; S.pt = 1; U.refresh() end end)
    P.teach[i] = b
  end

  -- colonne droite : familier actif, à viser
  local R = CreateFrame("Frame", nil, pane)
  R:SetPoint("TOPLEFT", pane, "TOPLEFT", 1204, -34); R:SetSize(270, 690)
  W.fill(R, .05, .06, .09, 1):SetAllPoints()
  P.R = R
  W.text(R, "GameFontNormalLarge", "Familier actif", 10, -8, 250)
  P.rActive = W.text(R, "GameFontHighlight", "", 10, -34, 250)
  W.text(R, "GameFontNormalLarge", "À viser", 10, -120, 250)
  P.goals = {}
  for i = 1, 8 do
    local b = CreateFrame("Button", nil, R)
    b:SetSize(250, 34); b:SetPoint("TOPLEFT", R, "TOPLEFT", 10, -(146 + (i - 1) * 38))
    b.hl = W.fill(b, 1, .83, .42, .10, "HIGHLIGHT"); b.hl:SetAllPoints()
    b.txt = W.text(b, "GameFontHighlightSmall", "", 2, -2, 246)
    b:SetScript("OnClick", function(self) if self.petId then S.view = "tame"; S.filter = "all"; S.sel = self.petId; S.pt = 1; U.refresh() end end)
    P.goals[i] = b
  end
  P.rRules = W.text(R, "GameFontHighlightSmall", dim("Bonheur : Heureux 125 %, Content 100 %, Mécontent 75 % des dégâts. Le familier gagne 25 % de ton XP et ne dépasse pas ton niveau. 3 familiers max : 1 actif + 2 à l'écurie."), 10, -470, 250)
end

------------------------------------------------------------------------
-- Rafraîchissement
------------------------------------------------------------------------
local function setTiles(P, a)
  for i = 1, 4 do
    local t = a[i]
    if t then P.tiles[i].frame:Show(); P.tiles[i]:Set(t[1], t[2], t[3]) else P.tiles[i].frame:Hide() end
  end
end

local function refreshTame(P)
  local lvl = K().level()
  local list = K().list(S.filter, S.q)
  if not S.sel or not K().byId(S.sel) then S.sel = list[1] and list[1].id or nil end
  P.title:SetText("Bêtes")
  P.cHead[1]:SetText("Bête"); P.cHead[2]:SetText("Famille"); P.cHead[3]:SetText("Niv."); P.cHead[4]:SetText("Zone"); P.cHead[5]:SetText("Statut")
  P.list:SetData(list, true)
  P.note:SetText(dim(("Vert = apprivoisable maintenant (niveau ≤ %d). %d bêtes affichées sur %d relevées sur Wowhead Forever FR."):format(lvl, #list, #K().all())))
  local p = K().byId(S.sel)
  P.bAim:SetShown(true); P.bAimOff:SetShown(true); P.bGoal:SetShown(true)
  for i = 1, 4 do P.teach[i]:Hide() end
  if not p then
    P.dTitle:SetText("Aucune bête"); P.dSub:SetText(""); setTiles(P, {}); P.s1:SetText(""); P.t1:SetText(""); P.s2:SetText(""); P.t2:SetText(""); P.s3:SetText(""); P.t3:SetText("")
    P.bAim:Hide(); P.bAimOff:Hide(); P.bGoal:Hide()
    return
  end
  local ok = K().canTame(p, lvl)
  P.dTitle:SetText(p.n)
  P.dSub:SetText(("%s · niveau %s%s · %s"):format(p.f, K().levelText(p), (K().rarity(p) ~= "") and (" · " .. K().rarity(p):lower()) or "", p.z or "—"))
  local fs
  for _, f in ipairs(K().fams()) do if f.n == p.f then fs = f.spec end end
  setTiles(P, {
    { "Niveau", K().levelText(p), p.lo and (ok and ("tu es niveau " .. lvl .. " : apprivoisable") or ("tu es niveau " .. lvl .. " : trop bas")) or "niveau non relevé" },
    { "Famille", p.f, fs and ("capacité propre : " .. fs) or "pas de capacité propre" },
    { "Vitesse d'attaque", p.sp and (("%.2f"):format(p.sp):gsub("%.", ",") .. " s") or "—", p.sp and "relevée sur Wowhead" or "non relevée" },
    { "Enseigne", (p.a and #p.a > 0) and (p.L and "capacités" or "1 à 2 capacités") or "rien", (p.a and #p.a > 0) and (K().abilityText(p):sub(1, 60)) or "aucune capacité à apprendre" },
  })
  P.s1:SetText("Où le trouver")
  if p.m and p.p then
    local pts = {}
    for i, c in ipairs(p.p) do pts[#pts + 1] = ("%s%d, %d%s"):format((i == S.pt) and "|cffffd36b" or "", math.floor(c[1] + .5), math.floor(c[2] + .5), (i == S.pt) and "|r" or "") end
    P.t1:SetText(("%s : %s\n%s"):format(p.z or "—", table.concat(pts, "  ·  "),
      dim("Points de passage les plus fréquents (carte, en %). Chaque clic sur « Cibler » passe au point suivant ; la flèche et la boussole s'affichent.")))
    P.bAim:Enable()
  else
    P.t1:SetText(("%s\n%s"):format(p.z or "—", dim("Pas de coordonnées connues (donjon, instance ou zone sans carte) : la flèche ne peut pas viser cette bête.")))
    P.bAim:Disable()
  end
  local man = ns.arrowManual and ns.arrowManual()
  P.bAimOff:SetShown(man and true or false)
  P.bGoal:SetText(K().st().goals[p.id] and "Retirer de « À viser »" or "Ajouter à « À viser »")
  -- ce que la bête apporte
  P.s2:SetText("Ce qu'elle t'apporte")
  local lines = {}
  if p.a and #p.a > 0 then lines[#lines + 1] = K().abilityText(p) end
  local best = K().famBest(p.f, lvl)
  for _, a in ipairs(p.a or {}) do
    local b = a[2] and best[a[1]]
    if b and b.rank > a[2] and b.pet.id ~= p.id then
      lines[#lines + 1] = W.col(C.orange, ("%s : rang %d accessible chez %s (niv. %s, %s)"):format(a[1], b.rank, b.pet.n, K().levelText(b.pet), b.pet.z or "—"))
    end
  end
  if p.sp then lines[#lines + 1] = ("Attaque rapide : %s s entre deux coups."):format(("%.2f"):format(p.sp):gsub("%.", ",")) end
  if #lines == 0 then lines[1] = dim("Cette bête n'enseigne rien : à apprivoiser pour son apparence ou sa vitesse d'attaque.") end
  P.t2:SetText(table.concat(lines, "\n"))
  P.s3:SetText("Avant d'apprivoiser")
  local act = K().active()
  P.t3:SetText((act and W.col(C.orange, ("Familier actif : %s. Renvoie-le à l'écurie : Apprivoiser est impossible avec un familier actif, même renvoyé.\n"):format(act.name or "?")) or "")
    .. "Armure −100 % pendant la canalisation ; si la bête perd son aggro ou subit des dégâts, l'apprivoisement échoue. Pas d'apprivoisement avec un familier mort à l'écurie. Bête de niveau ≤ le tien.")
end

local function refreshSkills(P)
  local lvl = K().level()
  local fams = K().fams()
  if not S.fam then S.fam = fams[1] and fams[1].n or nil end
  P.title:SetText("Familles")
  P.cHead[1]:SetText("Famille"); P.cHead[2]:SetText(""); P.cHead[3]:SetText(""); P.cHead[4]:SetText("Capacité propre"); P.cHead[5]:SetText("")
  P.list:SetData(fams, true)
  P.note:SetText(dim(("Vert = famille déjà apprivoisée (relevée sur ton personnage). %d familles."):format(#fams)))
  for i = 1, 4 do P.teach[i]:Hide() end
  P.bAim:Hide(); P.bAimOff:Hide(); P.bGoal:Hide()
  local f
  for _, x in ipairs(fams) do if x.n == S.fam then f = x end end
  if not f then P.dTitle:SetText("Aucune famille"); P.dSub:SetText(""); setTiles(P, {}); P.s1:SetText(""); P.t1:SetText(""); P.s2:SetText(""); P.t2:SetText(""); P.s3:SetText(""); P.t3:SetText(""); return end
  local names, best = K().famAbilities(f.n)
  local now = K().famBest(f.n, lvl)
  P.dTitle:SetText(f.n)
  P.dSub:SetText("Famille" .. (f.spec and (" · capacité propre : " .. f.spec) or "") .. (f.seen and " · déjà apprivoisée" or ""))
  local function tileFor(name)
    local b = name and best[name]
    if not b then return { name or "—", "—", "non relevée" } end
    return { name, "r." .. b.rank, (b.tp and (b.tp .. " TP") or "coût non relevé") }
  end
  local t3 = best["Morsure"] and "Morsure" or best["Griffe"] and "Griffe" or names[2]
  local t4 = best["Célérité"] and "Célérité" or names[3]
  setTiles(P, {
    { "Capacité propre", f.spec or "—", f.spec and best[f.spec] and ("rang max relevé : " .. best[f.spec].rank) or "" },
    { "Bêtes relevées", tostring(f.count), "dans le catalogue" },
    tileFor(t3), tileFor(t4),
  })
  P.s1:SetText("Où apprendre chaque rang")
  local rows = {}
  for _, n in ipairs(names) do
    local b, c = best[n], now[n]
    rows[#rows + 1] = ("%s · max r.%d : %s (niv. %s, %s)\n    %s"):format(n, b.rank, b.pet.n, K().levelText(b.pet), b.pet.z or "—",
      c and W.col(C.orange, ("à ton niveau (%d) : rang %d chez %s (niv. %s)"):format(lvl, c.rank, c.pet.n, K().levelText(c.pet))) or dim("aucune bête à ton niveau"))
  end
  P.t1:SetText(table.concat(rows, "\n"))
  P.s2:SetText(("Bêtes qui enseignent à ton niveau (%d)"):format(lvl))
  P.t2:SetText("")
  local tl = K().teachers(f.n, 4)
  for i = 1, 4 do
    local p, b = tl[i], P.teach[i]
    if p then b.petId = p.id; b.txt:SetText(("%s · niv. %s · %s    %s"):format(p.n, K().levelText(p), p.z or "—", dim(K().abilityText(p)))); b:Show()
    else b.petId = nil; b:Hide() end
  end
  P.s3:SetText("")
  P.t3:SetText(dim("Apprendre une capacité : apprivoiser la bête qui l'enseigne, puis la faire apprendre à ton familier. TP = points d'entraînement. Clique une bête pour la voir dans Apprivoisement. Les paliers de Célérité (niveau 30) ne sont pas interprétés."))
  if #tl == 0 then P.t2:SetText(dim("Aucune bête de cette famille n'enseigne quoi que ce soit à ton niveau.")) end
end

function U.refresh()
  local P = U.p; if not P then return end
  K().seeActive()
  local lvl = K().level()
  for _, b in ipairs(P.filt) do
    if b.key == S.filter then b:Disable() else b:Enable() end
    b:SetShown(S.view == "tame")
  end
  P.eq:SetShown(S.view == "tame")
  if S.view == "tame" then P.bTame:Disable(); P.bSkill:Enable(); refreshTame(P) else P.bTame:Enable(); P.bSkill:Disable(); refreshSkills(P) end
  local a = K().active()
  P.hdr:SetText(W.col(C.green, (UnitName and UnitName("player") or "") .. " · niveau " .. lvl .. " · chasseur"))
  P.rActive:SetText(a and (("%s\n%s · niveau %s\n%s"):format(W.col(C.gold, a.name or "?"), a.fam or "?", a.lvl or "?", (K().happyText(a.happy) and ("Bonheur : " .. K().happyText(a.happy)) or "")))
    or dim("Aucun familier actif. Famille, niveau et bonheur sont lus en jeu."))
  local goals = K().goals()
  for i = 1, 8 do
    local p, b = goals[i], P.goals[i]
    if p then
      b.petId = p.id; b:Show()
      local gap = p.lo and (p.lo > lvl) and W.col(C.orange, ("encore %d niveaux"):format(p.lo - lvl)) or W.col(C.green, "apprivoisable")
      b.txt:SetText(("%s · %s niv. %s\n%s · %s"):format(W.col(C.gold, p.n), p.f, K().levelText(p), gap, p.z or "—"))
    else b.petId = nil; b:Hide() end
  end
end

function U.setView(v) if v == "skills" or v == "tame" then S.view = v end end
function U.select(id) S.view = "tame"; S.filter = "all"; S.sel = id; S.pt = 1 end
