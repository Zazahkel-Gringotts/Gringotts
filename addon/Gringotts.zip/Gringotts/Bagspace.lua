-- Gringotts : compteur de places libres (libres / total) affiché sur la fenêtre d'inventaire de Bagnon,
-- au-dessus de la rangée d'emplacements de sacs. Sans Bagnon : ne fait rien. Désactivable : GringottsDB.noBagCounter = true
local ADDON, ns = ...

local fs, host
local lastTry = 0
local function bagnonLoaded()
  local f = (C_AddOns and C_AddOns.IsAddOnLoaded) or IsAddOnLoaded
  return f and f("Bagnon")
end

local function slots()
  local C = C_Container
  local numSlots = (C and C.GetContainerNumSlots) or GetContainerNumSlots
  local numFree = (C and C.GetContainerNumFreeSlots) or GetContainerNumFreeSlots
  if not numSlots or not numFree then return end
  local free, total = 0, 0
  for bag = 0, (NUM_BAG_SLOTS or 4) do   -- sacs portés (le sac de composants n'est pas compté)
    local ok, n = pcall(numSlots, bag)
    if ok and type(n) == "number" and n > 0 then
      local ok2, f = pcall(numFree, bag)
      if ok2 and type(f) == "number" then free = free + f; total = total + n end
    end
  end
  return free, total
end

local function update()
  if not fs then return end
  local free, total = slots()
  if not free or total == 0 then fs:SetText(""); return end
  local r, g, b = .31, .78, .55                                  -- vert
  if free <= 3 then r, g, b = .93, .42, .34                      -- rouge
  elseif free <= math.max(6, total * .15) then r, g, b = .92, .66, .27 end   -- orange
  fs:SetTextColor(r, g, b)
  fs:SetText(("Sacs : %d / %d libres"):format(free, total))
end

-- Retrouve la fenêtre d'inventaire de Bagnon (objet de type Frame avec id « inventory » et un BagGroup)
local function findFrame()
  if not EnumerateFrames then return end
  local f = EnumerateFrames()
  while f do
    local ok, hit = pcall(function() return f.id == "inventory" and f.BagGroup and f.Layout and f.GetObjectType and f:GetObjectType() == "Frame" end)
    if ok and hit then return f end
    f = EnumerateFrames(f)
  end
end

local function place()
  if not host then return end
  fs:ClearAllPoints()
  local bg = host.BagGroup
  if bg and bg.IsShown and bg:IsShown() then
    fs:SetPoint("BOTTOMLEFT", bg, "TOPLEFT", 2, 3)
  else
    fs:SetPoint("BOTTOMLEFT", host, "BOTTOMLEFT", 10, 6)       -- sacs masqués : en bas de la fenêtre
  end
end

local function attach()
  if fs or (GringottsDB and GringottsDB.noBagCounter) then return end
  local f = findFrame()
  if not f then return end
  host = f
  fs = f:CreateFontString(nil, "OVERLAY", "GringottsTextSmall")
  fs:SetJustifyH("LEFT")
  place(); update()
  f:HookScript("OnShow", function() place(); update() end)
  if f.Layout then hooksecurefunc(f, "Layout", function() place() end) end
end

local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_ENTERING_WORLD")
ev:RegisterEvent("BAG_UPDATE_DELAYED")
ev:RegisterEvent("BAG_UPDATE")
ev:SetScript("OnEvent", function(_, e)
  if not fs then
    -- Bagnon crée sa fenêtre à la demande : on réessaie à chaque mise à jour de sacs, avec un plafond
    local now = GetTime and GetTime() or 0
    if now - lastTry >= 5 and bagnonLoaded() then lastTry = now; attach() end
  elseif e ~= "BAG_UPDATE" then update()
  elseif host and host:IsShown() then update() end
end)
if C_Timer and C_Timer.After then C_Timer.After(3, attach) end
