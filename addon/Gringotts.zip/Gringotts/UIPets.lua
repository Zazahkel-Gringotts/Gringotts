-- Gringotts : onglet Bêtes (chasseur uniquement). Trois vues : Apprivoisement (catalogue, flèche), Compétences (familles, rangs) et Mon familier (stats, 3D, évolutions).
local ADDON, ns = ...
local W = ns.W
local C = W.C
local U = {}
ns.petsUI = U

local S = { view = "tame", filter = "all", q = "", sel = nil, fam = nil, pt = 1, famFilter = nil }
local function K() return ns.pets end

local FILTERS = { { "all", "Toutes" }, { "level", "À mon niveau" }, { "rare", "Rares / Élites" }, { "missing", "Familles manquantes" } }

local function dim(s) return W.col(C.grey, s) end
local function rarCol(p)
  local r = K().rarity(p)
  if r == "" then return "" end
  return (p.r == "R" or p.r == "ER") and W.col(C.gold, r) or W.col(C.white, r)
end


-- Icône ronde (masque de portrait si le client l'offre, sinon carrée recadrée)
local function roundIcon(parent, size, tex)
  local t = parent:CreateTexture(nil, "ARTWORK")
  t:SetSize(size, size)
  if t.SetMask then pcall(t.SetMask, t, "Interface\\CharacterFrame\\TempPortraitAlphaMask") else t:SetTexCoord(.08, .92, .08, .92) end
  if tex then t:SetTexture(tex) end
  return t
end
-- Régime : un objet représentatif par aliment (l'icône vient du client ; point d'interrogation si inconnu)
local FOOD_ITEM = { ["Viande"] = 117, ["Poisson"] = 6291, ["Poisson cru"] = 6291, ["Fromage"] = 414, ["Pain"] = 4540, ["Champignon"] = 4605, ["Fruit"] = 4536 }
local function foodIcon(food) return W.itemIcon(FOOD_ITEM[food]) end

-- Barre centrée sur zéro : vert à droite (bonus), rouge à gauche (malus)
local BAR_W, BAR_MAX = 84, 15
local function bipolar(parent, x, y)
  local b = {}
  b.track = W.fill(parent, ns.theme.c.panel2[1], ns.theme.c.panel2[2], ns.theme.c.panel2[3], 1); b.track:SetSize(BAR_W, 6); b.track:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
  b.mid = W.fill(parent, .55, .6, .68, .9, "ARTWORK"); b.mid:SetSize(1, 10); b.mid:SetPoint("TOP", b.track, "TOP", 0, 2)
  b.fill = W.fill(parent, .31, .78, .55, 1, "ARTWORK"); b.fill:SetHeight(6)
  function b:Set(v)
    v = v or 0
    local w = math.min(BAR_W / 2, math.abs(v) / BAR_MAX * (BAR_W / 2))
    self.fill:ClearAllPoints()
    if v == 0 or w < 1 then self.fill:Hide(); return end
    self.fill:Show(); self.fill:SetWidth(w)
    if v > 0 then self.fill:SetPoint("LEFT", self.track, "LEFT", BAR_W / 2, 0); self.fill:SetColorTexture(.31, .78, .55, 1)
    else self.fill:SetPoint("RIGHT", self.track, "LEFT", BAR_W / 2, 0); self.fill:SetColorTexture(.93, .42, .34, 1) end
  end
  return b
end

function U.visible() return U.p and U.p.pane and U.p.pane:IsShown() end

local function section(parent, label, y)
  return W.text(parent, "GringottsLabel", label, 12, y, 520)
end

------------------------------------------------------------------------
-- Construction
------------------------------------------------------------------------
function U.build(pane)
  local P = {}
  U.p = P
  P.pane = pane
  P.bTame = W.button(pane, "Apprivoisement", 150, 24, function() S.view = "tame"; U.refresh() end)
  P.bTame:SetPoint("TOPLEFT", pane, "TOPLEFT", 0, 0)
  P.bSkill = W.button(pane, "Compétences", 140, 24, function() S.view = "skills"; U.refresh() end)
  P.bSkill:SetPoint("TOPLEFT", pane, "TOPLEFT", 156, 0)
  P.bMine = W.button(pane, "Mon familier", 140, 24, function() S.view = "mine"; U.refresh() end)
  P.bMine:SetPoint("TOPLEFT", pane, "TOPLEFT", 302, 0)
  P.hdr = W.text(pane, "GringottsTextSmall", "", 330, -6, 500)
  P.hdr:ClearAllPoints(); P.hdr:SetPoint("TOPRIGHT", pane, "TOPRIGHT", -4, -6); P.hdr:SetJustifyH("RIGHT")

  -- colonne gauche : filtres, recherche, liste
  local Lf = CreateFrame("Frame", nil, pane)
  Lf:SetPoint("TOPLEFT", pane, "TOPLEFT", 0, -34); Lf:SetSize(620, 690)
  P.Lf = Lf
  P.title = W.text(Lf, "GringottsH2", "", 0, -2, 400)
  P.filt = {}
  local x = 0
  for i, f in ipairs(FILTERS) do
    local w = (i == 4) and 170 or 130
    local b = W.button(Lf, f[2], w, 22, function() S.filter = f[1]; U.refresh() end)
    b:SetPoint("TOPLEFT", Lf, "TOPLEFT", x, -30); b.key = f[1]; P.filt[i] = b
    x = x + w + 6
  end
  W.text(Lf, "GringottsTextSmall", "Recherche", 0, -62, 70)
  P.eq = W.edit(Lf, 200, false, function(self) S.q = self:GetText(); U.refresh() end)
  P.eq:SetPoint("TOPLEFT", Lf, "TOPLEFT", 76, -58)
  P.eq:SetScript("OnTextChanged", function(self) local t = self:GetText(); if t ~= S.q then S.q = t; U.refresh() end end)
  -- bandeau d'icônes de familles : un clic filtre la liste
  P.strip = CreateFrame("Frame", nil, Lf); P.strip:SetSize(616, 28); P.strip:SetPoint("TOPLEFT", Lf, "TOPLEFT", 0, -84)
  P.stripAll = W.button(P.strip, "Toutes", 58, 24, function() S.famFilter = nil; U.refresh() end)
  P.stripAll:SetPoint("TOPLEFT", P.strip, "TOPLEFT", 0, 0)
  P.stripBtn = {}
  for i, f in ipairs(K().fams()) do
    local b = CreateFrame("Button", nil, P.strip)
    b:SetSize(26, 26); b:SetPoint("TOPLEFT", P.strip, "TOPLEFT", 66 + (i - 1) * 30, 0)
    b.ico = roundIcon(b, 22, f.icon); b.ico:SetPoint("CENTER")
    b.ring = W.fill(b, W.C.gold[1], W.C.gold[2], W.C.gold[3], 1, "BACKGROUND"); b.ring:SetAllPoints(); b.ring:Hide()
    b.hl = W.fill(b, 1, 1, 1, .12, "HIGHLIGHT"); b.hl:SetAllPoints()
    b.fam = f.n
    b:SetScript("OnClick", function(self) S.famFilter = (S.famFilter == self.fam) and nil or self.fam; U.refresh() end)
    b:SetScript("OnEnter", function(self)
      if not GameTooltip then return end
      GameTooltip:SetOwner(self, "ANCHOR_BOTTOM"); GameTooltip:SetText(self.fam); GameTooltip:AddLine(("%d bêtes"):format(self.count or 0), .7, .75, .8); GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() if GameTooltip then GameTooltip:Hide() end end)
    b.count = f.count
    P.stripBtn[i] = b
  end
  P.cHead = {
    W.text(Lf, "GringottsLabelSmall", "", 16, -118, 220),
    W.text(Lf, "GringottsLabelSmall", "", 244, -118, 100),
    W.text(Lf, "GringottsLabelSmall", "", 350, -118, 50, "RIGHT"),
    W.text(Lf, "GringottsLabelSmall", "", 410, -118, 130),
    W.text(Lf, "GringottsLabelSmall", "", 540, -118, 60, "RIGHT"),
  }
  P.list = W.list(Lf, 616, 528, 22, function(b)
    b.c1 = W.text(b, "GringottsText", "", 16, -3, 224); if b.c1.SetWordWrap then b.c1:SetWordWrap(false) end
    b.c2 = W.text(b, "GringottsTextSmall", "", 244, -4, 100); if b.c2.SetWordWrap then b.c2:SetWordWrap(false) end
    b.c3 = W.text(b, "GringottsText", "", 350, -3, 50, "RIGHT")
    b.c4 = W.text(b, "GringottsTextSmall", "", 410, -4, 126); if b.c4.SetWordWrap then b.c4:SetWordWrap(false) end
    b.c5 = W.text(b, "GringottsTextSmall", "", 540, -4, 60, "RIGHT")
    b.mark = W.fill(b, W.C.green[1], W.C.green[2], W.C.green[3], 1, "ARTWORK"); b.mark:SetSize(8, 8); b.mark:SetPoint("LEFT", b, "LEFT", 3, 0)
    b:SetScript("OnClick", function(self)
      local e = self.entry; if not e then return end
      if S.view == "tame" then S.sel = e.id; S.pt = 1 else S.fam = e.n end
      U.refresh()
    end)
  end, function(b, e)
    b.entry = e
    if S.view == "tame" then
      local ok = K().canTame(e)
      b.mark:SetShown(true)
      b.mark:SetColorTexture(ok and W.C.green[1] or .35, ok and W.C.green[2] or .35, ok and W.C.green[3] or .35, 1)
      b.c1:SetText(ok and e.n or dim(e.n))
      b.c2:SetText(dim(e.f))
      b.c3:SetText(ok and K().levelText(e) or dim(K().levelText(e)))
      b.c4:SetText(dim(e.z or ""))
      b.c5:SetText(rarCol(e))
      if b.sel then b.sel:SetShown(S.sel == e.id) end
    else
      b.mark:SetShown(true)
      b.mark:SetColorTexture(e.seen and W.C.green[1] or .35, e.seen and W.C.green[2] or .35, e.seen and W.C.green[3] or .35, 1)
      b.c1:SetText(e.n)
      b.c2:SetText(""); b.c3:SetText("")
      b.c4:SetText(dim(e.spec or "—"))
      b.c5:SetText(dim(e.count .. " bêtes"))
      if b.sel then b.sel:SetShown(S.fam == e.n) end
    end
  end)
  P.list.frame:SetPoint("TOPLEFT", Lf, "TOPLEFT", 0, -136)
  P.note = W.text(Lf, "GringottsTextSmall", "", 0, -670, 600)
  -- grille de familles (vue Compétences) : 3 colonnes x 6 rangées de cartes
  P.grid = CreateFrame("Frame", nil, Lf); P.grid:SetSize(616, 660); P.grid:SetPoint("TOPLEFT", Lf, "TOPLEFT", 0, -30)
  P.cards = {}
  local CW, CH, GAP = 200, 104, 8
  for i, f in ipairs(K().fams()) do
    local c = CreateFrame("Button", nil, P.grid)
    c:SetSize(CW, CH); c:SetPoint("TOPLEFT", P.grid, "TOPLEFT", ((i - 1) % 3) * (CW + GAP), -math.floor((i - 1) / 3) * (CH + 6))
    ns.theme.panel(c, "panel", "line", 0)
    c.sel = W.fill(c, W.C.gold[1], W.C.gold[2], W.C.gold[3], .14, "BACKGROUND"); c.sel:SetAllPoints(); c.sel:Hide()
    c.hl = W.fill(c, 1, 1, 1, .06, "HIGHLIGHT"); c.hl:SetAllPoints()
    c.ico = roundIcon(c, 36, f.icon); c.ico:SetPoint("TOPLEFT", c, "TOPLEFT", 8, -8)
    c.name = W.text(c, "GringottsText", f.n, 50, -9, CW - 58)
    c.count = W.text(c, "GringottsTextSmall", "", 50, -26, CW - 58)
    c.bars = {}
    for j, lab in ipairs({ "Dégâts", "Armure", "Vie" }) do
      local y = -50 - (j - 1) * 13
      W.text(c, "GringottsTextSmall", dim(lab), 8, y + 3, 46)
      c.bars[j] = bipolar(c, 56, y - 2)
      c["v" .. j] = W.text(c, "GringottsTextSmall", "", 144, y + 3, CW - 152, "RIGHT")
    end
    c.food = {}
    for j = 1, 6 do
      local t = c:CreateTexture(nil, "ARTWORK"); t:SetSize(14, 14); t:SetPoint("TOPLEFT", c, "TOPLEFT", 8 + (j - 1) * 17, -88); t:Hide(); c.food[j] = t
    end
    c.fam = f.n
    c:SetScript("OnClick", function(self) S.fam = self.fam; U.refresh() end)
    P.cards[i] = c
  end


  -- colonne centrale : détail
  local D = CreateFrame("Frame", nil, pane)
  D:SetPoint("TOPLEFT", pane, "TOPLEFT", 632, -34); D:SetSize(560, 690)
  ns.theme.panel(D, "panel", "line")
  P.D = D
  P.dTitle = W.text(D, "GringottsH2", "", 12, -8, 530)
  P.dSub = W.text(D, "GringottsTextSmall", "", 12, -34, 530)
  P.tiles = {}
  -- modèle 3D animé (grand, à gauche) ; tuiles en 2 x 2 à sa droite
  local MW, MH = 232, 196
  local mbg = CreateFrame("Frame", nil, D); mbg:SetSize(MW, MH); mbg:SetPoint("TOPLEFT", D, "TOPLEFT", 12, -56)
  ns.theme.panel(mbg, "bg", "line")
  P.mbg = mbg
  local okm, model = pcall(CreateFrame, "PlayerModel", nil, mbg)
  if okm and model then
    model:SetPoint("TOPLEFT", mbg, "TOPLEFT", 2, -2); model:SetPoint("BOTTOMRIGHT", mbg, "BOTTOMRIGHT", -2, 2)
    model.rot = 0
    model:SetScript("OnUpdate", function(self, dt)
      if not self.cid then return end
      self.rot = (self.rot + (dt or 0) * 0.6) % (math.pi * 2)   -- un tour en ~10 s
      if self.SetFacing then pcall(self.SetFacing, self, self.rot) end
    end)
    P.model = model
  end
  P.mNote = W.text(mbg, "GringottsTextSmall", "", 0, -90, MW, "CENTER")
  for i = 1, 4 do
    local t = W.tile(D, 150, 70)
    t.frame:SetPoint("TOPLEFT", D, "TOPLEFT", 252 + ((i - 1) % 2) * 156, -56 - math.floor((i - 1) / 2) * 76)
    -- valeur en police moyenne, une seule ligne : pas de chevauchement avec le sous-texte
    if t.value.SetFontObject then pcall(t.value.SetFontObject, t.value, "GringottsValue") end
    for _, fs in ipairs({ t.label, t.value, t.sub }) do if fs.SetWordWrap then fs:SetWordWrap(false) end; if fs.SetMaxLines then fs:SetMaxLines(1) end end
    P.tiles[i] = t
  end
  P.s1 = section(D, "", -270)
  P.t1 = W.text(D, "GringottsText", "", 12, -292, 536)
  P.bAim = W.button(D, "Cibler avec la flèche", 180, 22, function()
    local p = K().byId(S.sel); if not p then return end
    local ok, idx = K().aim(p, S.pt)
    if ok then S.pt = idx % #p.p + 1 end
    U.refresh()
  end)
  P.bAim:SetPoint("TOPLEFT", D, "TOPLEFT", 12, -380)
  P.bAimOff = W.button(D, "Arrêter la flèche", 140, 22, function() if ns.arrowGoto then ns.arrowGoto(nil) end; U.refresh() end)
  P.bAimOff:SetPoint("TOPLEFT", D, "TOPLEFT", 198, -380)
  P.bGoal = W.button(D, "Ajouter à « À viser »", 170, 22, function()
    local p = K().byId(S.sel); if p then K().toggleGoal(p.id) end; U.refresh()
  end)
  P.bGoal:SetPoint("TOPLEFT", D, "TOPLEFT", 344, -380)
  P.s2 = section(D, "", -414)
  P.t2 = W.text(D, "GringottsText", "", 12, -436, 536)
  P.s3 = section(D, "", -570)
  P.t3 = W.text(D, "GringottsText", "", 12, -592, 536)
  -- Compétences : bêtes qui enseignent (lignes cliquables)
  P.teach = {}
  for i = 1, 4 do
    local b = CreateFrame("Button", nil, D)
    b:SetSize(536, 34); b:SetPoint("TOPLEFT", D, "TOPLEFT", 12, -(460 + (i - 1) * 36))
    b.hl = W.fill(b, W.C.gold[1], W.C.gold[2], W.C.gold[3], .10, "HIGHLIGHT"); b.hl:SetAllPoints()
    b.txt = W.text(b, "GringottsText", "", 4, -3, 528); if b.txt.SetMaxLines then b.txt:SetMaxLines(2) end
    b:SetScript("OnClick", function(self) if self.petId then S.view = "tame"; S.filter = "all"; S.sel = self.petId; S.pt = 1; U.refresh() end end)
    P.teach[i] = b
  end

  -- vue « Mon familier » : couvre les colonnes gauche et centrale
  local M = CreateFrame("Frame", nil, pane)
  M:SetPoint("TOPLEFT", pane, "TOPLEFT", 0, -34); M:SetSize(1192, 690)
  ns.theme.panel(M, "panel", "line"); M:Hide()
  P.M = M
  P.mTitle = W.text(M, "GringottsH2", "", 12, -8, 700)
  P.mSub = W.text(M, "GringottsTextSmall", "", 12, -34, 1100)
  local mb = CreateFrame("Frame", nil, M); mb:SetSize(330, 300); mb:SetPoint("TOPLEFT", M, "TOPLEFT", 12, -56)
  ns.theme.panel(mb, "bg", "line")
  local okp, pm = pcall(CreateFrame, "PlayerModel", nil, mb)
  if okp and pm then
    pm:SetPoint("TOPLEFT", mb, "TOPLEFT", 2, -2); pm:SetPoint("BOTTOMRIGHT", mb, "BOTTOMRIGHT", -2, 2)
    pm.rot = 0
    pm:SetScript("OnUpdate", function(self, dt)
      if not self.on then return end
      self.rot = (self.rot + (dt or 0) * 0.5) % (math.pi * 2)
      if self.SetFacing then pcall(self.SetFacing, self, self.rot) end
    end)
    P.pmodel = pm
  end
  P.pmNote = W.text(mb, "GringottsTextSmall", "", 0, -140, 330, "CENTER")
  P.mTiles = {}
  for i = 1, 8 do
    local t = W.tile(M, 158, 70)
    t.frame:SetPoint("TOPLEFT", M, "TOPLEFT", 354 + ((i - 1) % 4) * 164, -56 - math.floor((i - 1) / 4) * 76)
    P.mTiles[i] = t
  end
  P.mS1 = section(M, "Compétences du familier", -214)
  P.mSk = {}
  for i = 1, 8 do
    P.mSk[i] = { n = W.text(M, "GringottsText", "", 356, -238 - (i - 1) * 20, 260), r = W.text(M, "GringottsText", "", 620, -238 - (i - 1) * 20, 90, "RIGHT"),
                 t = W.text(M, "GringottsTextSmall", "", 724, -240 - (i - 1) * 20, 450) }
  end
  P.mS2 = section(M, "", -388)
  P.mUp = {}
  for i = 1, 11 do
    local b = CreateFrame("Button", nil, M)
    b:SetSize(1168, 22); b:SetPoint("TOPLEFT", M, "TOPLEFT", 12, -(412 + (i - 1) * 24))
    b.hl = W.fill(b, W.C.gold[1], W.C.gold[2], W.C.gold[3], .10, "HIGHLIGHT"); b.hl:SetAllPoints()
    b.c1 = W.text(b, "GringottsText", "", 4, -3, 250)
    b.c2 = W.text(b, "GringottsText", "", 260, -3, 150)
    b.c3 = W.text(b, "GringottsText", "", 420, -3, 330)
    b.c4 = W.text(b, "GringottsTextSmall", "", 760, -4, 300)
    b.c5 = W.text(b, "GringottsTextSmall", "", 1070, -4, 90, "RIGHT")
    b:SetScript("OnClick", function(self) if self.petId then S.view = "tame"; S.filter = "all"; S.sel = self.petId; S.pt = 1; U.refresh() end end)
    P.mUp[i] = b
  end
  P.mNote2 = W.text(M, "GringottsTextSmall", "", 12, -676, 1168)
  M:SetScript("OnHide", function() if P.pmodel then P.pmodel.on = false end end)

  -- colonne droite : familier actif, à viser
  local R = CreateFrame("Frame", nil, pane)
  R:SetPoint("TOPLEFT", pane, "TOPLEFT", 1204, -34); R:SetSize(270, 690)
  ns.theme.panel(R, "panel", "line")
  P.R = R
  W.text(R, "GringottsH2", "Familier actif", 10, -8, 250)
  P.rActive = W.text(R, "GringottsText", "", 10, -34, 250)
  W.text(R, "GringottsH2", "À viser", 10, -120, 250)
  P.goals = {}
  for i = 1, 8 do
    local b = CreateFrame("Button", nil, R)
    b:SetSize(250, 34); b:SetPoint("TOPLEFT", R, "TOPLEFT", 10, -(146 + (i - 1) * 38))
    b.hl = W.fill(b, W.C.gold[1], W.C.gold[2], W.C.gold[3], .10, "HIGHLIGHT"); b.hl:SetAllPoints()
    b.txt = W.text(b, "GringottsTextSmall", "", 2, -2, 246)
    b:SetScript("OnClick", function(self) if self.petId then S.view = "tame"; S.filter = "all"; S.sel = self.petId; S.pt = 1; U.refresh() end end)
    P.goals[i] = b
  end
  P.rRules = W.text(R, "GringottsTextSmall", dim("Bonheur : Heureux 125 %, Content 100 %, Mécontent 75 % des dégâts. Le familier gagne 25 % de ton XP et ne dépasse pas ton niveau. 3 familiers max : 1 actif + 2 à l'écurie."), 10, -470, 250)
end

------------------------------------------------------------------------
-- Rafraîchissement
------------------------------------------------------------------------

-- Modèle 3D : un seul cadre, rechargé uniquement quand la bête change ; échelle de caméra selon la famille
local BIG = { ["Ours"] = 1.35, ["Crocilisque"] = 1.3, ["Gorille"] = 1.3, ["Haut-trotteur"] = 1.25, ["Raptor"] = 1.15, ["Tortue"] = 1.15, ["Sanglier"] = 1.1 }
local SMALL = { ["Araignée"] = .85, ["Crabe"] = .8, ["Scorpide"] = .85, ["Chauve-souris"] = .8, ["Renard"] = .9 }
local function showModel(P, pet)
  local m = P.model
  if not m then P.mbg:Hide(); return end
  if not pet or not pet.id then m:Hide(); m.cid = nil; P.mNote:SetText(""); return end
  P.mbg:Show(); m:Show()
  if m.cid ~= pet.id then
    m.cid = pet.id; m.rot = 0
    local ok = pcall(m.SetCreature, m, pet.id)
    if not ok then m.cid = nil; m:Hide(); P.mNote:SetText(dim("modèle indisponible")); return end
    if m.SetAnimation then pcall(m.SetAnimation, m, 0) end
    local function frame() if m.SetCamDistanceScale then pcall(m.SetCamDistanceScale, m, 1 / (BIG[pet.f] or SMALL[pet.f] or 1)) end; if m.SetPosition then pcall(m.SetPosition, m, 0, 0, 0) end end
    frame()
    P.mNote:SetText("")
    -- le chargement est asynchrone (bête pas encore en cache) : on réapplique le modèle à 0,3 / 0,8 / 1,6 / 3 s
    -- (sans détection : l'API de lecture n'est pas fiable sur ce client ; réappliquer est sans effet visible si c'est déjà chargé)
    if C_Timer and C_Timer.After then
      local cid = pet.id
      for _, d in ipairs({ 0.3, 0.8, 1.6, 3 }) do
        C_Timer.After(d, function()
          if m.cid ~= cid or not m:IsShown() then return end
          pcall(m.SetCreature, m, cid)
          if m.SetAnimation then pcall(m.SetAnimation, m, 0) end
          frame()
        end)
      end
    end
  end
end

local function famPet(name)
  local best
  for _, p in ipairs(K().all()) do
    if p.f == name and p.id and (not best or (p.lo or 0) > (best.lo or 0)) then best = p end
  end
  return best
end

local function setTiles(P, a)
  for i = 1, 4 do
    local t = a[i]
    if t then P.tiles[i].frame:Show(); P.tiles[i]:Set(t[1], t[2], t[3]) else P.tiles[i].frame:Hide() end
  end
end

local function placeD(P, fs, y) fs:ClearAllPoints(); fs:SetPoint("TOPLEFT", P.D, "TOPLEFT", 12, y) end
local function textH(fs, minLines) local h = tonumber(fs.GetStringHeight and fs:GetStringHeight()) or 0; return math.max(h, (minLines or 1) * 15) end
local function layoutDefault(P)
  placeD(P, P.s1, -270); placeD(P, P.t1, -292); placeD(P, P.s2, -414); placeD(P, P.t2, -436); placeD(P, P.s3, -570); placeD(P, P.t3, -592)
end
local function refreshTame(P)
  layoutDefault(P)
  local lvl = K().level()
  local list = K().list(S.filter, S.q, S.famFilter)
  if not S.sel or not K().byId(S.sel) then S.sel = list[1] and list[1].id or nil end
  P.title:SetText("Bêtes")
  P.cHead[1]:SetText("Bête"); P.cHead[2]:SetText("Famille"); P.cHead[3]:SetText("Niv."); P.cHead[4]:SetText("Zone"); P.cHead[5]:SetText("Statut")
  P.list:SetData(list, true)
  P.note:SetText(dim(("Vert = apprivoisable maintenant (niveau <= %d). %d bêtes affichées sur %d dans le catalogue."):format(lvl, #list, #K().all())))
  if S.famFilter then P.stripAll:Enable() else P.stripAll:Disable() end
  for _, b in ipairs(P.stripBtn) do b.ring:SetShown(S.famFilter == b.fam) end
  local p = K().byId(S.sel)
  P.bAim:SetShown(true); P.bAimOff:SetShown(true); P.bGoal:SetShown(true)
  for i = 1, 4 do P.teach[i]:Hide() end
  if not p then
    P.dTitle:SetText("Aucune bête"); P.dSub:SetText(""); setTiles(P, {}); P.s1:SetText(""); P.t1:SetText(""); P.s2:SetText(""); P.t2:SetText(""); P.s3:SetText(""); P.t3:SetText("")
    P.bAim:Hide(); P.bAimOff:Hide(); P.bGoal:Hide(); showModel(P, nil)
    return
  end
  showModel(P, p)
  local ok = K().canTame(p, lvl)
  P.dTitle:SetText(p.n)
  P.dSub:SetText(("%s · niveau %s%s · %s"):format(p.f, K().levelText(p), (K().rarity(p) ~= "") and (" · " .. K().rarity(p):lower()) or "", p.z or "—"))
  local fs
  for _, f in ipairs(K().fams()) do if f.n == p.f then fs = f.spec end end
  setTiles(P, {
    { "Niveau", K().levelText(p), p.lo and (ok and ("apprivoisable (toi : " .. lvl .. ")") or ("trop bas (toi : " .. lvl .. ")")) or "niveau non relevé" },
    { "Famille", p.f, fs and fs or "pas de capacité propre" },
    { "Vitesse d'attaque", p.sp and (("%.2f"):format(p.sp):gsub("%.", ",") .. " s") or "—", p.sp and "relevée (Wowhead)" or "non relevée" },
    { "Enseigne", (p.a and #p.a > 0) and (p.L and "capacités" or "1 à 2 capacités") or "rien", (p.a and #p.a > 0) and (K().abilityText(p):sub(1, 22)) or "aucune capacité" },
  })
  P.s1:SetText("Où le trouver")
  if p.m and p.p then
    local pts = {}
    for i, c in ipairs(p.p) do pts[#pts + 1] = ("%s%d, %d%s"):format((i == S.pt) and "|cffffd36b" or "", math.floor(c[1] + .5), math.floor(c[2] + .5), (i == S.pt) and "|r" or "") end
    P.t1:SetText(("%s : %s\n%s"):format(p.z or "—", table.concat(pts, "  ·  "),
      dim("Points de passage les plus fréquents (carte, en %). Chaque clic sur « Cibler » passe au point suivant ; la flèche et la boussole s'affichent.")))
    P.bAim:Enable()
  else
    P.t1:SetText(("%s\n%s"):format(p.z or "—", dim("Pas de coordonnées connues (donjon, instance ou zone sans carte) : la flèche ne peut pas viser cette bête.")))
    P.bAim:Disable()
  end
  local man = ns.arrowManual and ns.arrowManual()
  P.bAimOff:SetShown(man and true or false)
  P.bGoal:SetText(K().st().goals[p.id] and "Retirer de « À viser »" or "Ajouter à « À viser »")
  -- ce que la bête apporte
  P.s2:SetText("Ce qu'elle t'apporte")
  local lines = {}
  if p.a and #p.a > 0 then lines[#lines + 1] = K().abilityText(p) end
  local best = K().famBest(p.f, lvl)
  for _, a in ipairs(p.a or {}) do
    local b = a[2] and best[a[1]]
    if b and b.rank > a[2] and b.pet.id ~= p.id then
      lines[#lines + 1] = W.col(C.orange, ("%s : rang %d accessible chez %s (niv. %s, %s)"):format(a[1], b.rank, b.pet.n, K().levelText(b.pet), b.pet.z or "—"))
    end
  end
  if p.sp then lines[#lines + 1] = ("Attaque rapide : %s s entre deux coups."):format(("%.2f"):format(p.sp):gsub("%.", ",")) end
  if #lines == 0 then lines[1] = dim("Cette bête n'enseigne rien : à apprivoiser pour son apparence ou sa vitesse d'attaque.") end
  P.t2:SetText(table.concat(lines, "\n"))
  P.s3:SetText("Avant d'apprivoiser")
  local act = K().active()
  P.t3:SetText((act and W.col(C.orange, ("Familier actif : %s. Renvoie-le à l'écurie : Apprivoiser est impossible avec un familier actif, même renvoyé.\n"):format(act.name or "?")) or "")
    .. "Armure −100 % pendant la canalisation ; si la bête perd son aggro ou subit des dégâts, l'apprivoisement échoue. Pas d'apprivoisement avec un familier mort à l'écurie. Bête de niveau <= le tien.")
end

local function pcs(v) v = v or 0; return (v > 0 and "|cff4fc68d+" or (v < 0 and "|cffee6a57−" or "|cff8a97a6")) .. math.abs(v) .. " %|r" end
local function refreshSkills(P)
  local lvl = K().level()
  local fams = K().fams()
  if not S.fam then S.fam = fams[1] and fams[1].n or nil end
  P.title:SetText("Familles")
  P.note:SetText(dim(("Bonus de famille (dégâts, armure, vie) et régime alimentaire. Point vert = famille déjà apprivoisée. %d familles."):format(#fams)))
  for i, f in ipairs(fams) do
    local c = P.cards[i]
    if c then
      c.fam = f.n; c.ico:SetTexture(f.icon)
      c.name:SetText((f.seen and W.col(C.green, "● ") or "") .. f.n)
      c.count:SetText(dim(f.count .. " bêtes"))
      for j, v in ipairs({ f.dmg, f.armor, f.hp }) do c.bars[j]:Set(v); c["v" .. j]:SetText(pcs(v)) end
      for j = 1, 6 do
        local food = f.diet[j]
        if food then c.food[j]:SetTexture(foodIcon(food)); c.food[j]:Show() else c.food[j]:Hide() end
      end
      c.sel:SetShown(S.fam == f.n)
    end
  end
  for i = 1, 4 do P.teach[i]:Hide() end
  P.bAim:Hide(); P.bAimOff:Hide(); P.bGoal:Hide()
  local f
  for _, x in ipairs(fams) do if x.n == S.fam then f = x end end
  showModel(P, f and famPet(f.n) or nil)
  if not f then P.dTitle:SetText("Aucune famille"); P.dSub:SetText(""); setTiles(P, {}); P.s1:SetText(""); P.t1:SetText(""); P.s2:SetText(""); P.t2:SetText(""); P.s3:SetText(""); P.t3:SetText(""); return end
  local names, best = K().famAbilities(f.n)
  local now = K().famBest(f.n, lvl)
  P.dTitle:SetText(f.n)
  P.dSub:SetText("Famille" .. (f.spec and (" · capacité propre : " .. f.spec) or "") .. (f.seen and " · déjà apprivoisée" or ""))
  local function tileFor(name)
    local b = name and best[name]
    if not b then return { name or "—", "—", "non relevée" } end
    return { name, "r." .. b.rank, (b.tp and (b.tp .. " TP") or "coût non relevé") }
  end
  local t3 = best["Morsure"] and "Morsure" or best["Griffe"] and "Griffe" or names[2]
  local t4 = best["Célérité"] and "Célérité" or names[3]
  setTiles(P, {
    { "Capacité propre", f.spec or "—", f.spec and best[f.spec] and ("rang max relevé : " .. best[f.spec].rank) or "" },
    { "Bêtes relevées", tostring(f.count), "dans le catalogue" },
    tileFor(t3), tileFor(t4),
  })
  P.s1:SetText("Où apprendre chaque rang")
  local rows = {}
  for _, n in ipairs(names) do
    local b, c = best[n], now[n]
    rows[#rows + 1] = ("%s · max r.%d : %s (niv. %s, %s)\n    %s"):format(n, b.rank, b.pet.n, K().levelText(b.pet), b.pet.z or "—",
      c and W.col(C.orange, ("à ton niveau (%d) : rang %d chez %s (niv. %s)"):format(lvl, c.rank, c.pet.n, K().levelText(c.pet))) or dim("aucune bête à ton niveau"))
  end
  placeD(P, P.s1, -262); placeD(P, P.t1, -282)
  P.t1:SetText(table.concat(rows, "\n"))
  local y = -282 - textH(P.t1, #names * 2) - 10
  placeD(P, P.s2, y); placeD(P, P.t2, y - 22)
  local y2 = y - 22
  P.s2:SetText(("Bêtes qui enseignent à ton niveau (%d)"):format(lvl))
  P.t2:SetText("")
  local tl = K().teachers(f.n, 3)
  for i = 1, 4 do
    local p, b = tl[i], P.teach[i]
    if p then b.petId = p.id; b:ClearAllPoints(); b:SetPoint("TOPLEFT", P.D, "TOPLEFT", 12, y2 - (i - 1) * 36)
      b.txt:SetText(("%s · niv. %s · %s\n%s"):format(p.n, K().levelText(p), p.z or "—", dim(K().abilityText(p)))); b:Show()
    else b.petId = nil; b:Hide() end
  end
  P.s3:SetText("")
  local y3 = y2 - math.max(#tl, 1) * 36 - 6
  placeD(P, P.t3, y3)
  P.t3:SetText(W.col(C.gold, "Régime : ") .. (#f.diet > 0 and table.concat(f.diet, ", ") or "—") .. ("\nBonus de famille : dégâts %s · armure %s · vie %s\n"):format(pcs(f.dmg), pcs(f.armor), pcs(f.hp)) .. dim("Apprendre une capacité : apprivoiser la bête qui l'enseigne, puis la faire apprendre à ton familier. TP = points d'entraînement. Clique une bête pour la voir dans Apprivoisement. Les paliers de Célérité (niveau 30) ne sont pas interprétés."))
  if -y3 + textH(P.t3, 4) > 684 then   -- trop long : on retire la phrase d'aide
    P.t3:SetText(W.col(C.gold, "Régime : ") .. (#f.diet > 0 and table.concat(f.diet, ", ") or "—") .. ("\nBonus de famille : dégâts %s · armure %s · vie %s"):format(pcs(f.dmg), pcs(f.armor), pcs(f.hp)))
  end
  if #tl == 0 then P.t2:SetText(dim("Aucune bête de cette famille n'enseigne quoi que ce soit à ton niveau.")) end
end

local STAT = { "Force", "Agilité", "Endurance", "Intelligence", "Esprit" }
local function num(v) return v and tostring(math.floor(v + .5)) or "—" end
local function refreshMine(P)
  local a = K().active()
  local m = P.pmodel
  if not a then
    P.mTitle:SetText(W.col(C.grey, "Aucun familier actif"))
    P.mSub:SetText(dim("Invoque ton familier pour voir ses statistiques, ses compétences et les évolutions possibles. Les données sont lues en jeu."))
    for i = 1, 8 do P.mTiles[i].frame:Hide() end
    for i = 1, 8 do local r = P.mSk[i]; r.n:SetText(""); r.r:SetText(""); r.t:SetText("") end
    for i = 1, 11 do P.mUp[i]:Hide() end
    P.mS1:SetText(""); P.mS2:SetText(""); P.mNote2:SetText("")
    if m then m:Hide(); m.on = false end
    P.pmNote:SetText("")
    return
  end
  local st = K().petStats()
  local up = K().upgrades()
  local lvl = K().level()
  local fi = a.fam and K().famInfo(a.fam)
  P.mTitle:SetText(W.col(C.gold, a.name or "?"))
  P.mSub:SetText(("%s · niveau %s%s%s"):format(a.fam or "?", a.lvl or "?", K().happyText(a.happy) and (" · " .. K().happyText(a.happy)) or "",
    (fi and fi.spec) and (" · capacité propre : " .. fi.spec) or ""))
  if m then
    m:Show()
    if not m.shown or m.petName ~= a.name then
      m.shown, m.petName, m.rot = true, a.name, 0
      local ok = pcall(m.SetUnit, m, "pet")
      if ok then m.on = true; if m.SetCamDistanceScale then pcall(m.SetCamDistanceScale, m, 1) end; P.pmNote:SetText("")
      else m.on = false; P.pmNote:SetText(dim("modèle indisponible")) end
    end
  else P.pmNote:SetText(dim("modèle 3D indisponible")) end
  local tp = st.tpTotal and ("%s / %s"):format(num(st.tpSpent), num(st.tpTotal)) or "—"
  local xp = (st.xp and st.xpMax and st.xpMax > 0) and ("%d %%"):format(math.floor(st.xp / st.xpMax * 100)) or "—"
  local tl = {
    { "Niveau", tostring(a.lvl or "?"), (a.lvl and a.lvl >= lvl) and "plafond : ton niveau" or ("ton niveau : " .. lvl) },
    { "Vie", num(st.hp), "" },
    { "Puissance d'attaque", num(st.ap), "" },
    { "Armure", num(st.armor), "" },
    { "Points d'entraînement", tp, "dépensés / total" },
    { "Expérience", xp, "niveau en cours" },
    { "Force · Agilité", ("%s · %s"):format(num(st.stats[1]), num(st.stats[2])), "" },
    { "Endurance · Int. · Esprit", ("%s · %s · %s"):format(num(st.stats[3]), num(st.stats[4]), num(st.stats[5])), "" },
  }
  for i, t in ipairs(tl) do P.mTiles[i].frame:Show(); P.mTiles[i]:Set(t[1], t[2], t[3]) end
  -- compétences connues, triées par nom
  local ks = {}
  for _, k in pairs(up and up.known or K().petKnown()) do ks[#ks + 1] = k end
  table.sort(ks, function(x, y) return x.name < y.name end)
  P.mS1:SetText(("Compétences du familier (%d)"):format(#ks))
  for i = 1, 8 do
    local k, r = ks[i], P.mSk[i]
    if k then
      r.n:SetText(k.name); r.r:SetText(k.rank and ("rang " .. k.rank) or dim("—"))
      local nx = up and (function() for _, u in ipairs(up.list) do if u.name == k.name then return u end end end)()
      r.t:SetText(nx and W.col(C.green, ("rang %d disponible"):format(nx.rank)) or dim("à jour pour ton niveau"))
    else r.n:SetText(""); r.r:SetText(""); r.t:SetText("") end
  end
  if #ks > 8 then P.mSk[8].t:SetText(dim(("+ %d autres"):format(#ks - 7))) end
  -- évolutions
  local list = up and up.list or {}
  P.mS2:SetText(#list > 0 and ("Évolutions disponibles (%d)  ·  clique pour voir la bête"):format(#list) or "Évolutions disponibles")
  for i = 1, 11 do
    local u, b = list[i], P.mUp[i]
    if u then
      b.petId = u.pet.id; b:Show()
      b.c1:SetText(u.new and W.col(C.orange, u.name .. " (nouvelle)") or W.col(C.gold, u.name))
      b.c2:SetText(u.new and ("rang " .. u.rank) or ("rang %d › %d"):format(u.cur, u.rank))
      b.c3:SetText(("%s · niv. %s"):format(u.pet.n, K().levelText(u.pet)))
      b.c4:SetText(dim(u.pet.z or "—"))
      b.c5:SetText(u.tp and (u.tp .. " TP") or dim("TP ?"))
    else b.petId = nil; b:Hide() end
  end
  if #list == 0 then P.mNote2:SetText(dim(("Aucune évolution à ton niveau (%d) : toutes les capacités de la famille %s relevées sont déjà à leur meilleur rang accessible."):format(lvl, a.fam or "?")))
  else P.mNote2:SetText(dim("Pour apprendre : apprivoiser la bête indiquée, puis la faire apprendre à ton familier. Le rang dépend aussi du niveau de ton familier. Seules les bêtes apprivoisables à ton niveau sont proposées.")) end
end

function U.refresh()
  local P = U.p; if not P then return end
  if not S.inited then S.inited = true; if S.view == "tame" and K().active() then S.view = "mine" end end   -- familier actif : on ouvre Mon familier
  K().seeActive()
  local lvl = K().level()
  for _, b in ipairs(P.filt) do
    if b.key == S.filter then b:Disable() else b:Enable() end
    b:SetShown(S.view == "tame")
  end
  local mine = S.view == "mine"
  P.Lf:SetShown(not mine); P.D:SetShown(not mine); P.M:SetShown(mine)
  if mine then P.bMine:Disable() else P.bMine:Enable() end
  if mine then
    P.bTame:Enable(); P.bSkill:Enable()
    refreshMine(P)
    local a = K().active()
    P.hdr:SetText(W.col(C.green, (UnitName and UnitName("player") or "") .. " · niveau " .. K().level() .. " · chasseur"))
    P.rActive:SetText(a and (("%s\n%s · niveau %s\n%s"):format(W.col(C.gold, a.name or "?"), a.fam or "?", a.lvl or "?", (K().happyText(a.happy) and ("Bonheur : " .. K().happyText(a.happy)) or "")))
      or dim("Aucun familier actif. Famille, niveau et bonheur sont lus en jeu."))
    return
  end
  local tame = S.view == "tame"
  P.eq:SetShown(tame); P.list.frame:SetShown(tame); P.strip:SetShown(tame); P.grid:SetShown(not tame)
  for _, h in ipairs(P.cHead) do h:SetShown(tame) end
  if S.view == "tame" then P.bTame:Disable(); P.bSkill:Enable(); refreshTame(P) else P.bTame:Enable(); P.bSkill:Disable(); refreshSkills(P) end
  local a = K().active()
  P.hdr:SetText(W.col(C.green, (UnitName and UnitName("player") or "") .. " · niveau " .. lvl .. " · chasseur"))
  P.rActive:SetText(a and (("%s\n%s · niveau %s\n%s"):format(W.col(C.gold, a.name or "?"), a.fam or "?", a.lvl or "?", (K().happyText(a.happy) and ("Bonheur : " .. K().happyText(a.happy)) or "")))
    or dim("Aucun familier actif. Famille, niveau et bonheur sont lus en jeu."))
  local goals = K().goals()
  for i = 1, 8 do
    local p, b = goals[i], P.goals[i]
    if p then
      b.petId = p.id; b:Show()
      local gap = p.lo and (p.lo > lvl) and W.col(C.orange, ("encore %d niveaux"):format(p.lo - lvl)) or W.col(C.green, "apprivoisable")
      b.txt:SetText(("%s · %s niv. %s\n%s · %s"):format(W.col(C.gold, p.n), p.f, K().levelText(p), gap, p.z or "—"))
    else b.petId = nil; b:Hide() end
  end
end

function U.setView(v) if v == "skills" or v == "tame" or v == "mine" then S.view = v end end
function U.select(id) S.view = "tame"; S.filter = "all"; S.sel = id; S.pt = 1 end
