-- Gringotts : onglet « Gains » (Business) : session de farm, marge réelle par objet, rendement par lieu. + tuiles dans Finances.
local ADDON, ns = ...
local W = ns.W
local C = W.C
local G = ns.gring
local Gn = ns.gains

local LEFT_W, RIGHT_W = 440, 400
local function coins(c) return c and ns.api.coins(c) or W.col(C.grey, "—") end
local function hms(sec)
  sec = math.floor(sec or 0)
  return ("%d:%02d:%02d"):format(math.floor(sec / 3600), math.floor(sec % 3600 / 60), sec % 60)
end
local function signed(c)
  if not c or c == 0 then return coins(0) end
  return (c > 0 and W.col(C.green, "+") or W.col(C.red, "-")) .. coins(math.abs(c))
end

local GP

function G.buildGains(pane)
  local P = {}
  GP = P
  -- Gauche : session de farm
  local left = CreateFrame("Frame", nil, pane); left:SetPoint("TOPLEFT", pane, "TOPLEFT", 0, 0); left:SetPoint("BOTTOMLEFT", pane, "BOTTOMLEFT", 0, 0); left:SetWidth(LEFT_W)
  W.text(left, "GringottsH2", "Session de farm", 0, 0, 300)
  P.zone = W.text(left, "GringottsTextSmall", "", 0, -26, LEFT_W)
  P.go = W.button(left, "Démarrer", 140, 26, function()
    if Gn.current() then return end
    Gn.start(); G.refresh()
  end); P.go:SetPoint("TOPLEFT", left, "TOPLEFT", 0, -46)
  P.stop = W.button(left, "Arrêter", 140, 26, function()
    if not Gn.current() then return end
    Gn.stop(); G.refresh()
  end); P.stop:SetPoint("TOPLEFT", left, "TOPLEFT", 148, -46)
  P.t = {}
  for i = 1, 3 do local t = W.tile(left, 138, 64); t.frame:SetPoint("TOPLEFT", left, "TOPLEFT", (i - 1) * 146, -84); P.t[i] = t end
  W.text(left, "GringottsLabelSmall", "Butin de la session", 28, -160, 200)
  W.text(left, "GringottsLabelSmall", "Qté", 236, -160, 50, "RIGHT")
  W.text(left, "GringottsLabelSmall", "Valeur", 296, -160, 120, "RIGHT")
  P.list = W.list(left, LEFT_W, 480, 22, function(b)
    W.rowIcon(b, 22)
    b.name = W.text(b, "GringottsText", "", 28, -3, 200)
    b.q = W.text(b, "GringottsTextSmall", "", 236, -5, 50, "RIGHT")
    b.v = W.text(b, "GringottsTextSmall", "", 296, -5, 120, "RIGHT")
  end, function(b, e)
    W.setRowIcon(b, e.id)
    b.name:SetText(e.name); b.q:SetText(tostring(e.q)); b.v:SetText(coins(e.value))
    b.sel:Hide()
  end)
  P.list.frame:SetPoint("TOPLEFT", left, "TOPLEFT", 0, -180)
  P.note = W.text(left, "GringottsTextSmall", "", 0, -664, LEFT_W)

  -- Centre : marge réelle par objet
  local f = CreateFrame("Frame", nil, pane)
  f:SetPoint("TOPLEFT", pane, "TOPLEFT", LEFT_W + 20, 0); f:SetPoint("BOTTOMRIGHT", pane, "BOTTOMRIGHT", -RIGHT_W - 12, 0)
  W.text(f, "GringottsH2", "Marge réelle par objet · 30 jours", 0, 0, 600)
  P.msub = W.text(f, "GringottsTextSmall", "", 0, -26, 600)
  P.mt = {}
  for i = 1, 3 do local t = W.tile(f, 186, 64); t.frame:SetPoint("TOPLEFT", f, "TOPLEFT", (i - 1) * 194, -50); P.mt[i] = t end
  local hx = { 0, 236, 306, 410, 510 }
  W.text(f, "GringottsLabelSmall", "Objet", 28, -126, 200)
  W.text(f, "GringottsLabelSmall", "Vendus", hx[2], -126, 60, "RIGHT")
  W.text(f, "GringottsLabelSmall", "Net", hx[3], -126, 96, "RIGHT")
  W.text(f, "GringottsLabelSmall", "Coût", hx[4], -126, 96, "RIGHT")
  W.text(f, "GringottsLabelSmall", "Marge", hx[5], -126, 90, "RIGHT")
  P.mlist = W.list(f, 620, 520, 22, function(b)
    W.rowIcon(b, 22)
    b.name = W.text(b, "GringottsText", "", 28, -3, 205)
    b.q = W.text(b, "GringottsTextSmall", "", hx[2], -5, 60, "RIGHT")
    b.rev = W.text(b, "GringottsTextSmall", "", hx[3], -5, 96, "RIGHT")
    b.cost = W.text(b, "GringottsTextSmall", "", hx[4], -5, 96, "RIGHT")
    b.m = W.text(b, "GringottsTextSmall", "", hx[5], -5, 90, "RIGHT")
  end, function(b, e)
    local id = (ns.api.db().ids or {})[e.k]
    W.setRowIcon(b, id)
    local slow = Gn.isSlow(e.k)
    b.name:SetText(e.name .. (slow and ("  " .. W.col(C.orange or C.grey, "lent")) or ""))
    b.q:SetText(tostring(e.q)); b.rev:SetText(coins(e.rev))
    b.cost:SetText(e.src == "farm" and W.col(C.grey, "farmé") or coins(e.cost))
    b.m:SetText(signed(e.margin)); b.sel:Hide()
  end)
  P.mlist.frame:SetPoint("TOPLEFT", f, "TOPLEFT", 0, -146)
  P.mnote = W.text(f, "GringottsTextSmall", "", 0, -674, 600)

  -- Droite : rendement par lieu + dernières sessions
  local right = CreateFrame("Frame", nil, pane); right:SetPoint("TOPRIGHT", pane, "TOPRIGHT", 0, 0); right:SetPoint("BOTTOMRIGHT", pane, "BOTTOMRIGHT", 0, 0); right:SetWidth(RIGHT_W)
  ns.theme.panel(right, "panel", "line")
  W.text(right, "GringottsH2", "Rendement par lieu", 12, -8, RIGHT_W - 24)
  P.spots = {}
  for i = 1, 8 do
    local r = {}
    r.name = W.text(right, "GringottsText", "", 12, -42 - (i - 1) * 24, 230)
    r.n = W.text(right, "GringottsTextSmall", "", 244, -44 - (i - 1) * 24, 40, "RIGHT")
    r.gph = W.text(right, "GringottsTextSmall", "", 290, -44 - (i - 1) * 24, RIGHT_W - 302, "RIGHT")
    P.spots[i] = r
  end
  W.text(right, "GringottsH2", "Dernières sessions", 12, -252, RIGHT_W - 24)
  P.last = {}
  for i = 1, 10 do
    local r = {}
    r.name = W.text(right, "GringottsTextSmall", "", 12, -286 - (i - 1) * 22, 200)
    r.dur = W.text(right, "GringottsTextSmall", "", 214, -286 - (i - 1) * 22, 60, "RIGHT")
    r.gph = W.text(right, "GringottsTextSmall", "", 280, -286 - (i - 1) * 22, RIGHT_W - 292, "RIGHT")
    P.last[i] = r
  end
  P.empty = W.text(right, "GringottsTextSmall", "", 12, -42, RIGHT_W - 24)

  function P:Refresh()
    local cur = Gn.current()
    local g = ns.api.db().gains or {}
    local s = cur or (g.sessions and g.sessions[1])
    if cur then self.go:Disable(); self.stop:Enable() else self.go:Enable(); self.stop:Disable() end
    if cur then self.zone:SetText(W.col(C.green, "En cours · ") .. cur.zone)
    elseif s then self.zone:SetText("Dernière session · " .. s.zone)
    else self.zone:SetText("Place-toi sur ton lieu de farm puis clique Démarrer.") end
    self:Tick()
    self.list:SetData(Gn.lootList(s))
    self.note:SetText(W.col(C.grey, "Valeur = prix HV moins commission (ou prix PNJ si meilleur). Seul le butin ramassé compte."))
    -- marges
    local rows, T = Gn.margins(30)
    self.mlist:SetData(rows)
    self.mt[1]:Set("Ventes nettes", coins(T.rev), "", { tone = "gold" })
    self.mt[2]:Set("Coût d'acquisition", coins(T.cost), "", {})
    self.mt[3]:Set("Marge réelle", signed(T.margin), T.cost > 0 and ("%+d %% du coût"):format(math.floor(T.margin / T.cost * 100 + .5)) or "", { tone = T.margin >= 0 and "ok" or "bad" })
    self.msub:SetText(#rows == 0 and "Aucune vente relevée : ouvre ta boîte aux lettres après tes ventes HV." or (T.n .. " objets vendus"))
    self.mnote:SetText(W.col(C.grey, "Coût : achats HV (moyenne), sinon coût de craft ; « farmé » = coût nul. « lent » : se vend mal d'après tes annonces."))
    -- lieux
    local sp = Gn.spots()
    for i, r in ipairs(self.spots) do
      local z = sp[i]
      if z then r.name:SetText(z.zone); r.n:SetText(z.n .. "×"); r.gph:SetText(coins(z.gph) .. "/h"); r.name:Show(); r.n:Show(); r.gph:Show()
      else r.name:Hide(); r.n:Hide(); r.gph:Hide() end
    end
    self.empty:SetText(#sp == 0 and W.col(C.grey, "Aucune session terminée (60 s minimum).") or "")
    local ss = g.sessions or {}
    for i, r in ipairs(self.last) do
      local x = ss[i]
      if x then
        r.name:SetText(date("%d/%m ", x.t0) .. x.zone); r.dur:SetText(hms(Gn.elapsed(x))); r.gph:SetText(x.rate and (coins(x.rate) .. "/h") or "—")
        r.name:Show(); r.dur:Show(); r.gph:Show()
      else r.name:Hide(); r.dur:Hide(); r.gph:Hide() end
    end
  end

  -- tuiles de la session (relevé chaque seconde)
  function P:Tick()
    local cur = Gn.current()
    local g = ns.api.db().gains or {}
    local s = cur or (g.sessions and g.sessions[1])
    if not s then
      self.t[1]:Set("Or / heure", "—", "", {}); self.t[2]:Set("Durée", "0:00:00", "", {}); self.t[3]:Set("Valeur du butin", coins(0), "", {})
      return
    end
    local r = Gn.rate(s)
    self.t[1]:Set("Or / heure", r and coins(r) or "—", (not r) and "dès 60 s" or "", { tone = "gold" })
    self.t[2]:Set("Durée", hms(Gn.elapsed(s)), cur and "en cours" or "terminée", {})
    self.t[3]:Set("Valeur du butin", coins(Gn.total(s)), "", { tone = "ok" })
  end
  local acc = 0
  pane:SetScript("OnUpdate", function(_, dt)
    acc = acc + dt
    if acc >= 1 then acc = 0; if Gn.current() and pane:IsVisible() then P:Tick() end end
  end)
  return P
end

-- Appelé par Gains.lua à chaque butin : rafraîchit la liste si l'onglet est affiché
ns.gringUI = ns.gringUI or {}
function ns.gringUI.onGains()
  if GP and G.current == "gains" and G.panes and G.panes.gains and G.panes.gains.obj then
    local cur = Gn.current()
    GP.list:SetData(Gn.lootList(cur), true)
  end
end

------------------------------------------------------------------------
-- Finances : tuiles « or/h de farm » et « marge réelle » sous la répartition
------------------------------------------------------------------------
function G.buildFinanceGains(right, P)
  P.gt = {}
  for i = 1, 2 do
    local t = W.tile(right, RIGHT_W - 24, 64); t.frame:SetPoint("TOPLEFT", right, "TOPLEFT", 12, -452 - (i - 1) * 72); P.gt[i] = t
  end
end

function G.refreshFinanceGains(P)
  if not P.gt then return end
  local r, secs = Gn.rate7(7)
  P.gt[1]:Set("Or / heure de farm · 7 j", r and coins(r) or "—", r and ("sur " .. hms(secs)) or "Aucune session : onglet Gains", { tone = "gold" })
  local _, T = Gn.margins(30)
  P.gt[2]:Set("Marge réelle · 30 j", signed(T.margin), T.n > 0 and (T.n .. " objets vendus") or "Aucune vente relevée", { tone = T.margin >= 0 and "ok" or "bad" })
end
