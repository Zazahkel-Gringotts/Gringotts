-- Gringotts : prix publics de l'HV (fichier Prices.lua généré par le bot, copié par le raccourci avant de jouer).
-- Fournit : prix du jour, médiane 30 j, série, meilleur jour d'achat (profil hebdomadaire précalculé), âge des prix.
local ADDON, ns = ...
local P = {}
ns.prices = P

local DAY = 86400
local DOW = { [0] = "dimanche", "lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi" }

local function data() return type(GringottsPrices) == "table" and GringottsPrices or nil end
local function norm(s) return ns.norm and ns.norm(s) or tostring(s or ""):lower() end

function P.loaded() local d = data(); return d and type(d.items) == "table" and (d.t or 0) > 0 end

-- Âge du fichier : jours écoulés depuis le relevé du bot
function P.info()
  local d = data()
  if not P.loaded() then return { loaded = false, stale = true, age = nil } end
  local age = (time() - d.t) / DAY
  local limit = (GringottsDB and GringottsDB.staleDays) or 3
  return { loaded = true, t = d.t, age = age, stale = age > limit, ah = d.ah, last = d.last, limit = limit }
end

function P.rec(name)
  local d = data()
  return d and d.items and d.items[norm(name)] or nil
end

-- Prix en cuivre : Auctionator s'il est plus récent que le fichier, sinon le fichier. -> prix, source ("ah"/"file"), âge en jours
function P.price(name, id)
  local fileAge = P.info().age
  local r = P.rec(name)
  local fp = r and r.p and r.p > 0 and r.p or nil
  local ap, aage
  if ns.api and id then ap, aage = ns.api.priceOf(id) end
  if ap and (aage == nil or not fileAge or not fp or aage <= fileAge) then return ap, "ah", aage end
  if fp then return fp, "file", fileAge end
  return nil
end

function P.median(name) local r = P.rec(name); return r and r.m and r.m > 0 and r.m or nil end
function P.series(name) local r = P.rec(name); return r and r.s or nil end

-- Meilleur jour : nil si trop peu de semaines complètes, "flat" si l'écart entre jours est < 1 %, sinon l'indice 0 (dimanche) .. 6
function P.bestDay(name, minWeeks)
  local r = P.rec(name)
  if not r or not r.f or (r.w or 0) < (minWeeks or 3) then return nil end
  local lo, hi, best = math.huge, -math.huge, nil
  for i = 1, 7 do
    local v = r.f[i]
    if v < lo then lo, best = v, i - 1 end
    if v > hi then hi = v end
  end
  if hi - lo < 0.01 then return "flat" end
  return best
end
function P.dayName(i) if i == "flat" then return "indifférent" end return i and DOW[i] or "—" end
function P.todayIndex() return tonumber(date("%w")) end

-- Écart du prix du jour à la médiane 30 j (ex. -0.18 = 18 % sous la médiane)
function P.gap(name, price)
  local m = P.median(name)
  if not m or not price or price <= 0 then return nil end
  return price / m - 1
end

function P.ageText()
  local i = P.info()
  if not i.loaded then return "aucun fichier de prix" end
  return date("%d/%m à %Hh", i.t) .. " (" .. (i.age < 1 and (math.floor(i.age * 24) .. " h") or (math.floor(i.age) .. " j")) .. ")"
end

local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
ev:SetScript("OnEvent", function()
  C_Timer.After(6, function()
    local i = P.info()
    local say = function(m) print("|cffe4b84eGringotts|r " .. m) end
    if not i.loaded then
      say("|cffffb04aAucun fichier de prix.|r Lance le raccourci « Gringotts - Prix » avant de jouer, puis /reload.")
    elseif i.stale then
      say("|cffffb04aPrix vieux de " .. math.floor(i.age) .. " jours|r (" .. P.ageText() .. ") : lance le raccourci de mise à jour, puis /reload.")
    else
      say("Prix du " .. P.ageText() .. ".")
    end
  end)
end)
