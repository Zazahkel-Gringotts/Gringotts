-- Gringotts : petits composants d'interface (texte, bouton, tuile, liste à lignes recyclées, barres).
local ADDON, ns = ...
local W = {}
ns.W = W

-- Couleurs du dashboard (voir Theme.lua)
local TC = ns.theme and ns.theme.c
W.C = { gold = TC.gold, grey = TC.muted, green = TC.ok, red = TC.bad, orange = TC.warn, blue = TC.info, white = TC.ink, silver = TC.silver, copper = TC.copper }
local function hx(v) return math.floor(v * 255 + .5) end
function W.col(c, s) return ("|cff%02x%02x%02x%s|r"):format(hx(c[1]), hx(c[2]), hx(c[3]), tostring(s)) end

function W.fill(parent, r, g, b, a, layer)
  local t = parent:CreateTexture(nil, layer or "BACKGROUND")
  t:SetColorTexture(r, g, b, a or 1)
  return t
end

function W.text(parent, font, text, x, y, width, justify, point)
  local f = parent:CreateFontString(nil, "OVERLAY", font or "GringottsText")
  point = point or "TOPLEFT"
  f:SetPoint(point, parent, point, x or 0, y or 0)
  if width then f:SetWidth(width) end
  f:SetJustifyH(justify or "LEFT")
  if text then f:SetText(text) end
  return f
end

function W.button(parent, label, w, h, onclick, style)
  return ns.theme.button(parent, label, w, h or 22, onclick, style)
end

function W.edit(parent, w, numeric, onenter)
  return ns.theme.edit(parent, w, numeric, onenter)
end

-- Sélecteur de quantité unique : libellé + champ + − / + (Maj : ±10, molette : ±1) + Max optionnel.
-- Pose host.l1 (libellé), host.qty (champ), host.minus, host.plus, host.max (si o.max est fourni).
-- o : labelW (60), max = function() -> valeur, onChange = function(v), tip
function W.qty(host, parent, x, y, o)
  o = o or {}
  local lw = o.labelW or 60
  host.l1 = W.text(parent, "GringottsTextSmall", "Quantité", x, y - 4, lw)
  local e = W.edit(parent, 60, true); e:SetPoint("TOPLEFT", parent, "TOPLEFT", x + lw + 2, y); e:SetText("1")
  host.qty = e
  local function set(v)
    v = math.max(1, math.floor(v)); e:SetText(tostring(v)); if o.onChange then o.onChange(v) end
  end
  local function step(sign) set((tonumber(e:GetText()) or 0) + sign * (IsShiftKeyDown() and 10 or 1)) end
  local bx = x + lw + 2 + 68
  host.minus = W.button(parent, "-", 24, 22, function() step(-1) end); host.minus:SetPoint("TOPLEFT", parent, "TOPLEFT", bx, y + 1)
  host.plus = W.button(parent, "+", 24, 22, function() step(1) end); host.plus:SetPoint("TOPLEFT", parent, "TOPLEFT", bx + 28, y + 1)
  if o.max then
    host.max = W.button(parent, "Max", 50, 22, function() local v = o.max(); if v then set(v) end end)
    host.max:SetPoint("TOPLEFT", parent, "TOPLEFT", bx + 58, y + 1)
  end
  e:EnableMouseWheel(true)
  e:SetScript("OnMouseWheel", function(_, d) step(d > 0 and 1 or -1) end)
  return e
end

-- Choix exclusif en boutons juxtaposés : opts = { { clé, libellé, largeur }, ... } ; le choix actif est grisé.
-- get() -> clé active ; set(clé) appelé au clic. Retourne un objet avec :Refresh().
function W.seg(parent, x, y, opts, get, set)
  local o = { btn = {} }
  local bx = x
  for _, d in ipairs(opts) do
    local b = W.button(parent, d[2], d[3], 22, function() set(d[1]); o:Refresh() end)
    b:SetPoint("TOPLEFT", parent, "TOPLEFT", bx, y); o.btn[d[1]] = b; bx = bx + d[3] + 6
  end
  function o:Refresh()
    local cur = get()
    for k, b in pairs(self.btn) do if k == cur then b:Disable() else b:Enable() end end
  end
  return o
end

-- Tuile : libellé, valeur, sous-texte
function W.tile(parent, w, h)
  local f = CreateFrame("Frame", nil, parent)
  f:SetSize(w, h)
  ns.theme.panel(f, "panel", "line")
  local t = { frame = f }
  t.label = W.text(f, "GringottsLabelSmall", "", 8, -6, w - 16)
  t.value = W.text(f, "GringottsValue", "", 8, -22, w - 16)
  t.sub = W.text(f, "GringottsTextSmall", "", 8, -(h - 16), w - 16)
  function t:Set(label, value, sub) self.label:SetText(label or ""); self.value:SetText(value or ""); self.sub:SetText(sub or "") end
  return t
end

-- Liste à lignes recyclées : seules les lignes visibles existent, quel que soit le nombre d'entrées.
-- setup(btn) crée le contenu d'une ligne ; fill(btn, entree, index) le remplit.
function W.list(parent, w, h, rowH, setup, fill)
  local L = { data = {}, off = 0, n = math.floor(h / rowH), rows = {} }
  local f = CreateFrame("Frame", nil, parent)
  f:SetSize(w, h); L.frame = f
  local sb = CreateFrame("Slider", nil, f)
  sb:SetPoint("TOPRIGHT", f, "TOPRIGHT", 0, 0); sb:SetSize(12, h)
  sb:SetOrientation("VERTICAL")
  W.fill(sb, TC.panel2[1], TC.panel2[2], TC.panel2[3], 1):SetAllPoints()
  local th = W.fill(sb, TC.silver[1], TC.silver[2], TC.silver[3], .55, "OVERLAY"); th:SetSize(12, 36)
  sb:SetThumbTexture(th)
  sb:SetMinMaxValues(0, 0); sb:SetValueStep(1); sb:SetValue(0)
  L.bar = sb
  for i = 1, L.n do
    local b = CreateFrame("Button", nil, f)
    b:SetSize(w - 16, rowH); b:SetPoint("TOPLEFT", f, "TOPLEFT", 0, -(i - 1) * rowH)
    b.hl = W.fill(b, TC.gold[1], TC.gold[2], TC.gold[3], .10, "HIGHLIGHT"); b.hl:SetAllPoints()
    b.sel = W.fill(b, TC.gold[1], TC.gold[2], TC.gold[3], .14, "BACKGROUND"); b.sel:SetAllPoints(); b.sel:Hide()
    if setup then setup(b) end
    -- une ligne = une seule ligne de texte : pas de retour à la ligne (sinon les lignes se chevauchent), « ... » si trop long
    for _, r in ipairs({ b:GetRegions() }) do
      if r.GetObjectType and r:GetObjectType() == "FontString" then
        if r.SetWordWrap then r:SetWordWrap(false) end
        if r.SetMaxLines then r:SetMaxLines(1) end
      end
    end
    b:Hide()
    L.rows[i] = b
  end
  function L:Refresh()
    for i, b in ipairs(self.rows) do
      local e = self.data[self.off + i]
      if e then b:Show(); fill(b, e, self.off + i) else b:Hide() end
    end
  end
  function L:SetData(d, keepOffset)
    self.data = d or {}
    local maxOff = math.max(0, #self.data - self.n)
    if not keepOffset then self.off = 0 end
    if self.off > maxOff then self.off = maxOff end
    self.busy = true
    sb:SetMinMaxValues(0, maxOff); sb:SetValue(self.off)
    self.busy = false
    if maxOff == 0 then sb:Hide() else sb:Show() end
    self:Refresh()
  end
  sb:SetScript("OnValueChanged", function(_, v)
    if L.busy then return end
    L.off = math.floor((v or 0) + .5); L:Refresh()
  end)
  f:EnableMouseWheel(true)
  f:SetScript("OnMouseWheel", function(_, delta)
    local maxOff = math.max(0, #L.data - L.n)
    local o = math.max(0, math.min(maxOff, L.off - delta * 3))
    if o ~= L.off then L.off = o; L.busy = true; sb:SetValue(o); L.busy = false; L:Refresh() end
  end)
  return L
end

-- Barres verticales (courbe de prix, profil de la semaine) : values[i] > 0, 0 = inconnu
function W.bars(parent, n, bw, gap, h)
  local B = { tex = {}, n = n, h = h }
  local f = CreateFrame("Frame", nil, parent)
  f:SetSize(n * (bw + gap), h); B.frame = f
  ns.theme.panel(f, "bg", "line")
  for i = 1, n do
    local t = f:CreateTexture(nil, "ARTWORK")
    t:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", (i - 1) * (bw + gap) + gap / 2, 2)
    t:SetSize(bw, 1)
    B.tex[i] = t
  end
  B.med = f:CreateTexture(nil, "OVERLAY"); B.med:SetColorTexture(.8, .8, .8, .35); B.med:SetSize(n * (bw + gap), 1); B.med:Hide()
  -- hi : indice de la barre à mettre en valeur ; ref : valeur de référence (médiane) tracée en trait
  function B:Set(values, hi, ref, lowIsGood)
    local lo, mx = math.huge, 0
    for i = 1, self.n do local v = values[i]; if v and v > 0 then lo = math.min(lo, v); mx = math.max(mx, v) end end
    if mx == 0 then for i = 1, self.n do self.tex[i]:Hide() end; self.med:Hide(); return end
    local base = lo * 0.9
    local span = math.max(mx - base, 1)
    for i = 1, self.n do
      local v, t = values[i], self.tex[i]
      if v and v > 0 then
        t:SetHeight(math.max(2, (v - base) / span * (self.h - 8) + 4))
        if i == hi then t:SetColorTexture(TC.ok[1], TC.ok[2], TC.ok[3], 1) else t:SetColorTexture(TC.gold[1], TC.gold[2], TC.gold[3], .9) end
        t:Show()
      else t:Hide() end
    end
    if ref and ref > 0 and ref >= base and ref <= mx then
      self.med:ClearAllPoints()
      self.med:SetPoint("BOTTOMLEFT", self.frame, "BOTTOMLEFT", 0, 2 + (ref - base) / span * (self.h - 8) + 4)
      self.med:Show()
    else self.med:Hide() end
  end
  return B
end
