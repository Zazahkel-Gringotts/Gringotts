-- Gringotts : onglet « Gringotts » de la fenêtre (Tour de contrôle, Stock & achats, Finances), disposition à 3 colonnes.
local ADDON, ns = ...
local W = ns.W
local C = W.C
local G = {}
ns.gring = G

local LEFT_W, RIGHT_W = 440, 400
local STATUS = {
  buy = { "À acheter", C.green }, sell = { "À vendre", C.orange }, odd = { "Prix anormal", C.red }, wait = { "Attendre", C.grey }, noprice = { "Sans prix", C.red },
}
local ORDER = { "buy", "sell", "odd", "wait", "noprice" }
local S = { items = {}, byKey = {}, sel = nil, chip = "all", sort = "urgency", filter = "", collapsed = { wait = true, noprice = true }, checked = {} }

local function A() return ns.api end
local function E() return ns.engine end
local function coins(c) return c and A().coins(c) or W.col(C.grey, "—") end
local function pct(g) if not g then return "—" end return ("%+d %%"):format(math.floor(g * 100 + (g < 0 and -.5 or .5))) end
local function gapCol(g) if not g then return C.grey end if g <= -0.05 then return C.green elseif g >= 0.05 then return C.orange end return C.white end

function G.reload()
  S.items = E().items()
  S.byKey = {}
  for _, it in ipairs(S.items) do S.byKey[it.k] = it end
end

-- Médiane 30 j d'un objet suivi (par id), nil si inconnue
function G.medOf(id)
  for _, x in ipairs(S.items) do if x.id == id then return x.med end end
end
-- Prix max d'achat : prix du moment + marge, jamais au-dessus de la médiane 30 j
function G.capMax(price, med)
  local m = math.floor((price or 0) * (1 + E().cfg().snipeMargin))
  if med and med > 0 then m = math.min(m, med) end
  return m
end
function G.buyMaxUnit(it) return G.capMax(it.price, it.med) end
function G.refreshBuyBtn(D)
  local B, it = ns.buy, D.cur
  if not it then D.buyBtn:Disable(); D.sellBtn:Disable(); return end
  if B.state and B.state.stage == "await" then D.buyBtn:SetText("Confirmer l'achat"); D.buyBtn:Enable(); return end
  D.buyBtn:SetText(B.state and "Achat en cours..." or "Acheter à l'HV")
  local over = it.med and it.price and it.price > it.med
  if over then D.buyBtn:SetText("Au-dessus de la médiane") end
  if B.available() and B.ahOpen() and it.id and it.price and not B.state and not over then D.buyBtn:Enable() else D.buyBtn:Disable() end
  local have = it.id and B.bagCount and B.bagCount(it.id) or 0
  local q = math.min((it.sellQty or 0) > 0 and it.sellQty or have, have)
  D.sellBtn:SetText(q > 0 and ("Vendre %d à l'HV"):format(q) or "Vendre")
  if B.canSell() and it.sellAt and not it.belowFloor and it.status ~= "odd" and have > 0 then D.sellBtn:Enable() else D.sellBtn:Disable() end
end

------------------------------------------------------------------------
-- Panneau de détail d'un objet (partagé par Tour de contrôle et Stock & achats)
------------------------------------------------------------------------
local function makeDetail(parent, x, w)
  local D = {}
  local f = CreateFrame("Frame", nil, parent)
  f:SetPoint("TOPLEFT", parent, "TOPLEFT", x, 0); f:SetPoint("BOTTOMRIGHT", parent, "BOTTOMRIGHT", -RIGHT_W - 12, 0)
  D.frame = f
  D.title = W.text(f, "GringottsH2", "", 0, 0, w)
  D.sub = W.text(f, "GringottsTextSmall", "", 0, -26, w)
  local tw = math.floor((w - 24) / 4)
  D.tiles = {}
  for i = 1, 4 do
    local t = W.tile(f, tw, 64); t.frame:SetPoint("TOPLEFT", f, "TOPLEFT", (i - 1) * (tw + 8), -50)
    D.tiles[i] = t
  end
  W.text(f, "GringottsLabel", "Prix · 30 jours", 0, -126, w)
  D.chart = W.bars(f, 30, 14, 6, 100); D.chart.frame:SetPoint("TOPLEFT", f, "TOPLEFT", 0, -146)
  D.chartNote = W.text(f, "GringottsTextSmall", "", 0, -250, w)
  W.text(f, "GringottsLabel", "Jour de la semaine (mer › mar)", 0, -272, 260)
  D.week = W.bars(f, 7, 24, 12, 60); D.week.frame:SetPoint("TOPLEFT", f, "TOPLEFT", 0, -292)
  D.dayLbl = {}
  local names = { "Mer", "Jeu", "Ven", "Sam", "Dim", "Lun", "Mar" }
  for i = 1, 7 do D.dayLbl[i] = W.text(f, "GringottsTextSmall", names[i], (i - 1) * 36 + 4, -354, 36) end
  W.text(f, "GringottsLabel", "Où est le stock", 290, -272, w - 290)
  D.stock = {}
  for i = 1, 6 do D.stock[i] = W.text(f, "GringottsTextSmall", "", 290, -292 - (i - 1) * 16, w - 290) end
  -- Actions
  local ay = -386
  D.act = CreateFrame("Frame", nil, f); D.act:SetPoint("TOPLEFT", f, "TOPLEFT", 0, ay); D.act:SetSize(w, 150)
  ns.theme.panel(D.act, "okbg", "line")
  D.reco = W.text(D.act, "GringottsText", "", 10, -8, w - 20)
  W.text(D.act, "GringottsTextSmall", "Quantité", 10, -36, 60)
  D.qty = W.edit(D.act, 60, true); D.qty:SetPoint("TOPLEFT", D.act, "TOPLEFT", 72, -32); D.qty:SetText("1")
  D.minus = W.button(D.act, "-", 24, 22, function() D.qty:SetText(tostring(math.max(1, (tonumber(D.qty:GetText()) or 1) - 10))) end); D.minus:SetPoint("TOPLEFT", D.act, "TOPLEFT", 140, -31)
  D.plus = W.button(D.act, "+", 24, 22, function() D.qty:SetText(tostring((tonumber(D.qty:GetText()) or 0) + 10)) end); D.plus:SetPoint("TOPLEFT", D.act, "TOPLEFT", 168, -31)
  D.add = W.button(D.act, "Ajouter à la liste d'achats", 190, 22, function()
    if not D.cur then return end
    E().addShop(D.cur.k, tonumber(D.qty:GetText()) or 0); G.refresh()
  end); D.add:SetPoint("TOPLEFT", D.act, "TOPLEFT", 204, -31)
  D.buyBtn = W.button(D.act, "Acheter à l'HV", 190, 22, function()
    local it = D.cur; if not it or not it.id then return end
    local q = math.floor(tonumber(D.qty:GetText()) or 0)
    ns.buy.buy(it.id, q, G.buyMaxUnit(it), E().cfg().snipeOneClick)
  end); D.buyBtn:SetPoint("TOPLEFT", D.act, "TOPLEFT", 400, -31)
  D.sellBtn = W.button(D.act, "Vendre", 190, 22, function()
    local it = D.cur; if not it or not it.id or not it.sellAt then return end
    local have = ns.buy.bagCount(it.id)
    local q = math.min(it.sellQty > 0 and it.sellQty or have, have)
    if D.sellLeft and D.sellLeft > 0 and D.sellFor == it.k then q = math.min(D.sellLeft, have) end
    if ns.buy.sell(it.id, q, it.sellAt, E().cfg().sellDuration) then D.sellFor = it.k; D.sellLeft = (ns.buy.lastSold and ns.buy.lastSold.left) or 0 end
    G.refreshBuyBtn(D)
  end); D.sellBtn:SetPoint("TOPLEFT", D.act, "TOPLEFT", 400, -63)
  D.sell = W.text(D.act, "GringottsText", "", 10, -100, w - 20)
  D.sell2 = W.text(D.act, "GringottsTextSmall", "", 10, -124, w - 20)
  W.text(D.act, "GringottsTextSmall", "Cible de stock", 10, -68, 90)
  D.tgt = W.edit(D.act, 70, true); D.tgt:SetPoint("TOPLEFT", D.act, "TOPLEFT", 100, -64)
  D.setT = W.button(D.act, "Définir", 70, 22, function()
    if not D.cur then return end
    local d = A().db(); d.targets = d.targets or {}
    local v = tonumber(D.tgt:GetText()); d.targets[D.cur.k] = (v and v > 0) and v or nil
    G.reload(); G.refresh()
  end); D.setT:SetPoint("TOPLEFT", D.act, "TOPLEFT", 176, -63)
  D.noT = W.button(D.act, "Effacer", 70, 22, function()
    if not D.cur then return end
    local d = A().db(); if d.targets then d.targets[D.cur.k] = nil end
    D.tgt:SetText(""); G.reload(); G.refresh()
  end); D.noT:SetPoint("TOPLEFT", D.act, "TOPLEFT", 250, -63)

  function D:Show(it)
    self.cur = it
    if not it then
      self.title:SetText(W.col(C.grey, "Aucun objet sélectionné")); self.sub:SetText("")
      for i = 1, 4 do self.tiles[i]:Set("", "", "") end
      self.chart:Set({}); self.week:Set({}); self.chartNote:SetText(""); self.reco:SetText("")
      for i = 1, 6 do self.stock[i]:SetText("") end
      return
    end
    local P = ns.prices
    local st = STATUS[it.status]
    self.title:SetText(it.name)
    self.sub:SetText(W.col(st[2], st[1]) .. (it.why ~= "" and ("  ·  " .. it.why) or ""))
    local srcTxt = it.src == "ah" and ("Auctionator" .. (it.age and (" · il y a " .. math.floor(it.age) .. " j") or ""))
      or (it.src == "file" and ("Fichier du " .. P.ageText():match("^(%d+/%d+)")) or "")
    self.tiles[1]:Set("Prix HV", coins(it.price), srcTxt)
    self.tiles[2]:Set("Médiane 30 j", coins(it.med), P.info().loaded and "relevés du bot" or "")
    self.tiles[3]:Set("Écart à la médiane", it.gap and W.col(gapCol(it.gap), pct(it.gap)) or "—", it.gap and (it.gap < 0 and "moins cher que d'habitude" or "plus cher que d'habitude") or "")
    local best = it.best
    self.tiles[4]:Set("Meilleur jour d'achat", best and P.dayName(best) or "—", best and "" or "pas assez de semaines complètes")
    -- courbe : 30 derniers jours de la série
    local s = P.series(it.name) or {}
    local vals, n = {}, #s
    for i = 1, 30 do vals[i] = s[n - 30 + i] or 0 end
    self.chart:Set(vals, nil, it.med)
    self.chartNote:SetText(W.col(C.grey, "trait gris : médiane 30 j · trait vide = prix inconnu ce jour-là"))
    -- profil de la semaine (mercredi -> mardi) : f est indexé dimanche = 1
    local r = P.rec(it.name)
    local wv, hi = {}, nil
    if r and r.f then
      for i = 1, 7 do wv[i] = (r.f[((3 + i - 1) % 7) + 1] or 0) * 1000 end
      if type(best) == "number" then hi = ((best - 3) % 7) + 1 end
    end
    self.week:Set(wv, hi, nil)
    -- stock par personnage
    local by, guild = E().stockBy(it.k)
    local line = 1
    for _, c in ipairs(by) do
      if line <= 5 then self.stock[line]:SetText(("%s : sacs %d · banque %d"):format(c.name, c.bags, c.bank)); line = line + 1 end
    end
    if guild > 0 and line <= 6 then self.stock[line]:SetText(("Banque de guilde : %d"):format(guild)); line = line + 1 end
    if line == 1 then self.stock[1]:SetText(W.col(C.grey, "Aucun en stock")); line = 2 end
    for i = line, 6 do self.stock[i]:SetText("") end
    -- recommandation
    if it.status == "buy" then
      self.reco:SetText(("Acheter %d  ·  stock %d / cible %d"):format(it.toBuy, it.stock, it.target))
      self.qty:SetText(tostring(it.toBuy))
    elseif it.status == "sell" then
      self.reco:SetText(("Vendre %d  ·  prix %s la médiane"):format(it.sellQty, pct(it.gap)))
    elseif it.status == "odd" then
      self.reco:SetText(W.col(C.red, "Prix anormal : ") .. W.col(C.grey, "attends ou vérifie à l'HV."))
    else
      self.reco:SetText(W.col(C.grey, "Aucune action conseillée."))
    end
    local fee = E().cfg().fee
    if it.status == "odd" then
      self.sell:SetText(W.col(C.red, it.why)); self.sell2:SetText("")
    elseif it.sellAt then
      local line = "Prix de vente conseillé : " .. coins(it.sellAt) .. (it.belowFloor and "" or "  (1 c sous le marché)")
      if it.belowFloor then line = line .. W.col(C.orange, "  ·  le marché est sous ton plancher : attends") end
      self.sell:SetText(line)
      local l2 = ("Net après %d %% de commission : %s par unité"):format(math.floor(fee * 100 + .5), coins(it.netUnit))
      if it.netTotal then l2 = l2 .. ("  ·  %d à vendre = %s"):format(it.sellQty, coins(it.netTotal)) end
      if it.floor then l2 = l2 .. "  ·  plancher " .. coins(it.floor) end
      if it.profit then l2 = l2 .. (it.profit >= 0 and W.col(C.green, "  ·  gain à la revente ~ +" .. coins(it.profit)) or W.col(C.red, "  ·  perte à la revente ~ -" .. coins(-it.profit))) end
      self.sell2:SetText(l2)
    else
      self.sell:SetText(""); self.sell2:SetText("")
    end
    self.tgt:SetText(it.manual and tostring(it.manual) or "")
    G.refreshBuyBtn(self)
  end
  return D
end

------------------------------------------------------------------------
-- Stock & achats
------------------------------------------------------------------------
local function buildFlat()
  local f = S.filter ~= "" and A().norm(S.filter) or nil
  local groups = { buy = {}, sell = {}, odd = {}, wait = {}, noprice = {} }
  local shown = 0
  for _, it in ipairs(S.items) do
    local ok = true
    if S.chip == "buy" then ok = it.status == "buy"
    elseif S.chip == "sell" then ok = it.status == "sell" or it.status == "odd"
    elseif S.chip == "below" then ok = it.target > it.stock end
    if ok and f and not A().norm(it.name):find(f, 1, true) then ok = false end
    if ok then table.insert(groups[it.status], it); shown = shown + 1 end
  end
  local flat = {}
  for _, g in ipairs(ORDER) do
    local list = groups[g]
    if #list > 0 then
      if S.sort == "name" then table.sort(list, function(a, b) return a.name < b.name end)
      elseif S.sort == "value" then table.sort(list, function(a, b) return (a.price or 0) * a.stock > (b.price or 0) * b.stock end)
      else E().sortUrgency(list) end
      flat[#flat + 1] = { hdr = g, count = #list }
      if not S.collapsed[g] then for _, it in ipairs(list) do flat[#flat + 1] = it end end
    end
  end
  return flat, shown
end

local function nChecked() local n = 0; for _ in pairs(S.checked) do n = n + 1 end return n end

function G.buildStock(pane)
  local P = {}
  local left = CreateFrame("Frame", nil, pane); left:SetPoint("TOPLEFT", pane, "TOPLEFT", 0, 0); left:SetPoint("BOTTOMLEFT", pane, "BOTTOMLEFT", 0, 0); left:SetWidth(LEFT_W)
  P.head = W.text(left, "GringottsH2", "Stock & achats", 0, 0, 300)
  P.count = W.text(left, "GringottsTextSmall", "", 220, -4, LEFT_W - 230, "RIGHT")
  P.search = W.edit(left, 220, false); P.search:SetPoint("TOPLEFT", left, "TOPLEFT", 6, -26)
  P.search:SetScript("OnTextChanged", function(self) S.filter = self:GetText() or ""; if P.ready then G.refresh() end end)
  P.sortBtn = W.button(left, "Tri : urgence", 120, 22, function()
    S.sort = (S.sort == "urgency") and "name" or ((S.sort == "name") and "value" or "urgency"); G.refresh()
  end); P.sortBtn:SetPoint("TOPLEFT", left, "TOPLEFT", 240, -25)
  local chips = { { "all", "Tout" }, { "buy", "À acheter" }, { "sell", "À vendre" }, { "below", "Sous la cible" } }
  P.chips = {}
  local x = 0
  for _, c in ipairs(chips) do
    local b = W.button(left, c[2], 100, 22, function() S.chip = c[1]; G.refresh() end)
    b:SetPoint("TOPLEFT", left, "TOPLEFT", x, -54); P.chips[c[1]] = b; x = x + 104
  end
  P.colHead = W.text(left, "GringottsLabelSmall", "Objet", 28, -84, 200)
  W.text(left, "GringottsLabelSmall", "Stock / cible", 230, -84, 110, "RIGHT")
  W.text(left, "GringottsLabelSmall", "Écart", 340, -84, 70, "RIGHT")
  P.list = W.list(left, LEFT_W, 520, 22, function(b)
    b.chk = CreateFrame("Button", nil, b); b.chk:SetSize(18, 18); b.chk:SetPoint("LEFT", b, "LEFT", 2, 0)
    b.chkBg = W.fill(b.chk, .059, .075, .098, 1); b.chkBg:SetAllPoints()
    b.chkOn = W.fill(b.chk, W.C.gold[1], W.C.gold[2], W.C.gold[3], 1, "OVERLAY"); b.chkOn:SetPoint("CENTER"); b.chkOn:SetSize(10, 10)
    b.name = W.text(b, "GringottsText", "", 28, -3, 205)
    b.stk = W.text(b, "GringottsTextSmall", "", 230, -5, 110, "RIGHT")
    b.gap = W.text(b, "GringottsTextSmall", "", 340, -5, 70, "RIGHT")
    b:SetScript("OnClick", function(self)
      local e = self.entry; if not e then return end
      if e.hdr then S.collapsed[e.hdr] = not S.collapsed[e.hdr] else S.sel = e.k end
      G.refresh()
    end)
    b.chk:SetScript("OnClick", function(self)
      local e = b.entry; if not e or e.hdr then return end
      if S.checked[e.k] then S.checked[e.k] = nil else S.checked[e.k] = true end
      G.refresh()
    end)
  end, function(b, e)
    b.entry = e
    if e.hdr then
      local st = STATUS[e.hdr]
      b.chk:Hide(); b.sel:Hide()
      b.name:SetText(W.col(C.gold, (S.collapsed[e.hdr] and "+ " or "- ") .. st[1]) .. W.col(C.grey, "  (" .. e.count .. ")"))
      b.stk:SetText(""); b.gap:SetText("")
    else
      b.chk:Show(); if S.checked[e.k] then b.chkOn:Show() else b.chkOn:Hide() end
      b.name:SetText(e.name)
      b.stk:SetText(e.target > 0 and ("%d / %d"):format(e.stock, e.target) or tostring(e.stock))
      b.gap:SetText(e.gap and W.col(gapCol(e.gap), pct(e.gap)) or "")
      if S.sel == e.k then b.sel:Show() else b.sel:Hide() end
    end
  end)
  P.list.frame:SetPoint("TOPLEFT", left, "TOPLEFT", 0, -100)
  P.bulk = W.button(left, "Ajouter les cochés à la liste", 220, 24, function()
    local d = A().db()
    for k in pairs(S.checked) do
      local it = S.byKey[k]
      local q = it and it.toBuy > 0 and it.toBuy or 1
      E().addShop(k, q)
    end
    S.checked = {}; G.refresh()
  end); P.bulk:SetPoint("BOTTOMLEFT", left, "BOTTOMLEFT", 0, 0)
  P.bulkN = W.text(left, "GringottsTextSmall", "", 230, 0, 200, "LEFT", "BOTTOMLEFT"); P.bulkN:SetPoint("BOTTOMLEFT", left, "BOTTOMLEFT", 230, 6)
  -- centre
  P.detail = makeDetail(pane, LEFT_W + 20, 600)
  -- droite : liste d'achats
  local right = CreateFrame("Frame", nil, pane); right:SetPoint("TOPRIGHT", pane, "TOPRIGHT", 0, 0); right:SetPoint("BOTTOMRIGHT", pane, "BOTTOMRIGHT", 0, 0); right:SetWidth(RIGHT_W)
  ns.theme.panel(right, "panel", "line")
  W.text(right, "GringottsH2", "Liste d'achats", 12, -8, RIGHT_W - 24)
  P.shopRows = {}
  for i = 1, 18 do
    local r = {}
    r.name = W.text(right, "GringottsText", "", 12, -40 - (i - 1) * 20, 220)
    r.qty = W.text(right, "GringottsText", "", 232, -40 - (i - 1) * 20, 60, "RIGHT")
    r.cost = W.text(right, "GringottsTextSmall", "", 296, -42 - (i - 1) * 20, 60, "RIGHT")
    r.del = W.button(right, "x", 20, 18, function() if r.k then E().setShop(r.k, 0); G.refresh() end end)
    r.del:SetPoint("TOPLEFT", right, "TOPLEFT", RIGHT_W - 32, -38 - (i - 1) * 20)
    P.shopRows[i] = r
  end
  P.shopTotal = W.text(right, "GringottsText", "", 12, -408, RIGHT_W - 24)
  P.send = W.button(right, "Envoyer à Auctionator", 190, 24, function()
    local n, err = E().sendShop(S.items)
    print("|cffe4b84eGringotts|r " .. (n and ("Liste Auctionator « Gringotts - Achats » : " .. n .. " objets.") or ("Envoi impossible : " .. tostring(err))))
  end); P.send:SetPoint("TOPLEFT", right, "TOPLEFT", 12, -434)
  P.clear = W.button(right, "Vider", 90, 24, function() E().clearShop(); G.refresh() end); P.clear:SetPoint("TOPLEFT", right, "TOPLEFT", 210, -434)
  W.text(right, "GringottsLabel", "Utilisé dans", 12, -480, RIGHT_W - 24)
  P.used = W.text(right, "GringottsTextSmall", W.col(C.grey, "Les recettes qui utilisent cet objet apparaîtront avec l'onglet Métiers."), 12, -502, RIGHT_W - 24)
  P.right = right
  P.ready = true

  function P:Refresh()
    local flat, shown = buildFlat()
    self.count:SetText(("%d sur %d affichés"):format(shown, #S.items))
    self.sortBtn:SetText("Tri : " .. (S.sort == "urgency" and "urgence" or (S.sort == "name" and "nom" or "valeur")))
    for k, b in pairs(self.chips) do if k == S.chip then b:Disable() else b:Enable() end end
    self.list:SetData(flat, true)
    local n = nChecked()
    self.bulkN:SetText(n > 0 and (n .. " coché(s)") or W.col(C.grey, "cases à cocher : sélection multiple"))
    if n > 0 then self.bulk:Enable() else self.bulk:Disable() end
    self.detail:Show(S.sel and S.byKey[S.sel] or nil)
    local list, total = E().shopList(S.items)
    for i, r in ipairs(self.shopRows) do
      local e = list[i]
      if e then r.k = e.k; r.name:SetText(e.name); r.qty:SetText("x " .. e.qty); r.cost:SetText(e.cost and coins(e.cost) or "")
        r.name:Show(); r.qty:Show(); r.cost:Show(); r.del:Show()
      else r.k = nil; r.name:Hide(); r.qty:Hide(); r.cost:Hide(); r.del:Hide() end
    end
    self.shopTotal:SetText(#list > 0 and ("Total estimé : " .. coins(total)) or W.col(C.grey, "Liste vide : coche des objets ou utilise « Ajouter »."))
    if #list > 18 then self.shopTotal:SetText(("Total estimé : %s  (%d objets, 18 affichés)"):format(coins(total), #list)) end
  end
  return P
end

------------------------------------------------------------------------
-- Tour de contrôle
------------------------------------------------------------------------
function G.buildControl(pane)
  local P = {}
  local left = CreateFrame("Frame", nil, pane); left:SetPoint("TOPLEFT", pane, "TOPLEFT", 0, 0); left:SetPoint("BOTTOMLEFT", pane, "BOTTOMLEFT", 0, 0); left:SetWidth(LEFT_W)
  P.head = W.text(left, "GringottsH2", "Alertes", 0, 0, 300)
  P.count = W.text(left, "GringottsTextSmall", "", 220, -4, LEFT_W - 230, "RIGHT")
  P.list = W.list(left, LEFT_W, 640, 22, function(b)
    b.name = W.text(b, "GringottsText", "", 6, -3, 230)
    b.act = W.text(b, "GringottsTextSmall", "", 236, -5, 110, "RIGHT")
    b.gap = W.text(b, "GringottsTextSmall", "", 346, -5, 64, "RIGHT")
    b:SetScript("OnClick", function(self) if self.entry then S.ctlSel = self.entry.k; G.refresh() end end)
    b:SetScript("OnDoubleClick", function(self) if self.entry then S.sel = self.entry.k; ns.uiOpen("stock") end end)
  end, function(b, e)
    b.entry = e
    b.name:SetText(e.name)
    local st = STATUS[e.status]
    b.act:SetText(W.col(st[2], e.status == "buy" and ("Acheter " .. e.toBuy) or "Vendre"))
    b.gap:SetText(e.gap and W.col(gapCol(e.gap), pct(e.gap)) or "")
    if S.ctlSel == e.k then b.sel:Show() else b.sel:Hide() end
  end)
  P.list.frame:SetPoint("TOPLEFT", left, "TOPLEFT", 0, -28)
  P.detail = makeDetail(pane, LEFT_W + 20, 600)
  local right = CreateFrame("Frame", nil, pane); right:SetPoint("TOPRIGHT", pane, "TOPRIGHT", 0, 0); right:SetPoint("BOTTOMRIGHT", pane, "BOTTOMRIGHT", 0, 0); right:SetWidth(RIGHT_W)
  ns.theme.panel(right, "panel", "line")
  W.text(right, "GringottsH2", "Vue d'ensemble", 12, -8, RIGHT_W - 24)
  P.t = {}
  for i = 1, 4 do local t = W.tile(right, RIGHT_W - 24, 64); t.frame:SetPoint("TOPLEFT", right, "TOPLEFT", 12, -40 - (i - 1) * 72); P.t[i] = t end
  P.fresh = W.text(right, "GringottsText", "", 12, -340, RIGHT_W - 24)
  P.freshSub = W.text(right, "GringottsTextSmall", "", 12, -362, RIGHT_W - 24)
  W.text(right, "GringottsTextSmall", W.col(C.grey, "Double-clic sur une alerte : ouvrir dans Stock & achats."), 12, -420, RIGHT_W - 24)
  function P:Refresh()
    local alerts = {}
    for _, it in ipairs(S.items) do if it.status == "buy" or it.status == "sell" then alerts[#alerts + 1] = it end end
    E().sortUrgency(alerts)
    self.count:SetText(#alerts .. " action(s)")
    self.list:SetData(alerts, true)
    if not S.ctlSel and alerts[1] then S.ctlSel = alerts[1].k end
    self.detail:Show(S.ctlSel and S.byKey[S.ctlSel] or nil)
    local sum = E().summary(S.items)
    local g = E().gold(30)
    local gn = #g.total > 0 and g.total[#g.total] or 0
    self.t[1]:Set("Or total", coins(gn), #g.byChar .. " personnage(s)")
    self.t[2]:Set("Valeur du stock (prix HV)", coins(sum.value), "objets en stock avec un prix")
    self.t[3]:Set("Alertes", ("%d à acheter · %d à vendre"):format(sum.buy, sum.sell), (sum.odd > 0 and (sum.odd .. " prix anormaux · ") or "") .. "gain net si tu vends : " .. coins(sum.net))
    local i = ns.prices.info()
    self.t[4]:Set("Prix de l'HV", i.loaded and (i.stale and W.col(C.orange, "à rafraîchir") or W.col(C.green, "à jour")) or W.col(C.red, "absents"), i.loaded and ns.prices.ageText() or "lance le raccourci Gringotts - Prix")
    self.fresh:SetText("")
    self.freshSub:SetText("")
  end
  return P
end

------------------------------------------------------------------------
-- Finances
------------------------------------------------------------------------
function G.buildFinance(pane)
  local P = {}
  local left = CreateFrame("Frame", nil, pane); left:SetPoint("TOPLEFT", pane, "TOPLEFT", 0, 0); left:SetPoint("BOTTOMLEFT", pane, "BOTTOMLEFT", 0, 0); left:SetWidth(LEFT_W)
  W.text(left, "GringottsH2", "Finances", 0, 0, 300)
  P.rows = {}
  for i = 1, 14 do
    local b = CreateFrame("Button", nil, left); b:SetSize(LEFT_W, 24); b:SetPoint("TOPLEFT", left, "TOPLEFT", 0, -32 - (i - 1) * 24)
    b.hl = W.fill(b, W.C.gold[1], W.C.gold[2], W.C.gold[3], .10, "HIGHLIGHT"); b.hl:SetAllPoints()
    b.sel = W.fill(b, W.C.gold[1], W.C.gold[2], W.C.gold[3], .14, "BACKGROUND"); b.sel:SetAllPoints(); b.sel:Hide()
    b.name = W.text(b, "GringottsText", "", 8, -5, 230); b.val = W.text(b, "GringottsText", "", 240, -5, 190, "RIGHT")
    b:SetScript("OnClick", function(self) S.finSel = self.who; G.refresh() end)
    P.rows[i] = b
  end
  local f = CreateFrame("Frame", nil, pane); f:SetPoint("TOPLEFT", pane, "TOPLEFT", LEFT_W + 20, 0); f:SetPoint("BOTTOMRIGHT", pane, "BOTTOMRIGHT", -RIGHT_W - 12, 0)
  P.title = W.text(f, "GringottsH2", "", 0, 0, 600)
  P.sub = W.text(f, "GringottsTextSmall", "", 0, -26, 600)
  P.t = {}
  for i = 1, 3 do local t = W.tile(f, 196, 64); t.frame:SetPoint("TOPLEFT", f, "TOPLEFT", (i - 1) * 204, -50); P.t[i] = t end
  W.text(f, "GringottsLabel", "Or · 30 jours", 0, -126, 600)
  P.chart = W.bars(f, 30, 14, 6, 140); P.chart.frame:SetPoint("TOPLEFT", f, "TOPLEFT", 0, -146)
  ns.extra.buildJournal(f, -300, P)
  local right = CreateFrame("Frame", nil, pane); right:SetPoint("TOPRIGHT", pane, "TOPRIGHT", 0, 0); right:SetPoint("BOTTOMRIGHT", pane, "BOTTOMRIGHT", 0, 0); right:SetWidth(RIGHT_W)
  ns.theme.panel(right, "panel", "line")
  W.text(right, "GringottsH2", "Répartition", 12, -8, RIGHT_W - 24)
  P.bars = {}
  for i = 1, 10 do
    local r = {}
    r.name = W.text(right, "GringottsText", "", 12, -42 - (i - 1) * 40, 250)
    r.pct = W.text(right, "GringottsTextSmall", "", RIGHT_W - 72, -44 - (i - 1) * 40, 60, "RIGHT")
    r.bg = W.fill(right, .059, .075, .098, 1); r.bg:SetSize(RIGHT_W - 24, 8); r.bg:SetPoint("TOPLEFT", right, "TOPLEFT", 12, -62 - (i - 1) * 40)
    r.fg = W.fill(right, W.C.gold[1], W.C.gold[2], W.C.gold[3], 1, "ARTWORK"); r.fg:SetSize(1, 8); r.fg:SetPoint("TOPLEFT", right, "TOPLEFT", 12, -62 - (i - 1) * 40)
    P.bars[i] = r
  end
  function P:Refresh()
    local g = E().gold(30)
    local rows = { { name = "Tous les personnages", series = g.total, now = g.total[#g.total] or 0, all = true } }
    for _, c in ipairs(g.byChar) do rows[#rows + 1] = c end
    if not S.finSel then S.finSel = rows[1].name end
    local cur = rows[1]
    for i, b in ipairs(self.rows) do
      local r = rows[i]
      if r then
        b.who = r.name; b.name:SetText(r.name); b.val:SetText(coins(r.now)); b:Show()
        if r.name == S.finSel then b.sel:Show(); cur = r else b.sel:Hide() end
      else b:Hide() end
    end
    local s = cur.series
    local n = #s
    local now, d7, d30 = s[n] or 0, s[math.max(1, n - 7)] or 0, s[1] or 0
    self.title:SetText(cur.name)
    self.sub:SetText("Or total, relevé à chaque connexion et toutes les minutes en jeu")
    self.t[1]:Set("Or aujourd'hui", coins(now), "")
    self.t[2]:Set("Variation 7 jours", (now - d7 >= 0 and W.col(C.green, "+") or W.col(C.red, "-")) .. coins(math.abs(now - d7)), "")
    self.t[3]:Set("Variation 30 jours", (now - d30 >= 0 and W.col(C.green, "+") or W.col(C.red, "-")) .. coins(math.abs(now - d30)), "")
    local vals = {}
    for i = 1, 30 do vals[i] = s[i] or 0 end
    self.chart:Set(vals)
    ns.extra.refreshJournal(self, g)
    local tot = g.total[#g.total] or 0
    for i, r in ipairs(self.bars) do
      local c = g.byChar[i]
      if c and tot > 0 then
        local p = c.now / tot
        r.name:SetText(c.name); r.pct:SetText(("%d %%"):format(math.floor(p * 100 + .5))); r.fg:SetWidth(math.max(1, (RIGHT_W - 24) * p))
        r.name:Show(); r.pct:Show(); r.bg:Show(); r.fg:Show()
      else r.name:Hide(); r.pct:Hide(); r.bg:Hide(); r.fg:Hide() end
    end
  end
  return P
end

------------------------------------------------------------------------
-- Sniper : bonnes affaires d'après le dernier scan, achat direct à l'HV
------------------------------------------------------------------------
local SN = { sel = nil, checked = {}, deals = {} }

local function snipeCur() return SN.sel and S.byKey[SN.sel] or nil end

function G.buildSniper(pane)
  local P = {}
  G.sn = P
  local left = CreateFrame("Frame", nil, pane); left:SetPoint("TOPLEFT", pane, "TOPLEFT", 0, 0); left:SetPoint("BOTTOMLEFT", pane, "BOTTOMLEFT", 0, 0); left:SetWidth(LEFT_W)
  W.text(left, "GringottsH2", "Sniper", 0, 0, 200)
  P.count = W.text(left, "GringottsTextSmall", "", 220, -4, LEFT_W - 230, "RIGHT")
  P.fresh = W.text(left, "GringottsTextSmall", "", 0, -28, LEFT_W)
  W.text(left, "GringottsLabelSmall", "Objet", 28, -52, 180)
  W.text(left, "GringottsLabelSmall", "Écart", 210, -52, 70, "RIGHT")
  W.text(left, "GringottsLabelSmall", "Gain net / u.", 290, -52, 120, "RIGHT")
  P.list = W.list(left, LEFT_W, 560, 22, function(b)
    b.chk = CreateFrame("Button", nil, b); b.chk:SetSize(18, 18); b.chk:SetPoint("LEFT", b, "LEFT", 2, 0)
    b.chkBg = W.fill(b.chk, .059, .075, .098, 1); b.chkBg:SetAllPoints()
    b.chkOn = W.fill(b.chk, W.C.gold[1], W.C.gold[2], W.C.gold[3], 1, "OVERLAY"); b.chkOn:SetPoint("CENTER"); b.chkOn:SetSize(10, 10)
    b.name = W.text(b, "GringottsText", "", 28, -3, 180)
    b.gap = W.text(b, "GringottsTextSmall", "", 210, -5, 70, "RIGHT")
    b.gain = W.text(b, "GringottsTextSmall", "", 290, -5, 120, "RIGHT")
    b:SetScript("OnClick", function(self) if self.entry then SN.sel = self.entry.k; G.refresh() end end)
    b.chk:SetScript("OnClick", function() local e = b.entry; if not e then return end
      if SN.checked[e.k] then SN.checked[e.k] = nil else SN.checked[e.k] = true end; G.refresh() end)
  end, function(b, e)
    b.entry = e
    if SN.checked[e.k] then b.chkOn:Show() else b.chkOn:Hide() end
    b.name:SetText((e.lowOdd and W.col(C.red, "! ") or "") .. e.name)
    b.gap:SetText(W.col(C.green, pct(e.gap)))
    b.gain:SetText(coins(e.gain))
    if SN.sel == e.k then b.sel:Show() else b.sel:Hide() end
  end)
  P.list.frame:SetPoint("TOPLEFT", left, "TOPLEFT", 0, -72)
  P.bulk = W.button(left, "Ajouter les cochés à la liste", 220, 24, function()
    for k in pairs(SN.checked) do E().addShop(k, 1) end
    SN.checked = {}; G.refresh()
  end); P.bulk:SetPoint("BOTTOMLEFT", left, "BOTTOMLEFT", 0, 0)

  -- centre
  local f = CreateFrame("Frame", nil, pane)
  f:SetPoint("TOPLEFT", pane, "TOPLEFT", LEFT_W + 20, 0); f:SetPoint("BOTTOMRIGHT", pane, "BOTTOMRIGHT", -RIGHT_W - 12, 0)
  local w = 600
  P.title = W.text(f, "GringottsH2", "", 0, 0, w)
  P.sub = W.text(f, "GringottsTextSmall", "", 0, -26, w)
  local tw = math.floor((w - 24) / 4)
  P.tiles = {}
  for i = 1, 4 do
    local t = W.tile(f, tw, 64); t.frame:SetPoint("TOPLEFT", f, "TOPLEFT", (i - 1) * (tw + 8), -50); P.tiles[i] = t
  end
  W.text(f, "GringottsLabel", "Annonces en direct", 0, -126, w)
  P.bookNote = W.text(f, "GringottsTextSmall", "", 0, -146, w)
  P.book = {}
  for i = 1, 8 do
    P.book[i] = {
      q = W.text(f, "GringottsText", "", 0, -168 - (i - 1) * 18, 80, "RIGHT"),
      p = W.text(f, "GringottsText", "", 100, -168 - (i - 1) * 18, 160),
      t = W.text(f, "GringottsTextSmall", "", 280, -170 - (i - 1) * 18, 300),
    }
  end
  P.warn = W.text(f, "GringottsText", "", 0, -322, w)
  P.act = CreateFrame("Frame", nil, f); P.act:SetPoint("TOPLEFT", f, "TOPLEFT", 0, -360); P.act:SetSize(w, 130)
  ns.theme.panel(P.act, "okbg", "line")
  W.text(P.act, "GringottsTextSmall", "Quantité", 10, -14, 60)
  P.qty = W.edit(P.act, 60, true); P.qty:SetPoint("TOPLEFT", P.act, "TOPLEFT", 72, -10); P.qty:SetText("1")
  P.minus = W.button(P.act, "-", 24, 22, function() P.qty:SetText(tostring(math.max(1, (tonumber(P.qty:GetText()) or 1) - 1))); G.refreshSnipeInfo() end); P.minus:SetPoint("TOPLEFT", P.act, "TOPLEFT", 140, -9)
  P.plus = W.button(P.act, "+", 24, 22, function() P.qty:SetText(tostring((tonumber(P.qty:GetText()) or 0) + 1)); G.refreshSnipeInfo() end); P.plus:SetPoint("TOPLEFT", P.act, "TOPLEFT", 168, -9)
  P.max = W.button(P.act, "Max", 50, 22, function()
    local it = snipeCur(); if it then P.qty:SetText(tostring(G.snipeMaxQty(it))); G.refreshSnipeInfo() end
  end); P.max:SetPoint("TOPLEFT", P.act, "TOPLEFT", 198, -9)
  P.qty:SetScript("OnTextChanged", function() if P.ready then G.refreshSnipeInfo() end end)
  P.info = W.text(P.act, "GringottsText", "", 10, -44, w - 20)
  P.msg = W.text(P.act, "GringottsTextSmall", "", 10, -100, w - 20)
  P.buy = W.button(P.act, "Acheter", 260, 28, function()
    local it = snipeCur(); if not it then return end
    local q = math.floor(tonumber(P.qty:GetText()) or 0)
    local B = ns.buy
    if not (B.available() and B.ahOpen()) then
      local a = ns.api
      if Auctionator and Auctionator.API and Auctionator.API.v1 and Auctionator.API.v1.MultiSearchExact then pcall(Auctionator.API.v1.MultiSearchExact, "Gringotts", { it.name }) end
      return
    end
    B.buy(it.id, q, E().snipeMaxUnit(it), E().cfg().snipeOneClick)
  end); P.buy:SetPoint("TOPLEFT", P.act, "TOPLEFT", 10, -64)
  P.f = f

  -- droite : réglages
  local right = CreateFrame("Frame", nil, pane); right:SetPoint("TOPRIGHT", pane, "TOPRIGHT", 0, 0); right:SetPoint("BOTTOMRIGHT", pane, "BOTTOMRIGHT", 0, 0); right:SetWidth(RIGHT_W)
  ns.theme.panel(right, "panel", "line")
  W.text(right, "GringottsH2", "Réglages du Sniper", 12, -8, RIGHT_W - 24)
  local function row(y, label, get, set)
    W.text(right, "GringottsTextSmall", label, 12, y - 4, 250)
    local e = W.edit(right, 70, true); e:SetPoint("TOPLEFT", right, "TOPLEFT", 280, y)
    e:SetText(tostring(get()))
    e:SetScript("OnEnterPressed", function(self) local v = tonumber(self:GetText()); if v then set(v) end; self:ClearFocus(); G.refresh() end)
    return e
  end
  local cfg = E().cfg
  P.eGap = row(-40, "Écart minimum sous la médiane (%)", function() return math.floor(cfg().snipeGap * 100 + .5) end, function(v) cfg().snipeGap = math.max(1, math.min(95, v)) / 100 end)
  P.eGain = row(-68, "Gain net minimum par unité (argent)", function() return math.floor(cfg().snipeMinGain / 100 + .5) end, function(v) cfg().snipeMinGain = math.max(0, v) * 100 end)
  P.eMargin = row(-96, "Marge de prix tolérée (%)", function() return math.floor(cfg().snipeMargin * 100 + .5) end, function(v) cfg().snipeMargin = math.max(0, math.min(50, v)) / 100 end)
  P.one = W.button(right, "", 340, 24, function() cfg().snipeOneClick = not cfg().snipeOneClick; G.refresh() end); P.one:SetPoint("TOPLEFT", right, "TOPLEFT", 12, -130)
  P.odd = W.button(right, "", 340, 24, function() cfg().snipeOdd = not cfg().snipeOdd; G.refresh() end); P.odd:SetPoint("TOPLEFT", right, "TOPLEFT", 12, -160)
  P.ah = W.text(right, "GringottsText", "", 12, -200, RIGHT_W - 24)
  P.scan = W.text(right, "GringottsTextSmall", "", 12, -226, RIGHT_W - 24)
  W.text(right, "GringottsTextSmall", W.col(C.grey, "Scan : ouvre l'HV, lance un scan complet Auctionator, puis reviens ici. L'achat vérifie le prix réel avant de payer et s'annule s'il dépasse le prix max."), 12, -262, RIGHT_W - 24)
  P.right = right
  P.ready = true

  function P:Refresh()
    SN.deals = E().snipe(S.items)
    local fresh = E().freshCount(S.items)
    self.count:SetText(("%d bonne(s) affaire(s)"):format(#SN.deals))
    self.fresh:SetText(fresh > 0 and W.col(C.green, ("Scan du jour : %d objets relevés"):format(fresh)) or W.col(C.orange, "Aucun scan du jour : lance un scan complet Auctionator."))
    self.list:SetData(SN.deals, true)
    local ok = false
    for _, d in ipairs(SN.deals) do if d.k == SN.sel then ok = true end end
    if not ok then SN.sel = SN.deals[1] and SN.deals[1].k or nil end
    local n = 0; for _ in pairs(SN.checked) do n = n + 1 end
    if n > 0 then self.bulk:Enable() else self.bulk:Disable() end
    local c = E().cfg()
    self.eGap:SetText(tostring(math.floor(c.snipeGap * 100 + .5))); self.eGain:SetText(tostring(math.floor(c.snipeMinGain / 100 + .5))); self.eMargin:SetText(tostring(math.floor(c.snipeMargin * 100 + .5)))
    self.one:SetText("Achat en un clic : " .. (c.snipeOneClick and "OUI" or "non (2 clics)"))
    self.odd:SetText("Inclure les prix anormaux : " .. (c.snipeOdd and "OUI" or "non"))
    local B = ns.buy
    self.ah:SetText(not B.available() and W.col(C.orange, "Achat direct indisponible : recherche Auctionator") or (B.ahOpen() and W.col(C.green, "HV ouvert : achat direct possible") or W.col(C.grey, "HV fermé : ouvre-le pour acheter")))
    local ls = A().db().lastScan
    self.scan:SetText(ls and ("Dernier scan détecté : " .. date("%d/%m %H:%M", ls)) or "")
    local it = snipeCur()
    if not it then
      self.title:SetText(W.col(C.grey, "Aucune affaire pour l'instant")); self.sub:SetText("")
      for i = 1, 4 do self.tiles[i]:Set("", "", "") end
      for i = 1, 8 do self.book[i].q:SetText(""); self.book[i].p:SetText(""); self.book[i].t:SetText("") end
      self.bookNote:SetText(""); self.warn:SetText(""); self.info:SetText(""); self.buy:SetText("Acheter"); self.buy:Disable()
      return
    end
    if B.ahOpen() and B.available() and it.id and not (B.book[it.id] and time() - B.book[it.id].t < 20) then B.query(it.id) end
    self.title:SetText(it.name)
    self.sub:SetText(W.col(C.green, "Bonne affaire") .. ("  ·  %s vs médiane"):format(pct(it.gap)))
    self.tiles[1]:Set("Prix scan", coins(it.price), "Auctionator")
    self.tiles[2]:Set("Médiane 30 j", coins(it.med), "")
    self.tiles[3]:Set("Revente nette", coins(it.resaleNet), "après commission")
    self.tiles[4]:Set("Gain net / u.", coins(it.gain), "")
    self.warn:SetText(it.lowOdd and W.col(C.red, "Prix très bas : vérifie que l'annonce est réelle (erreur de prix, lot restreint).") or "")
    G.refreshSnipeInfo()
  end
  return P
end

-- Quantité maximale achetable : annonces sous le prix max, et or disponible
function G.snipeMaxQty(it)
  local mx = E().snipeMaxUnit(it)
  local av = ns.buy.availableUnder(it.id, mx) or 0
  local gold = GetMoney and math.floor(GetMoney() / math.max(mx, 1)) or av
  return math.max(1, math.min(av > 0 and av or 1, gold))
end

function G.refreshSnipeInfo()
  local P = G.sn; if not P or not P.ready then return end
  local it = snipeCur()
  if not it then return end
  local B = ns.buy
  local mx = E().snipeMaxUnit(it)
  local q = math.floor(tonumber(P.qty:GetText()) or 0)
  local bk = B.book[it.id]
  for i = 1, 8 do
    local l = bk and bk.levels[i]
    if l then
      P.book[i].q:SetText(tostring(l.q)); P.book[i].p:SetText(coins(l.p))
      P.book[i].t:SetText(l.p <= mx and W.col(C.green, "sous le prix max") or W.col(C.grey, "trop cher"))
    else P.book[i].q:SetText(""); P.book[i].p:SetText(""); P.book[i].t:SetText("") end
  end
  P.bookNote:SetText(bk and W.col(C.grey, bk.none and ("Aucune annonce lue (prix du scan utilisé) · prix max d'achat : %s"):format(A().coins(mx)) or ("Prix max d'achat : %s"):format(A().coins(mx))) or W.col(C.grey, B.ahOpen() and "Lecture des annonces..." or "Ouvre l'HV pour voir les annonces en direct."))
  local av = B.availableUnder(it.id, mx)
  local est = q * mx
  P.info:SetText(("Acheter %d  ·  total max %s%s"):format(q, A().coins(est), av and ("  ·  %d dispo sous le prix max"):format(av) or ""))
  local canBuy = B.available() and B.ahOpen() and it.id and q > 0 and not B.state
  P.buy:SetText(B.state and "Achat en cours..." or ((B.available() and B.ahOpen()) and ("Acheter " .. q) or "Chercher dans Auctionator"))
  if canBuy or (not (B.available() and B.ahOpen()) and Auctionator) then P.buy:Enable() else P.buy:Disable() end
  if B.state and B.state.stage == "await" then P.buy:SetText("Confirmer l'achat") ; P.buy:Enable() end
  P.msg:SetText(B.lastMsg and W.col(B.lastOk and C.green or C.orange, B.lastMsg) or "")
end

function G.onBuyUpdate()
  if G.hv and G.hv.ready then G.refreshQueue() end
  if G.current == "hv" and G.hv and G.hv.ready then G.hv:Refresh() end
  if G.current == "sniper" and G.sn and G.sn.ready then G.refreshSnipeInfo() end
  local cur = G.panes and G.panes[G.current]
  if cur and cur.obj and cur.obj.detail then G.refreshBuyBtn(cur.obj.detail) end
end
function G.afterBuy() if G.hvRequery then G.hvRequery() end; if G.current == "sniper" then G.sn.list.frame:Hide(); G.sn.list.frame:Show() end; G.onScanRefresh() end
function G.onScanRefresh() if G.root and G.root:IsShown() then G.refresh() end end
function ns.onScan() local d = A().db(); d.lastScan = time(); G.onScanRefresh() end

-- Avancement du scan HV : bouton du bandeau + bouton de l'onglet HV + barre
function G.onScanProgress()
  local lab = ns.buy.scanLabel and ns.buy.scanLabel()
  if G.scanBtn then
    if lab then G.scanBtn:SetText(ns.buy.scanPhase == "read" and ("Scan " .. (ns.buy.scanPct or 0) .. " %") or "Scan : attente..."); G.scanBtn:Disable()
    else G.scanBtn:SetText("Scanner l'HV"); G.scanBtn:Enable() end
  end
  if G.scanBar then
    if lab then
      G.scanBar.frame:Show()
      local w = G.scanBar.w * ((ns.buy.scanPhase == "read" and (ns.buy.scanPct or 0) or 0) / 100)
      G.scanBar.fill:SetWidth(math.max(.01, w))
      G.scanBar.txt:SetText(lab)
    else G.scanBar.frame:Hide() end
  end
  local P = G.hv
  if P and P.ready and P.scanB then
    if lab then P.scanB:SetText(lab); P.scanB:Disable() else P.scanB:SetText("Scanner l'HV (prix de tous les objets suivis)"); P.scanB:Enable() end
  end
end

------------------------------------------------------------------------
-- Hôtel des ventes intégré : acheter / vendre / mes ventes
------------------------------------------------------------------------
local HS = { sel = nil, sort = nil, checked = {} }
local function goldStr(c)
  local s = ("%.4f"):format((c or 0) / 10000)
  s = s:gsub("0+$", ""); s = s:gsub("%.$", "")
  return s
end
local function parseGold(t) local v = tonumber((((t or ""):gsub(",", ".")))); return v and math.floor(v * 10000 + .5) or nil end
local DUR = { { 1, "12 h" }, { 2, "24 h" }, { 3, "48 h" } }

local function hvEntries()
  local H, out = ns.hv, {}
  if H.mode == "buy" then
    if H.query ~= "" then
      for _, r in ipairs(H.results) do out[#out + 1] = { id = r.id, name = r.name, c1 = r.minPrice and coins(r.minPrice) or "", c2 = tostring(r.qty or ""), p = r.minPrice } end
    else
      local list = {}
      for _, it in ipairs(S.items) do if it.status == "buy" and it.id and it.price then list[#list + 1] = it end end
      E().sortUrgency(list)
      for _, it in ipairs(list) do out[#out + 1] = { id = it.id, name = it.name, c1 = coins(it.price), c2 = W.col(gapCol(it.gap), pct(it.gap)), tracked = it, p = it.price } end
    end
  elseif H.mode == "sell" then
    for _, b in ipairs(H.bags) do
      local it
      for _, x in ipairs(S.items) do if x.id == b.id then it = x break end end
      out[#out + 1] = { id = b.id, name = b.name, c1 = tostring(b.count), c2 = it and it.status == "sell" and W.col(C.orange, "à vendre") or "", tracked = it, count = b.count }
    end
  else
    for _, a in ipairs(H.owned) do
      out[#out + 1] = { id = a.id, auctionID = a.auctionID, name = a.name, c1 = "x " .. a.qty, c2 = a.buyout and coins(a.buyout) or "", auction = a }
    end
  end
  return out
end

function G.buildHV(pane)
  local P = {}
  G.hv = P
  local H, B = ns.hv, ns.buy
  local left = CreateFrame("Frame", nil, pane); left:SetPoint("TOPLEFT", pane, "TOPLEFT", 0, 0); left:SetPoint("BOTTOMLEFT", pane, "BOTTOMLEFT", 0, 0); left:SetWidth(LEFT_W)
  W.text(left, "GringottsH2", "Hôtel des ventes", 0, 0, 300)
  P.modes = {}
  local mx = 0
  for _, m in ipairs({ { "buy", "Acheter" }, { "sell", "Vendre" }, { "own", "Mes ventes" } }) do
    local b = W.button(left, m[2], 140, 24, function()
      H.mode = m[1]; HS.sel = nil; HS.priceSet = nil
      if m[1] == "sell" then H.readBags() elseif m[1] == "own" then H.queryOwned() end
      G.refresh()
    end); b:SetPoint("TOPLEFT", left, "TOPLEFT", mx, -28); P.modes[m[1]] = b; mx = mx + 144
  end
  P.search = W.edit(left, 300, false); P.search:SetPoint("TOPLEFT", left, "TOPLEFT", 6, -62)
  P.search:SetScript("OnEnterPressed", function(self) self:ClearFocus(); H.search(self:GetText() or ""); G.refresh() end)
  P.searchBtn = W.button(left, "Chercher", 100, 22, function() H.search(P.search:GetText() or ""); G.refresh() end); P.searchBtn:SetPoint("TOPLEFT", left, "TOPLEFT", 316, -61)
  P.hdr1 = W.text(left, "GringottsLabelSmall", "Objet", 8, -90, 200)
  P.hdr2 = W.text(left, "GringottsLabelSmall", "", 230, -90, 90, "RIGHT")
  P.hdr3 = W.text(left, "GringottsLabelSmall", "", 330, -90, 100, "RIGHT")
  P.list = W.list(left, LEFT_W, 560, 22, function(b)
    b.chk = CreateFrame("Button", nil, b); b.chk:SetSize(18, 18); b.chk:SetPoint("LEFT", b, "LEFT", 2, 0)
    b.chkBg = W.fill(b.chk, .059, .075, .098, 1); b.chkBg:SetAllPoints()
    b.chkOn = W.fill(b.chk, W.C.gold[1], W.C.gold[2], W.C.gold[3], 1, "OVERLAY"); b.chkOn:SetPoint("CENTER"); b.chkOn:SetSize(10, 10)
    b.name = W.text(b, "GringottsText", "", 28, -3, 195)
    b.c1 = W.text(b, "GringottsTextSmall", "", 230, -5, 90, "RIGHT")
    b.c2 = W.text(b, "GringottsTextSmall", "", 330, -5, 100, "RIGHT")
    b:SetScript("OnClick", function(self) if self.entry then HS.sel = self.entry.auctionID or self.entry.id; HS.entry = self.entry; HS.queried = nil; G.refresh() end end)
    b.chk:SetScript("OnClick", function() local e = b.entry; if not e or e.auctionID then return end
      if HS.checked[e.id] then HS.checked[e.id] = nil else HS.checked[e.id] = true end; G.refresh() end)
  end, function(b, e)
    b.entry = e
    if e.auctionID then b.chk:Hide() else b.chk:Show(); if HS.checked[e.id] then b.chkOn:Show() else b.chkOn:Hide() end end
    b.name:SetText(e.name); b.c1:SetText(e.c1 or ""); b.c2:SetText(e.c2 or "")
    if HS.sel == (e.auctionID or e.id) then b.sel:Show() else b.sel:Hide() end
  end)
  P.list.frame:SetPoint("TOPLEFT", left, "TOPLEFT", 0, -108)
  P.all = W.button(left, "Tout cocher", 110, 24, function()
    local es = hvEntries(); local all = true
    for _, e in ipairs(es) do if not e.auctionID and not HS.checked[e.id] then all = false end end
    HS.checked = {}
    if not all then for _, e in ipairs(es) do if not e.auctionID then HS.checked[e.id] = true end end end
    G.refresh()
  end); P.all:SetPoint("BOTTOMLEFT", left, "BOTTOMLEFT", 0, 0)
  P.bulk = W.button(left, "", 300, 24, function() G.hvBulk() end); P.bulk:SetPoint("BOTTOMLEFT", left, "BOTTOMLEFT", 118, 0)

  -- centre
  local f = CreateFrame("Frame", nil, pane)
  f:SetPoint("TOPLEFT", pane, "TOPLEFT", LEFT_W + 20, 0); f:SetPoint("BOTTOMRIGHT", pane, "BOTTOMRIGHT", -RIGHT_W - 12, 0)
  local w = 600
  P.title = W.text(f, "GringottsH2", "", 0, 0, w)
  P.sub = W.text(f, "GringottsTextSmall", "", 0, -26, w)
  local tw = math.floor((w - 24) / 4)
  P.tiles = {}
  for i = 1, 4 do local t = W.tile(f, tw, 64); t.frame:SetPoint("TOPLEFT", f, "TOPLEFT", (i - 1) * (tw + 8), -50); P.tiles[i] = t end
  W.text(f, "GringottsLabel", "Annonces en direct", 0, -126, w)
  P.bookNote = W.text(f, "GringottsTextSmall", "", 0, -146, w)
  P.book = {}
  for i = 1, 10 do
    P.book[i] = { q = W.text(f, "GringottsText", "", 0, -168 - (i - 1) * 18, 80, "RIGHT"), p = W.text(f, "GringottsText", "", 100, -168 - (i - 1) * 18, 160),
                  t = W.text(f, "GringottsTextSmall", "", 280, -170 - (i - 1) * 18, 300) }
  end
  P.act = CreateFrame("Frame", nil, f); P.act:SetPoint("TOPLEFT", f, "TOPLEFT", 0, -360); P.act:SetSize(w, 190)
  ns.theme.panel(P.act, "okbg", "line")
  P.l1 = W.text(P.act, "GringottsTextSmall", "Quantité", 10, -14, 70)
  P.qty = W.edit(P.act, 60, true); P.qty:SetPoint("TOPLEFT", P.act, "TOPLEFT", 82, -10); P.qty:SetText("1")
  P.minus = W.button(P.act, "-", 24, 22, function() P.qty:SetText(tostring(math.max(1, (tonumber(P.qty:GetText()) or 1) - 1))) end); P.minus:SetPoint("TOPLEFT", P.act, "TOPLEFT", 150, -9)
  P.plus = W.button(P.act, "+", 24, 22, function() P.qty:SetText(tostring((tonumber(P.qty:GetText()) or 0) + 1)) end); P.plus:SetPoint("TOPLEFT", P.act, "TOPLEFT", 178, -9)
  P.max = W.button(P.act, "Max", 50, 22, function() if HS.maxQty then P.qty:SetText(tostring(HS.maxQty)) end end); P.max:SetPoint("TOPLEFT", P.act, "TOPLEFT", 208, -9)
  P.l2 = W.text(P.act, "GringottsTextSmall", "Prix unitaire (or)", 10, -46, 130)
  P.price = W.edit(P.act, 90, false); P.price:SetPoint("TOPLEFT", P.act, "TOPLEFT", 150, -42)
  P.dur = W.button(P.act, "Durée : 24 h", 110, 22, function()
    local s = E().cfg(); s.sellDuration = (s.sellDuration % 3) + 1; G.refresh()
  end); P.dur:SetPoint("TOPLEFT", P.act, "TOPLEFT", 250, -41)
  P.info = W.text(P.act, "GringottsText", "", 10, -76, w - 20)
  P.info2 = W.text(P.act, "GringottsTextSmall", "", 10, -100, w - 20)
  P.go = W.button(P.act, "Acheter", 300, 30, function() G.hvGo() end); P.go:SetPoint("TOPLEFT", P.act, "TOPLEFT", 10, -130)
  P.msg = W.text(P.act, "GringottsTextSmall", "", 10, -166, w - 20)
  P.f = f
  -- file d'achats / de ventes groupés (recouvre le centre)
  local qf = CreateFrame("Frame", nil, pane)
  qf:SetPoint("TOPLEFT", pane, "TOPLEFT", LEFT_W + 20, 0); qf:SetPoint("BOTTOMRIGHT", pane, "BOTTOMRIGHT", -RIGHT_W - 12, 0)
  ns.theme.panel(qf, "panel", "line")
  qf:Hide(); P.qf = qf
  qf:SetScript("OnHide", function() if ClearOverrideBindings then pcall(ClearOverrideBindings, qf) end end)
  P.qTitle = W.text(qf, "GringottsH2", "", 0, 0, 600)
  P.qSub = W.text(qf, "GringottsTextSmall", "", 0, -26, 600)
  P.qRows = {}
  for i = 1, 18 do
    P.qRows[i] = { n = W.text(qf, "GringottsText", "", 0, -56 - (i - 1) * 22, 260), q = W.text(qf, "GringottsTextSmall", "", 270, -58 - (i - 1) * 22, 70, "RIGHT"),
                   l = W.text(qf, "GringottsTextSmall", "", 350, -58 - (i - 1) * 22, 110, "RIGHT"), s = W.text(qf, "GringottsTextSmall", "", 470, -58 - (i - 1) * 22, 130) }
  end
  P.qNext = ns.theme.button(qf, nil, 360, 36, nil, "primary", "GringottsQueueBtn"); P.qNext:SetPoint("BOTTOMLEFT", qf, "BOTTOMLEFT", 0, 40)
  P.qNext:SetScript("OnClick", function() ns.buy.qStep() end)
  P.qStopB = W.button(qf, "Arrêter la file", 160, 28, function() ns.buy.qStop() end); P.qStopB:SetPoint("BOTTOMLEFT", qf, "BOTTOMLEFT", 380, 44)
  P.qHint = W.text(qf, "GringottsTextSmall", W.col(C.grey, "Un clic ou la touche Espace = un achat (ou une pile). Blizzard n'autorise pas mieux. Les prix min et max sont vérifiés pour chaque objet."), 0, 0, 600, "LEFT", "BOTTOMLEFT")
  P.qHint:SetPoint("BOTTOMLEFT", qf, "BOTTOMLEFT", 0, 6)
  P.qMsg = W.text(qf, "GringottsTextSmall", "", 0, 0, 600, "LEFT", "BOTTOMLEFT"); P.qMsg:SetPoint("BOTTOMLEFT", qf, "BOTTOMLEFT", 0, 84)

  -- droite
  local right = CreateFrame("Frame", nil, pane); right:SetPoint("TOPRIGHT", pane, "TOPRIGHT", 0, 0); right:SetPoint("BOTTOMRIGHT", pane, "BOTTOMRIGHT", 0, 0); right:SetWidth(RIGHT_W)
  ns.theme.panel(right, "panel", "line")
  W.text(right, "GringottsH2", "Hôtel des ventes", 12, -8, RIGHT_W - 24)
  W.text(right, "GringottsTextSmall", "Quantité par objet (achat groupé sans cible)", 12, -246, 280)
  P.bulkQ = W.edit(right, 60, true); P.bulkQ:SetPoint("TOPLEFT", right, "TOPLEFT", 300, -242)
  P.bulkQ:SetText(tostring(E().cfg().bulkQty))
  P.bulkQ:SetScript("OnEnterPressed", function(self) self:ClearFocus(); local v = tonumber(self:GetText()); if v and v > 0 then E().cfg().bulkQty = math.floor(v) end end)
  P.ah = W.text(right, "GringottsText", "", 12, -40, RIGHT_W - 24)
  P.gold = W.text(right, "GringottsText", "", 12, -66, RIGHT_W - 24)
  P.blizz = W.button(right, "", 340, 24, function() H.showBlizzard = not H.showBlizzard; H.applyBlizzard(); G.refresh() end); P.blizz:SetPoint("TOPLEFT", right, "TOPLEFT", 12, -96)
  P.repl = W.button(right, "", 340, 24, function() local s = E().cfg(); s.hvReplace = (s.hvReplace == false); G.refresh() end); P.repl:SetPoint("TOPLEFT", right, "TOPLEFT", 12, -126)
  P.scanB = W.button(right, "Scanner l'HV (prix de tous les objets suivis)", 340, 24, function() ns.buy.scan() end); P.scanB:SetPoint("TOPLEFT", right, "TOPLEFT", 12, -164)
  W.text(right, "GringottsTextSmall", W.col(C.grey, "Chaque achat ou mise en vente demande un clic (règle de Blizzard). Les achats vérifient le prix réel avant de payer."), 12, -206, RIGHT_W - 24)
  P.right = right
  P.ready = true

  function P:Refresh()
    local B = ns.buy
    for k, b in pairs(self.modes) do if k == H.mode then b:Disable() else b:Enable() end end
    local entries = hvEntries()
    self.list:SetData(entries, true)
    local nc = 0; for _, e in ipairs(entries) do if HS.checked[e.id] and not e.auctionID then nc = nc + 1 end end
    if H.mode == "own" then self.bulk:Hide(); self.all:Hide() else self.bulk:Show(); self.all:Show() end
    self.bulk:SetText(nc > 0 and ((H.mode == "buy" and "Acheter les " or "Vendre les ") .. nc .. " cochés") or "Coche des objets pour un achat/vente groupé")
    if nc > 0 and ns.buy.ahOpen() and not ns.buy.qActive() then self.bulk:Enable() else self.bulk:Disable() end
    G.refreshQueue()
    local isOwn = H.mode == "own"
    if H.mode == "buy" then self.search:Show(); self.searchBtn:Show() else self.search:Hide(); self.searchBtn:Hide() end
    self.hdr1:SetText(H.mode == "buy" and (H.query ~= "" and "Résultats" or "À acheter (tes objets suivis)") or (H.mode == "sell" and "Dans tes sacs" or "Tes enchères"))
    self.hdr2:SetText(H.mode == "buy" and (H.query ~= "" and "Prix mini" or "Prix") or (H.mode == "sell" and "Quantité" or "Quantité"))
    self.hdr3:SetText(H.mode == "buy" and (H.query ~= "" and "Disponibles" or "Écart") or (H.mode == "sell" and "" or "Prix"))
    local ahOk = B.ahOpen()
    self.ah:SetText(ahOk and W.col(C.green, "HV ouvert") or W.col(C.orange, "HV fermé : va voir le commissaire-priseur"))
    self.gold:SetText("Or : " .. (GetMoney and A().coins(GetMoney()) or "—"))
    self.blizz:SetText("Fenêtre Blizzard : " .. (H.showBlizzard and "visible" or "masquée"))
    self.repl:SetText("Ouvrir Gringotts à la place de l'HV : " .. (E().cfg().hvReplace == false and "non" or "oui"))
    self.dur:SetText("Durée : " .. DUR[E().cfg().sellDuration][2])
    -- sélection
    local sel
    for _, e in ipairs(entries) do if (e.auctionID or e.id) == HS.sel then sel = e end end
    if not sel then HS.sel = nil end
    HS.entry = sel
    if not sel then
      self.title:SetText(W.col(C.grey, isOwn and "Choisis une enchère" or "Choisis un objet")); self.sub:SetText("")
      for i = 1, 4 do self.tiles[i]:Set("", "", "") end
      for i = 1, 10 do self.book[i].q:SetText(""); self.book[i].p:SetText(""); self.book[i].t:SetText("") end
      self.bookNote:SetText(""); self.info:SetText(""); self.info2:SetText(""); self.go:SetText("—"); self.go:Disable()
      self.qty:Hide(); self.price:Hide(); self.minus:Hide(); self.plus:Hide(); self.max:Hide(); self.dur:Hide(); self.l1:SetText(""); self.l2:SetText("")
      return
    end
    local id = sel.id
    if not isOwn and ahOk and not HS.queried then HS.queried = true; B.query(id) end
    self.title:SetText(sel.name)
    local it = sel.tracked
    if not it then for _, x in ipairs(S.items) do if x.id == id then it = x break end end end
    local bk = B.book[id]
    local low = bk and bk.levels[1] and bk.levels[1].p
    HS.low = low
    self.tiles[1]:Set("Prix mini à l'HV", coins(low or (it and it.price)), bk and "en direct" or "")
    self.tiles[2]:Set("Médiane 30 j", it and coins(it.med) or "—", "")
    self.tiles[3]:Set("Écart", (it and it.gap) and W.col(gapCol(it.gap), pct(it.gap)) or "—", "")
    local vend = id and ns.sellPriceOf and ns.sellPriceOf(id) or nil
    if H.mode == "sell" then
      self.tiles[4]:Set("Prix PNJ", (vend and vend > 0) and coins(vend) or "—", (vend and vend > 0) and "à l'unité" or "ne se vend pas")
    else
      self.tiles[4]:Set("Stock", it and tostring(it.stock) or "—", "")
    end
    local mq = (E().cfg().sellDuration)
    if isOwn then
      local a = sel.auction
      self.sub:SetText(("%d en vente · %s"):format(a.qty, a.buyout and coins(a.buyout) or ""))
      for i = 1, 10 do self.book[i].q:SetText(""); self.book[i].p:SetText(""); self.book[i].t:SetText("") end
      self.bookNote:SetText("")
      self.qty:Hide(); self.price:Hide(); self.minus:Hide(); self.plus:Hide(); self.max:Hide(); self.dur:Hide(); self.l1:SetText(""); self.l2:SetText("")
      self.info:SetText("Annuler te rend l'objet par courrier (le dépôt est perdu).")
      self.info2:SetText("")
      self.go:SetText("Annuler cette enchère"); if ahOk then self.go:Enable() else self.go:Disable() end
      self.mode = "own"
    else
      for i = 1, 10 do
        local l = bk and bk.levels[i]
        if l then self.book[i].q:SetText(tostring(l.q)); self.book[i].p:SetText(coins(l.p)); self.book[i].t:SetText("") else self.book[i].q:SetText(""); self.book[i].p:SetText(""); self.book[i].t:SetText("") end
      end
      self.bookNote:SetText(bk and (bk.none and W.col(C.grey, "Aucune annonce en direct pour cet objet (prix du scan affiché).") or "") or W.col(C.grey, ahOk and "Lecture des annonces..." or "Ouvre l'HV pour voir les annonces."))
      self.qty:Show(); self.price:Show(); self.minus:Show(); self.plus:Show(); self.max:Show(); self.l1:SetText("Quantité"); self.l2:SetText("Prix unitaire (or)")
      local q = math.floor(tonumber(self.qty:GetText()) or 0)
      if H.mode == "buy" then
        self.dur:Hide()
        local s = E().cfg()
        local mx = parseGold(self.price:GetText())
        if (not HS.priceSet or HS.priceFor ~= id) and low then
          mx = G.capMax(low, it and it.med); self.price:SetText(goldStr(mx)); HS.priceSet, HS.priceFor = true, id
        end
        self.l2:SetText("Prix max / unité (or)")
        HS.maxQty = (mx and B.availableUnder(id, mx)) or nil
        local av = (mx and B.availableUnder(id, mx))
        self.info:SetText(("Acheter %d  ·  total max %s"):format(q, mx and A().coins(q * mx) or "—"))
        self.info2:SetText((it and it.med and low and low > it.med) and W.col(C.orange, "Prix mini au-dessus de la médiane : tu peux monter le prix max à la main.") or (av and ("%d disponibles sous ce prix"):format(av) or ""))
        local st = B.state
        self.go:SetText(st and (st.stage == "await" and "Confirmer l'achat" or "Achat en cours...") or ("Acheter " .. q))
        if ahOk and B.available() and mx and q > 0 and (not st or st.stage == "await") then self.go:Enable() else self.go:Disable() end
        self.mode = "buy"
      else
        self.dur:Show()
        local have = sel.count or 0
        HS.maxQty = have
        if HS.qtyFor ~= id or HS.qtyHave ~= have then   -- autre objet ou sac modifié : quantité = tout le sac
          HS.qtyFor, HS.qtyHave = id, have
          self.qty:SetText(tostring(math.max(have, 1)))
        end
        local sp = ns.buy.scanPrice and ns.buy.scanPrice(id)
        local sug = it and it.sellAt or (low and math.max(low - 1, 1)) or sp or ((vend and vend > 0) and vend * 2 or nil)
        if (not HS.priceSet or HS.priceFor ~= id) and sug then self.price:SetText(goldStr(sug)); HS.priceSet, HS.priceFor = true, id end
        local up = parseGold(self.price:GetText())
        local fee = E().cfg().fee
        self.info:SetText(("Vendre %d sur %d en sac  ·  net %s"):format(math.min(q, have), have, up and A().coins(math.floor(up * (1 - fee)) * math.min(q, have)) or "—"))
        local dep = up and H.deposit(id, E().cfg().sellDuration, math.min(q, have))
        local t2 = {}
        if dep then t2[#t2 + 1] = "Dépôt : " .. A().coins(dep) end
        if vend and vend > 0 then
          t2[#t2 + 1] = "PNJ : " .. A().coins(vend) .. " l'unité"
          if up and up > 0 and math.floor(up * (1 - fee)) < vend then t2[#t2 + 1] = W.col(C.red, "net sous le prix PNJ : vends-le au marchand") end
        end
        self.info2:SetText(table.concat(t2, "  ·  "))
        self.go:SetText(("Mettre en vente %d"):format(math.min(q, have)))
        if ahOk and B.canSell() and up and up > 0 and q > 0 and have > 0 then self.go:Enable() else self.go:Disable() end
        self.mode = "sell"
      end
    end
    self.msg:SetText(B.lastMsg and W.col(B.lastOk and C.green or C.orange, B.lastMsg) or "")
  end
  return P
end

function G.hvGo()
  local P, B, H = G.hv, ns.buy, ns.hv
  local e = HS.entry; if not e then return end
  if P.mode == "own" then H.cancel(e.auctionID); return end
  local q = math.floor(tonumber(P.qty:GetText()) or 0)
  local up = parseGold(P.price:GetText()); if not up or q <= 0 then return end
  if P.mode == "buy" then B.buy(e.id, q, up, E().cfg().snipeOneClick)
  else B.sell(e.id, math.min(q, e.count or q), up, E().cfg().sellDuration) end
end

function G.hvBulk()
  local B, H, s = ns.buy, ns.hv, E().cfg()
  local entries, out = hvEntries(), {}
  for _, e in ipairs(entries) do
    if HS.checked[e.id] and not e.auctionID then
      local it = e.tracked
      if H.mode == "buy" then
        local p = e.p or (it and it.price)
        if p then
          local qty = (it and it.toBuy and it.toBuy > 0) and it.toBuy or s.bulkQty
          out[#out + 1] = { id = e.id, name = e.name, qty = qty, limit = G.capMax(p, it and it.med or G.medOf(e.id)) }
        end
      else
        local qty = e.count or 0
        if it and it.target and it.target > 0 then qty = math.min(qty, it.sellQty or 0) end
        if qty > 0 then out[#out + 1] = { id = e.id, name = e.name, qty = qty, limit = it and it.sellAt or nil, fixed = it and it.sellAt and true or nil, floor = it and it.floor or nil } end
      end
    end
  end
  if #out == 0 then print("|cffe4b84eGringotts|r Rien à traiter dans la sélection."); return end
  HS.checked = {}
  B.qStart(H.mode, out)
  G.refresh()
end

local stCol = { need = "lecture...", ready = "prêt", running = "en cours", done = "OK", skip = "ignoré" }
function G.refreshQueue()
  local P, B = G.hv, ns.buy
  if not (P and P.ready) then return end
  local q = B.q
  if not q then
    if P.qf:IsShown() then P.qf:Hide() end
    if ClearOverrideBindings and P.qf and not (InCombatLockdown and InCombatLockdown()) then pcall(ClearOverrideBindings, P.qf) end
    return
  end
  P.qf:Show()
  if SetOverrideBindingClick and not (InCombatLockdown and InCombatLockdown()) then pcall(SetOverrideBindingClick, P.qf, true, "SPACE", "GringottsQueueBtn") end
  local buy = q.mode == "buy"
  local done, tot = 0, #q.items
  for _, e in ipairs(q.items) do if e.state == "done" or e.state == "skip" then done = done + 1 end end
  P.qTitle:SetText(buy and "Achats groupés" or "Ventes groupées")
  P.qSub:SetText(("%d / %d traités"):format(done, tot))
  P.qHint:SetText(P.qHint:GetText())
  for i, r in ipairs(P.qRows) do
    local e = q.items[i]
    if e then
      r.n:SetText(e.name); r.q:SetText("x " .. (buy and e.qty or e.left))
      r.l:SetText(buy and ("max " .. A().coins(e.limit)) or (e.limit and coins(e.limit) or "au marché"))
      local col = e.state == "done" and C.green or (e.state == "skip" and C.orange or C.white)
      r.s:SetText(W.col(col, stCol[e.state] .. (e.msg and e.state ~= "need" and (" · " .. e.msg) or "")))
    else r.n:SetText(""); r.q:SetText(""); r.l:SetText(""); r.s:SetText("") end
  end
  local pend = B.qPending()
  if pend == 0 and not B.state then
    P.qNext:SetText("Terminé : fermer la file"); P.qNext:SetScript("OnClick", function() B.qStop() end)
  else
    P.qNext:SetText((buy and "Acheter le suivant" or "Vendre le suivant") .. "  (Espace)  ·  " .. pend .. " restant(s)")
    P.qNext:SetScript("OnClick", function() B.qStep() end)
  end
  P.qMsg:SetText(B.lastMsg and W.col(B.lastOk and C.green or C.orange, B.lastMsg) or "")
end
function G.onQueueUpdate() if G.hv and G.hv.ready then G.refreshQueue(); if G.current == "hv" then G.hv:Refresh() end end end

function G.hvRequery() HS.queried = nil end
function G.onHVUpdate() if G.current == "hv" and G.hv and G.hv.ready then HS.queried = HS.queried; G.hv:Refresh() end end

------------------------------------------------------------------------
-- Assemblage : sous-onglets
------------------------------------------------------------------------
local SUBS = { { "control", "Tour de contrôle" }, { "stock", "Stock & achats" }, { "finance", "Finances" }, { "sniper", "Sniper" }, { "hv", "Hôtel des ventes" }, { "ench", "Enchantements" }, { "de", "Désenchantement" } }
function G.build(parent)
  local root = CreateFrame("Frame", nil, parent); root:SetAllPoints()
  G.root = root
  G.buttons, G.panes = {}, {}
  local x = 0
  for _, s in ipairs(SUBS) do
    local b = W.button(root, s[2], 140, 24, function() G.select(s[1]) end)
    b:SetPoint("TOPLEFT", root, "TOPLEFT", x, 0); G.buttons[s[1]] = b; x = x + 144
  end
  G.scanBtn = W.button(root, "Scanner l'HV", 150, 24, function()
    if ns.buy.available() and C_AuctionHouse and C_AuctionHouse.ReplicateItems then ns.buy.scan()
    else print("|cffe4b84eGringotts|r Scan intégré indisponible : lance un scan Auctionator.") end
  end)
  G.scanBtn:SetPoint("TOPRIGHT", root, "TOPRIGHT", 0, 0)
  G.status = W.text(root, "GringottsTextSmall", "", 0, -4, 400, "RIGHT", "TOPRIGHT")
  G.status:SetPoint("TOPRIGHT", root, "TOPRIGHT", -158, -6)
  -- barre de progression du scan HV (sous le bandeau, visible seulement pendant un scan)
  do
    local bw = 400
    local bf = CreateFrame("Frame", nil, root); bf:SetSize(bw, 8); bf:SetPoint("TOPRIGHT", root, "TOPRIGHT", 0, -26); bf:Hide()
    ns.theme.panel(bf, "bg", "line")
    local fl = bf:CreateTexture(nil, "ARTWORK"); fl:SetPoint("TOPLEFT", bf, "TOPLEFT", 1, -1); fl:SetPoint("BOTTOMLEFT", bf, "BOTTOMLEFT", 1, 1)
    fl:SetColorTexture(ns.theme.c.info[1], ns.theme.c.info[2], ns.theme.c.info[3], 1)
    local tx = { SetText = function() end }
    G.scanBar = { frame = bf, fill = fl, txt = tx, w = bw - 2 }
    local acc = 0
    bf:SetScript("OnUpdate", function(_, dt) acc = acc + dt; if acc >= 0.5 then acc = 0; G.onScanProgress() end end)
  end
  local area = CreateFrame("Frame", nil, root)
  area:SetPoint("TOPLEFT", root, "TOPLEFT", 0, -34); area:SetPoint("BOTTOMRIGHT", root, "BOTTOMRIGHT", 0, 0)
  local function sub(name, builder)
    local p = CreateFrame("Frame", nil, area); p:SetAllPoints(); p:Hide()
    G.panes[name] = { frame = p, obj = builder(p) }
  end
  sub("control", G.buildControl); sub("stock", G.buildStock); sub("finance", G.buildFinance); sub("sniper", G.buildSniper); sub("hv", G.buildHV); sub("ench", G.buildEnchant); sub("de", G.buildDE)
  G.current = "control"
end

function G.refresh()
  if not G.root then return end
  G.reload()
  local cur = G.panes[G.current]
  if cur and cur.obj.Refresh then cur.obj:Refresh() end
  local i = ns.prices.info()
  G.status:SetText(i.loaded and ("Prix du " .. ns.prices.ageText()) or W.col(C.red, "Aucun fichier de prix"))
end

function G.select(name)
  if not G.panes or not G.panes[name] then return end
  G.current = name
  for k, p in pairs(G.panes) do if k == name then p.frame:Show() else p.frame:Hide() end end
  for k, b in pairs(G.buttons) do if k == name then b:Disable() else b:Enable() end end
  G.refresh()
end
