-- Gringotts : Bêtes (chasseur). Catalogue des familiers apprivoisables et des capacités à apprendre.
-- Données : PetsDB.lua (relevé Wowhead WoW Forever FR). Familier actif et familles déjà apprivoisées : lus en jeu.
local ADDON, ns = ...
local P = {}
ns.pets = P

local function db() return ns.api and ns.api.db() end
local function norm(s) return ns.norm and ns.norm(s or "") or (s or ""):lower() end

-- L'onglet n'existe que pour un chasseur
function P.isHunter()
  if not UnitClass then return false end
  local _, cls = UnitClass("player")
  return cls == "HUNTER"
end
function P.level() return (UnitLevel and UnitLevel("player")) or 1 end

-- État sauvegardé par personnage : { seen = {famille = true}, goals = {id = true} }
function P.st()
  local d = db(); if not d then return { seen = {}, goals = {} } end
  d.pets = d.pets or {}
  local me = (UnitName and UnitName("player")) or "?"
  d.pets[me] = d.pets[me] or {}
  local s = d.pets[me]
  s.seen = s.seen or {}; s.goals = s.goals or {}
  return s
end

local DB, byId, famSpec, famCount
local function init()
  if DB then return end
  DB = ns.petsDB or { fams = {}, pets = {} }
  byId, famSpec, famCount = {}, {}, {}
  for _, p in ipairs(DB.pets) do byId[p.id] = p; famCount[p.f] = (famCount[p.f] or 0) + 1 end
  for _, f in ipairs(DB.fams) do famSpec[f.n] = f.spec end
end
function P.famInfo(name) init(); for _, f in ipairs(DB.fams) do if f.n == name then return f end end end
function P.byId(id) init(); return byId[id] end
function P.all() init(); return DB.pets end
function P.fams()
  init()
  local out = {}
  for _, f in ipairs(DB.fams) do out[#out + 1] = { n = f.n, spec = f.spec ~= "" and f.spec or nil, count = famCount[f.n] or 0, seen = P.st().seen[f.n] and true or false,
      icon = f.icon, dmg = f.dmg or 0, armor = f.armor or 0, hp = f.hp or 0, diet = f.diet or {} } end
  table.sort(out, function(a, b) return a.n < b.n end)
  return out
end

function P.rarity(p) return ({ R = "Rare", E = "Élite", ER = "Élite rare" })[p.r or ""] or "" end
function P.levelText(p)
  if not p.lo then return "—" end
  return (p.lo == p.hi) and tostring(p.lo) or (p.lo .. "-" .. p.hi)
end
function P.canTame(p, lvl) return p.lo ~= nil and p.lo <= (lvl or P.level()) end

-- Liste filtrée et triée : filtre = all | level | rare | missing ; q = recherche (nom, famille, zone)
function P.list(filter, q, fam)
  init()
  local lvl, st, out = P.level(), P.st(), {}
  q = norm(q or ""); if q ~= "" then q = q:gsub("^%s+", ""):gsub("%s+$", "") end
  for _, p in ipairs(DB.pets) do
    local ok = (not fam) or p.f == fam
    if not ok then -- famille exclue
    elseif filter == "level" then ok = P.canTame(p, lvl)
    elseif filter == "rare" then ok = (p.r or "") ~= ""
    elseif filter == "missing" then ok = not st.seen[p.f] end
    if ok and q ~= "" then
      ok = norm(p.n):find(q, 1, true) or norm(p.f):find(q, 1, true) or norm(p.z or ""):find(q, 1, true)
    end
    if ok then out[#out + 1] = p end
  end
  table.sort(out, function(a, b)
    local la, lb = a.lo or 999, b.lo or 999
    if la ~= lb then return la < lb end
    if a.n ~= b.n then return a.n < b.n end
    return a.id < b.id
  end)
  return out
end

-- Meilleur rang de chaque capacité pour une famille : { [nom] = { rank, pet, tp } }.
-- maxLvl : seules les bêtes apprivoisables à ce niveau (à égalité de rang : la plus haute, sinon la plus basse).
function P.famBest(fam, maxLvl)
  init()
  local d = {}
  for _, p in ipairs(DB.pets) do
    if p.f == fam and p.a and (not maxLvl or P.canTame(p, maxLvl)) then
      for _, a in ipairs(p.a) do
        local rank = a[2]
        if rank then
          local cur = d[a[1]]
          local better = not cur or rank > cur.rank
          if cur and rank == cur.rank then
            local lo, clo = p.lo or 999, cur.pet.lo or 999
            better = maxLvl and (lo > clo) or (not maxLvl and lo < clo)
          end
          if better then d[a[1]] = { rank = rank, pet = p, tp = a[3] } end
        end
      end
    end
  end
  return d
end
-- Noms de capacités d'une famille, triés par rang max décroissant puis nom
function P.famAbilities(fam)
  local best, names = P.famBest(fam), {}
  for n in pairs(best) do names[#names + 1] = n end
  local spec = famSpec[fam]
  table.sort(names, function(a, b)
    if (a == spec) ~= (b == spec) then return a == spec end
    if best[a].rank ~= best[b].rank then return best[a].rank > best[b].rank end
    return a < b
  end)
  return names, best
end
-- Bêtes d'une famille qui enseignent quelque chose et que tu peux apprivoiser maintenant (les plus hautes d'abord)
function P.teachers(fam, n)
  init()
  local lvl, out = P.level(), {}
  for _, p in ipairs(DB.pets) do
    if p.f == fam and p.L and P.canTame(p, lvl) then out[#out + 1] = p end
  end
  table.sort(out, function(a, b) if a.lo ~= b.lo then return a.lo > b.lo end return a.n < b.n end)
  while #out > (n or 4) do out[#out] = nil end
  return out
end

function P.abilityText(p)
  local t = {}
  for _, a in ipairs(p.a or {}) do
    if a[2] then t[#t + 1] = a[1] .. " r." .. a[2] .. (a[3] and (" (" .. a[3] .. " TP)") or "")
    elseif a[4] then t[#t + 1] = a[1] .. " (palier " .. a[4] .. ")" end
  end
  return table.concat(t, " · ")
end

-- Familier actif lu en jeu
function P.active()
  if not (UnitExists and UnitExists("pet")) then return nil end
  local fam = UnitCreatureFamily and UnitCreatureFamily("pet")
  local happy = GetPetHappiness and select(1, GetPetHappiness())
  return { name = UnitName("pet"), fam = fam, lvl = UnitLevel("pet"), happy = happy }
end
-- Compétences connues du familier actif : { [nom] = { name, rank (nil si sans rang) } } (livre de sorts du familier)
local function petBookName(i)
  if C_SpellBook and C_SpellBook.GetSpellBookItemName and Enum and Enum.SpellBookSpellBank then
    local ok, a, b = pcall(C_SpellBook.GetSpellBookItemName, i, Enum.SpellBookSpellBank.Pet)
    if ok and a then return a, b end
  end
  if GetSpellBookItemName then
    local ok, a, b = pcall(GetSpellBookItemName, i, "pet")
    if ok and a then return a, b end
  end
  if GetSpellName then
    local ok, a, b = pcall(GetSpellName, i, "pet")
    if ok and a then return a, b end
  end
end
function P.petKnown()
  local out = {}
  local n = 0
  if HasPetSpells then local ok, v = pcall(HasPetSpells); if ok and tonumber(v) then n = tonumber(v) end end
  for i = 1, n do
    local name, sub = petBookName(i)
    if name then
      local rank = sub and tonumber(tostring(sub):match("(%d+)")) or nil
      local cur = out[name]
      if not cur or (rank or 0) > (cur.rank or 0) then out[name] = { name = name, rank = rank } end
    end
  end
  return out
end

-- Statistiques du familier actif (chaque valeur est nil si l'API ne la fournit pas)
function P.petStats()
  local function try(f, ...) if not f then return nil end local ok, v = pcall(f, ...); if ok then return v end end
  local s = { stats = {} }
  for i = 1, 5 do local ok, _, eff = pcall(UnitStat or function() end, "pet", i); s.stats[i] = ok and eff or nil end
  s.hp = try(UnitHealthMax, "pet")
  s.ap = try(UnitAttackPower, "pet")
  s.armor = try(function() local _, eff = UnitArmor("pet"); return eff end)
  s.mana = try(UnitPowerMax, "pet")
  if GetPetTrainingPoints then
    local ok, total, spent = pcall(GetPetTrainingPoints)
    if ok and total then s.tpTotal, s.tpSpent = total, spent end
  end
  if GetPetExperience then
    local ok, cur, mx = pcall(GetPetExperience)
    if ok and cur and mx then s.xp, s.xpMax = cur, mx end
  end
  return s
end

-- Évolutions possibles du familier actif : rang supérieur d'une capacité qu'il a, ou capacité de la famille qu'il n'a pas.
-- Seules les bêtes apprivoisables à ton niveau sont proposées. Renvoie { list = {...}, known = {...}, fam }
function P.upgrades()
  local a = P.active()
  if not (a and a.fam and a.fam ~= "") then return nil end
  init()
  local known = P.petKnown()
  local names = P.famAbilities(a.fam)
  local now = P.famBest(a.fam, P.level())
  local list = {}
  for _, n in ipairs(names) do
    local k = known[n]
    local cur = k and (k.rank or 1) or 0
    local nx = now[n]
    if nx and nx.rank > cur then
      list[#list + 1] = { name = n, cur = cur, rank = nx.rank, pet = nx.pet, tp = nx.tp, new = (k == nil) }
    end
  end
  -- rangs supérieurs d'abord, nouvelles capacités ensuite
  table.sort(list, function(x, y) if x.new ~= y.new then return not x.new end if x.rank ~= y.rank then return x.rank > y.rank end return x.name < y.name end)
  return { list = list, known = known, fam = a.fam, spec = famSpec[a.fam] }
end

local HAPPY = { "Mécontent", "Content", "Heureux" }
function P.happyText(h) return HAPPY[h or 0] end
local function seeActive()
  if not P.isHunter() then return end
  local a = P.active()
  if a and a.fam and a.fam ~= "" then P.st().seen[a.fam] = true end
end
P.seeActive = seeActive

-- Zone → carte (flèche)
function P.aim(p, idx)
  if not (p and p.m and p.p and #p.p > 0) then return false end
  idx = ((idx or 1) - 1) % #p.p + 1
  local pt = p.p[idx]
  if not (ns.arrowGoto and ns.arrowGoto({ zone = p.m, x = pt[1], y = pt[2], name = p.n, zoneName = p.z })) then return false end
  return true, idx
end

function P.toggleGoal(id) local g = P.st().goals; g[id] = (not g[id]) or nil; return g[id] and true or false end
function P.goals()
  local out = {}
  for id in pairs(P.st().goals) do local p = P.byId(id); if p then out[#out + 1] = p end end
  table.sort(out, function(a, b) return (a.lo or 999) < (b.lo or 999) end)
  return out
end

local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_ENTERING_WORLD"); ev:RegisterEvent("UNIT_PET")
ev:SetScript("OnEvent", function(_, e, unit)
  if e == "UNIT_PET" and unit ~= "player" then return end
  seeActive()
  if ns.petsUI and ns.petsUI.refresh and ns.petsUI.visible and ns.petsUI.visible() then ns.petsUI.refresh() end
end)

------------------------------------------------------------------------
-- Infobulle d'une bête : seulement pour un chasseur, et seulement si la bête est domptable
-- (créature de type Bête, vivante, avec une famille de familier, non contrôlée par un joueur).
------------------------------------------------------------------------
local function isBeast(unit)
  local t = UnitCreatureType and UnitCreatureType(unit)
  if not t then return false end
  return t == "Beast" or t == "Bête" or norm(t) == "bete"
end
function P.tipOn() return not (GringottsDB and GringottsDB.petsTipOff) end
function P.setTip(on) GringottsDB = GringottsDB or {}; GringottsDB.petsTipOff = (not on) and true or nil end
function P.tameable(unit)
  if not (P.isHunter() and unit and UnitExists and UnitExists(unit)) then return false end
  if UnitIsPlayer and UnitIsPlayer(unit) then return false end
  if UnitPlayerControlled and UnitPlayerControlled(unit) then return false end
  if UnitIsDead and UnitIsDead(unit) then return false end
  if not isBeast(unit) then return false end
  local fam = UnitCreatureFamily and UnitCreatureFamily(unit)
  return fam ~= nil and fam ~= ""
end

local function findByName(name, fam)
  init()
  local n = norm(name or "")
  for _, p in ipairs(DB.pets) do if p.f == fam and norm(p.n) == n then return p end end
end

-- Modificateurs de famille (Petopia Forever / WCLBox, nov. 2026) : dégâts, armure, santé en % face à une bête sans famille.
-- Vitesse d'attaque : fourchette observée sur les bêtes de la famille (Petopia, page « Pet Attack Speeds »).
local FAMSTAT = {
  ["Félin"] = { 10, 0, -2, 1.0, 2.0 },          ["Raptor"] = { 10, 3, -5, 2.0, 2.0 },        ["Araignée"] = { 7, 0, 0, 1.4, 2.7 },
  ["Chauve-souris"] = { 7, 0, 0, 1.0, 2.0 },    ["Oiseau de proie"] = { 7, 0, 0, 2.0, 2.0 }, ["Serpent des vents"] = { 7, 0, 0, 2.0, 2.0 },
  ["Gorille"] = { 2, 0, 4, 2.0, 2.0 },          ["Loup"] = { 0, 5, 0, 1.2, 2.0 },            ["Crocilisque"] = { 0, 10, -5, 2.0, 2.0 },
  ["Charognard"] = { 0, 5, 0, 1.2, 2.0 },       ["Haut-trotteur"] = { 0, 0, 5, 1.3, 2.0 },   ["Hyène"] = { 0, 5, 0, 1.3, 2.0 },
  ["Renard"] = { 0, 5, 0, 1.5, 2.0 },           ["Crabe"] = { -5, 13, -4, 2.0, 2.0 },        ["Scorpide"] = { -6, 10, 0, 1.6, 2.0 },
  ["Ours"] = { -9, 5, 8, 1.6, 2.5 },            ["Sanglier"] = { -10, 9, 4, 2.0, 2.0 },      ["Tortue"] = { -10, 13, 0, 2.0, 2.0 },
}
P.famStat = FAMSTAT
local function pc(v) return (v > 0 and "+" or (v < 0 and "−" or "")) .. math.abs(v) .. " %" end
local function fs1(v) return (("%.1f"):format(v):gsub("%.", ",")) end

-- Lignes ajoutées à l'infobulle (texte déjà coloré), ou nil si rien à ajouter
function P.tipLines(unit)
  if not P.tipOn() then return nil end
  if not P.tameable(unit) then return nil end
  local fam = UnitCreatureFamily(unit)
  local lvl, mine = (UnitLevel and UnitLevel(unit)) or 0, P.level()
  local L = {}
  local c = ns.W and ns.W.C
  local function col(k, s) return (ns.W and c) and ns.W.col(c[k], s) or s end
  if lvl <= 0 then L[#L + 1] = col("orange", "Domptable : niveau inconnu (??)")
  elseif lvl <= mine then L[#L + 1] = col("green", ("Domptable : oui (niveau %d <= %d)"):format(lvl, mine))
  else L[#L + 1] = col("orange", ("Domptable à partir du niveau %d (encore %d)"):format(lvl, lvl - mine)) end
  init()
  local spec = famSpec[fam]
  local seen = P.st().seen[fam]
  L[#L + 1] = ("Famille %s%s%s"):format(fam, (spec and spec ~= "") and (" · " .. spec) or "", seen and "" or col("gold", " · nouvelle famille"))
  local fsx = FAMSTAT[fam]
  if fsx then
    L[#L + 1] = ("Armure %s · Endurance %s · Dégâts %s"):format(pc(fsx[2]), pc(fsx[3]), pc(fsx[1]))
    L[#L + 1] = col("grey", fsx[4] == fsx[5] and ("Vitesse d'attaque : " .. fs1(fsx[4]) .. " s") or ("Vitesse d'attaque : " .. fs1(fsx[4]) .. " à " .. fs1(fsx[5]) .. " s selon la bête"))
  end
  local p = findByName(UnitName(unit), fam)
  if p then
    if (p.r or "") ~= "" then L[#L + 1] = col("gold", P.rarity(p)) end
    -- vitesse d'attaque exacte quand le catalogue la connaît
    if p.sp then L[#L + 1] = "Vitesse d'attaque " .. fs1(p.sp) .. " s" end
    local t = P.abilityText(p)
    L[#L + 1] = (t ~= "") and ("Enseigne : " .. t) or col("grey", "N'enseigne aucune capacité")
  else
    local best, names = P.famBest(fam, mine), {}
    for n, b in pairs(best) do names[#names + 1] = { n, b.rank } end
    table.sort(names, function(a, b) if a[2] ~= b[2] then return a[2] > b[2] end return a[1] < b[1] end)
    local t = {}
    for i = 1, math.min(3, #names) do t[#t + 1] = names[i][1] .. " r." .. names[i][2] end
    if #t > 0 then L[#L + 1] = col("grey", "Meilleurs rangs à ton niveau (famille) : " .. table.concat(t, ", ")) end
  end
  return L
end

local function addUnitTip(tt)
  if not (tt and tt.GetUnit and tt.AddLine) then return end
  if tt.IsForbidden and tt:IsForbidden() then return end   -- infobulle réservée à l'IU de Blizzard : on n'y touche pas
  local _, unit = tt:GetUnit()
  if not unit then return end
  local L = P.tipLines(unit)
  if not L then return end
  tt:AddLine(" ")
  tt:AddLine(((ns.W and ns.W.col(ns.W.C.gold, "Gringotts · Bête")) or "Gringotts · Bête"))
  for _, l in ipairs(L) do tt:AddLine(l, 1, 1, 1, true) end
end
P.addUnitTip = addUnitTip

if TooltipDataProcessor and Enum and Enum.TooltipDataType and Enum.TooltipDataType.Unit then
  TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Unit, function(tt) pcall(addUnitTip, tt) end)
elseif GameTooltip and GameTooltip.HookScript then
  GameTooltip:HookScript("OnTooltipSetUnit", function(tt) pcall(addUnitTip, tt); if tt.Show and not (tt.IsForbidden and tt:IsForbidden()) then tt:Show() end end)
end

-- gardes : une erreur est journalisée (/gt erreurs) au lieu d'ouvrir le popup de Blizzard
if ns.safe then ev:SetScript("OnEvent", ns.safe(ev:GetScript("OnEvent"), "bêtes")) end
