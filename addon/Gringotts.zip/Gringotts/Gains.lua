-- Gringotts : gains. Sessions de farm (or/h), marge réelle par objet (coût d'acquisition vs vente nette), liquidité (objets « lents »).
-- Aucune interface ici (voir UIGains.lua). Données : db.gains.sessions, db.gains.cur, et le journal db.trades du Core.
local ADDON, ns = ...
local Gn = {}
ns.gains = Gn

local KEEP = 60                       -- sessions conservées
local MIN_SECS = 60                   -- en dessous, l'or/h n'a pas de sens

local function db() return ns.api and ns.api.db and ns.api.db() or nil end
local function norm(s) return ns.norm(s) end
local function fee() local ok, c = pcall(ns.engine.cfg); return ok and c and c.fee or 0.05 end

local function store()
  local d = db(); if not d then return nil end
  d.gains = d.gains or {}
  d.gains.sessions = d.gains.sessions or {}
  return d.gains
end

------------------------------------------------------------------------
-- Valeur d'un objet : meilleur de (HV moins commission) et (marchand PNJ)
------------------------------------------------------------------------
function Gn.unitValue(name, id)
  local hv, vend = nil, nil
  if ns.prices and name then
    local ok, p = pcall(ns.prices.price, name, id)
    if ok and type(p) == "number" and p > 0 then hv = math.floor(p * (1 - fee())) end
  end
  if id and ns.sellPriceOf then
    local ok, v = pcall(ns.sellPriceOf, id)
    if ok and type(v) == "number" and v > 0 then vend = v end
  end
  if hv and (not vend or hv >= vend) then return hv, "hv" end
  if vend then return vend, "pnj" end
  return 0, nil
end

------------------------------------------------------------------------
-- Sessions de farm
------------------------------------------------------------------------
local function zoneName()
  local z = GetSubZoneText and GetSubZoneText() or ""
  local r = GetZoneText and GetZoneText() or ""
  if z ~= "" and r ~= "" and z ~= r then return r .. " · " .. z end
  return r ~= "" and r or (z ~= "" and z or "Zone inconnue")
end

function Gn.current() local g = store(); return g and g.cur or nil end

function Gn.start(label)
  local g = store(); if not g or g.cur then return false end
  g.cur = { t0 = time(), zone = (label and label ~= "") and label or zoneName(), items = {}, money = 0, val = 0 }
  return true
end

function Gn.elapsed(s) return math.max(0, (s.t1 or time()) - s.t0) end
function Gn.total(s) return (s.val or 0) + (s.money or 0) end
-- or/h en cuivre, nil si la session est trop courte
function Gn.rate(s)
  local sec = Gn.elapsed(s)
  if sec < MIN_SECS then return nil end
  return math.floor(Gn.total(s) / (sec / 3600))
end

function Gn.stop()
  local g = store(); if not g or not g.cur then return nil end
  local s = g.cur
  s.t1 = time()
  g.cur = nil
  s.rate = Gn.rate(s)
  table.insert(g.sessions, 1, s)
  while #g.sessions > KEEP do table.remove(g.sessions) end
  return s
end

function Gn.cancel() local g = store(); if g then g.cur = nil end end

-- Session terminée ailleurs (ex. pêche) : entre dans l'historique comme une session de farm.
-- { t0, t1 (heure unix), zone, items = { {n, q} }, fallback (valeur totale connue) }
function Gn.addExternal(x)
  local g = store(); if not g or not x or not x.t0 then return nil end
  local s = { t0 = x.t0, t1 = x.t1 or time(), zone = x.zone or "Zone inconnue", items = {}, money = 0, val = 0, src = x.src }
  for _, it in ipairs(x.items or {}) do
    local q = it.q or 0
    if it.n and q > 0 then
      local k = norm(it.n)
      local u = Gn.unitValue(it.n, it.id)
      s.items[k] = { n = it.n, id = it.id, q = q, v = u }
      s.val = s.val + u * q
    end
  end
  if s.val <= 0 and (x.fallback or 0) > 0 then s.val = x.fallback end
  if s.val <= 0 and next(s.items) == nil then return nil end
  s.rate = Gn.rate(s)
  table.insert(g.sessions, 1, s)
  while #g.sessions > KEEP do table.remove(g.sessions) end
  return s
end

function Gn.addLoot(name, id, qty)
  local g = store(); local s = g and g.cur
  if not s or not name then return end
  qty = (qty and qty > 0) and qty or 1
  local k = norm(name)
  local u = Gn.unitValue(name, id)
  local it = s.items[k]
  if not it then it = { n = name, id = id, q = 0, v = 0 }; s.items[k] = it end
  it.q = it.q + qty; it.v = u; it.id = it.id or id
  s.val = (s.val or 0) + u * qty
end

function Gn.addMoney(c)
  local g = store(); local s = g and g.cur
  if s and c and c > 0 then s.money = (s.money or 0) + c end
end

-- objets d'une session triés par valeur
function Gn.lootList(s)
  local out = {}
  for k, it in pairs(s and s.items or {}) do out[#out + 1] = { k = k, name = it.n, id = it.id, q = it.q, unit = it.v, value = it.q * it.v } end
  table.sort(out, function(a, b) if a.value ~= b.value then return a.value > b.value end return a.name < b.name end)
  return out
end

-- Rendement moyen par lieu : { zone, n, secs, total, gph, last }
function Gn.spots()
  local g = store(); if not g then return {} end
  local by = {}
  for _, s in ipairs(g.sessions) do
    if Gn.elapsed(s) >= MIN_SECS then
      local z = by[s.zone]
      if not z then z = { zone = s.zone, n = 0, secs = 0, total = 0, last = 0 }; by[s.zone] = z end
      z.n = z.n + 1; z.secs = z.secs + Gn.elapsed(s); z.total = z.total + Gn.total(s); z.last = math.max(z.last, s.t0)
    end
  end
  local out = {}
  for _, z in pairs(by) do z.gph = math.floor(z.total / (z.secs / 3600)); out[#out + 1] = z end
  table.sort(out, function(a, b) if a.gph ~= b.gph then return a.gph > b.gph end return a.zone < b.zone end)
  return out
end

-- Or/h sur les N derniers jours (toutes sessions terminées)
function Gn.rate7(days)
  local g = store(); if not g then return nil end
  local lim, secs, tot = time() - (days or 7) * 86400, 0, 0
  for _, s in ipairs(g.sessions) do
    if s.t0 >= lim and Gn.elapsed(s) >= MIN_SECS then secs = secs + Gn.elapsed(s); tot = tot + Gn.total(s) end
  end
  if secs < MIN_SECS then return nil, 0 end
  return math.floor(tot / (secs / 3600)), secs
end

------------------------------------------------------------------------
-- Capture du butin (messages du chat) : actif seulement pendant une session
------------------------------------------------------------------------
local function pat(fmt, caps)
  if type(fmt) ~= "string" then return nil end
  local p = fmt:gsub("[%(%)%.%+%-%*%?%[%]%^%$]", "%%%0")
  p = p:gsub("%%s", "(.+)"):gsub("%%d", "(%%d+)")
  return "^" .. p .. "$"
end
local LOOT = {
  { pat(LOOT_ITEM_SELF_MULTIPLE), true }, { pat(LOOT_ITEM_PUSHED_SELF_MULTIPLE), true },
  { pat(LOOT_ITEM_SELF), false }, { pat(LOOT_ITEM_PUSHED_SELF), false },
}
local function coinPat(fmt, fallback)
  local f = type(fmt) == "string" and fmt or fallback
  return (f:gsub("[%(%)%.%+%-%*%?%[%]%^%$]", "%%%0"):gsub("%%d", "(%%d+)"))
end
local PG, PS, PC = coinPat(GOLD_AMOUNT, "%d Or"), coinPat(SILVER_AMOUNT, "%d Argent"), coinPat(COPPER_AMOUNT, "%d Cuivre")

function Gn.parseLoot(msg)
  if type(msg) ~= "string" then return nil end
  for _, e in ipairs(LOOT) do
    if e[1] then
      local a, b = msg:match(e[1])
      if a then
        local link, qty = a, 1
        if e[2] then link, qty = a, tonumber(b) or 1 end
        local name = link:match("%[(.-)%]")
        local id = tonumber(link:match("item:(%d+)"))
        if name then return name, id, qty end
      end
    end
  end
end

function Gn.parseMoney(msg)
  if type(msg) ~= "string" then return nil end
  local g, s, c = msg:match(PG), msg:match(PS), msg:match(PC)
  if not (g or s or c) then return nil end
  return (tonumber(g) or 0) * 10000 + (tonumber(s) or 0) * 100 + (tonumber(c) or 0)
end

function Gn.onEvent(event, msg, ...)
  if not Gn.current() then return end
  if event == "CHAT_MSG_LOOT" then
    local name, id, qty = Gn.parseLoot(msg)
    if name then Gn.addLoot(name, id, qty); if ns.gringUI and ns.gringUI.onGains then ns.gringUI.onGains() end end
  elseif event == "CHAT_MSG_MONEY" then
    local c = Gn.parseMoney(msg)
    if c then Gn.addMoney(c) end
  end
end

------------------------------------------------------------------------
-- Journal de profit : marge réelle par objet (30 j)
-- Coût d'acquisition : achats HV (moyenne pondérée) ; sinon coût de craft ; sinon farmé (coût 0).
------------------------------------------------------------------------
local function craftUnitCost(k)
  local c = ns.crafts and ns.crafts.cache
  if not c then return nil end
  for _, e in ipairs(c) do
    if e.out and norm(e.out) == k and e.cost and e.cost > 0 and not e.unpriced then return math.floor(e.cost / math.max(e.q or 1, 1)) end
  end
end

function Gn.margins(days)
  local d = db(); if not d then return {}, { rev = 0, cost = 0, margin = 0, n = 0 } end
  local lim, f = time() - (days or 30) * 86400, fee()
  local buy, sold = {}, {}
  for _, tr in ipairs(d.trades or {}) do
    local k = norm(tr.n)
    if tr.k == "A" and tr.q and tr.q > 0 then
      local b = buy[k] or { q = 0, c = 0 }; b.q = b.q + tr.q; b.c = b.c + (tr.c or 0); buy[k] = b
    elseif tr.k == "V" and tr.t >= lim then
      local s = sold[k] or { name = tr.n, q = 0, gross = 0 }
      s.q = s.q + (tr.q or 1); s.gross = s.gross + (tr.c or 0); sold[k] = s
    end
  end
  local out, T = {}, { rev = 0, cost = 0, margin = 0, n = 0 }
  for k, s in pairs(sold) do
    local rev = math.floor(s.gross * (1 - f))
    local unit, src
    if buy[k] and buy[k].q > 0 then unit, src = math.floor(buy[k].c / buy[k].q), "achat"
    else
      local cu = craftUnitCost(k)
      if cu then unit, src = cu, "craft" else unit, src = 0, "farm" end
    end
    local cost = unit * s.q
    local m = rev - cost
    out[#out + 1] = { k = k, name = s.name, q = s.q, rev = rev, cost = cost, margin = m, pct = cost > 0 and m / cost or nil, src = src }
    T.rev = T.rev + rev; T.cost = T.cost + cost; T.margin = T.margin + m; T.n = T.n + 1
  end
  table.sort(out, function(a, b) if a.margin ~= b.margin then return a.margin > b.margin end return a.name < b.name end)
  return out, T
end

------------------------------------------------------------------------
-- Liquidité : « lent » si l'objet se vend mal d'après tes annonces (30 j), ou si le fichier de prix donne un volume faible (champ v)
------------------------------------------------------------------------
function Gn.liq(k)
  local d = db()
  local lim = time() - 30 * 86400
  local sold, listed, exp = 0, 0, 0
  for _, tr in ipairs(d and d.trades or {}) do
    if tr.t >= lim and norm(tr.n) == k then
      if tr.k == "V" then sold = sold + (tr.q or 1)
      elseif tr.k == "L" then listed = listed + (tr.q or 1)
      elseif tr.k == "E" then exp = exp + (tr.q or 1) end
    end
  end
  local state, why
  if listed >= 4 then
    local st = sold / listed
    if st < 0.35 then state, why = "slow", ("%d vendus / %d mis en vente (%d expirés)"):format(sold, listed, exp)
    else state = "ok" end
  end
  if not state and GringottsPrices and GringottsPrices.items then
    local r = GringottsPrices.items[k]
    if r and type(r.v) == "number" then
      if r.v < 2 then state, why = "slow", ("volume moyen %.1f / jour"):format(r.v) else state = "ok" end
    end
  end
  return state, why, sold, listed, exp
end

function Gn.isSlow(k) return (Gn.liq(k)) == "slow" end

local ev = CreateFrame("Frame")
for _, e in ipairs({ "CHAT_MSG_LOOT", "CHAT_MSG_MONEY" }) do pcall(ev.RegisterEvent, ev, e) end
ev:SetScript("OnEvent", function(_, e, msg) pcall(Gn.onEvent, e, msg) end)
